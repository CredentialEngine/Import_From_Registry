USE [credFinder]
GO
--use sandbox_credFinder
--go
--USE staging_credFinder
--GO


--use snhu_credFinder
--go


/****** Object:  StoredProcedure [dbo].[Pathway.ElasticSearch]    Script Date: 4/20/2018 11:40:06 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
USE [credFinder]
GO

SELECT TOP (1000) [Id]
      ,[RowId]
      ,[EntityStateId]
      ,[Name]
      ,[Description]
      ,[SubjectWebpage]
      ,[CTID]
      ,[OwningAgentUid]
      ,[CredentialRegistryId]
      ,[StartDate]
      ,[EndDate]
      ,[Created]
      ,[LastUpdated]
      ,[CodedNotation]
      ,[IdentifierJson]
      ,[PathwayJson]
      ,[PathwayFromJson]
      ,[PathwayForJson]
  FROM [credFinder].[dbo].[Pathway]



--=====================================================

DECLARE @RC int,@SortOrder varchar(100),@Filter varchar(5000)
DECLARE @StartPageIndex int, @PageSize int, @TotalRows int
--

set @SortOrder = ''
set @SortOrder = 'base.Name'

set @Filter = ' ( base.EntityStateId = 3 ) and [ExistsInRegistry] = 1 '


-- blind search 
set @Filter = ''
set @StartPageIndex = 1
set @PageSize = 55
--set statistics time on       
EXECUTE @RC = [Pathway.ElasticSearch]
     @Filter,@SortOrder  ,@StartPageIndex  ,@PageSize,  @TotalRows OUTPUT

select 'total rows = ' + convert(varchar,@TotalRows)

--set statistics time off       


*/


/* =============================================
Description:      Pathway search
Options:

  @StartPageIndex - starting page number. If interface is at 20 when next
page is requested, this would be set to 21?
  @PageSize - number of records on a page
  @TotalRows OUTPUT - total available rows. Used by interface to build a
custom pager
  ------------------------------------------------------
Modifications
20-01-14 mparsons - new

*/

Alter  PROCEDURE [dbo].[Pathway.ElasticSearch] 
		@Filter           varchar(5000)
		,@SortOrder       varchar(100)
		,@StartPageIndex  int
		,@PageSize        int
		,@TotalRows       int OUTPUT

As

SET NOCOUNT ON;
-- paging
DECLARE
      @first_id               int
      ,@startRow        int
	  ,@lastRow int
      ,@debugLevel      int
      ,@SQL             varchar(5000)
      ,@OrderBy         varchar(100)
	  ,@HasSitePrivileges bit

-- =================================

--set @CurrentUserId = 24
Set @debugLevel = 4
set @HasSitePrivileges= 0

if @SortOrder = 'relevance' set @SortOrder = 'base.Name '
else if @SortOrder = 'alpha' set @SortOrder = 'base.Name '
else if @SortOrder = 'newest' set @SortOrder = 'base.lastUpdated Desc '
else set @SortOrder = 'base.Name '

if len(@SortOrder) > 0 
      set @OrderBy = ' Order by ' + @SortOrder
else
      set @OrderBy = ' Order by base.Name '

--===================================================
-- Calculate the range
--===================================================
if @PageSize < 1				set @PageSize = 1000
IF @StartPageIndex < 1			SET @StartPageIndex = 1
SET @StartPageIndex =  ((@StartPageIndex - 1)  * @PageSize) + 1
SET @lastRow =  (@StartPageIndex + @PageSize) - 1
PRINT '@StartPageIndex = ' + convert(varchar,@StartPageIndex) +  ' @lastRow = ' + convert(varchar,@lastRow)

-- =================================
CREATE TABLE #tempWorkTable(
	RowNumber         int PRIMARY KEY  NOT NULL,
	Id int,
	Name             varchar(500),
	LastUpdated			datetime,
)
  CREATE TABLE #tempQueryTotalTable(
      TotalRows int
)
-- =================================

  if len(@Filter) > 0 begin
     if charindex( 'where', @Filter ) = 0 OR charindex( 'where',  @Filter ) > 10
        set @Filter =     ' where ' + @Filter
     end

  print '@Filter len: '  +  convert(varchar,len(@Filter))
  -- ================================= 

        
  --if charindex( 'order by', lower(@Filter) ) = 0
  --  set @SQL = @SQL + ' ' + @OrderBy

  --print '@SQL len: '  +  convert(varchar,len(@SQL))
  --print @SQL
set @SQL = '   SELECT count(*) as TotalRows  FROM [dbo].PathwaySummary base  '  + @Filter 
INSERT INTO #tempQueryTotalTable (TotalRows)
exec (@SQL)
--select * from #tempQueryTotalTable
select top 1  @TotalRows= TotalRows from #tempQueryTotalTable
-- ================================= 
  set @SQL = ' 
  SELECT        
		DerivedTable.RowNumber, 
		base.Id
		,base.[Name]
		,base.[lastUpdated]
From 
   (
SELECT 
         ROW_NUMBER() OVER(' + @OrderBy + ') as RowNumber,
          base.Id, base.Name, base.lastUpdated
		from [PathwaySummary] base  ' 
        + @Filter + ' 
   ) as DerivedTable
       Inner join [dbo].[PathwaySummary] base on DerivedTable.Id = base.Id
WHERE RowNumber BETWEEN ' + convert(varchar,@StartPageIndex) + ' AND ' + convert(varchar,@lastRow) + ' '  

  print '@SQL len: '  +  convert(varchar,len(@SQL))
  print @SQL
  INSERT INTO #tempWorkTable (RowNumber, Id, Name, LastUpdated)
  exec (@SQL)

--====
  --set @SQL = 'SELECT  base.Id, base.Name from [PathwaySummary] base   '
  --      + @Filter
  --INSERT INTO #tempWorkTable (Id, Name)
  --exec (@SQL)
  ----print 'rows: ' + convert(varchar, @@ROWCOUNT)
  --SELECT @TotalRows = @@ROWCOUNT
-- =================================

--print 'added to temp table: ' + convert(varchar,@TotalRows)
--if @debugLevel > 7 begin
--  select * from #tempWorkTable
--  end

-- Calculate the range
--===================================================
--PRINT '@StartPageIndex = ' + convert(varchar,@StartPageIndex)

--SET ROWCOUNT @StartPageIndex
----SELECT @first_id = RowNumber FROM #tempWorkTable   ORDER BY RowNumber
--SELECT @first_id = @StartPageIndex
--PRINT '@first_id = ' + convert(varchar,@first_id)

--if @first_id = 1 set @first_id = 0
----set max to return
--SET ROWCOUNT @PageSize

-- ================================= 
SELECT        
	RowNumber, 
	base.[Id]
	,base.[RowId]
	,base.[EntityStateId]
	,base.[Name]
	,base.[Description]
	,base.[SubjectWebpage]
	,base.[CTID]
	,base.[OwningAgentUid]
	--need to add owning org
	,isnull(c.ctid,'')  as OrganizationCTID
	,c.Id as OrganizationId
	,c.Name as OrganizationName
	--???????????????
	,base.[HasProgressionModel]
	,base.[CredentialRegistryId]
	,base.Properties
	--,e.LastUpdated As EntityLastUpdated
	,ec.CacheDate As EntityLastUpdated
	,ec.ResourceDetail
	,base.[Created]
	,base.[LastUpdated]
	--,base.LifeCycleStatusType
	--,base.LifeCycleStatusTypeId
	--TODO
	--add industries (10), occupations (11), subjects (34), keywords (35)
	-- use of Json properties?

	 -- don't need to use [Entity_Subjects] which is a union of direct and indirect subjects
	, (SELECT CategoryId, a.[TextValue] 
		FROM [dbo].[Entity.Reference] a 
		inner join Entity b on a.EntityId = b.Id
		--inner join [Codes.EntityTypes] c on b.EntityTypeId = c.id 
		where b.EntityTypeId = 8 AND [CategoryId] in ( 34 , 35)
		AND b.EntityUid = base.RowId 
		FOR XML RAW, ROOT('TextValues')) TextValues

	--, (SELECT a.[TextValue], 'Direct'  As Source, b.EntityTypeId, b.EntityBaseId as ReferenceBaseId 
	--	FROM [dbo].[Entity.Reference] a 
	--	inner join Entity b on a.EntityId = b.Id
	--	inner join [Codes.EntityTypes] c on b.EntityTypeId = c.id 
	--	where b.EntityTypeId = 8 AND [CategoryId]= 35 
	--	AND b.EntityUid = base.RowId 
	--	FOR XML RAW, ROOT('Keywords')) Keywords
	
	--all entity to organization relationships with org information. 
	 ,(SELECT DISTINCT AgentRelativeId As OrgId, AgentName, AgentUrl, EntityStateId, RoleIds as RelationshipTypeIds,  Roles as Relationships, AgentContextRoles FROM [dbo].[Entity.AgentRelationshipIdCSV]
			WHERE EntityTypeId= 8 AND EntityBaseId = base.id 
			FOR XML RAW, ROOT('AgentRelationshipsForEntity')) AgentRelationshipsForEntity
	--now obsolete
	,'' as AgentRelationships

	--destination component? - there is not a separate page for this

	--component count
	--what for components?
		,(SELECT a.[CategoryId], a.[ReferenceFrameworkItemId], a.[Name], a.[SchemaName], ISNULL(NULLIF(a.[CodeGroup], ''), NULL) CodeGroup, a.[CodedNotation] FROM [dbo].[Entity_ReferenceFramework_Summary] a inner join Entity b on a.EntityId = b.Id 
		inner join Pathway c on b.EntityUid = c.RowId 
		where a.[CategoryId] IN (10, 11, 23) AND c.[Id] = base.[Id] 
		FOR XML RAW, ROOT('Frameworks')
	) Frameworks 

	-- addresses for owning org - will only be used if there is no address for the pathway (never is)
	, (SELECT b.RowId, b.Id, b.EntityId, a.EntityUid, a.EntityTypeId, a.EntityBaseId, a.EntityBaseName, b.Id AS EntityAddressId, b.Name, b.IsPrimaryAddress, b.Address1, b.Address2, b.City, b.Region, b.SubRegion, b.PostOfficeBoxNumber, b.PostalCode, b.Country, b.Latitude, b.Longitude, b.Created, b.LastUpdated FROM dbo.Entity AS a 
		INNER JOIN dbo.[Entity.Address] AS b ON a.Id = b.EntityId 
		where a.[EntityUid] = base.OwningAgentUid
	FOR XML RAW, ROOT('OrgAddresses')) OrgAddresses
	--collection member
 	, (SELECT a.CollectionId, b.Name as Collection  FROM [dbo].[Collection.CollectionMember] a Inner Join Collection b on a.CollectionId = b.Id where a.ProxyFor = base.CTID
		FOR XML RAW, ROOT('CollectionMembers')
	) CollectionMembers

From #tempWorkTable work
Inner join PathwaySummary base on work.Id = base.Id
--Inner join Entity e on a.RowId = e.EntityUid 
left join Entity_Cache ec on base.RowId = ec.EntityUid
Left Join Organization c on base.OwningAgentUid = c.RowId

--**N/A for new approach
--WHERE RowNumber > @first_id
order by RowNumber 
go

grant execute on [Pathway.ElasticSearch] to public
go
