

/****** Object:  StoredProcedure [dbo].[LearningOpportunity.ElasticSearchV2]    Script Date: 1/22/2018 4:26:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

SELECT [Id]
      ,[RowId]
      ,[Name]
      ,[Description]
      ,[OrgId]
      ,[Organization]
      ,[OwningOrganizationCtid]
      ,[OwningAgentUid]
      ,[SubjectWebpage]
      ,[DateEffective]
      ,[EntityStateId]
      ,[CTID]
      ,[CredentialRegistryId]
      ,[cerEnvelopeUrl]
      ,[Created]
      ,[LastUpdated]
      ,[IdentificationCode]
      ,[availableOnlineAt]
      ,[AvailabilityListing]
      ,[RequiresCount]
      ,[RecommendsCount]
      ,[isRequiredForCount]
      ,[IsRecommendedForCount]
      ,[IsAdvancedStandingForCount]
      ,[AdvancedStandingFromCount]
      ,[isPreparationForCount]
      ,[PreparationFromCount]
      ,[ConnectionsList]
      ,[CredentialsList]
      ,[Org_QAAgentAndRoles]
  FROM [dbo].[LearningOpportunity_Summary]
GO




--=====================================================

DECLARE @RC int,@SortOrder varchar(100),@Filter varchar(5000)
DECLARE @StartPageIndex int, @PageSize int, @TotalRows int
--

set @SortOrder = 'newest'
set @SortOrder = 'cost_highest'
set @SortOrder = 'cost_lowest'
set @SortOrder = 'org_alpha'
--set @SortOrder = 'duration_shortest'
--set @SortOrder = 'duration_longest'

-- blind search 

--set @Filter = '  (base.name like ''%western gov%'' OR base.Description like ''%western gov%''  OR base.Organization like ''%western gov%''   OR base.Url like ''%western gov%'') '

--set @Filter = ' (base.name like ''%western%'' OR base.Description like ''%western%''  OR base.Organization like ''%western%''  )'
	
--set @Filter = '  (base.Id in (SELECT c.id FROM [dbo].[Entity.FrameworkItemSummary] a inner join Entity b on a.EntityId = b.Id inner join LearningOpportunity c on b.EntityUid = c.RowId where [CategoryId] = 23 and ([CodeGroup] in ('''')  OR ([CodeId] in ('''') ) ) ) )  '
set @Filter = '  (base.Id = 2150) '
set @Filter = ' base.EntityStateId > 1'

--drop table LearningOpportunity_IndexBuild

--set @Filter = ''
set @StartPageIndex = 1
set @PageSize = 10000
--set statistics time on       
EXECUTE @RC = [LearningOpportunity.ElasticSearchV2]
     @Filter,@SortOrder  ,@StartPageIndex  ,@PageSize, @TotalRows OUTPUT

select 'total rows = ' + convert(varchar,@TotalRows)

--set statistics time off       


<QualityAssurance><row RelationshipTypeId="2" SourceToAgentRelationship="Approved By" AgentToSourceRelationship="Approves" AgentRelativeId="209" AgentName="TESTING_(ISC)�" EntityStateId="3"/><row RelationshipTypeId="7" SourceToAgentRelationship="Offered By" AgentToSourceRelationship="Offers" AgentRelativeId="209" AgentName="TESTING_(ISC)�" EntityStateId="3"/></QualityAssurance>

<Connections><row ConnectionTypeId="6" ConnectionType="Advanced Standing For" CredentialId="1027" CredentialName="TESTING_Bachelor of Science in Nursing" AssessmentId="0" LearningOpportunityId="0"/></Connections>
*/


/* =============================================
Description:      LearningOpportunity special case search for elastic load
Options:

  @StartPageIndex - starting page number. 
  @PageSize - number of records on a page
  @TotalRows OUTPUT - total available rows. Used by interface to build a
custom pager
  ------------------------------------------------------
Modifications
22-01-22 mparsons - created for exception case where LearningOpportunity_IndexBuild is used
*/

--exec [dbo].[LearningOpportunity.ElasticSearchV2] '', '', 0,0,0
Alter PROCEDURE [dbo].[LearningOpportunity.ElasticSearchV2]
		@Filter           varchar(5000)
		,@SortOrder       varchar(100)
		,@StartPageIndex  int
		,@PageSize        int
		,@TotalRows       int OUTPUT

As

SET NOCOUNT ON;
-- paging
DECLARE
	@first_id  int
	,@startRow int
	,@lastRow int
	,@debugLevel      int
	,@SQL             varchar(5000)
	,@OrderBy         varchar(100)
	,@HasSitePrivileges bit

-- =================================

Set @debugLevel = 4
set @HasSitePrivileges= 0

print '@SortOrder ' + @SortOrder
if @SortOrder = 'relevance' set @SortOrder = 'base.Name '
else if @SortOrder = 'alpha' set @SortOrder = 'base.Name '
else if @SortOrder = 'org_alpha' set @SortOrder = 'base.Organization, base.Name '
else if @SortOrder = 'oldest' set @SortOrder = 'base.Id'
else if @SortOrder = 'newest' set @SortOrder = 'base.lastUpdated Desc '
--else if @SortOrder = 'cost_highest' set @SortOrder = 'costs.TotalCost DESC'
--else if @SortOrder = 'cost_lowest' set @SortOrder = 'costs.TotalCost'
else set @SortOrder = 'base.Name '

if len(@SortOrder) > 0 
      set @OrderBy = ' Order by ' + @SortOrder
else
      set @OrderBy = ' Order by base.Name '

-- nolock testing @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

--===================================================
-- Calculate the range
--===================================================
if @PageSize < 1				set @PageSize = 1000
if @PageSize < 1				set @PageSize = 1000
IF @StartPageIndex < 1			SET @StartPageIndex = 1
SET @StartPageIndex =  ((@StartPageIndex - 1)  * @PageSize) + 1
SET @lastRow =  (@StartPageIndex + @PageSize) - 1
PRINT '@StartPageIndex = ' + convert(varchar,@StartPageIndex) +  ' @lastRow = ' + convert(varchar,@lastRow)
 
-- =================================
CREATE TABLE #tempWorkTable(
      RowNumber         int PRIMARY KEY  NOT NULL,
      Id int,
      Name             varchar(500)
	,Organization varchar(500)
)
  CREATE TABLE #tempQueryTotalTable(
      TotalRows int
)
-- =================================
  if len(@Filter) > 0 begin
     if charindex( 'where', @Filter ) = 0 OR charindex( 'where',  @Filter ) > 10
        set @Filter =     ' where ' + @Filter
     end

  print '@Filter len: '  +  convert(varchar,len(@Filter))
-- =================================
set @SQL = '   SELECT count(*) as TotalRows  FROM [dbo].LearningOpportunity_IndexBuild base  '  + @Filter 
INSERT INTO #tempQueryTotalTable (TotalRows)
exec (@SQL)
--select * from #tempQueryTotalTable
select top 1  @TotalRows= TotalRows from #tempQueryTotalTable
--====
  set @SQL = ' 
  SELECT        
		DerivedTable.RowNumber, 
		base.Id
		,base.[Name], base.Organization
From ( SELECT 
         ROW_NUMBER() OVER(' + @OrderBy + ') as RowNumber,
          base.Id, base.Name, base.Organization
		from [LearningOpportunity_IndexBuild] base  ' 
        + @Filter + ' 
   ) as DerivedTable
       Inner join [dbo].[LearningOpportunity_IndexBuild] base on DerivedTable.Id = base.Id
WHERE DerivedTable.RowNumber BETWEEN ' + convert(varchar,@StartPageIndex) + ' AND ' + convert(varchar,@lastRow) + ' '  

  print '@SQL len: '  +  convert(varchar,len(@SQL))
  print @SQL
  INSERT INTO #tempWorkTable (RowNumber, Id, Name, Organization)
  exec (@SQL)

--select * from #tempWorkTable

--===================================================
PRINT '@StartPageIndex = ' + convert(varchar,@StartPageIndex)

SET ROWCOUNT @StartPageIndex
--SELECT @first_id = RowNumber FROM #tempWorkTable   ORDER BY RowNumber
SELECT @first_id = @StartPageIndex
PRINT '@first_id = ' + convert(varchar,@first_id)

if @first_id = 1 set @first_id = 0
--set max to return
SET ROWCOUNT @PageSize

-- ================================= 

SELECT [RowNumber]
      ,[LearningEntityTypeId]
      ,[id]
      ,[Name]
      ,[Description]
      ,[OrgId]
      ,[Organization]
      ,[OwningOrganizationCtid]
      ,[SubjectWebpage]
      ,[DateEffective]
      ,[IdentificationCode]
      ,[availableOnlineAt]
      ,[AvailabilityListing]
      ,[Created]
      ,[LastUpdated]
      ,[EntityLastUpdated]
      ,[RowId]
      ,[EntityStateId]
      ,[LifeCycleStatusType]
      ,[LifeCycleStatusTypeId]
      ,[ConnectionsList]
      ,[CredentialsList]
      ,[IsNonCredit]
      ,[RequiresCount]
      ,[RecommendsCount]
      ,[isRequiredForCount]
      ,[IsRecommendedForCount]
      ,[IsAdvancedStandingForCount]
      ,[AdvancedStandingFromCount]
      ,[isPreparationForCount]
      ,[PreparationFromCount]
      ,[NumberOfCostProfileItems]
      ,[CostProfilesCount]
      ,[ConditionProfilesCount]
      ,[TotalCostCount]
      ,[CommonCostsCount]
      ,[CommonConditionsCount]
      ,[FinancialAidCount]
      ,[ProcessProfilesCount]
      ,[AggregateDataProfileCount]
      ,[DataSetProfileCount]
      ,[HasTransferValueProfileCount]
      ,[HasCIPCount]
      ,[HasDurationCount]
      ,[LoppConnections]
      ,[CompetenciesCount]
      ,[CTID]
      ,[CredentialRegistryId]
      ,[TextValues]
      ,[TeachesCompetencies]
      ,[RequiresCompetencies]
      ,[AssessesCompetencies]
      ,[SubjectAreas]
      ,[Classifications]
      ,[Frameworks]
      ,[LoppProperties]
      ,[Languages]
      ,[ResourceForWidget]
      ,[TransferValueReference]
      ,[CollectionMembers]
      ,[Org_QAAgentAndRoles]
      ,[AgentRelationships]
      ,[QualityAssurances]
      ,[AgentRelationshipsForEntity]
      ,[ThirdPartyQualityAssuranceReceived]
      ,[Addresses]
      ,[OrgAddresses]
  FROM [dbo].[LearningOpportunity_IndexBuild]

--WHERE RowNumber > @first_id
order by RowNumber 
go

grant execute on [LearningOpportunity.ElasticSearchV2] to public
go
