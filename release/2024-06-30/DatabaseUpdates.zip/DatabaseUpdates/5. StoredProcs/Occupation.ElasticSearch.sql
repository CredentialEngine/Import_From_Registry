
/****** Object:  StoredProcedure [dbo].[Occupation.ElasticSearch]    Script Date: 4/20/2018 11:40:06 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
USE [credFinder]
GO

SELECT TOP (1000) [Id]
      ,[RowId]
      ,[EntityStateId]
      ,[Name]
      ,[Description]
      ,[SubjectWebpage]
      ,[CTID]
      ,[OwningAgentUid]
      ,[LifecycleStatusType]
      ,[CredentialRegistryId]
      ,[StartDate]
      ,[EndDate]
      ,[Created]
      ,[LastUpdated]
      ,[CodedNotation]
      ,[IdentifierJson]
      ,[OccupationJson]
      ,[OccupationFromJson]
      ,[OccupationForJson]
  FROM [credFinder].[dbo].[OccupationProfile]



--=====================================================

DECLARE @RC int,@SortOrder varchar(100),@Filter varchar(5000)
DECLARE @StartPageIndex int, @PageSize int, @TotalRows int
--

set @SortOrder = ''
set @SortOrder = 'base.Name'

--set @Filter = ' ( base.Id in (SELECT  OrgId FROM [Occupation.Member] where UserId = 2) ) '
set @Filter = ' ( base.EntityStateId = 3 ) and [ExistsInRegistry] = 1 '


-- blind search 
set @Filter = ''
set @StartPageIndex = 1
set @PageSize = 500
--set statistics time on       
EXECUTE @RC = [Occupation.ElasticSearch]
     @Filter,@SortOrder  ,@StartPageIndex  ,@PageSize,  @TotalRows OUTPUT

select 'total rows = ' + convert(varchar,@TotalRows)

--set statistics time off       


*/


/* =============================================
Description:      CF search
Options:

  @StartPageIndex - starting page number. If interface is at 20 when next
page is requested, this would be set to 21?
  @PageSize - number of records on a page
  @TotalRows OUTPUT - total available rows. Used by interface to build a
custom pager
  ------------------------------------------------------
Modifications
22-11-08 mparsons - new
24-03-07 sneha - Provides TransferValue For and Receives TransferValue From Tags to search 

*/

Alter  PROCEDURE [dbo].[Occupation.ElasticSearch] 
		@Filter           varchar(5000)
		,@SortOrder       varchar(100)
		,@StartPageIndex  int
		,@PageSize        int
		,@TotalRows       int OUTPUT

As

SET NOCOUNT ON;
-- paging
DECLARE
	@first_id  int
	,@startRow int
	,@lastRow int
	,@debugLevel      int
	,@SQL             varchar(5000)
	,@OrderBy         varchar(100)

-- =================================

Set @debugLevel = 4

if @SortOrder = 'relevance' set @SortOrder = 'base.Name '
else if @SortOrder = 'alpha' set @SortOrder = 'base.Name '
else if @SortOrder = 'oldest' set @SortOrder = 'base.Id'
else if @SortOrder = 'newest' set @SortOrder = 'base.lastUpdated Desc '
else set @SortOrder = 'base.Name '

if len(@SortOrder) > 0 
      set @OrderBy = ' Order by ' + @SortOrder
else
      set @OrderBy = ' Order by base.Name '

--===================================================
-- Calculate the range
--===================================================
if @PageSize < 1				set @PageSize = 1000
IF @StartPageIndex < 1			SET @StartPageIndex = 1
SET @StartPageIndex =  ((@StartPageIndex - 1)  * @PageSize) + 1
SET @lastRow =  (@StartPageIndex + @PageSize) - 1
PRINT '@StartPageIndex = ' + convert(varchar,@StartPageIndex) +  ' @lastRow = ' + convert(varchar,@lastRow)
  
-- =================================
CREATE TABLE #tempWorkTable(
	RowNumber         int PRIMARY KEY NOT NULL,
	Id int,
	Name             varchar(500),
	LastUpdated			datetime
)
  CREATE TABLE #tempQueryTotalTable(
      TotalRows int
)
--=======================================================

  if len(@Filter) > 0 begin
     if charindex( 'where', @Filter ) = 0 OR charindex( 'where',  @Filter ) > 10
        set @Filter =     ' where ' + @Filter
     end

  print '@Filter len: '  +  convert(varchar,len(@Filter))
-- =================================
set @SQL = '   SELECT count(*) as TotalRows  FROM [dbo].OccupationProfileSummary base  '  + @Filter 
INSERT INTO #tempQueryTotalTable (TotalRows)
exec (@SQL)
--select * from #tempQueryTotalTable
select top 1  @TotalRows= TotalRows from #tempQueryTotalTable
--====
  set @SQL = ' 
  SELECT        
		DerivedTable.RowNumber, 
		base.Id
		,base.[Name]
		,base.[lastUpdated]
From ( SELECT 
         ROW_NUMBER() OVER(' + @OrderBy + ') as RowNumber,
          base.Id, base.Name, base.lastUpdated
		from [OccupationProfileSummary] base  ' 
        + @Filter + ' 
   ) as DerivedTable
       Inner join [dbo].[OccupationProfileSummary] base on DerivedTable.Id = base.Id
WHERE RowNumber BETWEEN ' + convert(varchar,@StartPageIndex) + ' AND ' + convert(varchar,@lastRow) + ' '  

  print '@SQL len: '  +  convert(varchar,len(@SQL))
  print @SQL
  INSERT INTO #tempWorkTable (RowNumber, Id, Name, LastUpdated)
  exec (@SQL)

--select * from #tempWorkTable

-- ================================= 
SELECT        
	RowNumber
	, base.[Id]
	,base.[RowId]
	,base.EntityId
	,base.[Name]
	,base.[Description]
	,base.[EntityStateId]
	,base.[CTID]
	,base.[PrimaryAgentUid]
	,base.PrimaryOrganizationCTID
	,base.PrimaryOrganizationId
	,base.PrimaryOrganizationName
	,base.[SubjectWebpage]
	,base.[AbilityEmbodied]
	,base.[Classification]
	,base.[CodedNotation]
	,base.[Comment]
	,base.[Identifier]
	,base.[KnowledgeEmbodied]
	,base.[SkillEmbodied]
	,base.[SameAs]
	,base.[VersionIdentifier]
	,base.[JsonProperties]
	,base.[Created]
	,base.[LastUpdated]
	,base.[LifeCycleStatusTypeId]
    ,base.[LifeCycleStatusType]
	,base.[Competencies]
	,ec.CacheDate As EntityLastUpdated
	,ec.ResourceDetail

	,(SELECT DISTINCT ear.AgentRelativeId As OrgId, ear.AgentName, ear.AgentUrl, ear.EntityStateId, ear.RoleIds as RelationshipTypeIds,  ear.Roles as Relationships, ear.AgentContextRoles FROM [dbo].[Entity.AgentRelationshipIdCSV] ear
		WHERE ear.EntityTypeId= 35 AND ear.EntityBaseId = base.id 
		FOR XML RAW, ROOT('AgentRelationshipsForEntity')) AgentRelationshipsForEntity

	,(SELECT DISTINCT ehrs.Name,ehrs.ResourceId FROM [Entity.HasResourceSummary] ehrs 
		WHERE [EntityTypeId] = 26 AND ehrs.EntityId = base.EntityId and [RelationshipTypeId]=15
		FOR XML RAW, ROOT('ProvidesTransferValueFor')) ProvidesTransferValueFor

	,(SELECT DISTINCT ehrs.Name,ehrs.ResourceId FROM [Entity.HasResourceSummary] ehrs 
	WHERE [EntityTypeId] = 26 AND ehrs.EntityId = base.EntityId and [RelationshipTypeId]=16
	FOR XML RAW, ROOT('ReceivesTransferValueFrom')) ReceivesTransferValueFrom

From #tempWorkTable work
Inner join OccupationProfileSummary base on work.Id = base.Id
left join Entity_Cache ec on base.RowId = ec.EntityUid

--WHERE RowNumber > @first_id
order by RowNumber 
go

grant execute on [Occupation.ElasticSearch] to public
go
