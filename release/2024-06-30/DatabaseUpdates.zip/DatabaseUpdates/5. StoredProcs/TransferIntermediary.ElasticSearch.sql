
/****** Object:  StoredProcedure [dbo].[TransferIntermediary.ElasticSearch]    Script Date: 4/20/2018 11:40:06 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*

SELECT TOP (1000) [Id]
      ,[RowId]
      ,[EntityStateId]
      ,[Name]
      ,[Description]
      ,[SubjectWebpage]
      ,[CTID]
      ,[OwningAgentUid]
      ,[CredentialRegistryId]
      ,[StartDate]
      ,[EndDate]
      ,[Created]
      ,[LastUpdated]
      ,[CodedNotation]
      ,[IdentifierJson]
      ,[TransferValueJson]
      ,[TransferValueFromJson]
      ,[TransferValueForJson]
  FROM [credFinder].[dbo].[TransferValueProfile]



--=====================================================

DECLARE @RC int,@SortOrder varchar(100),@Filter varchar(5000)
DECLARE @StartPageIndex int, @PageSize int, @TotalRows int
--

set @SortOrder = ''
set @SortOrder = 'base.Name'

--set @Filter = ' ( base.Id in (SELECT  OrgId FROM [TransferIntermediary.Member] where UserId = 2) ) '
set @Filter = ' ( base.EntityStateId = 3 ) '


-- blind search 
--set @Filter = ''
set @StartPageIndex = 1
set @PageSize = 500
--set statistics time on       
EXECUTE @RC = [TransferIntermediary.ElasticSearch]
     @Filter,@SortOrder  ,@StartPageIndex  ,@PageSize,  @TotalRows OUTPUT

select 'total rows = ' + convert(varchar,@TotalRows)

--set statistics time off       
 

*/


/* =============================================
Description:     TransferIntermediary search
Options:

  @StartPageIndex - starting page number. If interface is at 20 when next
page is requested, this would be set to 21?
  @PageSize - number of records on a page
  @TotalRows OUTPUT - total available rows. Used by interface to build a
custom pager
  ------------------------------------------------------
Modifications
22-02-12 mparsons - new

*/

Alter  PROCEDURE [dbo].[TransferIntermediary.ElasticSearch] 
		@Filter           varchar(5000)
		,@SortOrder       varchar(100)
		,@StartPageIndex  int
		,@PageSize        int
		,@TotalRows       int OUTPUT

As

SET NOCOUNT ON;
-- paging
DECLARE
	@first_id  int
	,@startRow int
	,@lastRow int
	,@debugLevel      int
	,@SQL             varchar(5000)
	,@OrderBy         varchar(100)
	,@HasSitePrivileges bit

-- =================================

--set @CurrentUserId = 24
Set @debugLevel = 4
set @HasSitePrivileges= 0

if @SortOrder = 'relevance' set @SortOrder = 'base.Name '
else if @SortOrder = 'alpha' set @SortOrder = 'base.Name '
else if @SortOrder = 'oldest' set @SortOrder = 'base.Id'
else if @SortOrder = 'newest' set @SortOrder = 'base.lastUpdated Desc '
else set @SortOrder = 'base.Name '

if len(@SortOrder) > 0 
      set @OrderBy = ' Order by ' + @SortOrder
else
      set @OrderBy = ' Order by base.Name '

--===================================================
-- Calculate the range
--===================================================
if @PageSize < 1				set @PageSize = 1000
IF @StartPageIndex < 1			SET @StartPageIndex = 1
SET @StartPageIndex =  ((@StartPageIndex - 1)  * @PageSize) + 1
SET @lastRow =  (@StartPageIndex + @PageSize) - 1
PRINT '@StartPageIndex = ' + convert(varchar,@StartPageIndex) +  ' @lastRow = ' + convert(varchar,@lastRow)
  
-- =================================
CREATE TABLE #tempWorkTable(
	RowNumber         int PRIMARY KEY  NOT NULL,
	Id int,
	Name             varchar(500),
	LastUpdated			datetime
)
  CREATE TABLE #tempQueryTotalTable(
      TotalRows int
)
--=======================================================

  if len(@Filter) > 0 begin
     if charindex( 'where', @Filter ) = 0 OR charindex( 'where',  @Filter ) > 10
        set @Filter =     ' where ' + @Filter
     end

  print '@Filter len: '  +  convert(varchar,len(@Filter))
-- =================================
set @SQL = '   SELECT count(*) as TotalRows  FROM [dbo].TransferIntermediarySummary base  '  + @Filter 
INSERT INTO #tempQueryTotalTable (TotalRows)
exec (@SQL)
--select * from #tempQueryTotalTable
select top 1  @TotalRows= TotalRows from #tempQueryTotalTable
--====
  set @SQL = ' 
  SELECT        
		DerivedTable.RowNumber, 
		base.Id
		,base.[Name]
		,base.[lastUpdated]
From ( SELECT 
         ROW_NUMBER() OVER(' + @OrderBy + ') as RowNumber,
          base.Id, base.Name, base.lastUpdated
		from [TransferIntermediarySummary] base  ' 
        + @Filter + ' 
   ) as DerivedTable
       Inner join [dbo].[TransferIntermediarySummary] base on DerivedTable.Id = base.Id
WHERE RowNumber BETWEEN ' + convert(varchar,@StartPageIndex) + ' AND ' + convert(varchar,@lastRow) + ' '  

  print '@SQL len: '  +  convert(varchar,len(@SQL))
  print @SQL
  INSERT INTO #tempWorkTable (RowNumber, Id, Name, LastUpdated)
  exec (@SQL)

--select * from #tempWorkTable

-- ================================= 
SELECT        
	RowNumber, 
	a.[Id]
	,a.[RowId]
		,a.EntityId
	,a.[EntityStateId]
	,a.[Name]
	,a.[Description]
	,a.[SubjectWebpage]
	,a.[CTID]
	,a.[OwningAgentUid]
	--need to add owning org
	,a.OrganizationCTID
	,a.OrganizationId
	,a.OrganizationName
    
	,a.[HasTransferValueProfiles]
	,a.[CredentialRegistryId]
	,a.[CodedNotation]
	,a.[CreditValueJson]
	,a.[IntermediaryForJson]
	,a.[Subject]
	,a.[Created]
	,a.[LastUpdated]

	,e.CacheDate As EntityLastUpdated
	,isnull(e.ResourceDetail,'') as ResourceDetail

	--all entity to organization relationships with org information. 
	--not sure we need this- ned owns and published by
	 ,(SELECT DISTINCT AgentRelativeId As OrgId, AgentName, AgentUrl, EntityStateId, RoleIds as RelationshipTypeIds,  Roles as Relationships, AgentContextRoles FROM [dbo].[Entity.AgentRelationshipIdCSV]
			WHERE EntityTypeId= 28 AND EntityBaseId = a.id 
			FOR XML RAW, ROOT('AgentRelationshipsForEntity')) AgentRelationshipsForEntity
	--now obsolete
	,'' as AgentRelationships

	-- addresses for owning org - 
	, (SELECT b.RowId, b.Id, b.EntityId, ea.EntityUid, ea.EntityTypeId, ea.EntityBaseId, ea.EntityBaseName, b.Id AS EntityAddressId, b.Name, b.IsPrimaryAddress, b.Address1, b.Address2, b.City, b.Region, b.SubRegion, b.PostOfficeBoxNumber, b.PostalCode, b.Country, b.Latitude, b.Longitude, b.Created, b.LastUpdated 
		FROM dbo.Entity AS ea 
		INNER JOIN dbo.[Entity.Address] AS b ON ea.Id = b.EntityId 
		where ea.[EntityUid] = a.OwningAgentUid
	FOR XML RAW, ROOT('OrgAddresses')) OrgAddresses

From #tempWorkTable work
Inner join TransferIntermediarySummary a on work.Id = a.Id
left join Entity_Cache e on a.RowId = e.EntityUid

--WHERE RowNumber > @first_id
order by RowNumber 
go

grant execute on [TransferIntermediary.ElasticSearch] to public
go
