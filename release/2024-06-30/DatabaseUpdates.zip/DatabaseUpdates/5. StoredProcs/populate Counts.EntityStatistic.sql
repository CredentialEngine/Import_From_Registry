
USE [credFinder]
GO
truncate table [Counts.EntityStatistic]
go

INSERT INTO [dbo].[Counts.EntityStatistic]
           ([EntityTypeId]
           ,[Title]
           ,[Description]
           ,[SortOrder]
           ,[IsActive]
           ,[SchemaName]
           ,[Totals]
           ,[Created])


SELECT        
--Id
--, CategoryId,
case 
	when CategoryId= 58 then 1
	when CategoryId= 59 then 2
	when CategoryId= 60 then 3
	when CategoryId= 61 then 7
	when CategoryId= 62 then 17
	--else 0  
	end as EntityTypeId
, Title
, Description, SortOrder, IsActive, SchemaName, Totals,  Created
--Into [Counts.EntityStatistic]
FROM            [Codes.PropertyValue]

WHERE        (CategoryId in (58,59, 60, 61, 62))
ORDER BY CategoryId, Title