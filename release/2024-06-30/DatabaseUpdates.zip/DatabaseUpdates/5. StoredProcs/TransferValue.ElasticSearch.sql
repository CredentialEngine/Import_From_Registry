USE [credFinder]
GO

--USE staging_credFinder
--GO

use sandbox_credFinder
go

--use flstaging_credFinder	
--go
/****** Object:  StoredProcedure [dbo].[TransferValue.ElasticSearch]    Script Date: 4/20/2018 11:40:06 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
USE [credFinder]
GO

SELECT TOP (1000) [Id]
      ,[RowId]
      ,[EntityStateId]
      ,[Name]
      ,[Description]
      ,[SubjectWebpage]
      ,[CTID]
      ,[OwningAgentUid]
      ,[LifecycleStatusType]
      ,[CredentialRegistryId]
      ,[StartDate]
      ,[EndDate]
      ,[Created]
      ,[LastUpdated]
      ,[CodedNotation]
      ,[IdentifierJson]
      ,[TransferValueJson]
      ,[TransferValueFromJson]
      ,[TransferValueForJson]
  FROM [credFinder].[dbo].[TransferValueProfile]



--=====================================================

DECLARE @RC int,@SortOrder varchar(100),@Filter varchar(5000)
DECLARE @StartPageIndex int, @PageSize int, @TotalRows int
--

set @SortOrder = ''
set @SortOrder = 'base.Name'
set @SortOrder = 'oldest'

--set @Filter = ' ( base.Id in (SELECT  OrgId FROM [TransferValue.Member] where UserId = 2) ) '
set @Filter = ' ( base.EntityStateId = 3 ) and [ExistsInRegistry] = 1 '


-- blind search 
set @Filter = '  base.ID = 2906 '
set @StartPageIndex = 1
set @PageSize = 500
--set statistics time on       
EXECUTE @RC = [TransferValue.ElasticSearch]
     @Filter,@SortOrder  ,@StartPageIndex  ,@PageSize,  @TotalRows OUTPUT

select 'total rows = ' + convert(varchar,@TotalRows)

--set statistics time off       


*/


/* =============================================
Description:      CF search
Options:

  @StartPageIndex - starting page number. If interface is at 20 when next
page is requested, this would be set to 21?
  @PageSize - number of records on a page
  @TotalRows OUTPUT - total available rows. Used by interface to build a
custom pager
  ------------------------------------------------------
Modifications
20-01-14 mparsons - new

*/

Alter  PROCEDURE [dbo].[TransferValue.ElasticSearch] 
		@Filter           varchar(5000)
		,@SortOrder       varchar(100)
		,@StartPageIndex  int
		,@PageSize        int
		,@TotalRows       int OUTPUT

As

SET NOCOUNT ON;
-- paging
DECLARE
	@first_id  int
	,@startRow int
	,@lastRow int
	,@debugLevel      int
	,@SQL             varchar(5000)
	,@OrderBy         varchar(100)
	,@HasSitePrivileges bit

-- =================================

--set @CurrentUserId = 24
Set @debugLevel = 4
set @HasSitePrivileges= 0

if @SortOrder = 'relevance' set @SortOrder = 'base.Name '
else if @SortOrder = 'alpha' set @SortOrder = 'base.Name '
else if @SortOrder = 'oldest' set @SortOrder = 'base.Id'
else if @SortOrder = 'newest' set @SortOrder = 'base.lastUpdated Desc '
else set @SortOrder = 'base.Name '

if len(@SortOrder) > 0 
      set @OrderBy = ' Order by ' + @SortOrder
else
      set @OrderBy = ' Order by base.Name '

--===================================================
-- Calculate the range
--===================================================
if @PageSize < 1				set @PageSize = 1000
IF @StartPageIndex < 1			SET @StartPageIndex = 1
SET @StartPageIndex =  ((@StartPageIndex - 1)  * @PageSize) + 1
SET @lastRow =  (@StartPageIndex + @PageSize) - 1
PRINT '@StartPageIndex = ' + convert(varchar,@StartPageIndex) +  ' @lastRow = ' + convert(varchar,@lastRow)
  
-- =================================
CREATE TABLE #tempWorkTable(
	RowNumber         int PRIMARY KEY NOT NULL,
	Id int,
	LastUpdated			datetime
)
  CREATE TABLE #tempQueryTotalTable(
      TotalRows int
)
--=======================================================

  if len(@Filter) > 0 begin
     if charindex( 'where', @Filter ) = 0 OR charindex( 'where',  @Filter ) > 10
        set @Filter =     ' where ' + @Filter
     end

  print '@Filter len: '  +  convert(varchar,len(@Filter))
-- =================================
set @SQL = '   SELECT count(*) as TotalRows  FROM [dbo].TransferValueProfileSummary base  '  + @Filter 
INSERT INTO #tempQueryTotalTable (TotalRows)
exec (@SQL)
--select * from #tempQueryTotalTable
select top 1  @TotalRows= TotalRows from #tempQueryTotalTable
--====
  set @SQL = ' 
  SELECT        
		DerivedTable.RowNumber, 
		base.Id
		,base.[lastUpdated]
From ( SELECT 
         ROW_NUMBER() OVER(' + @OrderBy + ') as RowNumber,
          base.Id, base.lastUpdated
		from [TransferValueProfileSummary] base  ' 
        + @Filter + ' 
   ) as DerivedTable
       Inner join [dbo].[TransferValueProfileSummary] base on DerivedTable.Id = base.Id
WHERE RowNumber BETWEEN ' + convert(varchar,@StartPageIndex) + ' AND ' + convert(varchar,@lastRow) + ' '  

  print '@SQL len: '  +  convert(varchar,len(@SQL))
  print @SQL
  INSERT INTO #tempWorkTable (RowNumber, Id,  LastUpdated)
  exec (@SQL)

--select * from #tempWorkTable


-- ================================= 
SELECT        
	RowNumber, 
	a.[Id]
	,a.[RowId]
	,a.EntityId
	,a.[EntityStateId]
	,a.[Name]
	,a.[Description]
	,a.[SubjectWebpage]
	,a.[CTID]
	,a.[OwningAgentUid]
	--need to add owning org
	,isnull(c.ctid,'')  as OrganizationCTID
	,c.Id as OrganizationId
	,c.Name as OrganizationName
	,a.LifeCycleStatusType
	,a.LifeCycleStatusTypeId
	,a.[CredentialRegistryId]
	,a.[StartDate]
	,a.[EndDate]
	--,e.LastUpdated As EntityLastUpdated
	,ec.CacheDate As EntityLastUpdated
	,ec.ResourceDetail
	,a.[Created]
	,a.[LastUpdated]
	,a.[CodedNotation]
	,a.[IdentifierJson]
	,a.[TransferValueJson]
	,a.[TransferValueFromJson]
	,a.[TransferValueForJson]
	-- list of Ids for any transfer intermedaries
	,a.TransferIntermediariesFor
	-- probably will stop using the counts once the resources are added
	,a.TransferValueForCredentialsCount
	,a.TransferValueFromCredentialsCount
	--
	,a.TransferValueForAssessmentsCount
	,a.TransferValueFromAssessmentsCount
	--
	,a.TransferValueForLoppsCount
	,a.TransferValueFromLoppsCount
	--
	,a.TransferValueHasDevProcessCount
	--temp,--21-06-03 remove, just using counts
	--,a.CredentialsFor
	--,a.CredentialsFrom
	--all entity to organization relationships with org information. 
	--not sure we need this- need owns and published by
	 ,(SELECT DISTINCT AgentRelativeId As OrgId, AgentName, AgentUrl, EntityStateId, RoleIds as RelationshipTypeIds,  Roles as Relationships, AgentContextRoles FROM [dbo].[Entity.AgentRelationshipIdCSV]
			WHERE EntityTypeId= 26 AND EntityBaseId = a.id 
			FOR XML RAW, ROOT('AgentRelationshipsForEntity')) AgentRelationshipsForEntity
--NOTE: not using this now, will get the content from TransferValueFromJson/TransferValueForJson
	--,(SELECT DISTINCT ResourceId, EntityTypeId, EntityStateId, Name as ResourceName, ResourceOwningOrgId, ResourceOrganizationName
	--		FROM [dbo].[Entity.HasResourceSummary] 
	--		WHERE RelationshipTypeId= 17 AND EntityId = a.EntityId 
	--		FOR XML RAW, ROOT('TransferValuesFrom')) TransferValuesFrom
	--,(SELECT DISTINCT ResourceId, EntityTypeId, EntityStateId, Name as ResourceName, ResourceOwningOrgId, ResourceOrganizationName
	--		FROM [dbo].[Entity.HasResourceSummary] 
	--		WHERE RelationshipTypeId= 18 AND EntityId = a.EntityId 
	--		FOR XML RAW, ROOT('TransferValuesFor')) TransferValuesFor
	--now obsolete
	,'' as AgentRelationships

	-- addresses for owning org - 
	--, (SELECT b.RowId, b.Id, b.EntityId, ea.EntityUid, ea.EntityTypeId, ea.EntityBaseId, ea.EntityBaseName, b.Id AS EntityAddressId, b.Name, b.IsPrimaryAddress, b.Address1, b.Address2, b.City, b.Region, b.SubRegion, b.PostOfficeBoxNumber, b.PostalCode, b.Country, b.Latitude, b.Longitude, b.Created, b.LastUpdated 
	--	FROM dbo.Entity AS ea 
	--	INNER JOIN dbo.[Entity.Address] AS b ON ea.Id = b.EntityId 
	--	where ea.[EntityUid] = a.OwningAgentUid
	--FOR XML RAW, ROOT('OrgAddresses')) OrgAddresses
	,'' as OrgAddresses

From #tempWorkTable work
Inner join TransferValueProfileSummary a on work.Id = a.Id
--Inner join Entity e on a.RowId = e.EntityUid 
left join Entity_Cache ec on a.RowId = ec.EntityUid
Left Join Organization c on a.OwningAgentUid = c.RowId

--WHERE RowNumber > @first_id
order by RowNumber 
go

grant execute on [TransferValue.ElasticSearch] to public
go
