
/*
select ec.ctid, ec.baseId,ec.Name,resource.LastUpdated,  resource.AgentRelationshipsForEntity 
   from entity_cache ec 
   --inner join credential c on ec.CTID = c.CTID 
   inner join ( 
   select Id, entityStateId, ctid, LastUpdated 
   	 ,(SELECT DISTINCT ear.AgentRelativeId As OrgId, ear.AgentName, ear.AgentUrl, ear.EntityStateId, ear.RoleIds as RelationshipTypeIds,  ear.Roles as Relationships, ear.AgentContextRoles FROM [dbo].[Entity.AgentRelationshipIdCSV] ear
			WHERE ear.EntityTypeId= 1 AND ear.EntityBaseId = base.Id 
			FOR XML RAW, ROOT('AgentRelationshipsForEntity')) AgentRelationshipsForEntity
   from credential base 
   ) resource on ec.CTID = resource.CTID

 WHERE resource.EntityStateId = 3
 and ec.EntityStateId = 3
 AND ec.CTID = 'ce-6efdcdfd-923d-433f-a674-f06d7cccca01'
 and ec.[AgentRelationshipsForEntity] is null 
 --and resource.LastUpdated > '2023-01-01'
GO
Select * from entity_cache ec 
where ec.CTID = 'ce-6efdcdfd-923d-433f-a674-f06d7cccca01'
or ec.AgentRelationshipsForEntity is not null 


[Entity_Cache_PopulateCredentialAgentRelationships] 'ce-6efdcdfd-923d-433f-a674-f06d7cccca01'

*/
/*
Entity_Cache_PopulateCredentialAgentRelationships
Due to the atrocious performance deriving AgentRelationshipsForEntity in procs, changing approach to populate separately. 
We need a means to check if it works, and notify if not

*/
Alter Procedure [dbo].Entity_Cache_PopulateCredentialAgentRelationships
	@Identifier	varchar(50)
AS
-- =================================
if IsNull(@Identifier,'') = '' begin

	print 'Entity_Cache_PopulateCredentialAgentRelationships - Invalid request, missing CTID/GUID' 
	end
else
 BEGIN TRY  
 DECLARE @IsGuid BIT = 0;

-- Check if it's a valid GUID
    SET @IsGuid = CASE WHEN TRY_CAST(@Identifier AS UNIQUEIDENTIFIER) IS NOT NULL THEN 1 ELSE 0 END;
END TRY
BEGIN CATCH
    SET @IsGuid = 0;
END CATCH
BEGIN TRY

	 IF @IsGuid = 1
        BEGIN----Handling references
            UPDATE [dbo].[Entity_Cache]
            SET [AgentRelationshipsForEntity] = resource.AgentRelationshipsForEntity
			--select ec.ctid, ec.baseId,ec.Name,resource.LastUpdated,  resource.AgentRelationshipsForEntity
            FROM entity_cache ec
            INNER JOIN (
                SELECT
                    Id,
                    EntityStateId,
                    ctid,
                    LastUpdated,
                    Name,
                    RowId,
                    (
                        SELECT DISTINCT
                            ear.AgentRelativeId AS OrgId,
                            ear.AgentName,
                            ear.AgentUrl,
                            ear.EntityStateId,
                            ear.RoleIds AS RelationshipTypeIds,
                            ear.Roles AS Relationships,
                            ear.AgentContextRoles
                        FROM [dbo].[Entity.AgentRelationshipIdCSV] ear
                        WHERE
                            ear.EntityTypeId = 1
                            AND ear.EntityBaseId = base.Id
                        FOR XML RAW, ROOT('AgentRelationshipsForEntity')
                    ) AgentRelationshipsForEntity
                FROM credential base
            ) resource ON ec.EntityUid = resource.RowId
            WHERE resource.EntityStateId >= 2
            AND ec.EntityStateId >= 2
            AND resource.RowId = @Identifier;
        END
	ELSE 
	
		UPDATE [dbo].[Entity_Cache]
		   SET [AgentRelationshipsForEntity] = resource.AgentRelationshipsForEntity
		-- select ec.ctid, ec.baseId,ec.Name,resource.LastUpdated,  resource.AgentRelationshipsForEntity 
		   from entity_cache ec 
		   inner join 
		   ( 
			   select Id, entityStateId, ctid, LastUpdated 
   				 ,(SELECT DISTINCT ear.AgentRelativeId As OrgId, ear.AgentName, ear.AgentUrl, ear.EntityStateId, ear.RoleIds as RelationshipTypeIds,  ear.Roles as Relationships, ear.AgentContextRoles FROM [dbo].[Entity.AgentRelationshipIdCSV] ear
						WHERE ear.EntityTypeId= 1 AND ear.EntityBaseId = base.Id 
						FOR XML RAW, ROOT('AgentRelationshipsForEntity')
					) AgentRelationshipsForEntity
			   from credential base 
		   ) resource on ec.CTID = resource.CTID

		 WHERE resource.EntityStateId >= 2
		 and ec.EntityStateId >= 2
		 --and ec.[AgentRelationshipsForEntity] is null 
		 and resource.CTID = @Identifier
		 --now check. Or return the result, and have the caller check?


END TRY  
BEGIN CATCH  
     print 'Errors encountered in Entity_Cache_PopulateCredentialAgentRelationships ' 
	   --SELECT
    --ERROR_NUMBER() AS ErrorNumber,
    --ERROR_STATE() AS ErrorState,
    --ERROR_SEVERITY() AS ErrorSeverity,
    --ERROR_PROCEDURE() AS ErrorProcedure,
    --ERROR_LINE() AS ErrorLine,
    --ERROR_MESSAGE() AS ErrorMessage;

INSERT INTO [dbo].[MessageLog]
           ([Created],[Application],[Activity]
           ,[MessageType],[Message],[Description]
           ,[ActionByUserId],[ActivityObjectId]
           ,[RelatedUrl],[SessionId],[IPAddress],[Tags])
     VALUES
           (getdate(), 'CredentialFinder'
           ,'Credential'
           ,'Error'
           ,ERROR_MESSAGE()
           ,'Errors encountered in Entity_Cache_PopulateCredentialAgentRelationships for ' + @Identifier 
           ,0
           ,@Identifier
           ,NULL,NULL,NULL,NULL)

END CATCH 

go
grant execute on Entity_Cache_PopulateCredentialAgentRelationships to public
go

