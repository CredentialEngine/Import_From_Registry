
/****** Object:  StoredProcedure [dbo].[PublisherReIndexAll]    Script Date: 5/14/2021 10:41:13 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


/*
USE [sandbox_credFinder]
GO

--ProPath
exec [PublisherReIndexAll] 'ce-89bd0d16-6492-4ae1-8059-deabc3d89c15'


--Minnesota
exec [PublisherReIndexAll] 'ce-a0c0984a-1153-4244-b510-dbb0a805fa35'



*/


/* =============================================
Description:      [PublisherReIndexAll]
Options:
- add published by relationship for a third party publisher
 
------------------------------------------------------
Modifications


*/

Alter PROCEDURE [dbo].PublisherReIndexAll
		@PublisherCTID	varchar(50)

As

SET NOCOUNT ON;
--===	add published by 

-- ===================================================
-- ===				organizations		
-- ===================================================

--first add to reindex (don't execute until after the next step - has to be done manually anyway )
print 'Adding organization records to  [SearchPendingReindex] ...'
INSERT INTO [dbo].[SearchPendingReindex]
           ([EntityTypeId]
           ,[RecordId]
           ,[StatusId]
           ,[IsUpdateOrDeleteTypeId]
           ,[Created]
           ,[LastUpdated])

SELECT distinct 
2, publishedBy.TargetRecordId, 1,1,getdate(), getdate()
from Organization publisher
Inner Join (
SELECT distinct 
	   a.[PublisherCTID]	   
      ,a.[DataOwnerCTID], owner.Name as DataOwner     
      ,a.[PublishingEntityType]
      ,a.[EntityCtid]
	  ,be.Id as TargetEntityId
	   ,b.Id as TargetRecordId
  FROM [dbo].[Import.PendingRequest] a
  inner join Organization owner on a.DataOwnerCTID = owner.CTID
  --
  inner join Organization b		on a.EntityCtid = b.CTID
  inner join Entity be			on b.RowId = be.EntityUid
  --
  where a.[PublisherCTID]	<> a.DataOwnerCTID
  --and (a.[PublishMethodURI]	<> 'Registry Purge' AND a.[PublishMethodURI]	<> 'Registry Delete' AND a.[PublishMethodURI]	<> 'Transfer of owner')
  and (a.[PublishMethodURI]	= 'publishMethod:ManualEntry' OR a.[PublishMethodURI]	= 'publishMethod:RegistryAssistant' OR a.[PublishMethodURI]	= 'ManualPublish')
  and a.[PublishingEntityType] = 'Organization'
  and a.PublisherCTID		= @PublisherCTID
  and b.EntityStateId	= 3
  --order by 1,2,3,4
  ) publishedBy on publisher.CTID = publishedBy.[PublisherCTID]

    left join [Entity.AgentRelationship] c on publisher.RowId = c.AgentUid and c.EntityId = publishedBy.TargetEntityId
			and c.RelationshipTypeId = 30
  where 
   publisher.CTID = @PublisherCTID
   and  c.Id is null 
   print 'rows: ' + convert(varchar, @@ROWCOUNT)
--******************************************
--===
INSERT INTO [dbo].[Entity.AgentRelationship]
           ([EntityId]
           ,[RelationshipTypeId]
           ,[AgentUid]
           ,[Created]
           ,[LastUpdated]
           ,[RowId]
           ,[IsInverseRole])

SELECT distinct 
--a.[Id]
publishedBy.TargetEntityId as EntityId, 30 as RelationshipTypeId, publisher.RowId as AgentUid, GETDATE(), GETDATE(), NEWID(), 1
from Organization publisher
Inner Join (
SELECT distinct 
	   a.[PublisherCTID]	   
      ,a.[DataOwnerCTID], owner.Name as DataOwner     
      ,a.[PublishingEntityType]
      ,a.[EntityCtid]
	  ,be.Id as TargetEntityId
	   ,b.Id as TargetRecordId
  FROM [dbo].[Import.PendingRequest] a
  inner join Organization owner on a.DataOwnerCTID = owner.CTID
  --
  inner join Organization b		on a.EntityCtid = b.CTID
  inner join Entity be			on b.RowId = be.EntityUid
  --
  where a.[PublisherCTID]	<> a.DataOwnerCTID
  --and (a.[PublishMethodURI]	<> 'Registry Purge' AND a.[PublishMethodURI]	<> 'Registry Delete' AND a.[PublishMethodURI]	<> 'Transfer of owner')
  and (a.[PublishMethodURI]	= 'publishMethod:ManualEntry' OR a.[PublishMethodURI]	= 'publishMethod:RegistryAssistant' OR a.[PublishMethodURI]	= 'ManualPublish')
  and a.[PublishingEntityType] = 'Organization'
  and a.PublisherCTID		= @PublisherCTID
  and b.EntityStateId	= 3
  --order by 1,2,3,4
  ) publishedBy on publisher.CTID = publishedBy.[PublisherCTID]

    left join [Entity.AgentRelationship] c on publisher.RowId = c.AgentUid and c.EntityId = publishedBy.TargetEntityId
			and c.RelationshipTypeId = 30
  where 
   publisher.CTID = @PublisherCTID
   and  c.Id is null
   print 'rows: ' + convert(varchar, @@ROWCOUNT)
-- ===================================================
-- ===				Credential		
-- ===================================================
--first add to reindex (don't execute until after the next step)
print 'Adding credential records to  [SearchPendingReindex] ...'
INSERT INTO [dbo].[SearchPendingReindex]
           ([EntityTypeId]
           ,[RecordId]
           ,[StatusId]
           ,[IsUpdateOrDeleteTypeId]
           ,[Created]
           ,[LastUpdated])

SELECT distinct 
1, publishedBy.TargetRecordId, 1,1,getdate(), getdate()
from Organization publisher
Inner Join (
	SELECT distinct 
			a.[PublisherCTID]	   
			,a.[DataOwnerCTID], owner.Name as DataOwner     
			,a.[PublishingEntityType]
			,a.[EntityCtid]
			,be.Id as TargetEntityId
			,b.Id as TargetRecordId
		FROM [dbo].[Import.PendingRequest] a
		inner join Organization owner on a.DataOwnerCTID = owner.CTID
		--
		inner join Credential b	on a.EntityCtid = b.CTID
		inner join Entity be		on b.RowId = be.EntityUid

		where a.[PublisherCTID]	<> a.DataOwnerCTID
		and (a.[PublishMethodURI]	= 'publishMethod:ManualEntry' OR a.[PublishMethodURI]	= 'publishMethod:RegistryAssistant' OR a.[PublishMethodURI]	= 'ManualPublish')
		and a.[PublishingEntityType] = 'Credential'
		and a.PublisherCTID		= @PublisherCTID
		and b.EntityStateId		= 3
	  --order by 1,2,3,4
  ) publishedBy on publisher.CTID = publishedBy.[PublisherCTID]

  left join [Entity.AgentRelationship] c on publisher.RowId = c.AgentUid and c.EntityId = publishedBy.TargetEntityId
		and c.RelationshipTypeId = 30
  where 
   publisher.CTID = @PublisherCTID
   
   and  c.Id is null 
   print 'rows: ' + convert(varchar, @@ROWCOUNT)

--******************************************
-- add published by for credentials 
INSERT INTO [dbo].[Entity.AgentRelationship]
           ([EntityId]
           ,[RelationshipTypeId]
           ,[AgentUid]
           ,[Created]
           ,[LastUpdated]
           ,[RowId]
           ,[IsInverseRole])

SELECT distinct 
--a.[Id]
publishedBy.TargetEntityId as EntityId, 30 as RelationshipTypeId, publisher.RowId as AgentUid, GETDATE(), GETDATE(), NEWID(), 1
from Organization publisher
Inner Join (
	SELECT distinct 
			a.[PublisherCTID]	   
			,a.[DataOwnerCTID], owner.Name as DataOwner     
			,a.[PublishingEntityType]
			,a.[EntityCtid]
			,be.Id as TargetEntityId
			,b.Id as TargetRecordId
		FROM [dbo].[Import.PendingRequest] a
		inner join Organization owner on a.DataOwnerCTID = owner.CTID
		--
		inner join Credential b	on a.EntityCtid = b.CTID
		inner join Entity be		on b.RowId = be.EntityUid

		where a.[PublisherCTID]	<> a.DataOwnerCTID
		and (a.[PublishMethodURI]	= 'publishMethod:ManualEntry' OR a.[PublishMethodURI]	= 'publishMethod:RegistryAssistant' OR a.[PublishMethodURI]	= 'ManualPublish')
		and a.[PublishingEntityType] = 'Credential'
		and a.PublisherCTID		= @PublisherCTID
		and b.EntityStateId		= 3
	  --order by 1,2,3,4
  ) publishedBy on publisher.CTID = publishedBy.[PublisherCTID]

  left join [Entity.AgentRelationship] c on publisher.RowId = c.AgentUid and c.EntityId = publishedBy.TargetEntityId
		and c.RelationshipTypeId = 30
  where 
   publisher.CTID = @PublisherCTID
   and  c.Id is null 
   print 'rows: ' + convert(varchar, @@ROWCOUNT)

-- ===================================================
-- ===				LearningOpportunity		
-- ===================================================
  --first add to reindex (don't execute until after the next step)
  print 'Adding learning opp records to  [SearchPendingReindex] ...'
INSERT INTO [dbo].[SearchPendingReindex]
           ([EntityTypeId]
           ,[RecordId]
           ,[StatusId]
           ,[IsUpdateOrDeleteTypeId]
           ,[Created]
           ,[LastUpdated])

SELECT distinct 
7, publishedBy.TargetRecordId, 1,1,getdate(), getdate()
from Organization publisher
Inner Join (
	SELECT distinct 
			a.[PublisherCTID]	   
			,a.[DataOwnerCTID], owner.Name as DataOwner     
			,a.[PublishingEntityType]
			,a.[EntityCtid]
			,be.Id as TargetEntityId
			,b.Id as TargetRecordId
		FROM [dbo].[Import.PendingRequest] a
		inner join Organization owner on a.DataOwnerCTID = owner.CTID
		--
		inner join LearningOpportunity b	on a.EntityCtid = b.CTID
		inner join Entity be		on b.RowId = be.EntityUid

		where a.[PublisherCTID]	<> a.DataOwnerCTID
		and (a.[PublishMethodURI]	= 'publishMethod:ManualEntry' OR a.[PublishMethodURI]	= 'publishMethod:RegistryAssistant' OR a.[PublishMethodURI]	= 'ManualPublish')
		and a.[PublishingEntityType] = 'LearningOpportunity'
		and a.PublisherCTID		= @PublisherCTID
		and b.EntityStateId		= 3
  --order by 1,2,3,4
  ) publishedBy on publisher.CTID = publishedBy.[PublisherCTID]

  left join [Entity.AgentRelationship] c on publisher.RowId = c.AgentUid and c.EntityId = publishedBy.TargetEntityId
		and c.RelationshipTypeId = 30
  where 
   publisher.CTID = @PublisherCTID
   and  c.Id is null 
   print 'rows: ' + convert(varchar, @@ROWCOUNT)
--******************************************

INSERT INTO [dbo].[Entity.AgentRelationship]
           ([EntityId]
           ,[RelationshipTypeId]
           ,[AgentUid]
           ,[Created]
           ,[LastUpdated]
           ,[RowId]
           ,[IsInverseRole])

SELECT distinct 
--a.[Id]
publishedBy.TargetEntityId as EntityId, 30 as RelationshipTypeId, publisher.RowId as AgentUid, GETDATE(), GETDATE(), NEWID(), 1
from Organization publisher
Inner Join (
	SELECT distinct 
			a.[PublisherCTID]	   
			,a.[DataOwnerCTID], owner.Name as DataOwner     
			,a.[PublishingEntityType]
			,a.[EntityCtid]
			,be.Id as TargetEntityId
			,b.Id as TargetRecordId
		FROM [dbo].[Import.PendingRequest] a
		inner join Organization owner on a.DataOwnerCTID = owner.CTID
		--
		inner join LearningOpportunity b	on a.EntityCtid = b.CTID
		inner join Entity be		on b.RowId = be.EntityUid

		where a.[PublisherCTID]	<> a.DataOwnerCTID
		and (a.[PublishMethodURI]	= 'publishMethod:ManualEntry' OR a.[PublishMethodURI]	= 'publishMethod:RegistryAssistant' OR a.[PublishMethodURI]	= 'ManualPublish')
		and a.[PublishingEntityType] = 'LearningOpportunity'
		and a.PublisherCTID		= @PublisherCTID
		and b.EntityStateId		= 3
  --order by 1,2,3,4
  ) publishedBy on publisher.CTID = publishedBy.[PublisherCTID]

  left join [Entity.AgentRelationship] c on publisher.RowId = c.AgentUid and c.EntityId = publishedBy.TargetEntityId
		and c.RelationshipTypeId = 30
  where 
   publisher.CTID = @PublisherCTID
   and  c.Id is null 
   print 'rows: ' + convert(varchar, @@ROWCOUNT)

-- ===================================================
-- ===				Assessment		
-- ===================================================
  --first add to reindex (don't execute until after the next step)
  print 'Adding assessment records to  [SearchPendingReindex] ...'
INSERT INTO [dbo].[SearchPendingReindex]
           ([EntityTypeId]
           ,[RecordId]
           ,[StatusId]
           ,[IsUpdateOrDeleteTypeId]
           ,[Created]
           ,[LastUpdated])

SELECT distinct 
3, publishedBy.TargetRecordId, 1,1,getdate(), getdate()
from Organization publisher
Inner Join (
	SELECT distinct 
			a.[PublisherCTID]	   
			,a.[DataOwnerCTID], owner.Name as DataOwner     
			,a.[PublishingEntityType]
			,a.[EntityCtid]
			,be.Id as TargetEntityId
			,b.Id as TargetRecordId
		FROM [dbo].[Import.PendingRequest] a
		inner join Organization owner on a.DataOwnerCTID = owner.CTID
		--
		inner join Assessment b	on a.EntityCtid = b.CTID
		inner join Entity be		on b.RowId = be.EntityUid

		where a.[PublisherCTID]	<> a.DataOwnerCTID
		and (a.[PublishMethodURI]	= 'publishMethod:ManualEntry' OR a.[PublishMethodURI]	= 'publishMethod:RegistryAssistant' OR a.[PublishMethodURI]	= 'ManualPublish')
		and a.[PublishingEntityType] = 'Assessment'
		and a.PublisherCTID		= @PublisherCTID
		and b.EntityStateId		= 3
  --order by 1,2,3,4
  ) publishedBy on publisher.CTID = publishedBy.[PublisherCTID]

  left join [Entity.AgentRelationship] c on publisher.RowId = c.AgentUid and c.EntityId = publishedBy.TargetEntityId
		and c.RelationshipTypeId = 30
  where 
   publisher.CTID = @PublisherCTID
   and  c.Id is null 
   print 'rows: ' + convert(varchar, @@ROWCOUNT)
--******************************************

INSERT INTO [dbo].[Entity.AgentRelationship]
           ([EntityId]
           ,[RelationshipTypeId]
           ,[AgentUid]
           ,[Created]
           ,[LastUpdated]
           ,[RowId]
           ,[IsInverseRole])

SELECT distinct 
--a.[Id]
publishedBy.TargetEntityId as EntityId, 30 as RelationshipTypeId, publisher.RowId as AgentUid, GETDATE(), GETDATE(), NEWID(), 1
from Organization publisher
Inner Join (
	SELECT distinct 
			a.[PublisherCTID]	   
			,a.[DataOwnerCTID], owner.Name as DataOwner     
			,a.[PublishingEntityType]
			,a.[EntityCtid]
			,be.Id as TargetEntityId
			,b.Id as TargetRecordId
		FROM [dbo].[Import.PendingRequest] a
		inner join Organization owner on a.DataOwnerCTID = owner.CTID
		--
		inner join Assessment b	on a.EntityCtid = b.CTID
		inner join Entity be		on b.RowId = be.EntityUid

		where a.[PublisherCTID]	<> a.DataOwnerCTID
		and (a.[PublishMethodURI]	= 'publishMethod:ManualEntry' OR a.[PublishMethodURI]	= 'publishMethod:RegistryAssistant' OR a.[PublishMethodURI]	= 'ManualPublish')
		and a.[PublishingEntityType] = 'Assessment'
		and a.PublisherCTID		= @PublisherCTID
		and b.EntityStateId		= 3
  --order by 1,2,3,4
  ) publishedBy on publisher.CTID = publishedBy.[PublisherCTID]

  left join [Entity.AgentRelationship] c on publisher.RowId = c.AgentUid and c.EntityId = publishedBy.TargetEntityId
		and c.RelationshipTypeId = 30
  where 
   publisher.CTID = @PublisherCTID
   and  c.Id is null 
   print 'rows: ' + convert(varchar, @@ROWCOUNT)
   go

grant execute on PublisherReIndexAll to public
go