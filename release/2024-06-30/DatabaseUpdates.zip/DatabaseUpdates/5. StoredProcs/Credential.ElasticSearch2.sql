USE [credFinder]
GO

--use credFinder_github
--go
--use flstaging_credfinder
--go
--use staging_credFinder
--go

--use sandbox_credFinder
--go

/****** Object:  StoredProcedure [dbo].[Credential.ElasticSearch2]    Script Date: 3/8/2018 7:22:21 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
SELECT TOP (1000) [Id]
      ,[EntityId]
      ,[CredentialId]
      ,[Created]
  FROM [credFinder].[dbo].[Entity.Credential]
  where entityid in (29692 , 29679, 235941 , 236400 )
  or CredentialId in (48, 681, 717, 310 )
  order by 2,3


<Connections><row ConnectionTypeId="7" ConnectionType="Advanced Standing From" AssessmentId="0" AssessmentName="" CredentialId="139" CredentialName="Associate in Applied Science in Surveying Technology" LearningOpportunityId="0" LearningOpportunityName="" credOrgid="47" credOrganization="Ferris State University" asmtOrgid="0" loppOrgid="0"/></Connections>

<DataSetProfileProviders><row OrgId="359" DataProviderName="Indiana State Board of Nursing"/></DataSetProfileProviders>
--=====================================================

	DECLARE @RC int,@SortOrder varchar(100),@Filter varchar(5000)
	DECLARE @StartPageIndex int, @PageSize int, @TotalRows int
	--
	set @SortOrder = ''
	set @SortOrder = 'newest'
	set @SortOrder = 'id'
	-- blind search 
	set @Filter = '  (base.Id in (8492) )  '
	--set @Filter = '  (base.Id in (SELECT [RecordId]  FROM [dbo].[Widget.Selection] where [EntityTypeId]= 1 --And widgetId = 63) )  '
	--
	
	--set @Filter = '  (base.Id in (	SELECT e.EntityBaseId   FROM [dbo].[Entity.JurisdictionProfile] tags inner join Entity e on tags.EntityId = e.Id Inner Join Credential c on e.EntityUid = c.RowId  where tags.JProfilePurposeId =1 AND c.EntityStateId=3	  group by EntityBaseId )) '

	set @Filter = '  (base.OwningOrganizationCTID = ''ce-8f1a526b-3e18-4a4e-829f-05b85197772c'') '


	--set @Filter = ' len(base.QAAgentAndRoles) > 0'
	set @Filter = ' entitystateId > 2 '

	set @StartPageIndex = 1
	set @PageSize = 200
	--set statistics IO on     
	
	EXECUTE @RC = [Credential.ElasticSearch2]
			 @Filter,@SortOrder  ,@StartPageIndex  ,@PageSize, @TotalRows OUTPUT

	select 'total rows = ' + convert(varchar,@TotalRows)

	set statistics IO off    
	
	21-04-22 - trying
	- slow in credFinder
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	*/

/*
Description:      Credential search for elastic load
Options:

  @StartPageIndex - starting page number. 
  @PageSize - number of records on a page
  @TotalRows OUTPUT - total available rows. Used by interface to build a
custom pager
  ------------------------------------------------------
Modifications
20-12-14 mparsons - created using  improved approach
21-01-21 mparsons - added HoldersProfileCount
21-01-29 mparsons - added EarningsProfileCount and EmploymentOutcome
21-03-29 mparsons - added AggregateDataProfileCount
21-04-22 mparsons - in order to address deadlock issues, added SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
					- how to assess effectiveness? Some consider the use of this to be bad practice. It does make some sense in our context. 
21-05-30 mparsons - add tv profiles
21-05-31 mparsons - add outcomes provided by external entity via DataSetProfileSummary

22-11-17 mparsons - NOTE Credential_summary still uses [Credential.SummaryCache]
23-02-22 mparsons - replace Entity with Entity_Cache and include ResourceDetail
23-03-06 mparsons - performance issues on sandbox. Will not complete when reindexing
				Assess
				- 8 sec after skipping 
					- AgentRelationshipsForEntity, ThirdPartyQualityAssuranceReceived, Competencies
				- 26 sec after skipping 
					- AgentRelationshipsForEntity, ThirdPartyQualityAssuranceReceived

23-04-21 - need to determine why incorrect org addresses are sometimes returned?
24-03-07 sneha - Provides TransferValue For and Receives TransferValue From Tags to search 

*/
Alter PROCEDURE [dbo].[Credential.ElasticSearch2] 
		@Filter           varchar(5000)
		,@SortOrder       varchar(100)
		,@StartPageIndex  int
		,@PageSize        int
		,@TotalRows       int OUTPUT
As

SET NOCOUNT ON;
-- paging
DECLARE
      @first_id               int
      ,@startRow        int
	  ,@lastRow int
      ,@debugLevel      int
      ,@SQL             varchar(5000)
      ,@OrderBy         varchar(100)
	  ,@HasSitePrivileges bit
	  ,@UsingSummaryCache bit
-- =================================	  
--set @CurrentUserId = 21
Set @debugLevel = 4
set @HasSitePrivileges= 0
-- probably will never use cache for a build
--unless we should always ensure cache sources are updated before a build???
set @UsingSummaryCache = 0

if @SortOrder = 'relevance' set @SortOrder = 'base.Name '
else if @SortOrder = 'alpha' set @SortOrder = 'base.Name '
else if @SortOrder = 'id' set @SortOrder = 'base.Id '
--else if @SortOrder = 'cost_highest' set @SortOrder = 'costs.TotalCost DESC'
--else if @SortOrder = 'cost_lowest' set @SortOrder = 'costs.TotalCost'
else if @SortOrder = 'duration_shortest' set @SortOrder = 'duration.AverageMinutes '
else if @SortOrder = 'duration_longest' set @SortOrder = 'duration.AverageMinutes DESC'
else if @SortOrder = 'oldest' set @SortOrder = 'base.Id'

else if @SortOrder = 'newest' set @SortOrder = 'base.lastUpdated Desc '
else set @SortOrder = 'base.Name '

if len(@SortOrder) > 0 
      set @OrderBy = ' Order by ' + @SortOrder
else
      set @OrderBy = ' Order by base.Name '

-- nolock testing @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

--===================================================
-- Calculate the range
--===================================================
IF @StartPageIndex < 1			SET @StartPageIndex = 1
SET @StartPageIndex =  ((@StartPageIndex - 1)  * @PageSize) + 1
SET @lastRow =  (@StartPageIndex + @PageSize) - 1
PRINT '@StartPageIndex = ' + convert(varchar,@StartPageIndex) +  ' @lastRow = ' + convert(varchar,@lastRow)
-- =================================
CREATE TABLE #tempWorkTable(
	RowNumber         int PRIMARY KEY  NOT NULL,
	Id int,
	Title             varchar(500),
	LastUpdated			datetime,
)
  CREATE TABLE #tempQueryTotalTable(
      TotalRows int
)
--=======================================================
  if len(@Filter) > 0 begin
     if charindex( 'where', @Filter ) = 0 OR charindex( 'where',  @Filter ) > 10
        set @Filter =     ' where ' + @Filter
     end
 print '@Filter len: '  +  convert(varchar,len(@Filter))

-- ================================= 
set @SQL = '   SELECT count(*) as TotalRows  FROM [dbo].Credential_Summary base  '  + @Filter 
INSERT INTO #tempQueryTotalTable (TotalRows)
exec (@SQL)
--select * from #tempQueryTotalTable
select top 1  @TotalRows= TotalRows from #tempQueryTotalTable
-- ================================= 
  set @SQL = ' 
  SELECT        
		DerivedTable.RowNumber, 
		base.Id
		,base.[Name]
		,base.[lastUpdated]
	From 
	   (
		SELECT 
			 ROW_NUMBER() OVER(' + @OrderBy + ') as RowNumber,
			  base.Id, base.Name, base.lastUpdated
			from [Credential_Summary] base  ' 
			+ @Filter + ' 
	   ) as DerivedTable
       Inner join [dbo].[Credential_Summary] base on DerivedTable.Id = base.Id
WHERE RowNumber BETWEEN ' + convert(varchar,@StartPageIndex) + ' AND ' + convert(varchar,@lastRow) + ' '  

  print '@SQL len: '  +  convert(varchar,len(@SQL))
  print @SQL
  INSERT INTO #tempWorkTable (RowNumber, Id, Title, LastUpdated)
  exec (@SQL)

--select * from #tempWorkTable
-- ================================= 
  /*
  --not ideal, but doing a total
--left join (
--					Select ParentEntityUid, sum(isnull(TotalCost, 0)) As TotalCost from Entity_CostProfileTotal group by ParentEntityUid
--					) costs	on base.RowId = costs.ParentEntityUid 

--left join (SELECT [ParentEntityUid] ,sum([AverageMinutes]) as [AverageMinutes] 
--		FROM [dbo].[Entity_Duration_EntityAverage] group by [ParentEntityUid])  duration on base.RowId = duration.ParentEntityUid 
*/
	--if @UsingSummaryCache = 1 begin
	--	set @SQL = 'SELECT distinct base.Id, base.Name, base.lastUpdated
	--				from [Credential.SummaryCache] b  
	--				Inner join credential base on b.CredentialId = base.Id
	--				inner join [Credential_Summary] cs  on cs.Id = base.Id 
	--				'
	--				+ @Filter
	--			end
	--else begin
	--	set @SQL = 'SELECT distinct base.Id, base.Name, base.lastUpdated
	--				from [Credential_Summary] base  	'
 --       + @Filter
	--	end
--, AverageMinutes 
----left join [Entity_Duration_EntityAverage] duration on base.EntityUid = duration.ParentEntityUid 
--				
        
--  if charindex( 'order by', lower(@Filter) ) = 0
--    set @SQL = @SQL + ' ' + @OrderBy

--  print '@SQL len: '  +  convert(varchar,len(@SQL))
--  print @SQL

--  INSERT INTO #tempWorkTable (Id, Title, LastUpdated)
--  exec (@SQL)
--  SELECT @TotalRows = @@ROWCOUNT
--  print 'rows: ' + convert(varchar, @TotalRows)
---- =================================

--print 'added to temp table: ' + convert(varchar,@TotalRows)
--if @debugLevel > 7 begin
--  select * from #tempWorkTable
--  end

-- Calculate the range
--===================================================


--SET ROWCOUNT @StartPageIndex
----SELECT @first_id = RowNumber FROM #tempWorkTable   ORDER BY RowNumber
--SELECT @first_id = @StartPageIndex
--PRINT '@first_id = ' + convert(varchar,@first_id)

--if @first_id = 1 set @first_id = 0
----set max to return
--SET ROWCOUNT @PageSize

-- ================================= 

SELECT        Distinct
	RowNumber, 
	work.Id, 
	IsNUll(base.CTID,'') AS CTID, 
	base.EntityStateId,
	base.Name, 
	base.AlternateName,
	base.EntityUid,
	base.Description, base.SubjectWebpage,
	base.OwningAgentUid,
	base.OwningOrganizationId,
	base.OwningOrganization,
	base.OwningOrganizationCtid,
	--base.ManagingOrgId, managingOrg.Name as ManagingOrganization,

	--21-12-17 changed to use DateEffective. Retain alias for a bit
	base.DateEffective,
	--base.DateEffective as EffectiveDate,
	base.Version,
	base.LatestVersionUrl,
	
	base.PreviousVersion,	

	base.CredentialRegistryId,
	base.CredentialId,
	base.availableOnlineAt,
	base.AvailabilityListing,
	base.Created, 
	base.LastUpdated, 
	--e.LastUpdated As EntityLastUpdated,
	ec.CacheDate As EntityLastUpdated,
	ec.ResourceDetail,
	-- ======================================================
	base.EntityId,
	base.CredentialType,
	base.CredentialTypeId,
	base.CredentialTypeSchema,
	base.CredentialStatus,
	base.CredentialStatusId,
	base.CredentialStatusTypeId,
	Isnull(base.ImageUrl,'') as ImageUrl,
	base.IsAQACredential,
--	base.HasQualityAssurance,
	base.IsNonCredit,

		--creator org
	--base.CreatorOrgs,
	'' as CreatorOrgs,
	--base.OwningOrgs
	'' as OwningOrgs
	--*****************************************************
	-- WARNING - in some cases the below counts are not meant for a total but for just existing to filter by Has??? etc.
	,base.AssessmentsCompetenciesCount
	,base.LearningOppsCompetenciesCount
	,base.RequiresCompetenciesCount
	--,base.QARolesCount

	,base.RequiresCount
	,base.RecommendsCount
	,base.entryConditionCount

	,base.isRequiredForCount
	,base.IsRecommendedForCount
	,IsNull(Renewals.Nbr,0) as RenewalCount
	,base.IsAdvancedStandingForCount
	,base.AdvancedStandingFromCount
	,base.isPreparationForCount
	,base.isPreparationFromCount

	,IsNull(CommonCost.Nbr,0) As CommonCostsCount
	,IsNull(CommonCondition.Nbr,0) As CommonConditionsCount
	
	,IsNULL(costProfiles.Nbr, 0) As CostProfilesCount
	--remove these
	--,IsNULL(costs.TotalCost, 0) As TotalCostCount
	,0 as TotalCost
	,0 As TotalCostCount
	--total cost items - just for credential, AND child items
	/* 20-10-10 mp - added back number of cost profile items. Monitoring performance.	*/
	,Isnull(allCostProfiles.Total,0) as NumberOfCostProfileItems
	,IsNULL(FinancialAid.Nbr, 0) As FinancialAidCount
	,IsNULL(EmbeddedCredentials.Nbr, 0) As EmbeddedCredentialsCount
	--targets
	,IsNULL(reqTargets.HasTargetAssessments, 0) As RequiredAssessmentsCount
	,IsNULL(reqTargets.HasTargetCredentials, 0) As RequiredCredentialsCount
	,IsNULL(reqTargets.HasLearningOpportunities, 0) As RequiredLoppCount

	,IsNULL(recommendedTargets.HasTargetAssessments, 0) As RecommendedAssessmentsCount
	,IsNULL(recommendedTargets.HasTargetCredentials, 0) As RecommendedCredentialsCount
	,IsNULL(recommendedTargets.HasLearningOpportunities, 0) As RecommendedLoppCount

	,IsNULL(processProfiles.Nbr, 0)		As ProcessProfilesCount
	,IsNULL(revocationProfiles.Nbr, 0)	As RevocationProfilesCount
	,IsNull(aggregateDataProfile.Nbr,0) As AggregateDataProfileCount
	--this is to be external datasets
	,IsNull(dataSetProfile.Nbr,0)		As DataSetProfileCount
	,IsNull(tvProfile.Nbr,0)			As HasTransferValueProfileCount
	,IsNULL(jurisdictionProfiles.Nbr, 0)	As JurisdictionProfilesCount

	--
	--TBD delete HasTranserValueProfiles after count is established
	,0 as HasTranserValueProfiles

	--probably should dump these as not in use
	--,IsNull(HoldersProfile.Nbr,0) As HoldersProfileCount
	--,IsNull(EarningsProfile.Nbr,0) As EarningsProfileCount
	--,IsNull(EmploymentOutcomeProfile.Nbr,0) As EmploymentOutcomeProfileCount
	
	--ASSESS!!!!
	 ,(SELECT DISTINCT DataProviderId As OrgId, DataProviderName, b.EntityStateId, b.SubjectWebpage, b.CTID FROM [dbo].DataSetProfileSummary a
	 inner join Organization b on a.DataProviderId = b.id 
			WHERE a.CredentialId = work.Id AND a.InternalDSPEntityId is null 
			FOR XML RAW, ROOT('DataSetProfileProviders')) DataSetProfileProviders
	--========
	,IsNULL(HasOccupations.Nbr, 0) As HasOccupationsCount
	,IsNULL(HasIndustries.Nbr, 0) As HasIndustriesCount
	--,IsNULL(HasCIPs.Nbr, 0) As HasCipsCount
	--,ISNULL(CIPCounts.Nbr, 0 ) As InstructionalProgramCount
	,IsNULL(HasConditionProfile.Nbr, 0) As HasConditionProfileCount
	,IsNULL(HasDuration.Nbr, 0) As HasDurationCount
	--,duration.AverageMinutes,
	,isnull(duration.AverageMinutes,0) as AverageMinutes

	--may add the following to the assessment_summary, or a separate view that is clearly only for use with the index build
	,(SELECT DISTINCT ConnectionTypeId ,ConnectionType  ,AssessmentId, isnull(AssessmentName,'') As AssessmentName,   CredentialId, IsNUll(CredentialName,'') As CredentialName, LearningOpportunityId,			    Isnull(LearningOpportunityName,'') As LearningOpportunityName ,credOrgid,credOrganization, asmtOrgid, asmtOrganization, loppOrgid, loppOrganization
		FROM [dbo].[Entity_ConditionProfilesConnectionsSummary]  
		WHERE EntityTypeId = 1 AND EntityBaseId = work.Id  
		FOR XML RAW, ROOT('Connections')) CredentialConnections

	--this may be obsolete now - that is it should be moved to the summaries or cache?
	--18-04-11 mp - still in use ==> needed when using View, vs cache
	,isnull(connectionsCsv.Profiles,'') As ConnectionsList			--actual connection type (no credential info)
	,isnull(connectionsCsv.CredentialsList,'') As CredentialsList	--connection type, plus Id, and name of credential
	--isnull(costProfiles.Total,0) as NumberOfCostProfiles,


	--isnull(duration.FromDuration,'') as FromDuration,
	--isnull(duration.ToDuration,'') as ToDuration,
	--isnull(props.properties,'') As Properties,
	--isnull(naicsCsv.naics,'') As NaicsList,
	--isnull(naicsCsv.Others,'') As OtherIndustriesList,
	--isnull(occsCsv.Occupations,'') As OccupationsList,
	--isnull(occsCsv.Others,'') As OtherOccupationsList,
	--isnull(subjectsCsv.Subjects,'') As SubjectsList,

	,isnull(badgeClaims.Total, 0) as badgeClaimsCount

	,base.HasPartCount
	,base.HasPartList as HasPartsList
	,base.IsPartOfCount
	,base.IsPartOfList
	-- ======================================================
	-- For ElasticSearch
	-- Depends on Entity.SearchIndex, so the latter must be up to date!
	, (SELECT ISNULL(NULLIF(a.TextValue, ''), NULL) TextValue, a.[CodedNotation], a.CategoryId FROM [dbo].[Entity] e INNER JOIN [dbo].[Entity.SearchIndex] a ON a.EntityId = e.Id where e.EntityTypeId = 1 AND base.RowId = e.EntityUid FOR XML RAW, ROOT('TextValues')) TextValues

 
 ,  ( SELECT DISTINCT a.CategoryId, a.[PropertyValueId], a.Property, PropertySchemaName  FROM [dbo].[EntityProperty_Summary] a where EntityTypeId= 1 AND CategoryId IN (4, 14, 18, 21) AND work.Id = [EntityBaseId] FOR XML RAW, ROOT('CredentialProperties')) CredentialProperties

	,isnull(Languages.Languages,'') As Languages	
	-- **************************************************************************************************
	--17-05-04 mp - these were added to Credential.SummaryCache and joined in summary 
	--		to be replaced by QualityAssurance
	,isnull(base.QARolesList,'') As QARolesList
	,isnull(base.AgentAndRoles,'') As AgentAndRoles
	--renaming this
	,isnull(base.QAOrgRolesList,'') As QAOrgRolesList

	-- to this
	,isnull(base.QAOrgRolesList,'') As Org_QARolesList
	,isnull(base.QAAgentAndRoles,'') As Org_QAAgentAndRoles

	-------------------================================TRANSFERVALUES-=====================================--Using Resource Detail 
	--,(SELECT DISTINCT ehrs.Name,ehrs.ResourceId  FROM [Entity.HasResourceSummary] ehrs 
	--WHERE [EntityTypeId] = 26 AND ehrs.EntityId = base.EntityId and [RelationshipTypeId]=15
	--FOR XML RAW, ROOT('ProvidesTransferValueFor')) ProvidesTransferValueFor,
 --     (SELECT DISTINCT ehrs.Name,ehrs.ResourceId FROM [Entity.HasResourceSummary] ehrs 
	--WHERE [EntityTypeId] = 26 AND ehrs.EntityId = base.EntityId and [RelationshipTypeId]=16
	--FOR XML RAW, ROOT('ReceivesTransferValueFrom')) ReceivesTransferValueFrom

	-- ========================================================================
	--relationships is non QA - typically owns and offers, revoked, and renewed
	--, STUFF((SELECT '|' + ISNULL(NULLIF(CAST(a.[RelationshipTypeId] AS NVARCHAR(MAX)), ''), NULL) AS [text()] 
	--	FROM [dbo].[Entity.AgentRelationship] a inner join Entity b on a.EntityId = b.Id 
	--	WHERE b.EntityUid = base.RowId 
	--	FOR XML Path('')), 1,1,'') RelationshipTypes
	--now obsolete
	,'' as RelationshipTypes
	,'' as AgentRelationships


	 -- QualityAssurance is QA only
	 --18-10-08 mparsons - removed IsQARole, and return all. Use to facilitate widget filtering
	 --19-02-11 mparsons - this will be replaced by AgentRelationshipsForEntity
	 --AND [IsQARole]= 1
	 --,(SELECT DISTINCT [RelationshipTypeId] ,[SourceToAgentRelationship]   ,[AgentToSourceRelationship], Isnull([AgentUrl],'') As AgentUrl  ,[AgentRelativeId], Isnull(AgentName,'') As AgentName, IsQARole, [EntityStateId] FROM [dbo].[Entity_Relationship_AgentSummary]  WHERE [SourceEntityTypeId] = 1  and [SourceEntityBaseId] = work.Id FOR XML RAW, ROOT('QualityAssurance')) QualityAssurance

	 -- **************************************************************************************************

 -- [Entity_Subjects] is a union of direct and indirect subjects (using Entity.ReferenceConnection)
	, (SELECT a.[Subject], a.[Source], a.EntityTypeId, a.ReferenceBaseId FROM [dbo].[Entity_Subjects] a WHERE a.EntityTypeId = 1 AND a.EntityUid = base.RowId 
		FOR XML RAW, ROOT('Subjects')) Subjects

 	, (SELECT a.[CategoryId], a.[ReferenceFrameworkItemId], a.[Name], a.[SchemaName], ISNULL(NULLIF(a.[CodeGroup], ''), NULL) CodeGroup, a.CodedNotation FROM [dbo].[Entity_ReferenceFramework_Summary] a inner join Entity b on a.EntityId = b.Id inner join [Credential] c on b.EntityUid = c.RowId where a.[CategoryId] IN (10, 11, 23) AND c.[Id] = base.[Id] 
		FOR XML RAW, ROOT('Frameworks')) Frameworks
	--widget selection
 	, (SELECT a.WidgetId, a.WidgetSection  FROM [dbo].[Widget.Selection] a where a.EntityTypeId = 1 AND a.RecordId = base.[Id] 
		FOR XML RAW, ROOT('WidgetTags')
	) ResourceForWidget

	----transfer value member
	----24-02-18 mp - noted that this is  not being populated. Plus seems duplicate from use of tvProfile
 --	, (SELECT a.TransferValueProfileId, c.Name as TransferValueProfile  FROM [dbo].[Entity.TransferValueProfile] a Inner Join Entity b on a.EntityId = b.Id and b.EntityUid = base.RowId inner join TransferValueProfile c on a.TransferValueProfileId = c.Id where b.entityTypeId=1 and b.entityUID = base.RowId
	--	FOR XML RAW, ROOT('TransferValueReference')
	--) TransferValueReference
	,'' as TransferValueReference


	--collection member
 	, (SELECT a.CollectionId, b.Name as Collection  FROM [dbo].[Collection.CollectionMember] a Inner Join Collection b on a.CollectionId = b.Id where a.ProxyFor = base.CTID
		FOR XML RAW, ROOT('CollectionMembers')
	) CollectionMembers
-- ============
	,ea.Nbr as AvailableAddresses
	,base.JsonProperties		--prototyping
	, (SELECT b.RowId, b.Id, b.EntityId, a.EntityUid, a.EntityTypeId, a.EntityBaseId, a.EntityBaseName, b.Id AS EntityAddressId, b.Name, b.IsPrimaryAddress, b.Address1, b.Address2, b.City, b.Region, b.SubRegion, b.PostOfficeBoxNumber, b.PostalCode, b.Country, b.Latitude, b.Longitude, b.IdentifierJson, b.Created, b.LastUpdated FROM dbo.Entity AS a INNER JOIN dbo.[Entity.Address] AS b ON a.Id = b.EntityId where a.[EntityUid] = base.[RowId] 
		FOR XML RAW, ROOT('Addresses')) Addresses
	--,'' Addresses
		-- addresses for owning org - will only be used if there is no address for the credential
	--prototyping where address are stored in o.JsonProperties
	,o.JsonProperties as OrganizationJsonProperties
	, (SELECT b.RowId, b.Id, b.EntityId, a.EntityUid, a.EntityTypeId, a.EntityBaseId, a.EntityBaseName, b.Id AS EntityAddressId, b.Name, b.IsPrimaryAddress, b.Address1, b.Address2, b.City, b.Region, b.SubRegion, b.PostOfficeBoxNumber, b.PostalCode, b.Country, b.Latitude, b.Longitude, b.IdentifierJson, b.Created, b.LastUpdated FROM dbo.Entity AS a 
			INNER JOIN dbo.[Entity.Address] AS b ON a.Id = b.EntityId 
			where a.[EntityUid] = base.OwningAgentUid 
		FOR XML RAW, ROOT('OrgAddresses')) OrgAddresses

	--** QA asserted by third part, not owner
	 ,(SELECT DISTINCT OrgId, Organization as AgentName, TargetEntityStateId as EntityStateId, Assertions as RelationshipTypeIds FROM [dbo].Organization_QAPerformedCSV  WHERE [TargetEntityTypeId]=1 AND  TargetEntityBaseId = base.id 
		FOR XML RAW, ROOT('ThirdPartyQualityAssuranceReceived')) ThirdPartyQualityAssuranceReceived

--SLOW!! ================================================

	--all entity to organization relationships with org information. 
	--Roles is from entity context, AgentContextRoles is from the agent context. Accredited By vs Accredits 

	 --,(SELECT DISTINCT AgentRelativeId As OrgId, AgentName, AgentUrl, EntityStateId, RoleIds as RelationshipTypeIds,  Roles as Relationships
		--, '' as AgentContextRoles FROM [dbo].[Entity.AgentRelationshipIdCSV]
		--	WHERE EntityTypeId= 1 AND EntityBaseId = work.Id 
		--	FOR XML RAW, ROOT('AgentRelationshipsForEntity')) AgentRelationshipsForEntity
--23-03-06 - experimenting with adding relationships to entity.cache
,ec.AgentRelationshipsForEntity
	--,'' as AgentRelationshipsForEntity

--also a union of asmt and lopp competencies - not required comps?
	, (SELECT ccs.[Name], ccs.[TargetNodeDescription] [Description] FROM [dbo].[ConditionProfile_Competencies_Summary] ccs 
		where ccs.CredentialId = work.Id 
		FOR XML RAW, ROOT('Competencies')) Competencies
		--,'' Competencies


From #tempWorkTable work
	Inner join Credential_Summary base on work.Id = base.Id
	Left Join Organization o on base.OwningAgentUid = o.RowId	--may include reference creds at some point without an owner
	--can we just use Entity_Cache rather than both?
	--left join Entity e on work.Id = e.EntityBaseId and e.EntityTypeId = 1
	left join Entity_Cache ec on base.RowId = ec.EntityUid

	left Join (select EntityId, count(*) as nbr from [Entity.Address] group by EntityId ) ea on base.EntityId = ea.EntityId

	--left join EntityProperty_EducationLevelCSV levelsCsv	on base.EntityId = levelsCsv.EntityId

	--left join EntityProperty_AudienceTypeCSV typesCsv on base.EntityId = typesCsv.EntityId

--17-05-04 mp - these were added to Credential.SummaryCache and joined in summary 
	--left join [Credential.QARolesCSV] qaRolesCsv	on work.id = qaRolesCsv.CredentialId

	left join Credential_ConditionProfilesCSV connectionsCsv on work.id = connectionsCsv.CredentialId
	--left join [Entity_SubjectsCSV] subjectsCsv		on base.EntityUid = subjectsCsv.EntityUid

	-- ========== check for a verifiable badge claim ========== 
	Left Join (SELECT c.CredentialId, count(*) as Total
		FROM [Entity.VerificationProfile] a
		inner join entity vpEntity							on a.RowId = vpEntity.EntityUid
		inner join  [dbo].[Entity.Credential] c on vpEntity.Id = c.EntityId
		inner join  [dbo].[Entity.Property] ep  on vpEntity.Id = ep.EntityId
		inner join [Codes.PropertyValue] b			on ep.PropertyValueId = b.Id
		where 	b.SchemaName = 'claimType:BadgeClaim'
		group by c.CredentialId

	) badgeClaims on work.Id = badgeClaims.CredentialId

	left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.CostProfile] a Inner join Entity b ON a.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId
	) costProfiles	on work.Id = costProfiles.EntityBaseId  
	--not ideal, but doing a total
	--left join (
	--Select ParentEntityUid, sum(isnull(TotalCost, 0)) As TotalCost from Entity_CostProfileTotal group by ParentEntityUid
	--) costs				
	--	on base.EntityUid = costs.ParentEntityUid

-- ========== total cost items - just for credential, no child items ========== 
	--left join (
	--				Select ParentEntityUid, Count(*) As Total from Entity_CostProfileTotal group by ParentEntityUid
	--				) costProfiles	on base.EntityUid = costProfiles.ParentEntityUid

-- ========== total cost items - just for credential, AND child items ==========
/* 20-10-10 mp - added back number of cost profile items. Monitoring performance.	*/
	left join (
		Select condProfParentEntityBaseId, Sum(TotalCostItems) As Total from [CostProfile_SummaryForSearch] 
		where condProfParentEntityTypeId =1  and TotalCostItems > 0
		group by condProfParentEntityBaseId 
		) allCostProfiles	on work.Id = allCostProfiles.condProfParentEntityBaseId

	left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.CommonCost] a Inner join Entity b ON a.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId
		) CommonCost	on work.Id = CommonCost.EntityBaseId     
	left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.CommonCondition] a Inner join Entity b ON a.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId
		) CommonCondition	on work.Id = CommonCondition.EntityBaseId     
	--left join (
	--	Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.FinancialAlignmentProfile] a Inner join Entity b ON a.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId 
	--	) FinancialAid	on work.Id = FinancialAid.EntityBaseId 
	left join (
	Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.FinancialAssistanceProfile] a Inner join Entity b ON a.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId 
	) FinancialAid	on work.Id = FinancialAid.EntityBaseId  
		--renewals ----------------------------
	left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.ConditionProfile] a 
			Inner join Entity b ON a.EntityId = b.Id 
			inner Join Credential c on b.EntityUid = c.RowId
		where c.EntityStateId = 3
	  and a.ConnectionTypeId = 5 and isnull(a.ConditionSubTypeId,0) = 1
		Group By b.EntityBaseId 
		) Renewals	on work.Id = Renewals.EntityBaseId 
	--embedded ----------------------------
	left join (
	Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.Credential] a Inner join Entity b ON a.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId 
	) EmbeddedCredentials	on work.Id = EmbeddedCredentials.EntityBaseId 

	--targets
	left join (
		SELECT parentId as EntityBaseId, Sum(HasTargetAssessment) As HasTargetAssessments, Sum(HasTargetCredential) As HasTargetCredentials, Sum(HasLearningOpportunity) as HasLearningOpportunities FROM [dbo].[Entity_ConditionProfileTargetsSummary] where ParentEntityTypeId = 1 and ConnectionTypeId = 1 and (HasTargetAssessment > 0 OR HasTargetCredential > 0 OR HasLearningOpportunity > 0) group by parentId
		) reqTargets	on work.Id = reqTargets.EntityBaseId 

	left join (
		SELECT parentId as EntityBaseId, Sum(HasTargetAssessment) As HasTargetAssessments, Sum(HasTargetCredential) As HasTargetCredentials, Sum(HasLearningOpportunity) as HasLearningOpportunities FROM [dbo].[Entity_ConditionProfileTargetsSummary] where ParentEntityTypeId = 1 and ConnectionTypeId = 2 and (HasTargetAssessment > 0 OR HasTargetCredential > 0 OR HasLearningOpportunity > 0) group by parentId
		) recommendedTargets	on work.Id = recommendedTargets.EntityBaseId 
	left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.ProcessProfile] a Inner join Entity b ON a.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId
		) processProfiles	on work.Id = processProfiles.EntityBaseId     
	left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.RevocationProfile] a Inner join Entity b ON a.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId
		) revocationProfiles	on work.Id = revocationProfiles.EntityBaseId   
	left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.ReferenceFramework] a Inner join Entity b ON a.EntityId = b.Id Where b.EntityTypeId = 1 and CategoryId = 11 Group By b.EntityBaseId 
		) HasOccupations	on work.Id = HasOccupations.EntityBaseId   
	left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.ReferenceFramework] a Inner join Entity b ON a.EntityId = b.Id Where b.EntityTypeId = 1 and CategoryId = 10 Group By b.EntityBaseId 
		) HasIndustries	on work.Id = HasIndustries.EntityBaseId 
	
	--left join (
	--	Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.ReferenceFramework] a Inner join Entity b ON a.EntityId = b.Id Where b.EntityTypeId = 1 and CategoryId = 23 Group By b.EntityBaseId 
	--	) CIPCounts on work.Id = CIPCounts.EntityBaseId 
--SLOWish
	left Join ( 
		SELECT     distinct base.Id, 
		CASE WHEN Languages IS NULL THEN ''           WHEN len(Languages) = 0 THEN ''          ELSE left(Languages,len(Languages)-1)     END AS Languages
		From dbo.credential base
		CROSS APPLY ( SELECT a.Title + '| ' + a.TextValue + '| '
			FROM [dbo].[Entity.Reference] a inner join [Entity] b on a.EntityId = b.Id 
			where b.EntityTypeId= 1 AND a.CategoryId = 65
			and base.Id = b.EntityBaseId FOR XML Path('')  ) D (Languages)
		where Languages is not null
	) Languages on work.Id = Languages.Id

	left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.ConditionProfile] a Inner join Entity b ON a.EntityId = b.Id Where b.EntityTypeId = 1 Group By b.EntityBaseId 
		) HasConditionProfile	on work.Id = HasConditionProfile.EntityBaseId 
	 left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.DurationProfile] a Inner join Entity b ON a.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId 
		) HasDuration	on work.Id = HasDuration.EntityBaseId  
-- =======================================================
	left join (SELECT [ParentEntityUid] ,sum([AverageMinutes]) as [AverageMinutes] 
	  FROM [dbo].[Entity_Duration_EntityAverage] group by [ParentEntityUid]
	  )  duration on base.EntityUid = duration.ParentEntityUid 
--=========
	left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.AggregateDataProfile] a Inner join Entity b ON a.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId
		) aggregateDataProfile	on work.Id = aggregateDataProfile.EntityBaseId 
-- datasetProfile could be via aggregateDataProfile or eventually under credential via about
--21-05-26 mp	- now ensure this will only be external datasets
--				- should not have a Entity.DataSetProfile??
left join (
		Select c.CredentialId, COUNT(*)  As Nbr from [DataSetProfile] a inner join entity b on a.RowId = b.EntityUid inner join [Entity.Credential] c ON b.Id = c.EntityId Left Join [entity.DataSetProfile] d on a.Id = d.DataSetProfileId where d.Id is null Group By c.CredentialId
		) dataSetProfile	on work.Id = dataSetProfile.CredentialId 
--has transfer value
left join (
		Select c.CredentialId, COUNT(*)  As Nbr from [TransferValueProfile] a inner join entity b on a.RowId = b.EntityUid inner join [Entity.Credential] c ON b.Id = c.EntityId
			where a.EntityStateId = 3 Group By c.CredentialId
		) tvProfile	on work.Id = tvProfile.CredentialId 
--
left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.JurisdictionProfile] a Inner join Entity b ON a.EntityId = b.Id Where a.JProfilePurposeId =1 AND b.EntityTypeId = 1  Group By b.EntityBaseId
		) jurisdictionProfiles	on work.Id = jurisdictionProfiles.EntityBaseId   

--=========
--	left join (
--		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.HoldersProfile] a Inner join Entity b ON a.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId
--		) HoldersProfile	on work.Id = HoldersProfile.EntityBaseId  
----=========
--	left join (
--		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.EarningsProfile] a Inner join Entity b ON a.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId
--		) EarningsProfile	on work.Id = EarningsProfile.EntityBaseId  
----=========
--	left join (
--		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.EmploymentOutcomeProfile] a Inner join Entity b ON a.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId
--		) EmploymentOutcomeProfile	on work.Id = EmploymentOutcomeProfile.EntityBaseId  
-- =========================================================
--**N/A for new approach
--WHERE RowNumber > @first_id
order by RowNumber 

GO

grant execute on [Credential.ElasticSearch2] to public
go