use credfinder
go

use sandbox_credFinder 
go

--use staging_credFinder
--go

--use credfinder_prod
--go

/****** 
	Populate the Pathway properties totals table. 
	FIRST CREATE THE VIEW: [Pathway_PropertyTotals]
	The first three steps are to initially generate the counts table. Additional properties can be added manaually as needed. 
	1. Use the following to generate the columns into _Dictionary (or create a customized version for this process)
		aspGenerateColumnDef @TableFilter = 'Pathway_Property%', @TypeFilter='view'

	2. Then generate a counts table
		truncate if needed
		truncate table [dbo].[Counts.Pathway_Property]

		SELECT [col_id] As Id, colName as Property, 0 as Total
		  --into [dbo].[Counts.Pathway_Property]
		FROM [dbo].[_Dictionary]
		where tableName = 'Pathway_PropertyTotals'
		order by 1
		OR - if already exists
		INSERT INTO [dbo].[Counts.Pathway_Property]
           ([Id]           ,[Property] ,Label          ,[Total])
    	SELECT [col_id] As Id, colName as Property, colName as Label,0 as Total
		FROM [dbo].[_Dictionary]
		where tableName = 'Pathway_PropertyTotals'


	3. Next generate the Update statements 
		- use the select sql below
	4. Execute the update statements

******/

/*
SELECT TOP (1000) Id
      ,Property
      ,[Total]

	  ,'UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = b.' + [Property] + ' from [Counts.Pathway_Property] a cross join Pathway_PropertyTotals b  WHERE a.[Property] = ''' + [Property] + '''  ' as updateLine
	  
	  FROM [dbo].[Counts.Pathway_Property]
	  order by 1
  go

  */

/*
--reset
UPDATE [dbo].[Counts.Pathway_Property]
   SET [Total] = 0
go
*/
--UPDATE [dbo].[Counts.Pathway_Property] 
--   SET [Total] = b.Name
--from [Counts.Pathway_Property] a
----inner join 
--cross join Pathway_PropertyTotals b
-- WHERE a.Property = 'Name'
--GO


/*
USE [credFinder]
GO

DROP PROCEDURE [dbo].[Counts.Pathway_PropertyPathway_Property_UpdateTotals]
GO



exec [Counts.Pathway_Property_UpdateTotals]
go

select * FROM [credFinder].[dbo].[Counts.Pathway_Property]
order by id

*/
Alter PROCEDURE [Counts.Pathway_Property_UpdateTotals] 
AS
BEGIN
declare @OverallTotal decimal(9,2)
--reset first
UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = 0
--
 
UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = b.Total from [Counts.Pathway_Property] a cross join Pathway_PropertyTotals b  WHERE a.[Property] = 'Total'  
--
select @OverallTotal= Total from [Counts.Pathway_Property] where Property='Total'
print 'over all total: ' + convert(varchar,@OverallTotal)
--============

UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = b.Name from [Counts.Pathway_Property] a cross join Pathway_PropertyTotals b  WHERE a.[Property] = 'Name'  
UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = b.Description from [Counts.Pathway_Property] a cross join Pathway_PropertyTotals b  WHERE a.[Property] = 'Description'  
UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = b.SubjectWebpage from [Counts.Pathway_Property] a cross join Pathway_PropertyTotals b  WHERE a.[Property] = 'SubjectWebpage'  
UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = b.CTID from [Counts.Pathway_Property] a cross join Pathway_PropertyTotals b  WHERE a.[Property] = 'CTID'  
UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = b.HasDestinationComponent from [Counts.Pathway_Property] a cross join Pathway_PropertyTotals b  WHERE a.[Property] = 'HasDestinationComponent'  
UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = b.HasChild from [Counts.Pathway_Property] a cross join Pathway_PropertyTotals b  WHERE a.[Property] = 'HasChild'  
UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = b.HasProgressionModel from [Counts.Pathway_Property] a cross join Pathway_PropertyTotals b  WHERE a.[Property] = 'HasProgressionModel'  
UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = b.OwnedBy from [Counts.Pathway_Property] a cross join Pathway_PropertyTotals b  WHERE a.[Property] = 'OwnedBy'  
UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = b.OfferedBy from [Counts.Pathway_Property] a cross join Pathway_PropertyTotals b  WHERE a.[Property] = 'OfferedBy'  
UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = b.AssessmentComponents from [Counts.Pathway_Property] a cross join Pathway_PropertyTotals b  WHERE a.[Property] = 'AssessmentComponents'  
UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = b.BasicComponents from [Counts.Pathway_Property] a cross join Pathway_PropertyTotals b  WHERE a.[Property] = 'BasicComponents'  
UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = b.CocurricularComponents from [Counts.Pathway_Property] a cross join Pathway_PropertyTotals b  WHERE a.[Property] = 'CocurricularComponents'  
UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = b.CompentencyComponents from [Counts.Pathway_Property] a cross join Pathway_PropertyTotals b  WHERE a.[Property] = 'CompentencyComponents'  
UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = b.CourseComponents from [Counts.Pathway_Property] a cross join Pathway_PropertyTotals b  WHERE a.[Property] = 'CourseComponents'  
UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = b.CredentialComponents from [Counts.Pathway_Property] a cross join Pathway_PropertyTotals b  WHERE a.[Property] = 'CredentialComponents'  
UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = b.ExtraCurricularComponents from [Counts.Pathway_Property] a cross join Pathway_PropertyTotals b  WHERE a.[Property] = 'ExtraCurricularComponents'  
UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = b.JobComponents from [Counts.Pathway_Property] a cross join Pathway_PropertyTotals b  WHERE a.[Property] = 'JobComponents'  
UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = b.WorkExperienceComponents from [Counts.Pathway_Property] a cross join Pathway_PropertyTotals b  WHERE a.[Property] = 'WorkExperienceComponents'  

UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = b.MultiComponents from [Counts.Pathway_Property] a cross join Pathway_PropertyTotals b  WHERE a.[Property] = 'MultiComponents' 
UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = b.CollectionComponents from [Counts.Pathway_Property] a cross join Pathway_PropertyTotals b  WHERE a.[Property] = 'CollectionComponents' 
--UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = b.SelectComponents from [Counts.Pathway_Property] a cross join Pathway_PropertyTotals b  WHERE a.[Property] = 'SelectComponents' 

UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = b.OccupationType from [Counts.Pathway_Property] a cross join Pathway_PropertyTotals b  WHERE a.[Property] = 'OccupationType'  
UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = b.IndustryType from [Counts.Pathway_Property] a cross join Pathway_PropertyTotals b  WHERE a.[Property] = 'IndustryType'  
UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = b.ProgramType from [Counts.Pathway_Property] a cross join Pathway_PropertyTotals b  WHERE a.[Property] = 'ProgramType'  

UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = b.Subject from [Counts.Pathway_Property] a cross join Pathway_PropertyTotals b  WHERE a.[Property] = 'Subject'  
UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = b.Keyword from [Counts.Pathway_Property] a cross join Pathway_PropertyTotals b  WHERE a.[Property] = 'Keyword'  
UPDATE [dbo].[Counts.Pathway_Property]  SET [Total] = b.DevelopmentProcess from [Counts.Pathway_Property] a cross join Pathway_PropertyTotals b  WHERE a.[Property] = 'DevelopmentProcess'  

--
UPDATE [dbo].[Counts.Pathway_Property]  SET PercentOfOverallTotal = (Total * 100) / @OverallTotal

-- overall data points
declare @TotalDatapoints int
 Select @TotalDatapoints=Sum([Total])  FROM [dbo].[Counts.Pathway_Property]  
 where property <> 'Total' AND property <> 'Overall Data Points'
print '@TotalDatapoints: ' + convert(varchar, @TotalDatapoints)

UPDATE [dbo].[Counts.Pathway_Property]  SET  Total =  @TotalDatapoints where property = 'Overall Data Points'


END
GO
grant execute on [Counts.Pathway_Property_UpdateTotals] to public
go

/*

INSERT INTO [dbo].[Counts.Pathway_Property]
           ([Id]
           ,[Property]
           ,[Label]
           ,[Policy]
           ,[PropertyGroup]
           ,[Total]
           ,[PercentOfOverallTotal])
     VALUES
           (2
           ,'Overall Data Points'
           ,'Overall Data Points'
           ,'1. Required'
           ,''
           ,0
           ,0)
GO

*/