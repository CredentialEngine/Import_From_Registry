
-- 23-10-06 add triggers for framework competencies and collection competencies

/****** Object:  Trigger [dbo].[trgCompetencyFrameworkAfterInsert]    Script Date: 10/6/2023 12:55:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE TRIGGER [dbo].[trgCompetencyFrameworkCompetencyAfterInsert] ON  [dbo].[CompetencyFramework.Competency]
FOR INSERT
AS  
    INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
					 ,EntityBaseId, EntityBaseName)
    SELECT RowId,17, getdate(), Id, 'framework competency'
    FROM inserted;
GO

ALTER TABLE [dbo].[CompetencyFramework.Competency] ENABLE TRIGGER [trgCompetencyFrameworkCompetencyAfterInsert]
GO


CREATE TRIGGER [dbo].[trgCollectionCompetencyAfterInsert] ON  [dbo].[Collection.Competency]
FOR INSERT
AS  
    INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
					 ,EntityBaseId, EntityBaseName)
    SELECT RowId,18, getdate(), Id, 'collection competency'
    FROM inserted;
GO

ALTER TABLE [dbo].[Collection.Competency] ENABLE TRIGGER [trgCollectionCompetencyAfterInsert]
GO


