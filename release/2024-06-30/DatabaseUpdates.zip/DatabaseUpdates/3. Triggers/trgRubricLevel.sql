
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
Modifcations
24-01-17 mparsons - new

*/
/*
		Drop TRIGGER [dbo].[trgRubricLevelAfterInsert]
		Drop TRIGGER [dbo].[trgRubricLevelAfterDelete]
*/

Create TRIGGER [dbo].[trgRubricLevelAfterInsert] ON  [dbo].[RubricLevel]
FOR INSERT
AS  
   INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
		   ,EntityBaseId, EntityBaseName)
    SELECT RowId, 46, getdate(), Id, IsNull(Name,'RubricLevel')  as Name
    FROM inserted;
GO

ALTER TABLE [dbo].[RubricLevel] ENABLE TRIGGER [trgRubricLevelAfterInsert]
GO


Create TRIGGER [dbo].[trgRubricLevelAfterDelete] ON  [dbo].[RubricLevel]
FOR DELETE
AS  
BEGIN
     -- delete the entity
		DELETE a	
			FROM [dbo].[Entity] a
			inner join Deleted d on a.EntityUid = d.RowId

END
GO

ALTER TABLE [dbo].[RubricLevel] ENABLE TRIGGER [trgRubricLevelAfterDelete]
GO



