
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
Modifcations
24-01-17 mparsons - new

*/

Create TRIGGER [dbo].[trgRubricCriterionLevelAfterInsert] ON  [dbo].[Rubric.CriterionLevel]
FOR INSERT
AS  
   INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
		   ,EntityBaseId, EntityBaseName)
    SELECT RowId, 45, getdate(), Id, IsNull(BenchmarkLabel,'Rubric.CriterionLevel')  as Name
    FROM inserted;
GO

ALTER TABLE [dbo].[Rubric.CriterionLevel] ENABLE TRIGGER [trgRubricCriterionLevelAfterInsert]
GO


Create TRIGGER [dbo].[trgRubricCriterionLevelAfterDelete] ON  [dbo].[Rubric.CriterionLevel]
FOR DELETE
AS  
BEGIN
     -- delete the entity
		DELETE a	
			FROM [dbo].[Entity] a
			inner join Deleted d on a.EntityUid = d.RowId

END
GO

ALTER TABLE [dbo].[Rubric.CriterionLevel] ENABLE TRIGGER [trgRubricCriterionLevelAfterDelete]
GO



