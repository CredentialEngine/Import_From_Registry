

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
Modifcations
23-09-27 mparsons - new
*/

Create TRIGGER [dbo].[trgRubricAfterInsert] ON  [dbo].[Rubric]
FOR INSERT
AS  
    INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
		   ,EntityBaseId, EntityBaseName)
    SELECT RowId, 39, getdate(), Id, IsNull(Name,'Rubric')  as Name
    FROM inserted;
GO

ALTER TABLE [dbo].[Rubric] ENABLE TRIGGER [trgRubricAfterInsert]
GO


Create TRIGGER [dbo].[trgRubricAfterDelete] ON  [dbo].[Rubric]
FOR DELETE
AS  
BEGIN
     -- delete the entity
		DELETE a	
			FROM [dbo].[Entity] a
			inner join Deleted d on a.EntityUid = d.RowId

END
GO

ALTER TABLE [dbo].[Rubric] ENABLE TRIGGER [trgRubricAfterDelete]
GO
