

/****** Object:  Trigger [dbo].[trgOrganizationBeforeDelete]    Script Date: 8/17/2017 3:04:05 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Create date: 16-09-20
-- Description:	
--	Deletes are typically triggered from entity frameworks code. 
--	Tables like Entity are not removed via Referencial Integrity. 
--	The latter will be deleted, and then the Organization
-- =============================================


Alter TRIGGER [dbo].[trgOrganizationBeforeDelete]
ON [dbo].[Organization]
INSTEAD OF DELETE
AS
BEGIN

     -- Some code you want to do before delete
		DELETE a	
			FROM [dbo].[Entity] a
			inner join Deleted d on a.EntityUid = d.RowId

			DELETE a	
			FROM [dbo].[Entity_Cache] a
			inner join Deleted d on a.EntityUid = d.RowId

		 -- do the delete
     DELETE Organization
     FROM DELETED D
     INNER JOIN dbo.Organization T ON T.Id = D.Id
END

GO


