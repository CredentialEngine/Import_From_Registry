

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
Modifcations
23-09-27 mparsons - new
*/

Create TRIGGER [dbo].[trgRubricCriterionAfterInsert] ON  [dbo].[RubricCriterion]
FOR INSERT
AS  
    INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
		   ,EntityBaseId, EntityBaseName)
    SELECT RowId, 44, getdate(), Id, IsNull(Name,'RubricCriterion')  as Name
    FROM inserted;
GO

ALTER TABLE [dbo].[RubricCriterion] ENABLE TRIGGER [trgRubricCriterionAfterInsert]
GO


Create TRIGGER [dbo].[trgRubricCriterionAfterDelete] ON  [dbo].[RubricCriterion]
FOR DELETE
AS  
BEGIN
     -- delete the entity
		DELETE a	
			FROM [dbo].[Entity] a
			inner join Deleted d on a.EntityUid = d.RowId

END
GO

ALTER TABLE [dbo].[RubricCriterion] ENABLE TRIGGER [trgRubricCriterionAfterDelete]
GO



