
/****** Object:  Trigger [dbo].[trgCompetencyFrameworkAfterInsert]    Script Date: 2/27/2020 6:16:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Alter TRIGGER [dbo].[trgCompetencyFrameworkAfterInsert] ON  [dbo].[CompetencyFramework]
FOR INSERT
AS  
    INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
					 ,EntityBaseId, EntityBaseName)
    SELECT RowId,10, getdate(), Id, Name
    FROM inserted;
GO

ALTER TABLE [dbo].[CompetencyFramework] ENABLE TRIGGER [trgCompetencyFrameworkAfterInsert]
GO

CREATE TRIGGER [dbo].[trgCompetencyFrameworkAfterDelete]
ON [dbo].[CompetencyFramework]
   AFTER DELETE
AS
BEGIN

	DELETE a	
		FROM [dbo].[Entity] a
		inner join Deleted d on a.EntityUid = d.RowId

END
GO

ALTER TABLE [dbo].[CompetencyFramework] ENABLE TRIGGER [trgCompetencyFrameworkAfterDelete]
GO


/*
--populate Entity
--do we want all, or only if from registry?
USE [credFinder]
GO


INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
           ,[EntityBaseId]
           ,[EntityBaseName]
           ,[LastUpdated])
SELECT [RowId]
      ,10
	  ,[Created]
      ,[Id]
      ,Name
      ,case when [LastUpdated] is null then created else [LastUpdated] end
     ,ctid
  FROM [dbo].[CompetencyFramework]
  where len(Isnull(ctid, '')) = 39
GO
*/






