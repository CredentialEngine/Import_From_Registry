

/****** Object:  Trigger [dbo].[trgCollectionCompetencyAfterInsert]    Script Date: 1/23/2024 5:45:34 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



ALTER TRIGGER [dbo].[trgCollectionCompetencyAfterInsert] ON  [dbo].[Collection.Competency]
FOR INSERT
AS  
    INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
					 ,EntityBaseId, EntityBaseName)
    SELECT RowId,18, getdate(), Id,  
	case WHEN len(competencyText) < 600 then competencyText else SUBSTRING(competencyText,1,500) end as Name
    FROM inserted;
GO


ALTER TABLE [dbo].[Collection.Competency] ENABLE TRIGGER [trgCollectionCompetencyAfterInsert]
GO

CREATE TRIGGER [dbo].[trgCollectionCompetencyAfterDelete]
ON [dbo].[Collection.Competency]
   AFTER DELETE
AS
BEGIN

	DELETE a	
		FROM [dbo].[Entity] a
		inner join Deleted d on a.EntityUid = d.RowId

END
GO
ALTER TABLE [dbo].[Collection.Competency] ENABLE TRIGGER [trgCollectionCompetencyAfterDelete]
GO

