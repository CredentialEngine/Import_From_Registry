
/****** Object:  Trigger [dbo].[trgConceptSchemeConceptAfterInsert]    Script Date: 1/23/2024 5:21:02 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




CREATE TRIGGER [dbo].[trgConceptSchemeConceptAfterInsert] ON  [dbo].[ConceptScheme.Concept]
FOR INSERT
AS  
    INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
					 ,EntityBaseId, EntityBaseName)
    SELECT RowId,29, getdate(), Id, PrefLabel
    FROM inserted;
GO

ALTER TABLE [dbo].[ConceptScheme.Concept] ENABLE TRIGGER [trgConceptSchemeConceptAfterInsert]
GO


/*
Need to use an after delete trigger, as there is a cascading delete on this table
*/

CREATE TRIGGER [dbo].[trgConceptSchemeConceptAfterDelete]
ON [dbo].[ConceptScheme.Concept]
   AFTER DELETE
AS
BEGIN

	DELETE a	
		FROM [dbo].[Entity] a
		inner join Deleted d on a.EntityUid = d.RowId

END
GO

ALTER TABLE [dbo].[ConceptScheme.Concept] ENABLE TRIGGER [trgConceptSchemeConceptAfterDelete]
GO

