
/****** Object:  Trigger [dbo].[trgCredentialingActionAfterInsert]    Script Date: 11/2/2023 7:14:20 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Create TRIGGER [dbo].[trgCredentialingActionAfterInsert] ON   [dbo].[CredentialingAction]
FOR INSERT
AS  
Begin
    INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
		,EntityBaseId, EntityBaseName)
    SELECT RowId,22, getdate(), Id, 'CredentialingAction: ' + convert(varchar(25), IsNull(ActionTypeId,0))
    FROM inserted;
End
GO

ALTER TABLE [dbo].[CredentialingAction] ENABLE TRIGGER [trgCredentialingActionAfterInsert]
GO


