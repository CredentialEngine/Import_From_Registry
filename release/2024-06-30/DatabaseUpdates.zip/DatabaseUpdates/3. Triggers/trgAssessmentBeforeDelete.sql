

/****** Object:  Trigger [dbo].[trgAssessmentBeforeDelete]    Script Date: 10/29/2017 8:56:36 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Create date: 2017-03-13
-- Description:	Delete the related Entity before deleting actual record
-- =============================================

Alter TRIGGER [dbo].[trgAssessmentBeforeDelete]
ON [dbo].[Assessment]
INSTEAD OF DELETE
AS
BEGIN

     -- Some code you want to do before delete
		DELETE a	
			FROM [dbo].[Entity] a
			inner join Deleted d on a.EntityUid = d.RowId
		DELETE a	
			FROM [dbo].[Entity_Cache] a
			inner join Deleted d on a.EntityUid = d.RowId

		 -- do the delete
     DELETE Assessment
     FROM DELETED D
     INNER JOIN dbo.Assessment T ON T.Id = D.Id
END

GO


