

-- add Codes.CredentialingActionType and populate 

/****** Object:  Table [dbo].[Codes.CredentialingActionType]    Script Date: 11/10/2023 10:47:34 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- create the table
CREATE TABLE [dbo].[Codes.CredentialingActionType](
	[Id] [int] NOT NULL,
	Name [varchar](100) NOT NULL,
	[Description] [varchar](500) NULL,
	[IsActive] [bit] NULL,
	[SchemaName] [varchar](200) NULL,
	[Created] [datetime] NULL,
	[Totals] [int] NULL,
 CONSTRAINT [PK_Codes.CredentialingActionType] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Codes.CredentialingActionType] ADD  CONSTRAINT [DF_Codes.CredentialingActionType_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO

ALTER TABLE [dbo].[Codes.CredentialingActionType] ADD  CONSTRAINT [DF_Codes.CredentialingActionType_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Codes.CredentialingActionType] ADD  CONSTRAINT [DF_Codes.CredentialingActionType_Totals]  DEFAULT ((0)) FOR [Totals]
GO


--populate
USE [credFinder_Petersons]
GO

INSERT INTO [dbo].[Codes.CredentialingActionType]
           ([Id],[Name],[Description]
           ,[IsActive],[SchemaName],[Created],[Totals])
     VALUES
           (1 ,'Accredit Action'
           ,'Action by an independent, neutral, and authoritative agent that certifies an entity as meeting a prescribed set of standards.'
           ,1 ,'ceterms:AccreditAction'
			,GETDATE() ,0
		   )
GO
-- 

INSERT INTO [dbo].[Codes.CredentialingActionType]
           ([Id],[Name],[Description]
           ,[IsActive],[SchemaName],[Created],[Totals])
VALUES
           (2 ,'Advanced Standing Action'
           ,'Claim by an agent asserting that the object credential of the action provides advanced standing for a credential under the asserting agent''s authority.'
           ,1 ,'ceterms:AdvancedStandingAction'           ,GETDATE()  ,0
		   )
GO


INSERT INTO [dbo].[Codes.CredentialingActionType]
           ([Id],[Name],[Description]
           ,[IsActive],[SchemaName],[Created],[Totals])
VALUES
           (3 ,'Approve Action'
           ,'Action by an independent, neutral, and authoritative agent that pronounces a favorable judgment of a credential.'
           ,1 ,'ceterms:ApproveAction'
           ,GETDATE() ,0 
		   )
GO

INSERT INTO [dbo].[Codes.CredentialingActionType]
           ([Id],[Name],[Description]
           ,[IsActive],[SchemaName],[Created],[Totals])
VALUES
           (4 ,'Credentialing Action'
           ,'Action taken by an agent affecting the status of an object entity.'
           ,1 ,'ceterms:CredentialingAction'
           ,GETDATE()  ,0
		   )
GO

INSERT INTO [dbo].[Codes.CredentialingActionType]
           ([Id],[Name],[Description]
           ,[IsActive],[SchemaName],[Created],[Totals])
VALUES
           (5 ,'Offer Action'
           ,'Action by an authoritative agent offering access to a entity such as a credential, learning opportunity or assessment.'
           ,1 ,'ceterms:OfferAction'
           ,GETDATE() ,0
		   )
GO

INSERT INTO [dbo].[Codes.CredentialingActionType]
           ([Id],[Name],[Description]
           ,[IsActive],[SchemaName],[Created],[Totals])
VALUES
           (6 ,'Recognize Action'
           ,'Action by an independent, neutral, and authoritative agent acknowledging the validity of a resource.'
           ,1 ,'ceterms:RecognizeAction'
           ,GETDATE()  ,0
		   )
GO

INSERT INTO [dbo].[Codes.CredentialingActionType]
           ([Id],[Name],[Description]
           ,[IsActive],[SchemaName],[Created],[Totals])
VALUES
           (7 ,'Regulate Action'
           ,'Action by an independent, neutral, and authoritative agent enforcing the legal requirements of a resource.'
           ,1 ,'ceterms:RegulateAction'
           ,GETDATE()  ,0
		   )
GO

INSERT INTO [dbo].[Codes.CredentialingActionType]
           ([Id],[Name],[Description]
           ,[IsActive],[SchemaName],[Created],[Totals])
VALUES
           (8 ,'Renew Action'
           ,'Action by an agent renewing an existing credential assertion.'
           ,1 ,'ceterms:RenewAction'
           ,GETDATE() ,0
		   )
GO


INSERT INTO [dbo].[Codes.CredentialingActionType]
           ([Id],[Name],[Description]
           ,[IsActive],[SchemaName],[Created],[Totals])
VALUES
           (9 ,'Revoke Action'
           ,'Action by an agent removing an awarded credential (credential assertion) from the credential holder based on violations or failure of the holder to renew.'
           ,1 ,'ceterms:RevokeAction'
           ,GETDATE() ,0
		   )
GO

INSERT INTO [dbo].[Codes.CredentialingActionType]
           ([Id],[Name],[Description]
           ,[IsActive],[SchemaName],[Created],[Totals])
VALUES
           (10 ,'Rights Action'
           ,'Action asserting legal rights by an agent to possess, defend, transfer, license, and grant conditional access to a credential, learning opportunity, or assessment.'
           ,1 ,'ceterms:RightsAction'
           ,GETDATE() ,0
		   )
GO

INSERT INTO [dbo].[Codes.CredentialingActionType]
           ([Id],[Name],[Description]
           ,[IsActive],[SchemaName],[Created],[Totals])
VALUES
           (11 ,'Workforce Demand Action'
           ,'Action taken by an agent asserting that the resource being described has a workforce demand level worthy of note.'
           ,1 ,'ceterms::WorkforceDemandAction'
           ,GETDATE()  ,0
		   )
GO


INSERT INTO [dbo].[Codes.CredentialingActionType]
           ([Id]
           ,[Name]
           ,[Description]
           ,[IsActive]
           ,[SchemaName]
           ,[Created]
           ,[Totals])
     VALUES
           (12,'Registration Action'
           ,'Action by an independent, neutral, and authoritative agent that registers a resource that has been vetted, approved, and validated to meet specific criteria.'
           ,1
           ,'ceterms:RegistrationAction'
           ,getdate()
           ,0)
GO

