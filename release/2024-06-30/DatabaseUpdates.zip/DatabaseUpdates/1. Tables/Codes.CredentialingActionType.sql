
-- add Codes.CredentialingActionType and populate 
-- 24-02-06 - add RegistrationAction 


/****** Object:  Table [dbo].[Codes.CredentialingActionType]    Script Date: 11/10/2023 10:47:34 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
CREATE TABLE [dbo].[Codes.CredentialingActionType](
	[Id] [int] NOT NULL,
	Name [varchar](100) NOT NULL,
	[Description] [varchar](500) NULL,
	[IsActive] [bit] NULL,
	[SchemaName] [varchar](200) NULL,
	[Created] [datetime] NULL,
	[Totals] [int] NULL,
 CONSTRAINT [PK_Codes.CredentialingActionType] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Codes.CredentialingActionType] ADD  CONSTRAINT [DF_Codes.CredentialingActionType_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO

ALTER TABLE [dbo].[Codes.CredentialingActionType] ADD  CONSTRAINT [DF_Codes.CredentialingActionType_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Codes.CredentialingActionType] ADD  CONSTRAINT [DF_Codes.CredentialingActionType_Totals]  DEFAULT ((0)) FOR [Totals]
GO

INSERT INTO [dbo].[Codes.CredentialingActionType]
           ([Id]
           ,[Name]
           ,[Description]
           ,[IsActive]
           ,[SchemaName]
           ,[Created]
           ,[Totals])
Select ROW_NUMBER() OVER( order by id ) as Id
,Title, Description, 1, SchemaName, Created, 0
  FROM [sandbox_credFinder].[dbo].[Codes.PropertyValue]
  where CategoryId = 26

GO
--fixes 
  --:Workforce Demand Action
  update [Codes.CredentialingActionType]
  set name = 'Workforce Demand Action'
  where id = 11
  go

    update [Codes.CredentialingActionType]
  set IsActive = 0
  where id = 4

  */

    --:Workforce Demand Action
  update [Codes.CredentialingActionType]
  set name = 'Workforce Demand Action',
  SchemaName = 'ceterms:WorkforceDemandAction'
  where id = 11
  go

INSERT INTO [dbo].[Codes.CredentialingActionType]
           ([Id]
           ,[Name]
           ,[Description]
           ,[IsActive]
           ,[SchemaName]
           ,[Created]
           ,[Totals])
     VALUES
           (12,'Registration Action'
           ,'Action by an independent, neutral, and authoritative agent that registers a resource that has been vetted, approved, and validated to meet specific criteria.'
           ,1
           ,'ceterms:RegistrationAction'
           ,getdate()
           ,0)
GO

