
/****** Object:  Table [dbo].[DataProfile.QuantitativeValue]    Script Date: 11/20/2023 9:52:00 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
Drop TABLE [dbo].[DataProfile.QuantitativeValue]
go
*/
--could blend monetaryAmount as well?
CREATE TABLE [dbo].[DataProfile.QuantitativeValue]
(
	[Id] [int] IDENTITY(1,1) NOT NULL,
	--[EntityId] [int] NOT NULL,
	[DataProfileId] [int] NOT NULL,
	--or should this be a codeId?
	[PropertyName] [varchar](50) NULL,
	[UnitTypeId] [int] NULL,
	[UnitText] [nvarchar](100) NULL,
	[Value] [decimal](9, 2) NULL,
	[MinValue] [decimal](9, 2) NULL,
	[MaxValue] [decimal](9, 2) NULL,
	[Description] [nvarchar](max) NULL,
	--[Created] [datetime] NOT NULL,
	--[LastUpdated] [datetime] NOT NULL,
	--?????????
	[RowId] [uniqueidentifier] NOT NULL,
	--consider if could store the content in delimited format for easy export?
	DelimitedSummary [nvarchar](max) NULL,
 CONSTRAINT [PK_DataProfile.QuantitativeValue] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

--ALTER TABLE [dbo].[DataProfile.QuantitativeValue] ADD  CONSTRAINT [DF_DataProfile.QuantitativeValue_Created]  DEFAULT (getdate()) FOR [Created]
--GO

--ALTER TABLE [dbo].[DataProfile.QuantitativeValue] ADD  CONSTRAINT [DF_DataProfile.QuantitativeValue_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
--GO

ALTER TABLE [dbo].[DataProfile.QuantitativeValue] ADD  CONSTRAINT [DF_DataProfile.QuantitativeValue_RowId]  DEFAULT (newid()) FOR [RowId]
GO

--ALTER TABLE [dbo].[DataProfile.QuantitativeValue]  WITH CHECK ADD  CONSTRAINT [FK_Entity.QuantitativeValue_Entity] FOREIGN KEY([EntityId])
--REFERENCES [dbo].[Entity] ([Id])
--ON UPDATE CASCADE
--ON DELETE CASCADE
--GO

--ALTER TABLE [dbo].[DataProfile.QuantitativeValue] CHECK CONSTRAINT [DF_DataProfile.QuantitativeValue_Entity]
--GO


