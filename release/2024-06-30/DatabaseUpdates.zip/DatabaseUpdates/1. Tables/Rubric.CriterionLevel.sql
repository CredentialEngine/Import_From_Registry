
/****** Object:  Table [dbo].[Rubric.CriterionLevel]    Script Date: 1/10/2024 12:39:58 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
--		DROP TABLE [dbo].[Rubric.CriterionLevel]

CREATE TABLE [dbo].[Rubric.CriterionLevel]
(
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[RowId] [uniqueidentifier] NOT NULL,
	[RubricId] [int] NOT NULL,

	[BenchmarkLabel] [nvarchar](500) NOT NULL,
	[BenchmarkText] [nvarchar](max) NULL,
	[CodedNotation] [varchar](100) NULL,
	[Feedback] [nvarchar](max) NULL,
	[IsBinaryEvaluation] [bit] NULL,
	[ListID] [nvarchar](200) NULL,
	[Value] [decimal](7, 2) NULL,
	[MinValue] [decimal](7, 2) NULL,
	[MaxValue] [decimal](7, 2) NULL,
	[Percentage] [decimal](5, 2) NULL,
	[MinPercentage] [decimal](5, 2) NULL,
	[MaxPercentage] [decimal](5, 2) NULL,

	[Created] [datetime] NULL,
	[LastUpdated] [datetime] NULL,
 CONSTRAINT [PK_Rubric.CriterionLevel] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[Rubric.CriterionLevel] ADD  CONSTRAINT [DF_Rubric.CriterionLevel_RowId]  DEFAULT (newid()) FOR [RowId]
GO

ALTER TABLE [dbo].[Rubric.CriterionLevel] ADD  CONSTRAINT [DF_Rubric.CriterionLevel_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Rubric.CriterionLevel] ADD  CONSTRAINT [DF_Rubric.CriterionLevel_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO




