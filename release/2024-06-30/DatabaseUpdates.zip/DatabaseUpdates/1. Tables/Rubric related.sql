
use [credFinder_Petersons]
go


/****** Object:  Table [dbo].[Rubric]    Script Date: 6/28/2024 10:17:13 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Rubric](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[RowId] [uniqueidentifier] NOT NULL,
	[Name] [nvarchar](800) NOT NULL,
	[Description] [nvarchar](max) NULL,
	[EntityStateId] [int] NOT NULL,
	[CTID] [varchar](50) NULL,
	[PrimaryAgentUID] [uniqueidentifier] NULL,
	[SubjectWebpage] [varchar](500) NULL,
	[Creator] [uniqueidentifier] NULL,
	[AltCodedNotation] [varchar](500) NULL,
	[CodedNotation] [varchar](100) NULL,
	[ConceptKeyword] [nvarchar](max) NULL,
	[DateCopyrighted] [datetime] NULL,
	[DateCreated] [datetime] NULL,
	[DateModified] [datetime] NULL,
	[DateValidFrom] [datetime] NULL,
	[DateValidUntil] [datetime] NULL,
	[DerivedFrom] [varchar](max) NULL,
	[Identifier] [nvarchar](max) NULL,
	[InLanguage] [nvarchar](1000) NULL,
	[LatestVersion] [varchar](500) NULL,
	[PreviousVersion] [varchar](500) NULL,
	[NextVersion] [varchar](500) NULL,
	[License] [varchar](500) NULL,
	[LifeCycleStatusTypeId] [int] NULL,
	[Publisher] [uniqueidentifier] NULL,
	[PublisherName] [nvarchar](1000) NULL,
	[Rights] [nvarchar](max) NULL,
	[Subject] [nvarchar](max) NULL,
	[VersionIdentifier] [nvarchar](max) NULL,
	[Created] [datetime] NULL,
	[LastUpdated] [datetime] NULL,
	[JsonProperties] [nvarchar](max) NULL,
	[HasCriterionCategorySet] [uniqueidentifier] NULL,
	[HasProgressionModel] [uniqueidentifier] NULL,
	[HasProgressionLevel] [nvarchar](max) NULL,
	[HasScope] [nvarchar](max) NULL,
	[InCatalog] [nvarchar](max) NULL,
 CONSTRAINT [PK_Rubric] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [IX_Rubric_CTID] UNIQUE NONCLUSTERED 
(
	[CTID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[Rubric] ADD  CONSTRAINT [DF_Rubric_RowId]  DEFAULT (newid()) FOR [RowId]
GO

ALTER TABLE [dbo].[Rubric] ADD  CONSTRAINT [DF_Rubric_EntityStateId]  DEFAULT ((1)) FOR [EntityStateId]
GO

ALTER TABLE [dbo].[Rubric] ADD  CONSTRAINT [DF_Rubric_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Rubric] ADD  CONSTRAINT [DF_Rubric_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO


/****** Object:  Table [dbo].[Rubric.CriterionLevel]    Script Date: 6/28/2024 10:17:27 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Rubric.CriterionLevel](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[RowId] [uniqueidentifier] NOT NULL,
	[RubricId] [int] NOT NULL,
	[BenchmarkLabel] [varchar](500) NULL,
	[BenchmarkText] [nvarchar](max) NULL,
	[CodedNotation] [varchar](100) NULL,
	[Feedback] [nvarchar](max) NULL,
	[IsBinaryEvaluation] [bit] NULL,
	[ListID] [nvarchar](200) NULL,
	[Value] [decimal](7, 2) NULL,
	[MinValue] [decimal](7, 2) NULL,
	[MaxValue] [decimal](7, 2) NULL,
	[Percentage] [decimal](5, 2) NULL,
	[MinPercentage] [decimal](5, 2) NULL,
	[MaxPercentage] [decimal](5, 2) NULL,
	[Created] [datetime] NULL,
	[LastUpdated] [datetime] NULL,
 CONSTRAINT [PK_Rubric.CriterionLevel] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[Rubric.CriterionLevel] ADD  CONSTRAINT [DF_Rubric.CriterionLevel_RowId]  DEFAULT (newid()) FOR [RowId]
GO

ALTER TABLE [dbo].[Rubric.CriterionLevel] ADD  CONSTRAINT [DF_Rubric.CriterionLevel_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Rubric.CriterionLevel] ADD  CONSTRAINT [DF_Rubric.CriterionLevel_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO

ALTER TABLE [dbo].[Rubric.CriterionLevel]  WITH CHECK ADD  CONSTRAINT [FK_Rubric.CriterionLevel_Rubric] FOREIGN KEY([RubricId])
REFERENCES [dbo].[Rubric] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Rubric.CriterionLevel] CHECK CONSTRAINT [FK_Rubric.CriterionLevel_Rubric]
GO

/****** Object:  Table [dbo].[RubricCriterion]    Script Date: 6/28/2024 10:19:44 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[RubricCriterion](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[RowId] [uniqueidentifier] NOT NULL,
	[RubricId] [int] NOT NULL,
	[Name] [nvarchar](800) NOT NULL,
	[Description] [nvarchar](max) NULL,
	[CTID] [varchar](50) NOT NULL,
	[CodedNotation] [varchar](100) NULL,
	[ListID] [varchar](100) NULL,
	[HasProgressionLevel] [varchar](500) NULL,
	[Weight] [decimal](5, 2) NULL,
	[Created] [datetime] NULL,
	[LastUpdated] [datetime] NULL,
	[TargetCompetency] [nvarchar](max) NULL,
 CONSTRAINT [PK_RubricCriterion] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[RubricCriterion] ADD  CONSTRAINT [DF_RubricCriterion_RowId]  DEFAULT (newid()) FOR [RowId]
GO

ALTER TABLE [dbo].[RubricCriterion] ADD  CONSTRAINT [DF_RubricCriterion_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[RubricCriterion] ADD  CONSTRAINT [DF_RubricCriterion_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO

ALTER TABLE [dbo].[RubricCriterion]  WITH CHECK ADD  CONSTRAINT [FK_RubricCriterion_Rubric] FOREIGN KEY([RubricId])
REFERENCES [dbo].[Rubric] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[RubricCriterion] CHECK CONSTRAINT [FK_RubricCriterion_Rubric]
GO



/****** Object:  Table [dbo].[RubricLevel]    Script Date: 9/29/2023 12:40:07 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[RubricLevel](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[RowId] [uniqueidentifier] NOT NULL,
	[RubricId] [int] NOT NULL,
	[Name] [nvarchar](800) NOT NULL,
	[Description] [nvarchar](max) NULL,
	[ListID] [nvarchar](200) NULL,
	[CodedNotation] [varchar](100) NULL,
	[HasProgressionLevel] [varchar](500) NULL,
	[Created] [datetime] NULL,
	[LastUpdated] [datetime] NULL,
 CONSTRAINT [PK_RubricLevel] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[RubricLevel] ADD  CONSTRAINT [DF_RubricLevel_RowId]  DEFAULT (newid()) FOR [RowId]
GO

ALTER TABLE [dbo].[RubricLevel] ADD  CONSTRAINT [DF_RubricLevel_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[RubricLevel] ADD  CONSTRAINT [DF_RubricLevel_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO

ALTER TABLE [dbo].[RubricLevel]  WITH CHECK ADD  CONSTRAINT [FK_RubricLevel_Rubric] FOREIGN KEY([RubricId])
REFERENCES [dbo].[Rubric] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[RubricLevel] CHECK CONSTRAINT [FK_RubricLevel_Rubric]
GO




/****** Object:  Table [dbo].[Entity.CriterionLevel]    Script Date: 9/29/2023 12:53:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Entity.CriterionLevel](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[RowId] [uniqueidentifier] NOT NULL,
	[EntitId] [int] NOT NULL,
	[BenchmarkLabel] [nvarchar](500) NOT NULL,
	[BenchmarkText] [nvarchar](max) NULL,
	[CodedNotation] [varchar](100) NULL,
	[Feedback] [nvarchar](max) NULL,
	[IsBinaryEvaluation] [bit] NULL,
	[ListID] [nvarchar](200) NULL,
	[Value] [decimal](7, 2) NULL,
	[MinValue] [decimal](7, 2) NULL,
	[MaxValue] [decimal](7, 2) NULL,
	[Percentage] [decimal](5, 2) NULL,
	[MinPercentage] [decimal](5, 2) NULL,
	[MaxPercentage] [decimal](5, 2) NULL,
	[Created] [datetime] NULL,
	[LastUpdated] [datetime] NULL,
 CONSTRAINT [PK_Entity.CriterionLevel] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[Entity.CriterionLevel] ADD  CONSTRAINT [DF_Entity.CriterionLevel_RowId]  DEFAULT (newid()) FOR [RowId]
GO

ALTER TABLE [dbo].[Entity.CriterionLevel] ADD  CONSTRAINT [DF_Entity.CriterionLevel_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Entity.CriterionLevel] ADD  CONSTRAINT [DF_Entity.CriterionLevel_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO

ALTER TABLE [dbo].[Entity.CriterionLevel]  WITH CHECK ADD  CONSTRAINT [FK_Entity.CriterionLevel_Entity] FOREIGN KEY([EntitId])
REFERENCES [dbo].[Entity] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Entity.CriterionLevel] CHECK CONSTRAINT [FK_Entity.CriterionLevel_Entity]
GO



/****** Object:  Table [dbo].[Entity.HasCriterionLevel]    Script Date: 1/10/2024 1:28:50 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Entity.HasCriterionLevel](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[RowId] [uniqueidentifier] NOT NULL,
	[EntityId] [int] NOT NULL,
	[CriterionLevelId] [int] NOT NULL,
	[Created] [datetime] NULL,
	[CreatedById] [int] NULL,
 CONSTRAINT [PK_Entity.HasCriterionLevel] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Entity.HasCriterionLevel] ADD  CONSTRAINT [DF_Entity.HasCriterionLevel_RowId]  DEFAULT (newid()) FOR [RowId]
GO

ALTER TABLE [dbo].[Entity.HasCriterionLevel] ADD  CONSTRAINT [DF_Entity.HasCriterionLevel_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Entity.HasCriterionLevel]  WITH CHECK ADD  CONSTRAINT [FK_Entity.HasCriterionLevel_Entity] FOREIGN KEY([EntityId])
REFERENCES [dbo].[Entity] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Entity.HasCriterionLevel] CHECK CONSTRAINT [FK_Entity.HasCriterionLevel_Entity]
GO

ALTER TABLE [dbo].[Entity.HasCriterionLevel]  WITH CHECK ADD  CONSTRAINT [FK_Entity.HasCriterionLevel_Rubric.CriterionLevel] FOREIGN KEY([CriterionLevelId])
REFERENCES [dbo].[Rubric.CriterionLevel] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Entity.HasCriterionLevel] CHECK CONSTRAINT [FK_Entity.HasCriterionLevel_Rubric.CriterionLevel]
GO

