
/****** Object:  Table [dbo].[Rubric]    Script Date: 12/12/2023 11:51:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
DROP TABLE [dbo].[Rubric]
GO
*/
CREATE TABLE [dbo].[Rubric](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[RowId] [uniqueidentifier] NOT NULL,
	[Name] [nvarchar](800) NOT NULL,
	[Description] [nvarchar](max) NULL,
	[EntityStateId] [int] NOT NULL,
	[CTID] [varchar](50) NULL,
	[PrimaryAgentUID] [uniqueidentifier] NULL,
	[SubjectWebpage] [varchar](500) NULL,
	[Creator] [uniqueidentifier] NULL,
	[AltCodedNotation] [varchar](500) NULL,
	[CodedNotation] [varchar](100) NULL,
	[ConceptKeyword] [nvarchar](max) NULL,
	[DateCopyrighted] [datetime] NULL,
	[DateCreated] [datetime] NULL,
	[DateModified] [datetime] NULL,
	[DateValidFrom] [datetime] NULL,
	[DateValidUntil] [datetime] NULL,
	[DerivedFrom] [varchar](max) NULL,
	[Identifier] [nvarchar](max) NULL,
	[InLanguage] [nvarchar](1000) NULL,
	[LatestVersion] [varchar](500) NULL,
	[PreviousVersion] [varchar](500) NULL,
	[NextVersion] [varchar](500) NULL,
	[License] [varchar](500) NULL,
	[LifeCycleStatusTypeId] [int] NULL,
	[Publisher] [uniqueidentifier] NULL,
	[PublisherName] [nvarchar](1000) NULL,
	[Rights] [nvarchar](max) NULL,
	[Subject] [nvarchar](max) NULL,
	[VersionIdentifier] [nvarchar](max) NULL,
	[Created] [datetime] NULL,
	[LastUpdated] [datetime] NULL,
	[JsonProperties] [nvarchar](max) NULL,
 CONSTRAINT [PK_Rubric] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [IX_Rubric_CTID] UNIQUE NONCLUSTERED 
(
	[CTID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[Rubric] ADD  CONSTRAINT [DF_Rubric_RowId]  DEFAULT (newid()) FOR [RowId]
GO

ALTER TABLE [dbo].[Rubric] ADD  CONSTRAINT [DF_Rubric_EntityStateId]  DEFAULT ((1)) FOR [EntityStateId]
GO

ALTER TABLE [dbo].[Rubric] ADD  CONSTRAINT [DF_Rubric_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Rubric] ADD  CONSTRAINT [DF_Rubric_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO


