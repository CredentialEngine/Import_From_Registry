

--ALTER TABLE [dbo].[CredentialingAction] DROP CONSTRAINT [FK_CredentialingAction_Codes.PropertyValue]
--GO

--ALTER TABLE [dbo].[CredentialingAction] DROP CONSTRAINT [DF_CredentialingAction_LastUpdated]
--GO

--ALTER TABLE [dbo].[CredentialingAction] DROP CONSTRAINT [DF_CredentialingAction_Created]
--GO

--ALTER TABLE [dbo].[CredentialingAction] DROP CONSTRAINT [DF_CredentialingAction_EntityStateId]
--GO

--ALTER TABLE [dbo].[CredentialingAction] DROP CONSTRAINT [DF_CredentialingAction_RowId]
--GO

--/****** Object:  Table [dbo].[CredentialingAction]    Script Date: 11/10/2023 5:08:42 PM ******/
--IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CredentialingAction]') AND type in (N'U'))
--DROP TABLE [dbo].[CredentialingAction]
--GO

/****** Object:  Table [dbo].[CredentialingAction]    Script Date: 11/10/2023 5:08:42 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CredentialingAction](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[RowId] [uniqueidentifier] NOT NULL,
	[CTID] [varchar](50) NULL,
	[EntityStateId] [int] NOT NULL,
	[ActionTypeId] [int] NOT NULL,
	[Name] [nvarchar](400) NOT NULL,
	[Description] [nvarchar](max) NOT NULL,
	[ActingAgentUid] [uniqueidentifier] NOT NULL,
	[ActionStatusTypeId] [int] NULL,
	[StartDate] [varchar](50) NULL,
	[EndDate] [varchar](50) NULL,
	[EvidenceOfAction] [nvarchar](max) NULL,
	[ResultingAward] [nvarchar](max) NULL,
	[Created] [datetime] NULL,
	[LastUpdated] [datetime] NULL,
 CONSTRAINT [PK_CredentialingAction] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[CredentialingAction] ADD  CONSTRAINT [DF_CredentialingAction_RowId]  DEFAULT (newid()) FOR [RowId]
GO

ALTER TABLE [dbo].[CredentialingAction] ADD  CONSTRAINT [DF_CredentialingAction_EntityStateId]  DEFAULT ((1)) FOR [EntityStateId]
GO

ALTER TABLE [dbo].[CredentialingAction] ADD  CONSTRAINT [DF_CredentialingAction_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[CredentialingAction] ADD  CONSTRAINT [DF_CredentialingAction_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO

ALTER TABLE [dbo].[CredentialingAction]  WITH CHECK ADD  CONSTRAINT [FK_CredentialingAction_Codes.PropertyValue] FOREIGN KEY([ActionStatusTypeId])
REFERENCES [dbo].[Codes.PropertyValue] ([Id])
GO

ALTER TABLE [dbo].[CredentialingAction] CHECK CONSTRAINT [FK_CredentialingAction_Codes.PropertyValue]
GO


