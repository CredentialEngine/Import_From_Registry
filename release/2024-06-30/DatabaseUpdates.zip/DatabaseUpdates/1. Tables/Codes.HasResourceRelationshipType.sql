
/****** Object:  Table [dbo].[Codes.HasResourceRelationshipType]    Script Date: 2/18/2024 12:24:35 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Codes.HasResourceRelationshipType]') AND type in (N'U'))
DROP TABLE [dbo].[Codes.HasResourceRelationshipType]
GO

*/

-- create the table 
CREATE TABLE [dbo].[Codes.HasResourceRelationshipType](
	[Id] [int] NOT NULL,
	[Name] [varchar](100) NOT NULL,
	[Description] [varchar](500) NULL,
	[IsActive] [bit] NULL,
	[SchemaName] [varchar](200) NULL,
	[Created] [datetime] NULL,
	[Totals] [int] NULL,
 CONSTRAINT [PK_Codes.HasResourceRelationshipType] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Codes.HasResourceRelationshipType] ADD  CONSTRAINT [DF_Codes.HasResourceRelationshipType_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO

ALTER TABLE [dbo].[Codes.HasResourceRelationshipType] ADD  CONSTRAINT [DF_Codes.HasResourceRelationshipType_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Codes.HasResourceRelationshipType] ADD  CONSTRAINT [DF_Codes.HasResourceRelationshipType_Totals]  DEFAULT ((0)) FOR [Totals]
GO

-- populate the table 

INSERT INTO [dbo].[Codes.HasResourceRelationshipType]
           (Id, [Name] ,[Description] 
		   ,[IsActive] ,[SchemaName],[Created] ,[Totals] )
     VALUES
           (1 ,'Has Resource' ,'Default relationship. Typically used where the parent resource only has one resource type - but not very future proof.'
           ,1 ,'HasResource', GETDATE() ,0
		   )
GO
INSERT INTO [dbo].[Codes.HasResourceRelationshipType]
           (Id, [Name] ,[Description] 
		   ,[IsActive] ,[SchemaName],[Created] ,[Totals] )     VALUES
           (2 ,'Has Specialization' ,'Typically for an occupation (More specialized profession, trade, or career field that is encompassed by the one being described).'
           ,1 ,'HasSpecialization' ,GETDATE() ,0 
		   )
GO
INSERT INTO [dbo].[Codes.HasResourceRelationshipType]
           (Id, [Name] ,[Description] 
		   ,[IsActive] ,[SchemaName],[Created] ,[Totals] )     VALUES
           (3 ,'IsSpecializationOf' ,'this is an inverse, so should not be storing the 3, rather looking up reverse using HasSpecialization??'
           ,1 ,'IsSpecializationOf' ,GETDATE() ,0 
			)

INSERT INTO [dbo].[Codes.HasResourceRelationshipType]
           (Id, [Name] ,[Description] 
		   ,[IsActive] ,[SchemaName],[Created] ,[Totals] )
     VALUES
           (4 ,'Has Target Resource', 'Used with PathwayComponent.'
           ,1 ,'HasTargetResource', GETDATE() ,0
		   )
GO
INSERT INTO [dbo].[Codes.HasResourceRelationshipType]
           (Id, [Name] ,[Description] 
		   ,[IsActive] ,[SchemaName],[Created] ,[Totals] )     VALUES
           (5 ,'AbilityEmbodied' ,'AbilityEmbodied.'
           ,1 ,'AbilityEmbodied' ,GETDATE() ,0 
		   )
GO
INSERT INTO [dbo].[Codes.HasResourceRelationshipType]
           (Id, [Name] ,[Description] 
		   ,[IsActive] ,[SchemaName],[Created] ,[Totals] )     VALUES
           (6 ,'KnowledgeEmbodied' ,'KnowledgeEmbodied'
           ,1 ,'KnowledgeEmbodied' ,GETDATE() ,0 
			)

INSERT INTO [dbo].[Codes.HasResourceRelationshipType]
           (Id, [Name] ,[Description] 
		   ,[IsActive] ,[SchemaName],[Created] ,[Totals] )     VALUES
           (7 ,'SkillEmbodied' ,'SkillEmbodied.'
           ,1 ,'SkillEmbodied' ,GETDATE() ,0 
		   )
GO
INSERT INTO [dbo].[Codes.HasResourceRelationshipType]
           (Id, [Name] ,[Description] 
		   ,[IsActive] ,[SchemaName],[Created] ,[Totals] )     VALUES
           (8 ,'HasChild' ,'HasChild'
           ,1 ,'HasChild' ,GETDATE() ,0 
			)
GO			
INSERT INTO [dbo].[Codes.HasResourceRelationshipType]
           (Id, [Name] ,[Description] 
		   ,[IsActive] ,[SchemaName],[Created] ,[Totals] )     VALUES
           (9 ,'IsChildOf' ,'IsChildOf.'
           ,1 ,'IsChildOf' ,GETDATE() ,0 
		   )
GO

INSERT INTO [dbo].[Codes.HasResourceRelationshipType]
           (Id, [Name] ,[Description] 
		   ,[IsActive] ,[SchemaName],[Created] ,[Totals] )     VALUES
           (10 ,'PhysicalCapabilityType' ,'PhysicalCapabilityType'
           ,1 ,'PhysicalCapabilityType' ,GETDATE() ,0 
			)
GO

INSERT INTO [dbo].[Codes.HasResourceRelationshipType]
           (Id, [Name] ,[Description] 
		   ,[IsActive] ,[SchemaName],[Created] ,[Totals] )     VALUES
           (11 ,'PerformanceLevelType' ,'PerformanceLevelType'
           ,1 ,'PerformanceLevelType' ,GETDATE() ,0 
			)
GO

INSERT INTO [dbo].[Codes.HasResourceRelationshipType]
           (Id, [Name] ,[Description] 
		   ,[IsActive] ,[SchemaName],[Created] ,[Totals] )     VALUES
           (12 ,'EnvironmentalHazardType' ,'EnvironmentalHazardType'
           ,1 ,'EnvironmentalHazardType' ,GETDATE() ,0 
			)
GO

INSERT INTO [dbo].[Codes.HasResourceRelationshipType]
           (Id, [Name] ,[Description] 
		   ,[IsActive] ,[SchemaName],[Created] ,[Totals] )     VALUES
           (13 ,'SensoryCapabiltyType' ,'SensoryCapabiltyType'
           ,1 ,'SensoryCapabiltyType' ,GETDATE() ,0 
			)
GO

INSERT INTO [dbo].[Codes.HasResourceRelationshipType]
           (Id, [Name] ,[Description] 
		   ,[IsActive] ,[SchemaName],[Created] ,[Totals] )     VALUES
           (14 ,'Classification' ,'Classification'
           ,1 ,'Classification' ,GETDATE() ,0 
			)
GO

INSERT INTO [dbo].[Codes.HasResourceRelationshipType]
           (Id, [Name] ,[Description] 
		   ,[IsActive] ,[SchemaName],[Created] ,[Totals] )     VALUES
           (15 ,'ProvidesTransferValueFor' ,'ProvidesTransferValueFor'
           ,1 ,'ProvidesTransferValueFor' ,GETDATE() ,0 
			)
GO

INSERT INTO [dbo].[Codes.HasResourceRelationshipType]
           (Id, [Name] ,[Description] 
		   ,[IsActive] ,[SchemaName],[Created] ,[Totals] )     VALUES
           (16 ,'ReceivesTransferValueFrom' ,'ReceivesTransferValueFrom'
           ,1 ,'ReceivesTransferValueFrom' ,GETDATE() ,0 
			)
GO

INSERT INTO [dbo].[Codes.HasResourceRelationshipType]
           (Id, [Name] ,[Description] 
		   ,[IsActive] ,[SchemaName],[Created] ,[Totals] )     VALUES
           (17 ,'TransferValueFrom' ,'TransferValueFrom'
           ,1 ,'TransferValueFrom' ,GETDATE() ,0 
			)
GO

INSERT INTO [dbo].[Codes.HasResourceRelationshipType]
           (Id, [Name] ,[Description] 
		   ,[IsActive] ,[SchemaName],[Created] ,[Totals] )     VALUES
           (18 ,'TransferValueFor' ,'TransferValueFor'
           ,1 ,'TransferValueFor' ,GETDATE() ,0 
			)
GO



