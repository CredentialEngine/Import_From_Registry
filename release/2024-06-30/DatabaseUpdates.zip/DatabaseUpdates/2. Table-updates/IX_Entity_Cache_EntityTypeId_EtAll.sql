

/*
Missing Index Details from SQLQuery10.sql - MPARSONS-CE2.credFinder (AzureAD\MichaelParsons (70))
The Query Processor estimates that implementing the following index could improve the query cost by 62.9778%.
*/


--
CREATE NONCLUSTERED INDEX [IX_Entity_Cache_EntityTypeId_EtAll]
ON [dbo].[Entity_Cache] ([EntityTypeId])
INCLUDE ([EntityType],[EntityUid],[EntityStateId],[CTID],[parentEntityId],[parentEntityUid],[parentEntityType],[parentEntityTypeId],[BaseId],[Name],[Description],[SubjectWebpage],[OwningOrgId],[ImageUrl],[Created],[LastUpdated],[CacheDate],[PublishedByOrgId],[ResourceDetail],[AgentRelationshipsForEntity],[IsActive])
GO

