
--		2023-10-23 - TVP-add version properties
/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.TransferValueProfile ADD
	LatestVersion varchar(500) NULL,
	PreviousVersion varchar(500) NULL,
	NextVersion varchar(500) NULL,
	VersionIdentifier varchar(500) NULL
GO

ALTER TABLE dbo.TransferValueProfile SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO
--	23-09-18 Add IX_Entity.HasResource_TargetResource

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
CREATE NONCLUSTERED INDEX [IX_Entity.HasResource_TargetResource] ON dbo.[Entity.HasResource]
	(
	EntityTypeId,
	ResourceId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE dbo.[Entity.HasResource] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT-- 23-09-25 Add Properties to Job
GO
/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.JobProfile ADD
	Keyword varchar(500) NULL,
	AlternateName varchar(500) NULL,
	EnvironmentalHazardType varchar(max) NULL,
	PerformanceLevelType varchar(max) NULL,
	PhysicalCapabilityType varchar(max) NULL,
	SensoryCapabilityType varchar(max) NULL
GO

ALTER TABLE dbo.OccupationProfile SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO
-- 23-09-25 Add Properties to Occupation


/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.OccupationProfile ADD
	AlternateName varchar(500) NULL,
	EnvironmentalHazardType varchar(max) NULL,
	PerformanceLevelType varchar(max) NULL,
	PhysicalCapabilityType varchar(max) NULL,
	SensoryCapabilityType varchar(max) NULL
GO

ALTER TABLE dbo.OccupationProfile SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO

--23-09-25 Organization - add SupportServiceStatement, and desc

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.Organization ADD
	SupportServiceStatement varchar(600) NULL,
	SupportServiceStatementDescription nvarchar(MAX) NULL
GO
ALTER TABLE dbo.Organization SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.TaskProfile ADD
	EnvironmentalHazardType varchar(max) NULL,
	PerformanceLevelType varchar(max) NULL,
	PhysicalCapabilityType varchar(max) NULL,
	SensoryCapabilityType varchar(max) NULL
	--AlternateName varchar(500) NULL,
	--ListId varchar(500) NULL
GO

ALTER TABLE dbo.TaskProfile SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO

-- 23-09-27 Add Properties to WorkRole Table

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.WorkRole ADD
	EnvironmentalHazardType varchar(max) NULL,
	PerformanceLevelType varchar(max) NULL,
	PhysicalCapabilityType varchar(max) NULL,
	SensoryCapabilityType varchar(max) NULL,
	AlternateName varchar(500) NULL
GO

ALTER TABLE dbo.WorkRole SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO


IF EXISTS (SELECT 1
               FROM   INFORMATION_SCHEMA.COLUMNS
               WHERE  TABLE_NAME = 'WorkRole'
                      AND COLUMN_NAME = 'ListID'
                      AND TABLE_SCHEMA='DBO')
  BEGIN
      ALTER TABLE dbo.WorkRole
		DROP COLUMN ListID
  END
GO
--	23-10-05 add keyword to Occupation 
/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.OccupationProfile ADD
	Keyword varchar(MAX) NULL
GO
ALTER TABLE dbo.OccupationProfile SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
--	23-10-20 Entity.DurationProfile - chg all to decimal

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Entity.DurationProfile]
	DROP CONSTRAINT [FK_Entity.DurationProfile_Entity1]
GO
ALTER TABLE dbo.Entity SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Entity.DurationProfile]
	DROP CONSTRAINT [DF_Entity.DurationProfile_Created]
GO
ALTER TABLE dbo.[Entity.DurationProfile]
	DROP CONSTRAINT [DF_Entity.DurationProfile_LastUpdated]
GO
CREATE TABLE dbo.[Tmp_Entity.DurationProfile]
	(
	Id int NOT NULL IDENTITY (1, 1),
	EntityId int NULL,
	TypeId int NULL,
	FromYears decimal(7, 2) NULL,
	FromMonths decimal(7, 2) NULL,
	FromWeeks decimal(7, 2) NULL,
	FromDays decimal(7, 2) NULL,
	FromHours decimal(7, 2) NULL,
	FromMinutes decimal(7, 2) NULL,
	ToYears decimal(7, 2) NULL,
	ToMonths decimal(7, 2) NULL,
	ToWeeks decimal(7, 2) NULL,
	ToDays decimal(7, 2) NULL,
	ToHours decimal(7, 2) NULL,
	ToMinutes decimal(7, 2) NULL,
	DurationComment nvarchar(MAX) NULL,
	TotalHours decimal(18, 2) NULL,
	FromDuration varchar(50) NULL,
	ToDuration varchar(50) NULL,
	Created datetime NULL,
	LastUpdated datetime NULL,
	AverageMinutes int NULL,
	DurationSummary nvarchar(200) NULL
	)  ON [PRIMARY]
	 TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE dbo.[Tmp_Entity.DurationProfile] SET (LOCK_ESCALATION = TABLE)
GO
ALTER TABLE dbo.[Tmp_Entity.DurationProfile] ADD CONSTRAINT
	[DF_Entity.DurationProfile_Created] DEFAULT (getdate()) FOR Created
GO
ALTER TABLE dbo.[Tmp_Entity.DurationProfile] ADD CONSTRAINT
	[DF_Entity.DurationProfile_LastUpdated] DEFAULT (getdate()) FOR LastUpdated
GO
SET IDENTITY_INSERT dbo.[Tmp_Entity.DurationProfile] ON
GO
IF EXISTS(SELECT * FROM dbo.[Entity.DurationProfile])
	 EXEC('INSERT INTO dbo.[Tmp_Entity.DurationProfile] (Id, EntityId, TypeId, FromYears, FromMonths, FromWeeks, FromDays, FromHours, FromMinutes, ToYears, ToMonths, ToWeeks, ToDays, ToHours, ToMinutes, DurationComment, TotalHours, FromDuration, ToDuration, Created, LastUpdated, AverageMinutes, DurationSummary)
		SELECT Id, EntityId, TypeId, CONVERT(decimal(7, 2), FromYears), CONVERT(decimal(7, 2), FromMonths), CONVERT(decimal(7, 2), FromWeeks), CONVERT(decimal(7, 2), FromDays), CONVERT(decimal(7, 2), FromHours), CONVERT(decimal(7, 2), FromMinutes), CONVERT(decimal(7, 2), ToYears), CONVERT(decimal(7, 2), ToMonths), CONVERT(decimal(7, 2), ToWeeks), CONVERT(decimal(7, 2), ToDays), CONVERT(decimal(7, 2), ToHours), CONVERT(decimal(7, 2), ToMinutes), DurationComment, TotalHours, FromDuration, ToDuration, Created, LastUpdated, AverageMinutes, DurationSummary FROM dbo.[Entity.DurationProfile] WITH (HOLDLOCK TABLOCKX)')
GO
SET IDENTITY_INSERT dbo.[Tmp_Entity.DurationProfile] OFF
GO
DROP TABLE dbo.[Entity.DurationProfile]
GO
EXECUTE sp_rename N'dbo.[Tmp_Entity.DurationProfile]', N'Entity.DurationProfile', 'OBJECT' 
GO
ALTER TABLE dbo.[Entity.DurationProfile] ADD CONSTRAINT
	PK_Entity_DurationProfile PRIMARY KEY CLUSTERED 
	(
	Id
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
CREATE NONCLUSTERED INDEX [IX_Entity.DurationProfile_EntityId] ON dbo.[Entity.DurationProfile]
	(
	EntityId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE dbo.[Entity.DurationProfile] ADD CONSTRAINT
	[FK_Entity.DurationProfile_Entity1] FOREIGN KEY
	(
	EntityId
	) REFERENCES dbo.Entity
	(
	Id
	) ON UPDATE  CASCADE 
	 ON DELETE  CASCADE 
	
GO
COMMIT
GO
--23-10-31 Add target competency to occupation, job, task and workrole

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.JobProfile ADD
	TargetCompetency nvarchar(MAX) NULL
GO
ALTER TABLE dbo.JobProfile SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO

BEGIN TRANSACTION
GO
ALTER TABLE dbo.OccupationProfile ADD
	TargetCompetency nvarchar(MAX) NULL
GO
ALTER TABLE dbo.OccupationProfile SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO


BEGIN TRANSACTION
GO
ALTER TABLE dbo.TaskProfile ADD
	TargetCompetency nvarchar(MAX) NULL
GO
ALTER TABLE dbo.TaskProfile SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO


BEGIN TRANSACTION
GO
ALTER TABLE dbo.WorkRole ADD
	TargetCompetency nvarchar(MAX) NULL
GO
ALTER TABLE dbo.WorkRole SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO
-- 23-10-31 FK_Entity.HasResource_Entity_Cache remove this constraint as can be an issue with deletes from the entity cache, etc. 

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Entity.HasResource]
	DROP CONSTRAINT [FK_Entity.HasResource_Entity_Cache]
GO
ALTER TABLE dbo.Entity_Cache SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Entity.HasResource] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO
--23-11-14 CredentialingActionType- add FK on ActionTypeId to Codes.CredentialingActionType

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Codes.CredentialingActionType] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.CredentialingAction ADD CONSTRAINT
	[FK_CredentialingAction_Codes.CredentialingActionType] FOREIGN KEY
	(
	ActionTypeId
	) REFERENCES dbo.[Codes.CredentialingActionType]
	(
	Id
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.CredentialingAction SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO
-- 23-11-15 drop AfterUpdate triggers

/****** Object:  Trigger [trgCredentialAfterUpdate]    Script Date: 11/15/2023 5:02:23 PM ******/
DROP TRIGGER [dbo].[trgCredentialAfterUpdate]
GO


/****** Object:  Trigger [trgOrganizationAfterUpdate]    Script Date: 11/15/2023 5:02:08 PM ******/
DROP TRIGGER [dbo].[trgOrganizationAfterUpdate]
GO

/****** Object:  Trigger [trgAssessmentAfterUpdate]    Script Date: 11/15/2023 5:02:45 PM ******/
DROP TRIGGER [dbo].[trgAssessmentAfterUpdate]
GO


/****** Object:  Trigger [trgLearningOpportunityAfterUpdate]    Script Date: 11/15/2023 5:03:13 PM ******/
DROP TRIGGER [dbo].[trgLearningOpportunityAfterUpdate]
GO

/****** Object:  Trigger [trgJobAfterUpdate]    Script Date: 11/16/2023 10:19:29 AM ******/
DROP TRIGGER [dbo].[trgJobAfterUpdate]
GO

DROP TRIGGER [dbo].[trgCollectionAfterUpdate]
GO



DROP TRIGGER [dbo].[trgConditionManifestAfterUpdate]
GO



DROP TRIGGER [dbo].[trgCostManifestAfterUpdate]
GO
--not sure why dsp has an after delete?
DROP TRIGGER [dbo].[trgDataSetProfileAfterDelete]
GO
DROP TRIGGER [dbo].[trgOccupationAfterUpdate]
GO
DROP TRIGGER [dbo].[trgPathwayAfterUpdate]
GO

DROP TRIGGER [dbo].[trgPathwayComponentAfterUpdate]
GO
DROP TRIGGER [dbo].[trgPathwaySetAfterUpdate]
GO
DROP TRIGGER [dbo].[trgRubricAfterUpdate]
GO
DROP TRIGGER [dbo].[trgRubricCriterionAfterUpdate]
GO

DROP TRIGGER [dbo].[trgScheduledOfferingAfterUpdate]
GO
DROP TRIGGER [dbo].[trgSupportServiceAfterUpdate]
GO
DROP TRIGGER [dbo].[trgTransferIntermediaryAfterUpdate]
GO
DROP TRIGGER [dbo].[trgTransferValueProfileAfterUpdate]
GO




/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.CredentialingAction ADD
	Object varchar(500) NULL
GO

ALTER TABLE dbo.CredentialingAction SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO


--	23-11-20 DataProfile - adding concrete properties
/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.DataProfile ADD
	AdministrativeRecordCategoryId int NULL,
	IncomeDeterminationMethodId int NULL,
	Adjustment nvarchar(MAX) NULL,
	EarningsDefinition nvarchar(MAX) NULL,
	EarningsThreshold nvarchar(MAX) NULL,
	EmploymentDefinition nvarchar(MAX) NULL,
	WorkTimeThreshold nvarchar(MAX) NULL
GO
ALTER TABLE dbo.DataProfile SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO
/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.CredentialingAction ADD
	ImageUrl varchar(500) NULL
GO

ALTER TABLE dbo.CredentialingAction SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO





/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.JobProfile ADD
	LifeCycleStatusTypeId int NULL
GO
ALTER TABLE dbo.JobProfile SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO

BEGIN TRANSACTION
GO
ALTER TABLE dbo.OccupationProfile ADD
	LifeCycleStatusTypeId int NULL
GO
ALTER TABLE dbo.OccupationProfile SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO

BEGIN TRANSACTION
GO
ALTER TABLE dbo.TaskProfile ADD
	LifeCycleStatusTypeId int NULL 
GO
ALTER TABLE dbo.TaskProfile SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO

BEGIN TRANSACTION
GO
ALTER TABLE dbo.WorkRole ADD
	LifeCycleStatusTypeId int NULL 
GO
ALTER TABLE dbo.WorkRole SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO


-- 23-12-16 Import.PendingRequest ADD Envelope

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Import.PendingRequest] ADD
	Envelope nvarchar(MAX) NULL
GO
ALTER TABLE dbo.[Import.PendingRequest] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
-- 23-12-17 Import.PendingRequest - increase EntityName to 900

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Import.PendingRequest]
	DROP CONSTRAINT [DF_Import.PendingRequest_ImportWasSuccessful]
GO
CREATE TABLE dbo.[Tmp_Import.PendingRequest]
	(
	Id int NOT NULL IDENTITY (1, 1),
	Created datetime NOT NULL,
	WasProcessed bit NOT NULL,
	Environment varchar(50) NOT NULL,
	EnvelopeLastUpdated datetime NULL,
	WasChanged bit NULL,
	EnvelopeId varchar(50) NULL,
	DataOwnerCTID varchar(50) NULL,
	PublisherCTID varchar(50) NULL,
	PublishMethodURI varchar(50) NOT NULL,
	PublishingEntityType varchar(50) NOT NULL,
	EntityCtid varchar(50) NOT NULL,
	EntityName nvarchar(900) NULL,
	ImportedDate datetime NULL,
	ImportWasSuccessful bit NULL,
	Envelope nvarchar(MAX) NULL
	)  ON [PRIMARY]
	 TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE dbo.[Tmp_Import.PendingRequest] SET (LOCK_ESCALATION = TABLE)
GO
ALTER TABLE dbo.[Tmp_Import.PendingRequest] ADD CONSTRAINT
	[DF_Import.PendingRequest_ImportWasSuccessful] DEFAULT ((0)) FOR ImportWasSuccessful
GO
SET IDENTITY_INSERT dbo.[Tmp_Import.PendingRequest] ON
GO
IF EXISTS(SELECT * FROM dbo.[Import.PendingRequest])
	 EXEC('INSERT INTO dbo.[Tmp_Import.PendingRequest] (Id, Created, WasProcessed, Environment, EnvelopeLastUpdated, WasChanged, EnvelopeId, DataOwnerCTID, PublisherCTID, PublishMethodURI, PublishingEntityType, EntityCtid, EntityName, ImportedDate, ImportWasSuccessful, Envelope)
		SELECT Id, Created, WasProcessed, Environment, EnvelopeLastUpdated, WasChanged, EnvelopeId, DataOwnerCTID, PublisherCTID, PublishMethodURI, PublishingEntityType, EntityCtid, EntityName, ImportedDate, ImportWasSuccessful, Envelope FROM dbo.[Import.PendingRequest] WITH (HOLDLOCK TABLOCKX)')
GO
SET IDENTITY_INSERT dbo.[Tmp_Import.PendingRequest] OFF
GO
DROP TABLE dbo.[Import.PendingRequest]
GO
EXECUTE sp_rename N'dbo.[Tmp_Import.PendingRequest]', N'Import.PendingRequest', 'OBJECT' 
GO
ALTER TABLE dbo.[Import.PendingRequest] ADD CONSTRAINT
	PK_ImportPendingRequest PRIMARY KEY CLUSTERED 
	(
	Id
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
CREATE NONCLUSTERED INDEX [Import.PendingRequest_Publisher] ON dbo.[Import.PendingRequest]
	(
	PublisherCTID
	) INCLUDE (Created, DataOwnerCTID, PublishingEntityType, EntityCtid, EntityName) 
 WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Import.PendingRequest.EntityCTID] ON dbo.[Import.PendingRequest]
	(
	EntityCtid
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Import.PendingRequest_DataOwner] ON dbo.[Import.PendingRequest]
	(
	DataOwnerCTID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
COMMIT
GO

-- 23-12-17 TransferValueProfile - increase name to 800
/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.TransferValueProfile
	DROP CONSTRAINT DF_TransferValueProfile_RowId
GO
ALTER TABLE dbo.TransferValueProfile
	DROP CONSTRAINT DF_TransferValueProfile_EntityStateId
GO
ALTER TABLE dbo.TransferValueProfile
	DROP CONSTRAINT DF_TransferValueProfile_Created
GO
ALTER TABLE dbo.TransferValueProfile
	DROP CONSTRAINT DF_TransferValueProfile_LastUpdated
GO
ALTER TABLE dbo.TransferValueProfile
	DROP CONSTRAINT DF_TransferValueProfile_LifeCycleStatusTypeId
GO
CREATE TABLE dbo.Tmp_TransferValueProfile
	(
	Id int NOT NULL IDENTITY (1, 1),
	RowId uniqueidentifier NOT NULL,
	EntityStateId int NOT NULL,
	Name nvarchar(800) NOT NULL,
	Description nvarchar(MAX) NULL,
	SubjectWebpage varchar(600) NULL,
	CTID varchar(50) NULL,
	OwningAgentUid uniqueidentifier NULL,
	LifecycleStatusType varchar(50) NULL,
	CredentialRegistryId varchar(50) NULL,
	Created datetime NULL,
	LastUpdated datetime NULL,
	CodedNotation varchar(100) NULL,
	IdentifierJson varchar(MAX) NULL,
	TransferValueJson varchar(MAX) NULL,
	TransferValueFromJson varchar(MAX) NULL,
	TransferValueForJson varchar(MAX) NULL,
	StartDate varchar(20) NULL,
	EndDate varchar(20) NULL,
	LifeCycleStatusTypeId int NOT NULL,
	Supersedes varchar(500) NULL,
	SupersededBy varchar(500) NULL,
	LatestVersion varchar(500) NULL,
	PreviousVersion varchar(500) NULL,
	NextVersion varchar(500) NULL,
	VersionIdentifier varchar(500) NULL
	)  ON [PRIMARY]
	 TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_TransferValueProfile SET (LOCK_ESCALATION = TABLE)
GO
ALTER TABLE dbo.Tmp_TransferValueProfile ADD CONSTRAINT
	DF_TransferValueProfile_RowId DEFAULT (newid()) FOR RowId
GO
ALTER TABLE dbo.Tmp_TransferValueProfile ADD CONSTRAINT
	DF_TransferValueProfile_EntityStateId DEFAULT ((1)) FOR EntityStateId
GO
ALTER TABLE dbo.Tmp_TransferValueProfile ADD CONSTRAINT
	DF_TransferValueProfile_Created DEFAULT (getdate()) FOR Created
GO
ALTER TABLE dbo.Tmp_TransferValueProfile ADD CONSTRAINT
	DF_TransferValueProfile_LastUpdated DEFAULT (getdate()) FOR LastUpdated
GO
ALTER TABLE dbo.Tmp_TransferValueProfile ADD CONSTRAINT
	DF_TransferValueProfile_LifeCycleStatusTypeId DEFAULT ((0)) FOR LifeCycleStatusTypeId
GO
SET IDENTITY_INSERT dbo.Tmp_TransferValueProfile ON
GO
IF EXISTS(SELECT * FROM dbo.TransferValueProfile)
	 EXEC('INSERT INTO dbo.Tmp_TransferValueProfile (Id, RowId, EntityStateId, Name, Description, SubjectWebpage, CTID, OwningAgentUid, LifecycleStatusType, CredentialRegistryId, Created, LastUpdated, CodedNotation, IdentifierJson, TransferValueJson, TransferValueFromJson, TransferValueForJson, StartDate, EndDate, LifeCycleStatusTypeId, Supersedes, SupersededBy, LatestVersion, PreviousVersion, NextVersion, VersionIdentifier)
		SELECT Id, RowId, EntityStateId, CONVERT(nvarchar(800), Name), Description, SubjectWebpage, CTID, OwningAgentUid, LifecycleStatusType, CredentialRegistryId, Created, LastUpdated, CodedNotation, IdentifierJson, TransferValueJson, TransferValueFromJson, TransferValueForJson, StartDate, EndDate, LifeCycleStatusTypeId, Supersedes, SupersededBy, LatestVersion, PreviousVersion, NextVersion, VersionIdentifier FROM dbo.TransferValueProfile WITH (HOLDLOCK TABLOCKX)')
GO
SET IDENTITY_INSERT dbo.Tmp_TransferValueProfile OFF
GO
ALTER TABLE dbo.[Entity.TransferValueProfile]
	DROP CONSTRAINT FK_EntityTVP_TransferValueProfile
GO
ALTER TABLE dbo.[TransferIntermediary.TransferValue]
	DROP CONSTRAINT [FK_TransferIntermediary.TransferValue_TransferValueProfile]
GO
DROP TABLE dbo.TransferValueProfile
GO
EXECUTE sp_rename N'dbo.Tmp_TransferValueProfile', N'TransferValueProfile', 'OBJECT' 
GO
ALTER TABLE dbo.TransferValueProfile ADD CONSTRAINT
	PK_TransferValueProfile PRIMARY KEY CLUSTERED 
	(
	Id
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
CREATE NONCLUSTERED INDEX IX_TransferValue_RowId ON dbo.TransferValueProfile
	(
	EntityStateId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE dbo.TransferValueProfile ADD CONSTRAINT
	IX_TransferValueProfile_RowId UNIQUE NONCLUSTERED 
	(
	RowId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
CREATE NONCLUSTERED INDEX IX_TransferValueProfile_EntityStateId ON dbo.TransferValueProfile
	(
	EntityStateId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE UNIQUE NONCLUSTERED INDEX IX_TransferValueProfile_CTID ON dbo.TransferValueProfile
	(
	CTID
	) WHERE ([CTID] IS NOT NULL AND [EntityStateId]>(0))
 WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE TRIGGER [dbo].[trgTransferValueProfileAfterInsert] ON  dbo.TransferValueProfile
FOR INSERT
AS  
    INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
					 ,EntityBaseId, EntityBaseName)
    SELECT RowId,26, getdate(), Id, Name
    FROM inserted;
GO
-- =============================================
-- Create date: 16-09-20
-- Description:	
--	Deletes are typically triggered from entity frameworks code. 
--	Tables like Entity are not removed via Referencial Integrity. 
--	The latter will be deleted, and then the TransferValueProfile
-- =============================================


CREATE TRIGGER [dbo].[trgTransferValueProfileBeforeDelete]
ON dbo.TransferValueProfile
INSTEAD OF DELETE
AS
BEGIN

     -- Some code you want to do before delete
		DELETE a	
			FROM [dbo].[Entity] a
			inner join Deleted d on a.EntityUid = d.RowId

			--need verify competencies are deleted - should as hang under Entity
			--also Jurisdictions
			--added to Entity, now what about GeoCoordinates

		 -- do the delete
     DELETE TransferValueProfile
     FROM DELETED D
     INNER JOIN dbo.TransferValueProfile T ON T.Id = D.Id
END
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[TransferIntermediary.TransferValue] ADD CONSTRAINT
	[FK_TransferIntermediary.TransferValue_TransferValueProfile] FOREIGN KEY
	(
	TransferValueProfileId
	) REFERENCES dbo.TransferValueProfile
	(
	Id
	) ON UPDATE  CASCADE 
	 ON DELETE  CASCADE 
	
GO
ALTER TABLE dbo.[TransferIntermediary.TransferValue] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Entity.TransferValueProfile] ADD CONSTRAINT
	FK_EntityTVP_TransferValueProfile FOREIGN KEY
	(
	TransferValueProfileId
	) REFERENCES dbo.TransferValueProfile
	(
	Id
	) ON UPDATE  CASCADE 
	 ON DELETE  CASCADE 
	
GO
ALTER TABLE dbo.[Entity.TransferValueProfile] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
-- 23-12-18 Entity_cache - increase name to 900

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.Entity_Cache
	DROP CONSTRAINT FK_Entity_Cache_Entity
GO
ALTER TABLE dbo.Entity SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.Entity_Cache
	DROP CONSTRAINT DF_Entity_Cache_LastUpdated
GO
ALTER TABLE dbo.Entity_Cache
	DROP CONSTRAINT DF_Entity_Cache_CacheDate
GO
ALTER TABLE dbo.Entity_Cache
	DROP CONSTRAINT DF_Entity_Cache_IsActive
GO
CREATE TABLE dbo.Tmp_Entity_Cache
	(
	Id int NOT NULL,
	EntityTypeId int NOT NULL,
	EntityType varchar(100) NULL,
	EntityUid uniqueidentifier NOT NULL,
	EntityStateId int NULL,
	CTID varchar(50) NULL,
	parentEntityId int NULL,
	parentEntityUid uniqueidentifier NULL,
	parentEntityType varchar(100) NULL,
	parentEntityTypeId int NULL,
	BaseId int NOT NULL,
	Name nvarchar(900) NOT NULL,
	Description nvarchar(MAX) NOT NULL,
	SubjectWebpage varchar(600) NULL,
	OwningOrgId int NULL,
	ImageUrl varchar(600) NULL,
	Created datetime NULL,
	LastUpdated datetime NULL,
	CacheDate datetime NULL,
	PublishedByOrgId int NULL,
	ResourceDetail nvarchar(MAX) NULL,
	AgentRelationshipsForEntity nvarchar(MAX) NULL,
	IsActive bit NULL
	)  ON [PRIMARY]
	 TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_Entity_Cache SET (LOCK_ESCALATION = TABLE)
GO
ALTER TABLE dbo.Tmp_Entity_Cache ADD CONSTRAINT
	DF_Entity_Cache_LastUpdated DEFAULT (getdate()) FOR LastUpdated
GO
ALTER TABLE dbo.Tmp_Entity_Cache ADD CONSTRAINT
	DF_Entity_Cache_CacheDate DEFAULT (getdate()) FOR CacheDate
GO
ALTER TABLE dbo.Tmp_Entity_Cache ADD CONSTRAINT
	DF_Entity_Cache_IsActive DEFAULT ((1)) FOR IsActive
GO
IF EXISTS(SELECT * FROM dbo.Entity_Cache)
	 EXEC('INSERT INTO dbo.Tmp_Entity_Cache (Id, EntityTypeId, EntityType, EntityUid, EntityStateId, CTID, parentEntityId, parentEntityUid, parentEntityType, parentEntityTypeId, BaseId, Name, Description, SubjectWebpage, OwningOrgId, ImageUrl, Created, LastUpdated, CacheDate, PublishedByOrgId, ResourceDetail, AgentRelationshipsForEntity, IsActive)
		SELECT Id, EntityTypeId, EntityType, EntityUid, EntityStateId, CTID, parentEntityId, parentEntityUid, parentEntityType, parentEntityTypeId, BaseId, Name, Description, SubjectWebpage, OwningOrgId, ImageUrl, Created, LastUpdated, CacheDate, PublishedByOrgId, ResourceDetail, AgentRelationshipsForEntity, IsActive FROM dbo.Entity_Cache WITH (HOLDLOCK TABLOCKX)')
GO
DROP TABLE dbo.Entity_Cache
GO
EXECUTE sp_rename N'dbo.Tmp_Entity_Cache', N'Entity_Cache', 'OBJECT' 
GO
ALTER TABLE dbo.Entity_Cache ADD CONSTRAINT
	PK_Entity_Cache PRIMARY KEY CLUSTERED 
	(
	Id
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
ALTER TABLE dbo.Entity_Cache ADD CONSTRAINT
	IX_Entity_Cache_EntityUid UNIQUE NONCLUSTERED 
	(
	EntityUid
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
CREATE NONCLUSTERED INDEX IX_Entity_Cache_SWP ON dbo.Entity_Cache
	(
	SubjectWebpage
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE dbo.Entity_Cache ADD CONSTRAINT
	IX_Entity_Cache UNIQUE NONCLUSTERED 
	(
	EntityTypeId,
	BaseId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
CREATE NONCLUSTERED INDEX Entity_Cache_EntityTypeId ON dbo.Entity_Cache
	(
	EntityTypeId
	) INCLUDE (BaseId, Name, CTID, EntityStateId, OwningOrgId) 
 WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE UNIQUE NONCLUSTERED INDEX IX_Entity_Cache_CTID ON dbo.Entity_Cache
	(
	CTID
	) WHERE ([CTID] IS NOT NULL AND [CTID]<>'')
 WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IX_Entity_Cache_CTID_Plus ON dbo.Entity_Cache
	(
	CTID
	) INCLUDE (EntityType, Name, Description) 
 WHERE ([CTID] IS NOT NULL AND [CTID]<>'')
 WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE dbo.Entity_Cache ADD CONSTRAINT
	FK_Entity_Cache_Entity FOREIGN KEY
	(
	Id
	) REFERENCES dbo.Entity
	(
	Id
	) ON UPDATE  CASCADE 
	 ON DELETE  CASCADE 
	
GO
COMMIT
GO
--	24-02-16 Add targetAction to lopp 

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE [dbo].[LearningOpportunity] ADD
	TargetAction nvarchar(MAX) NULL
GO
ALTER TABLE [dbo].[LearningOpportunity] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO



/*
Modifcations
24-01-17 mparsons - new

*/

COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Entity.HasCriterionLevel] ADD CONSTRAINT
	[FK_Entity.HasCriterionLevel_Rubric.CriterionLevel] FOREIGN KEY
	(
	CriterionLevelId
	) REFERENCES dbo.[Rubric.CriterionLevel]
	(
	Id
	) ON UPDATE  CASCADE 
	 ON DELETE  CASCADE 
	
GO
ALTER TABLE dbo.[Entity.HasCriterionLevel] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT

-- 24-03-06 Add InCatalog to asmt, cred, and lopp

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.Assessment ADD
	InCatalog nvarchar(MAX) NULL
GO
ALTER TABLE dbo.Assessment SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO

BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.Credential ADD
	InCatalog nvarchar(MAX) NULL
GO
ALTER TABLE dbo.Credential SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO

BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.LearningOpportunity ADD
	InCatalog nvarchar(MAX) NULL
GO
ALTER TABLE dbo.LearningOpportunity SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO
-- 24-03-27 Add Incatalog to WorkClasses, TVP, Rubric and Collection
--BEGIN TRANSACTION
--SET QUOTED_IDENTIFIER ON
--SET ARITHABORT ON
--SET NUMERIC_ROUNDABORT OFF
--SET CONCAT_NULL_YIELDS_NULL ON
--SET ANSI_NULLS ON
--SET ANSI_PADDING ON
--SET ANSI_WARNINGS ON
--COMMIT
--BEGIN TRANSACTION
--GO
--ALTER TABLE dbo.[Rubric] ADD
--	InCatalog nvarchar(MAX) NULL
--GO
--ALTER TABLE dbo.[Rubric] SET (LOCK_ESCALATION = TABLE)
--GO
--COMMIT
--GO

BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.JobProfile ADD
	InCatalog nvarchar(MAX) NULL
GO
ALTER TABLE dbo.JobProfile SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO

BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.OccupationProfile ADD
	InCatalog nvarchar(MAX) NULL
GO
ALTER TABLE dbo.OccupationProfile SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO

BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.WorkRole ADD
	InCatalog nvarchar(MAX) NULL
GO
ALTER TABLE dbo.WorkRole SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO

BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.TaskProfile ADD
	InCatalog nvarchar(MAX) NULL
GO
ALTER TABLE dbo.TaskProfile SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.TransferValueProfile ADD
	InCatalog nvarchar(MAX) NULL
GO
ALTER TABLE dbo.TransferValueProfile SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO

BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.Collection ADD
	InCatalog nvarchar(MAX) NULL
GO
ALTER TABLE dbo.Collection SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO
ALTER TABLE [dbo].[TaskProfile]
ALTER COLUMN [Name] nvarchar(800) NULL;

ALTER TABLE [dbo].[TaskProfile]
ALTER COLUMN [Description] nvarchar(MAX) NOT NULL;

--	24-05-16 DurationProfile - add time required

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Entity.DurationProfile] ADD
	TimeRequired varchar(50) NULL,
	TimeAmount decimal(7, 2) NULL,
	TimeUnit varchar(50) NULL
GO
ALTER TABLE dbo.[Entity.DurationProfile] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
CREATE NONCLUSTERED INDEX [Import.PendingRequest_Publisher_IDX]
ON [dbo].[Import.PendingRequest] ([PublisherCTID])
INCLUDE ([Created],[DataOwnerCTID],[PublishingEntityType],[EntityCtid],[EntityName])
GO

/*
The Query Processor estimates that implementing the following index could improve the query cost by 13.1555%.
*/

/**/

CREATE NONCLUSTERED INDEX [IX.CompetencyFramework.EntityStateId]
ON [dbo].[CompetencyFramework] ([EntityStateId])
INCLUDE ([RowId])
GO


/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
CREATE NONCLUSTERED INDEX [IX_Entity.HasResource_EntIdResId] ON dbo.[Entity.HasResource]
	(
	EntityTypeId,
	ResourceId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE dbo.[Entity.HasResource] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT

/*
Missing Index Details from SQLQuery10.sql - MPARSONS-CE2.credFinder (AzureAD\MichaelParsons (70))
The Query Processor estimates that implementing the following index could improve the query cost by 62.9778%.
*/


--
CREATE NONCLUSTERED INDEX [IX_Entity_Cache_EntityTypeId_EtAll]
ON [dbo].[Entity_Cache] ([EntityTypeId])
INCLUDE ([EntityType],[EntityUid],[EntityStateId],[CTID],[parentEntityId],[parentEntityUid],[parentEntityType],[parentEntityTypeId],[BaseId],[Name],[Description],[SubjectWebpage],[OwningOrgId],[ImageUrl],[Created],[LastUpdated],[CacheDate],[PublishedByOrgId],[ResourceDetail],[AgentRelationshipsForEntity],[IsActive])
GO

