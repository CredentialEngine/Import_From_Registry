
-- 23-09-27 Add Properties to WorkRole Table

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.WorkRole ADD
	EnvironmentalHazardType varchar(max) NULL,
	PerformanceLevelType varchar(max) NULL,
	PhysicalCapabilityType varchar(max) NULL,
	SensoryCapabilityType varchar(max) NULL,
	AlternateName varchar(500) NULL
GO

ALTER TABLE dbo.WorkRole SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO


IF EXISTS (SELECT 1
               FROM   INFORMATION_SCHEMA.COLUMNS
               WHERE  TABLE_NAME = 'WorkRole'
                      AND COLUMN_NAME = 'ListID'
                      AND TABLE_SCHEMA='DBO')
  BEGIN
      ALTER TABLE dbo.WorkRole
		DROP COLUMN ListID
  END
GO