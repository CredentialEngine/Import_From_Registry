
-- 23-11-15 drop AfterUpdate triggers

/****** Object:  Trigger [trgCredentialAfterUpdate]    Script Date: 11/15/2023 5:02:23 PM ******/
DROP TRIGGER [dbo].[trgCredentialAfterUpdate]
GO


/****** Object:  Trigger [trgOrganizationAfterUpdate]    Script Date: 11/15/2023 5:02:08 PM ******/
DROP TRIGGER [dbo].[trgOrganizationAfterUpdate]
GO

/****** Object:  Trigger [trgAssessmentAfterUpdate]    Script Date: 11/15/2023 5:02:45 PM ******/
DROP TRIGGER [dbo].[trgAssessmentAfterUpdate]
GO


/****** Object:  Trigger [trgLearningOpportunityAfterUpdate]    Script Date: 11/15/2023 5:03:13 PM ******/
DROP TRIGGER [dbo].[trgLearningOpportunityAfterUpdate]
GO

/****** Object:  Trigger [trgJobAfterUpdate]    Script Date: 11/16/2023 10:19:29 AM ******/
DROP TRIGGER [dbo].[trgJobAfterUpdate]
GO

DROP TRIGGER [dbo].[trgCollectionAfterUpdate]
GO



DROP TRIGGER [dbo].[trgConditionManifestAfterUpdate]
GO



DROP TRIGGER [dbo].[trgCostManifestAfterUpdate]
GO
--not sure why dsp has an after delete?
DROP TRIGGER [dbo].[trgDataSetProfileAfterDelete]
GO
DROP TRIGGER [dbo].[trgOccupationAfterUpdate]
GO
DROP TRIGGER [dbo].[trgPathwayAfterUpdate]
GO

DROP TRIGGER [dbo].[trgPathwayComponentAfterUpdate]
GO
DROP TRIGGER [dbo].[trgPathwaySetAfterUpdate]
GO
DROP TRIGGER [dbo].[trgRubricAfterUpdate]
GO
DROP TRIGGER [dbo].[trgRubricCriterionAfterUpdate]
GO

DROP TRIGGER [dbo].[trgScheduledOfferingAfterUpdate]
GO
DROP TRIGGER [dbo].[trgSupportServiceAfterUpdate]
GO
DROP TRIGGER [dbo].[trgTransferIntermediaryAfterUpdate]
GO
DROP TRIGGER [dbo].[trgTransferValueProfileAfterUpdate]
GO



