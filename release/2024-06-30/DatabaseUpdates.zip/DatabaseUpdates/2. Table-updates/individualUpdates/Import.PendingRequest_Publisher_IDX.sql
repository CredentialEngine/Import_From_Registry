
CREATE NONCLUSTERED INDEX [Import.PendingRequest_Publisher_IDX]
ON [dbo].[Import.PendingRequest] ([PublisherCTID])
INCLUDE ([Created],[DataOwnerCTID],[PublishingEntityType],[EntityCtid],[EntityName])
GO

