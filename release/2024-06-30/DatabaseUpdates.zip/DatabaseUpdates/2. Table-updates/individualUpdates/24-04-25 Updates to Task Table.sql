
ALTER TABLE [dbo].[TaskProfile]
ALTER COLUMN [Name] nvarchar(800) NULL;

ALTER TABLE [dbo].[TaskProfile]
ALTER COLUMN [Description] nvarchar(MAX) NOT NULL;
