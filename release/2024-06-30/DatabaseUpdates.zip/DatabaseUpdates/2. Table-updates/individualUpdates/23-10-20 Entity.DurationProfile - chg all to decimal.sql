
--	23-10-20 Entity.DurationProfile - chg all to decimal

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Entity.DurationProfile]
	DROP CONSTRAINT [FK_Entity.DurationProfile_Entity1]
GO
ALTER TABLE dbo.Entity SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Entity.DurationProfile]
	DROP CONSTRAINT [DF_Entity.DurationProfile_Created]
GO
ALTER TABLE dbo.[Entity.DurationProfile]
	DROP CONSTRAINT [DF_Entity.DurationProfile_LastUpdated]
GO
CREATE TABLE dbo.[Tmp_Entity.DurationProfile]
	(
	Id int NOT NULL IDENTITY (1, 1),
	EntityId int NULL,
	TypeId int NULL,
	FromYears decimal(7, 2) NULL,
	FromMonths decimal(7, 2) NULL,
	FromWeeks decimal(7, 2) NULL,
	FromDays decimal(7, 2) NULL,
	FromHours decimal(7, 2) NULL,
	FromMinutes decimal(7, 2) NULL,
	ToYears decimal(7, 2) NULL,
	ToMonths decimal(7, 2) NULL,
	ToWeeks decimal(7, 2) NULL,
	ToDays decimal(7, 2) NULL,
	ToHours decimal(7, 2) NULL,
	ToMinutes decimal(7, 2) NULL,
	DurationComment nvarchar(MAX) NULL,
	TotalHours decimal(18, 2) NULL,
	FromDuration varchar(50) NULL,
	ToDuration varchar(50) NULL,
	Created datetime NULL,
	LastUpdated datetime NULL,
	AverageMinutes int NULL,
	DurationSummary nvarchar(200) NULL
	)  ON [PRIMARY]
	 TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE dbo.[Tmp_Entity.DurationProfile] SET (LOCK_ESCALATION = TABLE)
GO
ALTER TABLE dbo.[Tmp_Entity.DurationProfile] ADD CONSTRAINT
	[DF_Entity.DurationProfile_Created] DEFAULT (getdate()) FOR Created
GO
ALTER TABLE dbo.[Tmp_Entity.DurationProfile] ADD CONSTRAINT
	[DF_Entity.DurationProfile_LastUpdated] DEFAULT (getdate()) FOR LastUpdated
GO
SET IDENTITY_INSERT dbo.[Tmp_Entity.DurationProfile] ON
GO
IF EXISTS(SELECT * FROM dbo.[Entity.DurationProfile])
	 EXEC('INSERT INTO dbo.[Tmp_Entity.DurationProfile] (Id, EntityId, TypeId, FromYears, FromMonths, FromWeeks, FromDays, FromHours, FromMinutes, ToYears, ToMonths, ToWeeks, ToDays, ToHours, ToMinutes, DurationComment, TotalHours, FromDuration, ToDuration, Created, LastUpdated, AverageMinutes, DurationSummary)
		SELECT Id, EntityId, TypeId, CONVERT(decimal(7, 2), FromYears), CONVERT(decimal(7, 2), FromMonths), CONVERT(decimal(7, 2), FromWeeks), CONVERT(decimal(7, 2), FromDays), CONVERT(decimal(7, 2), FromHours), CONVERT(decimal(7, 2), FromMinutes), CONVERT(decimal(7, 2), ToYears), CONVERT(decimal(7, 2), ToMonths), CONVERT(decimal(7, 2), ToWeeks), CONVERT(decimal(7, 2), ToDays), CONVERT(decimal(7, 2), ToHours), CONVERT(decimal(7, 2), ToMinutes), DurationComment, TotalHours, FromDuration, ToDuration, Created, LastUpdated, AverageMinutes, DurationSummary FROM dbo.[Entity.DurationProfile] WITH (HOLDLOCK TABLOCKX)')
GO
SET IDENTITY_INSERT dbo.[Tmp_Entity.DurationProfile] OFF
GO
DROP TABLE dbo.[Entity.DurationProfile]
GO
EXECUTE sp_rename N'dbo.[Tmp_Entity.DurationProfile]', N'Entity.DurationProfile', 'OBJECT' 
GO
ALTER TABLE dbo.[Entity.DurationProfile] ADD CONSTRAINT
	PK_Entity_DurationProfile PRIMARY KEY CLUSTERED 
	(
	Id
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
CREATE NONCLUSTERED INDEX [IX_Entity.DurationProfile_EntityId] ON dbo.[Entity.DurationProfile]
	(
	EntityId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE dbo.[Entity.DurationProfile] ADD CONSTRAINT
	[FK_Entity.DurationProfile_Entity1] FOREIGN KEY
	(
	EntityId
	) REFERENCES dbo.Entity
	(
	Id
	) ON UPDATE  CASCADE 
	 ON DELETE  CASCADE 
	
GO
COMMIT