
-- 23-12-17 TransferValueProfile - increase name to 800
/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.TransferValueProfile
	DROP CONSTRAINT DF_TransferValueProfile_RowId
GO
ALTER TABLE dbo.TransferValueProfile
	DROP CONSTRAINT DF_TransferValueProfile_EntityStateId
GO
ALTER TABLE dbo.TransferValueProfile
	DROP CONSTRAINT DF_TransferValueProfile_Created
GO
ALTER TABLE dbo.TransferValueProfile
	DROP CONSTRAINT DF_TransferValueProfile_LastUpdated
GO
ALTER TABLE dbo.TransferValueProfile
	DROP CONSTRAINT DF_TransferValueProfile_LifeCycleStatusTypeId
GO
CREATE TABLE dbo.Tmp_TransferValueProfile
	(
	Id int NOT NULL IDENTITY (1, 1),
	RowId uniqueidentifier NOT NULL,
	EntityStateId int NOT NULL,
	Name nvarchar(800) NOT NULL,
	Description nvarchar(MAX) NULL,
	SubjectWebpage varchar(600) NULL,
	CTID varchar(50) NULL,
	OwningAgentUid uniqueidentifier NULL,
	LifecycleStatusType varchar(50) NULL,
	CredentialRegistryId varchar(50) NULL,
	Created datetime NULL,
	LastUpdated datetime NULL,
	CodedNotation varchar(100) NULL,
	IdentifierJson varchar(MAX) NULL,
	TransferValueJson varchar(MAX) NULL,
	TransferValueFromJson varchar(MAX) NULL,
	TransferValueForJson varchar(MAX) NULL,
	StartDate varchar(20) NULL,
	EndDate varchar(20) NULL,
	LifeCycleStatusTypeId int NOT NULL,
	Supersedes varchar(500) NULL,
	SupersededBy varchar(500) NULL,
	LatestVersion varchar(500) NULL,
	PreviousVersion varchar(500) NULL,
	NextVersion varchar(500) NULL,
	VersionIdentifier varchar(500) NULL
	)  ON [PRIMARY]
	 TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_TransferValueProfile SET (LOCK_ESCALATION = TABLE)
GO
ALTER TABLE dbo.Tmp_TransferValueProfile ADD CONSTRAINT
	DF_TransferValueProfile_RowId DEFAULT (newid()) FOR RowId
GO
ALTER TABLE dbo.Tmp_TransferValueProfile ADD CONSTRAINT
	DF_TransferValueProfile_EntityStateId DEFAULT ((1)) FOR EntityStateId
GO
ALTER TABLE dbo.Tmp_TransferValueProfile ADD CONSTRAINT
	DF_TransferValueProfile_Created DEFAULT (getdate()) FOR Created
GO
ALTER TABLE dbo.Tmp_TransferValueProfile ADD CONSTRAINT
	DF_TransferValueProfile_LastUpdated DEFAULT (getdate()) FOR LastUpdated
GO
ALTER TABLE dbo.Tmp_TransferValueProfile ADD CONSTRAINT
	DF_TransferValueProfile_LifeCycleStatusTypeId DEFAULT ((0)) FOR LifeCycleStatusTypeId
GO
SET IDENTITY_INSERT dbo.Tmp_TransferValueProfile ON
GO
IF EXISTS(SELECT * FROM dbo.TransferValueProfile)
	 EXEC('INSERT INTO dbo.Tmp_TransferValueProfile (Id, RowId, EntityStateId, Name, Description, SubjectWebpage, CTID, OwningAgentUid, LifecycleStatusType, CredentialRegistryId, Created, LastUpdated, CodedNotation, IdentifierJson, TransferValueJson, TransferValueFromJson, TransferValueForJson, StartDate, EndDate, LifeCycleStatusTypeId, Supersedes, SupersededBy, LatestVersion, PreviousVersion, NextVersion, VersionIdentifier)
		SELECT Id, RowId, EntityStateId, CONVERT(nvarchar(800), Name), Description, SubjectWebpage, CTID, OwningAgentUid, LifecycleStatusType, CredentialRegistryId, Created, LastUpdated, CodedNotation, IdentifierJson, TransferValueJson, TransferValueFromJson, TransferValueForJson, StartDate, EndDate, LifeCycleStatusTypeId, Supersedes, SupersededBy, LatestVersion, PreviousVersion, NextVersion, VersionIdentifier FROM dbo.TransferValueProfile WITH (HOLDLOCK TABLOCKX)')
GO
SET IDENTITY_INSERT dbo.Tmp_TransferValueProfile OFF
GO
ALTER TABLE dbo.[Entity.TransferValueProfile]
	DROP CONSTRAINT FK_EntityTVP_TransferValueProfile
GO
ALTER TABLE dbo.[TransferIntermediary.TransferValue]
	DROP CONSTRAINT [FK_TransferIntermediary.TransferValue_TransferValueProfile]
GO
DROP TABLE dbo.TransferValueProfile
GO
EXECUTE sp_rename N'dbo.Tmp_TransferValueProfile', N'TransferValueProfile', 'OBJECT' 
GO
ALTER TABLE dbo.TransferValueProfile ADD CONSTRAINT
	PK_TransferValueProfile PRIMARY KEY CLUSTERED 
	(
	Id
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
CREATE NONCLUSTERED INDEX IX_TransferValue_RowId ON dbo.TransferValueProfile
	(
	EntityStateId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE dbo.TransferValueProfile ADD CONSTRAINT
	IX_TransferValueProfile_RowId UNIQUE NONCLUSTERED 
	(
	RowId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
CREATE NONCLUSTERED INDEX IX_TransferValueProfile_EntityStateId ON dbo.TransferValueProfile
	(
	EntityStateId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE UNIQUE NONCLUSTERED INDEX IX_TransferValueProfile_CTID ON dbo.TransferValueProfile
	(
	CTID
	) WHERE ([CTID] IS NOT NULL AND [EntityStateId]>(0))
 WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE TRIGGER [dbo].[trgTransferValueProfileAfterInsert] ON  dbo.TransferValueProfile
FOR INSERT
AS  
    INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
					 ,EntityBaseId, EntityBaseName)
    SELECT RowId,26, getdate(), Id, Name
    FROM inserted;
GO
-- =============================================
-- Create date: 16-09-20
-- Description:	
--	Deletes are typically triggered from entity frameworks code. 
--	Tables like Entity are not removed via Referencial Integrity. 
--	The latter will be deleted, and then the TransferValueProfile
-- =============================================


CREATE TRIGGER [dbo].[trgTransferValueProfileBeforeDelete]
ON dbo.TransferValueProfile
INSTEAD OF DELETE
AS
BEGIN

     -- Some code you want to do before delete
		DELETE a	
			FROM [dbo].[Entity] a
			inner join Deleted d on a.EntityUid = d.RowId

			--need verify competencies are deleted - should as hang under Entity
			--also Jurisdictions
			--added to Entity, now what about GeoCoordinates

		 -- do the delete
     DELETE TransferValueProfile
     FROM DELETED D
     INNER JOIN dbo.TransferValueProfile T ON T.Id = D.Id
END
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[TransferIntermediary.TransferValue] ADD CONSTRAINT
	[FK_TransferIntermediary.TransferValue_TransferValueProfile] FOREIGN KEY
	(
	TransferValueProfileId
	) REFERENCES dbo.TransferValueProfile
	(
	Id
	) ON UPDATE  CASCADE 
	 ON DELETE  CASCADE 
	
GO
ALTER TABLE dbo.[TransferIntermediary.TransferValue] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Entity.TransferValueProfile] ADD CONSTRAINT
	FK_EntityTVP_TransferValueProfile FOREIGN KEY
	(
	TransferValueProfileId
	) REFERENCES dbo.TransferValueProfile
	(
	Id
	) ON UPDATE  CASCADE 
	 ON DELETE  CASCADE 
	
GO
ALTER TABLE dbo.[Entity.TransferValueProfile] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT