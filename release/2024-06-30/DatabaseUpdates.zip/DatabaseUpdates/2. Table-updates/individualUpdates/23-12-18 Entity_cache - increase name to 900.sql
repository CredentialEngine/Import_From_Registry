
-- 23-12-18 Entity_cache - increase name to 900

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.Entity_Cache
	DROP CONSTRAINT FK_Entity_Cache_Entity
GO
ALTER TABLE dbo.Entity SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.Entity_Cache
	DROP CONSTRAINT DF_Entity_Cache_LastUpdated
GO
ALTER TABLE dbo.Entity_Cache
	DROP CONSTRAINT DF_Entity_Cache_CacheDate
GO
ALTER TABLE dbo.Entity_Cache
	DROP CONSTRAINT DF_Entity_Cache_IsActive
GO
CREATE TABLE dbo.Tmp_Entity_Cache
	(
	Id int NOT NULL,
	EntityTypeId int NOT NULL,
	EntityType varchar(100) NULL,
	EntityUid uniqueidentifier NOT NULL,
	EntityStateId int NULL,
	CTID varchar(50) NULL,
	parentEntityId int NULL,
	parentEntityUid uniqueidentifier NULL,
	parentEntityType varchar(100) NULL,
	parentEntityTypeId int NULL,
	BaseId int NOT NULL,
	Name nvarchar(900) NOT NULL,
	Description nvarchar(MAX) NOT NULL,
	SubjectWebpage varchar(600) NULL,
	OwningOrgId int NULL,
	ImageUrl varchar(600) NULL,
	Created datetime NULL,
	LastUpdated datetime NULL,
	CacheDate datetime NULL,
	PublishedByOrgId int NULL,
	ResourceDetail nvarchar(MAX) NULL,
	AgentRelationshipsForEntity nvarchar(MAX) NULL,
	IsActive bit NULL
	)  ON [PRIMARY]
	 TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_Entity_Cache SET (LOCK_ESCALATION = TABLE)
GO
ALTER TABLE dbo.Tmp_Entity_Cache ADD CONSTRAINT
	DF_Entity_Cache_LastUpdated DEFAULT (getdate()) FOR LastUpdated
GO
ALTER TABLE dbo.Tmp_Entity_Cache ADD CONSTRAINT
	DF_Entity_Cache_CacheDate DEFAULT (getdate()) FOR CacheDate
GO
ALTER TABLE dbo.Tmp_Entity_Cache ADD CONSTRAINT
	DF_Entity_Cache_IsActive DEFAULT ((1)) FOR IsActive
GO
IF EXISTS(SELECT * FROM dbo.Entity_Cache)
	 EXEC('INSERT INTO dbo.Tmp_Entity_Cache (Id, EntityTypeId, EntityType, EntityUid, EntityStateId, CTID, parentEntityId, parentEntityUid, parentEntityType, parentEntityTypeId, BaseId, Name, Description, SubjectWebpage, OwningOrgId, ImageUrl, Created, LastUpdated, CacheDate, PublishedByOrgId, ResourceDetail, AgentRelationshipsForEntity, IsActive)
		SELECT Id, EntityTypeId, EntityType, EntityUid, EntityStateId, CTID, parentEntityId, parentEntityUid, parentEntityType, parentEntityTypeId, BaseId, Name, Description, SubjectWebpage, OwningOrgId, ImageUrl, Created, LastUpdated, CacheDate, PublishedByOrgId, ResourceDetail, AgentRelationshipsForEntity, IsActive FROM dbo.Entity_Cache WITH (HOLDLOCK TABLOCKX)')
GO
DROP TABLE dbo.Entity_Cache
GO
EXECUTE sp_rename N'dbo.Tmp_Entity_Cache', N'Entity_Cache', 'OBJECT' 
GO
ALTER TABLE dbo.Entity_Cache ADD CONSTRAINT
	PK_Entity_Cache PRIMARY KEY CLUSTERED 
	(
	Id
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
ALTER TABLE dbo.Entity_Cache ADD CONSTRAINT
	IX_Entity_Cache_EntityUid UNIQUE NONCLUSTERED 
	(
	EntityUid
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
CREATE NONCLUSTERED INDEX IX_Entity_Cache_SWP ON dbo.Entity_Cache
	(
	SubjectWebpage
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE dbo.Entity_Cache ADD CONSTRAINT
	IX_Entity_Cache UNIQUE NONCLUSTERED 
	(
	EntityTypeId,
	BaseId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
CREATE NONCLUSTERED INDEX Entity_Cache_EntityTypeId ON dbo.Entity_Cache
	(
	EntityTypeId
	) INCLUDE (BaseId, Name, CTID, EntityStateId, OwningOrgId) 
 WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE UNIQUE NONCLUSTERED INDEX IX_Entity_Cache_CTID ON dbo.Entity_Cache
	(
	CTID
	) WHERE ([CTID] IS NOT NULL AND [CTID]<>'')
 WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IX_Entity_Cache_CTID_Plus ON dbo.Entity_Cache
	(
	CTID
	) INCLUDE (EntityType, Name, Description) 
 WHERE ([CTID] IS NOT NULL AND [CTID]<>'')
 WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE dbo.Entity_Cache ADD CONSTRAINT
	FK_Entity_Cache_Entity FOREIGN KEY
	(
	Id
	) REFERENCES dbo.Entity
	(
	Id
	) ON UPDATE  CASCADE 
	 ON DELETE  CASCADE 
	
GO
COMMIT