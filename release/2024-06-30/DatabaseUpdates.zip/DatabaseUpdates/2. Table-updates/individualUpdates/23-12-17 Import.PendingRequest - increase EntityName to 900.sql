
-- 23-12-17 Import.PendingRequest - increase EntityName to 900

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Import.PendingRequest]
	DROP CONSTRAINT [DF_Import.PendingRequest_ImportWasSuccessful]
GO
CREATE TABLE dbo.[Tmp_Import.PendingRequest]
	(
	Id int NOT NULL IDENTITY (1, 1),
	Created datetime NOT NULL,
	WasProcessed bit NOT NULL,
	Environment varchar(50) NOT NULL,
	EnvelopeLastUpdated datetime NULL,
	WasChanged bit NULL,
	EnvelopeId varchar(50) NULL,
	DataOwnerCTID varchar(50) NULL,
	PublisherCTID varchar(50) NULL,
	PublishMethodURI varchar(50) NOT NULL,
	PublishingEntityType varchar(50) NOT NULL,
	EntityCtid varchar(50) NOT NULL,
	EntityName nvarchar(900) NULL,
	ImportedDate datetime NULL,
	ImportWasSuccessful bit NULL,
	Envelope nvarchar(MAX) NULL
	)  ON [PRIMARY]
	 TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE dbo.[Tmp_Import.PendingRequest] SET (LOCK_ESCALATION = TABLE)
GO
ALTER TABLE dbo.[Tmp_Import.PendingRequest] ADD CONSTRAINT
	[DF_Import.PendingRequest_ImportWasSuccessful] DEFAULT ((0)) FOR ImportWasSuccessful
GO
SET IDENTITY_INSERT dbo.[Tmp_Import.PendingRequest] ON
GO
IF EXISTS(SELECT * FROM dbo.[Import.PendingRequest])
	 EXEC('INSERT INTO dbo.[Tmp_Import.PendingRequest] (Id, Created, WasProcessed, Environment, EnvelopeLastUpdated, WasChanged, EnvelopeId, DataOwnerCTID, PublisherCTID, PublishMethodURI, PublishingEntityType, EntityCtid, EntityName, ImportedDate, ImportWasSuccessful, Envelope)
		SELECT Id, Created, WasProcessed, Environment, EnvelopeLastUpdated, WasChanged, EnvelopeId, DataOwnerCTID, PublisherCTID, PublishMethodURI, PublishingEntityType, EntityCtid, EntityName, ImportedDate, ImportWasSuccessful, Envelope FROM dbo.[Import.PendingRequest] WITH (HOLDLOCK TABLOCKX)')
GO
SET IDENTITY_INSERT dbo.[Tmp_Import.PendingRequest] OFF
GO
DROP TABLE dbo.[Import.PendingRequest]
GO
EXECUTE sp_rename N'dbo.[Tmp_Import.PendingRequest]', N'Import.PendingRequest', 'OBJECT' 
GO
ALTER TABLE dbo.[Import.PendingRequest] ADD CONSTRAINT
	PK_ImportPendingRequest PRIMARY KEY CLUSTERED 
	(
	Id
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
CREATE NONCLUSTERED INDEX [Import.PendingRequest_Publisher] ON dbo.[Import.PendingRequest]
	(
	PublisherCTID
	) INCLUDE (Created, DataOwnerCTID, PublishingEntityType, EntityCtid, EntityName) 
 WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Import.PendingRequest.EntityCTID] ON dbo.[Import.PendingRequest]
	(
	EntityCtid
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IX_Import.PendingRequest_DataOwner] ON dbo.[Import.PendingRequest]
	(
	DataOwnerCTID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
COMMIT
