

--23-10-31 Add target competency to occupation, job, task and workrole

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.JobProfile ADD
	TargetCompetency nvarchar(MAX) NULL
GO
ALTER TABLE dbo.JobProfile SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO

BEGIN TRANSACTION
GO
ALTER TABLE dbo.OccupationProfile ADD
	TargetCompetency nvarchar(MAX) NULL
GO
ALTER TABLE dbo.OccupationProfile SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO


BEGIN TRANSACTION
GO
ALTER TABLE dbo.TaskProfile ADD
	TargetCompetency nvarchar(MAX) NULL
GO
ALTER TABLE dbo.TaskProfile SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO


BEGIN TRANSACTION
GO
ALTER TABLE dbo.WorkRole ADD
	TargetCompetency nvarchar(MAX) NULL
GO
ALTER TABLE dbo.WorkRole SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO