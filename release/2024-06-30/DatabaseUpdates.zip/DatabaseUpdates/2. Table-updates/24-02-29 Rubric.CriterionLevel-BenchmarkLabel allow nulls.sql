
--	24-02-29 Rubric.CriterionLevel-BenchmarkLabel allow nulls

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Rubric.CriterionLevel]
	DROP CONSTRAINT [DF_Rubric.CriterionLevel_RowId]
GO
ALTER TABLE dbo.[Rubric.CriterionLevel]
	DROP CONSTRAINT [DF_Rubric.CriterionLevel_Created]
GO
ALTER TABLE dbo.[Rubric.CriterionLevel]
	DROP CONSTRAINT [DF_Rubric.CriterionLevel_LastUpdated]
GO
CREATE TABLE dbo.[Tmp_Rubric.CriterionLevel]
	(
	Id int NOT NULL IDENTITY (1, 1),
	RowId uniqueidentifier NOT NULL,
	RubricId int NOT NULL,
	BenchmarkLabel nvarchar(500) NULL,
	BenchmarkText nvarchar(MAX) NULL,
	CodedNotation varchar(100) NULL,
	Feedback nvarchar(MAX) NULL,
	IsBinaryEvaluation bit NULL,
	ListID nvarchar(200) NULL,
	Value decimal(7, 2) NULL,
	MinValue decimal(7, 2) NULL,
	MaxValue decimal(7, 2) NULL,
	Percentage decimal(5, 2) NULL,
	MinPercentage decimal(5, 2) NULL,
	MaxPercentage decimal(5, 2) NULL,
	Created datetime NULL,
	LastUpdated datetime NULL
	)  ON [PRIMARY]
	 TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE dbo.[Tmp_Rubric.CriterionLevel] SET (LOCK_ESCALATION = TABLE)
GO
ALTER TABLE dbo.[Tmp_Rubric.CriterionLevel] ADD CONSTRAINT
	[DF_Rubric.CriterionLevel_RowId] DEFAULT (newid()) FOR RowId
GO
ALTER TABLE dbo.[Tmp_Rubric.CriterionLevel] ADD CONSTRAINT
	[DF_Rubric.CriterionLevel_Created] DEFAULT (getdate()) FOR Created
GO
ALTER TABLE dbo.[Tmp_Rubric.CriterionLevel] ADD CONSTRAINT
	[DF_Rubric.CriterionLevel_LastUpdated] DEFAULT (getdate()) FOR LastUpdated
GO
SET IDENTITY_INSERT dbo.[Tmp_Rubric.CriterionLevel] ON
GO
IF EXISTS(SELECT * FROM dbo.[Rubric.CriterionLevel])
	 EXEC('INSERT INTO dbo.[Tmp_Rubric.CriterionLevel] (Id, RowId, RubricId, BenchmarkLabel, BenchmarkText, CodedNotation, Feedback, IsBinaryEvaluation, ListID, Value, MinValue, MaxValue, Percentage, MinPercentage, MaxPercentage, Created, LastUpdated)
		SELECT Id, RowId, RubricId, BenchmarkLabel, BenchmarkText, CodedNotation, Feedback, IsBinaryEvaluation, ListID, Value, MinValue, MaxValue, Percentage, MinPercentage, MaxPercentage, Created, LastUpdated FROM dbo.[Rubric.CriterionLevel] WITH (HOLDLOCK TABLOCKX)')
GO
SET IDENTITY_INSERT dbo.[Tmp_Rubric.CriterionLevel] OFF
GO
ALTER TABLE dbo.[Entity.HasCriterionLevel]
	DROP CONSTRAINT [FK_Entity.HasCriterionLevel_Rubric.CriterionLevel]
GO
DROP TABLE dbo.[Rubric.CriterionLevel]
GO
EXECUTE sp_rename N'dbo.[Tmp_Rubric.CriterionLevel]', N'Rubric.CriterionLevel', 'OBJECT' 
GO
ALTER TABLE dbo.[Rubric.CriterionLevel] ADD CONSTRAINT
	[PK_Rubric.CriterionLevel] PRIMARY KEY CLUSTERED 
	(
	Id
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
/*
Modifcations
24-01-17 mparsons - new

*/

Create TRIGGER [dbo].[trgRubricCriterionLevelAfterInsert] ON  dbo.[Rubric.CriterionLevel]
FOR INSERT
AS  
   INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
		   ,EntityBaseId, EntityBaseName)
    SELECT RowId, 45, getdate(), Id, IsNull(BenchmarkLabel,'Rubric.CriterionLevel')  as Name
    FROM inserted;
GO
Create TRIGGER [dbo].[trgRubricCriterionLevelAfterDelete] ON  dbo.[Rubric.CriterionLevel]
FOR DELETE
AS  
BEGIN
     -- delete the entity
		DELETE a	
			FROM [dbo].[Entity] a
			inner join Deleted d on a.EntityUid = d.RowId

END
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Entity.HasCriterionLevel] ADD CONSTRAINT
	[FK_Entity.HasCriterionLevel_Rubric.CriterionLevel] FOREIGN KEY
	(
	CriterionLevelId
	) REFERENCES dbo.[Rubric.CriterionLevel]
	(
	Id
	) ON UPDATE  CASCADE 
	 ON DELETE  CASCADE 
	
GO
ALTER TABLE dbo.[Entity.HasCriterionLevel] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT