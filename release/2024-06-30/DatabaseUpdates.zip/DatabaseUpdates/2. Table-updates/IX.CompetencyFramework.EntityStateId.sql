/*
The Query Processor estimates that implementing the following index could improve the query cost by 13.1555%.
*/

/**/

CREATE NONCLUSTERED INDEX [IX.CompetencyFramework.EntityStateId]
ON [dbo].[CompetencyFramework] ([EntityStateId])
INCLUDE ([RowId])
GO

