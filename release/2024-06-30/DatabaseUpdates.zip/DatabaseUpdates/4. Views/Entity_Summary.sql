use credFinder
go

--use credFinder_prod
--go

use sandbox_credFinder
go

--use staging_credFinder
--go


/****** Object:  View [dbo].[Entity_Summary]    Script Date: 7/26/2017 10:52:55 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*

SELECT [Id]
      ,[EntityTypeId]      ,[EntityType]
	  ,EntitySubTypeId
      ,[EntityUid]
      ,[parentEntityId]
      ,[parentEntityUid]
      ,[parentEntityType]
      ,[parentEntityTypeId]
      ,[BaseId]
      ,[Name]
      ,[Description]
      ,[Created]
      ,[LastUpdated]
      ,[OwningOrgId]
      ,[OwningOrganization]
      ,[SubjectWebpage]
      ,[ImageUrl]
      ,[CTID]
      ,[EntityStateId]
  FROM [dbo].[Entity_Summary]
  where EntityTypeId= 7
  or EntitySubTypeId= 37
GO




where id = 334


 -- where parententityuid = 'C10E0233-16E9-4790-9F77-AC4C0A33E901'
order by 
      [EntityType]
      ,[Name]


*/
/*
Modifications
17-08-22 mparsons - added to workIT
20-04-20 mparsons - replace EducationFrameworks with CompetencyFrameworks
21-05-29 mparsons - add OccupationProfile, JobProfile
21-11-24 mparsons - updated to use specific entityTypeIds for lopp classes - need to test implications
22-02-23 mparsons - Added collection. For credential, removed the inner join to credential type. 
22-03-01 mparsons - Added transfer intermediary
22-06-01 mparsons - now excluding non-top level resources
22-06-14 mparsons - added dataSet profile
22-07-07 mparsons - need to distinguish between the base type and a subtype. Use the base type (i.e. 7 for lopps) for main reporting
***** trying to move away from using this. Though may be useful for a full build ****
***** can we get rid of the non top level resources (ex. condition profiles, addresses)
24-02-15 mparsons - changed to just entity_cache
*/
Alter VIEW [dbo].[Entity_Summary]
AS
SELECT a.[Id]
      ,a.[EntityTypeId]
      ,a.[EntityType]
	  --TBD
	  ,a.EntityTypeId as EntitySubTypeId
      ,a.[EntityUid]
      ,a.[EntityStateId]
      ,a.[CTID]
      ,a.[parentEntityId]
      ,a.[parentEntityUid]
      ,a.[parentEntityType]
      ,a.[parentEntityTypeId]
      ,a.[BaseId]
      ,a.[Name]
      ,a.[Description]
      ,a.[SubjectWebpage]
      ,a.[OwningOrgId]
	  ,isnull(org.Name,'') as OwningOrganization --should be primaryOrg
      ,a.[ImageUrl]
      ,a.[Created]
      ,a.[LastUpdated]
      ,a.[CacheDate]
      ,a.[PublishedByOrgId]
      --,a.[ResourceDetail]
      --,a.[AgentRelationshipsForEntity]
      ,a.[IsActive]
  FROM [dbo].[Entity_Cache] a
  Left Join Organization org on a.OwningOrgId = org.Id
/*
SELECT        
-- Credential  --------------------------------------------
Isnull(e.Id, -1) As Id, e.EntityTypeId,  cet.Title AS EntityType, e.EntityTypeId As EntitySubTypeId, e.EntityUid
,0 as parentEntityId, null As parentEntityUid, '' as parentEntityType,  0 as parentEntityTypeId,
 
base.Id as BaseId,
IsNull(base.Name,'') As Name,  IsNull(base.Description,'') As Description
,base.Created, e.LastUpdated
,isnull(o.Id,0) as OwningOrgId
,isnull(o.Name,0) as OwningOrganization
,isnull(base.SubjectWebpage,'') As SubjectWebpage
,isnull(base.ImageUrl,'') As ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,base.PublishedByOrgId
FROM dbo.Entity e -- entity for the base
INNER JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.Credential base				ON e.EntityUid = base.RowId
Left Join Organization o on base.OwningAgentUid = o.RowId
--Inner join [Codes.PropertyValue] credTypeProperty on base.CredentialTypeId = credTypeProperty.Id 
where base.EntityStateId > 1
--20-08-23 mp - start including these now
--AND isnull(credTypeProperty.SchemaName,'') <> 'ceterms:QualityAssuranceCredential'

UNION
SELECT        
-- Organization --------------------------------------------
e.Id, e.EntityTypeId,  cet.Title AS EntityType, base.EntityTypeId As EntitySubTypeId, e.EntityUid
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType,0 as parentEntityTypeId,

base.Id as BaseId,
IsNull(base.Name,'') As Name,  IsNull(base.Description,'') As Description
,base.Created,  e.LastUpdated
,base.Id as OwingOrgId
,isnull(base.Name,'') as OwningOrganization
,isnull(base.SubjectWebpage,'') As SubjectWebpage
,isnull(base.ImageUrl,'') As ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,base.PublishedByOrgId
FROM dbo.Entity e		-- entity for the base
INNER JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.Organization base			ON e.EntityUid = base.RowId
where base.EntityStateId > 1

UNION
-- Assessment --------------------------------------------
SELECT        
e.Id, e.EntityTypeId,  'Assessment' AS EntityType,  e.EntityTypeId As EntitySubTypeId,e.EntityUid
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType, 0 as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  IsNull(base.Description,'') As Description

,base.Created, e.LastUpdated
,isnull(o.Id,0) as OwningOrgId
,isnull(o.Name,0) as OwningOrganization
,isnull(base.SubjectWebpage,'') As SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,base.PublishedByOrgId
FROM dbo.Entity e -- entity for the base
INNER JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.Assessment base				ON e.EntityUid = base.RowId
Left Join Organization o on base.OwningAgentUid = o.RowId
where base.EntityStateId > 1
UNION
-- LearningOpportunity --------------------------------------------
--22-11-13 mp - now will also always use LearningOpportunity (not cet.Title) for EntityType in entity cache
SELECT        
e.Id, e.EntityTypeId,'LearningOpportunity'  AS EntityType,   base.EntityTypeId As EntitySubTypeId, e.EntityUid 
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType, 0 as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  IsNull(base.Description,'') As Description

,base.Created, e.LastUpdated 
,isnull(o.Id,0) as OwningOrgId
	,isnull(o.Name,0) as OwningOrganization
,isnull(base.SubjectWebpage,'') As SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,base.PublishedByOrgId
FROM dbo.Entity e -- entity for the base
INNER JOIN dbo.LearningOpportunity base		ON e.EntityUid = base.RowId
INNER JOIN dbo.[Codes.EntityTypes]	cet		ON base.EntityTypeId = cet.Id 
Left Join Organization o on base.OwningAgentUid = o.RowId
where base.EntityStateId > 1

UNION
-- ConditionManifest --------------------------------------------
SELECT        
e.Id, e.EntityTypeId,'ConditionManifest' AS EntityType,   e.EntityTypeId As EntitySubTypeId, e.EntityUid 
, 0 as parentEntityId, o.EntityUid As parentEntityUid, 'Organization' as parentEntityType, o.EntityTypeId as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  IsNull(base.Description,'') As Description

,base.Created, e.LastUpdated
,base.OrganizationId as OwningOrgId
	,isnull(o.EntityBaseName,0) as OwningOrganization
,isnull(base.SubjectWebpage,'') As SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,0 as PublishedByOrgId
FROM dbo.Entity e -- entity for the base
INNER JOIN dbo.[Codes.EntityTypes]	cet		ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.ConditionManifest base		ON e.EntityUid = base.RowId
Left Join dbo.Entity o on base.OrganizationId = o.EntityBaseId and o.EntityTypeId = 2
where base.EntityStateId > 1

UNION
-- CostManifest --------------------------------------------
SELECT        
e.Id, e.EntityTypeId, 'CostManifest' AS EntityType,   e.EntityTypeId As EntitySubTypeId,e.EntityUid 
, 0 as parentEntityId, o.EntityUid As parentEntityUid, 'Organization' as parentEntityType, o.EntityTypeId as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  IsNull(base.Description,'') As Description

,base.Created, e.LastUpdated
,base.OrganizationId as OwningOrgId
,isnull(o.EntityBaseName,0) as OwningOrganization
,base.CostDetails As SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,0 as PublishedByOrgId
FROM dbo.Entity e -- entity for the base
INNER JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.CostManifest base			ON e.EntityUid = base.RowId
Left Join dbo.Entity o on base.OrganizationId = o.EntityBaseId and o.EntityTypeId = 2
where base.EntityStateId > 1

UNION
-- Competency Framework --------------------------------------------
SELECT        
e.Id, e.EntityTypeId,'CompetencyFramework' AS EntityType,   e.EntityTypeId As EntitySubTypeId, e.EntityUid 
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType, 0 as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  '' As Description

,base.Created, e.LastUpdated
,isnull(o.Id,0) as OwningOrgId
,isnull(o.Name,0) as OwningOrganization
,base.FrameworkUri As SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,base.PublishedByOrgId
FROM dbo.Entity e -- entity for the base
Left JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
--INNER JOIN dbo.[EducationFramework] base			ON e.EntityUid = base.RowId
INNER JOIN dbo.CompetencyFramework base			ON e.EntityUid = base.RowId
Left Join Organization o on base.OrganizationCTID = o.CTID
where base.EntityStateId > 1

UNION
-- Concept scheme --------------------------------------------
SELECT        
e.Id, e.EntityTypeId, 'Concept scheme' AS EntityType,   base.EntityTypeId As EntitySubTypeId,e.EntityUid 
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType, 0 as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  '' As Description

,base.Created, e.LastUpdated
,isnull(o.Id,0) as OwningOrgId
,isnull(o.Name,0) as OwningOrganization
,base.Source As SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,base.PublishedByOrgId
FROM dbo.Entity e -- entity for the base
Left JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.Conceptscheme base			ON e.EntityUid = base.RowId
Left Join Organization o on base.OrgId = o.Id
where base.EntityStateId > 1

UNION
-- Collection  --------------------------------------------
SELECT        
e.Id, e.EntityTypeId, 'Collection' AS EntityType,   e.EntityTypeId As EntitySubTypeId,e.EntityUid 
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType, 0 as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  '' As Description

,base.Created, e.LastUpdated
,isnull(o.Id,0) as OwningOrgId
,isnull(o.Name,0) as OwningOrganization
,base.SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,base.PublishedByOrgId
FROM dbo.Entity e -- entity for the base
Left JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.Collection base			ON e.EntityUid = base.RowId
Left Join Organization o on base.OwningAgentUid = o.RowId
where base.EntityStateId > 1

UNION
-- Pathway --------------------------------------------
SELECT        
e.Id, e.EntityTypeId,  cet.Title AS EntityType, e.EntityTypeId As EntitySubTypeId, e.EntityUid 
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType, 0 as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  '' As Description
,base.Created, e.LastUpdated
,isnull(o.Id,0) as OwningOrgId
,isnull(o.Name,0) as OwningOrganization
,base.SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,base.PublishedByOrgId
FROM dbo.Entity e -- entity for the base
Left JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.Pathway base			ON e.EntityUid = base.RowId
Left Join Organization o on base.OwningAgentUID = o.RowId
where base.EntityStateId > 1

UNION
-- PathwaySet --------------------------------------------
SELECT        
e.Id, e.EntityTypeId, 'PathwaySet' AS EntityType,   e.EntityTypeId As EntitySubTypeId,e.EntityUid 
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType, 0 as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  '' As Description
,base.Created, e.LastUpdated
,isnull(o.Id,0) as OwningOrgId
,isnull(o.Name,0) as OwningOrganization
,base.SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,base.PublishedByOrgId
FROM dbo.Entity e -- entity for the base
Left JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.PathwaySet base			ON e.EntityUid = base.RowId
Left Join Organization o on base.OwningAgentUID = o.RowId
where base.EntityStateId > 1

UNION
-- TransferValueProfile --------------------------------------------
SELECT        
e.Id, e.EntityTypeId, 'TransferValue' AS EntityType,   e.EntityTypeId As EntitySubTypeId,e.EntityUid 
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType, 0 as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  '' As Description
,base.Created, e.LastUpdated
,isnull(o.Id,0) as OwningOrgId
,isnull(o.Name,0) as OwningOrganization
,base.SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,base.PublishedByOrgId
FROM dbo.Entity e -- entity for the base
Left JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.TransferValueProfile base			ON e.EntityUid = base.RowId
Left Join Organization o on base.OwningAgentUID = o.RowId
where base.EntityStateId > 1

UNION
-- TransferIntermediary --------------------------------------------
SELECT        
e.Id, e.EntityTypeId, 'TransferIntermediary' AS EntityType,   e.EntityTypeId As EntitySubTypeId,e.EntityUid 
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType, 0 as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  '' As Description
,base.Created, e.LastUpdated
,isnull(o.Id,0) as OwningOrgId
,isnull(o.Name,0) as OwningOrganization
,base.SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,base.PublishedByOrgId
FROM dbo.Entity e -- entity for the base
Left JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.TransferIntermediary base			ON e.EntityUid = base.RowId
Left Join Organization o on base.OwningAgentUID = o.RowId
where base.EntityStateId > 1

UNION
-- DataSet Profile --------------------------------------------
SELECT        
e.Id, e.EntityTypeId, 'DataSetProfile' AS EntityType,   e.EntityTypeId As EntitySubTypeId,e.EntityUid 
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType, 0 as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  '' As Description
,base.Created, e.LastUpdated
,isnull(o.Id,0) as OwningOrgId
,isnull(o.Name,0) as OwningOrganization
,base.Source As SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,base.PublishedByOrgId
--	select count(*)
FROM dbo.Entity e -- entity for the base
INNER JOIN dbo.DataSetProfile base			ON e.EntityUid = base.RowId
Left Join Organization o on base.DataProviderUID = o.RowId
where base.EntityStateId > 0
UNION
-- ScheduledOffering --------------------------------------------
SELECT        
e.Id, e.EntityTypeId,  'ScheduledOffering' AS EntityType,  e.EntityTypeId As EntitySubTypeId,e.EntityUid
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType, 0 as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  IsNull(base.Description,'') As Description

,base.Created, e.LastUpdated
,isnull(o.Id,0) as OwningOrgId
,isnull(o.Name,0) as OwningOrganization
,isnull(base.SubjectWebpage,'') As SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,base.PublishedByOrgId
FROM dbo.Entity e -- entity for the base
INNER JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.ScheduledOffering base				ON e.EntityUid = base.RowId
Left Join Organization o on base.OfferedBy = o.RowId
where base.EntityStateId > 1
UNION
-- SupportService --------------------------------------------
SELECT        
e.Id, e.EntityTypeId,  'SupportService' AS EntityType,  e.EntityTypeId As EntitySubTypeId,e.EntityUid
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType, 0 as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  IsNull(base.Description,'') As Description

,base.Created, e.LastUpdated
,isnull(o.Id,0) as OwningOrgId
,isnull(o.Name,0) as OwningOrganization
,isnull(base.SubjectWebpage,'') As SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,base.PublishedByOrgId
FROM dbo.Entity e -- entity for the base
INNER JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.SupportService base				ON e.EntityUid = base.RowId
Left Join Organization o on base.PrimaryAgentUid = o.RowId
where base.EntityStateId > 1
UNION
-- Occupation --------------------------------------------
SELECT        
e.Id, e.EntityTypeId,  cet.Title AS EntityType, e.EntityTypeId As EntitySubTypeId, e.EntityUid 
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType, 0 as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  '' As Description
,base.Created, e.LastUpdated
,0 as OwningOrgId
,'' as OwningOrganization
,base.SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,0 as PublishedByOrgId
FROM dbo.Entity e -- entity for the base
Left JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.OccupationProfile base			ON e.EntityUid = base.RowId
--Left Join Organization o on base.OwningAgentUID = o.RowId
where base.EntityStateId > 1


UNION
-- Job --------------------------------------------
SELECT        
e.Id, e.EntityTypeId,  cet.Title AS EntityType, e.EntityTypeId As EntitySubTypeId, e.EntityUid 
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType, 0 as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  '' As Description
,base.Created, e.LastUpdated
,0 as OwningOrgId
,'' as OwningOrganization
,base.SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,0 as PublishedByOrgId
FROM dbo.Entity e -- entity for the base
Left JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.JobProfile base			ON e.EntityUid = base.RowId
--Left Join Organization o on base.OwningAgentUID = o.RowId
where base.EntityStateId > 1

UNION
-- Task --------------------------------------------
SELECT        
e.Id, e.EntityTypeId,  cet.Title AS EntityType, e.EntityTypeId As EntitySubTypeId, e.EntityUid 
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType, 0 as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  '' As Description
,base.Created, e.LastUpdated
,0 as OwningOrgId
,'' as OwningOrganization
,''	as SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,0 as PublishedByOrgId
FROM dbo.Entity e -- entity for the base
Left JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.TaskProfile base			ON e.EntityUid = base.RowId
--Left Join Organization o on base.OwningAgentUID = o.RowId
where base.EntityStateId > 1

UNION
-- WorkRole --------------------------------------------
SELECT        
e.Id, e.EntityTypeId,  cet.Title AS EntityType, e.EntityTypeId As EntitySubTypeId, e.EntityUid 
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType, 0 as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  '' As Description
,base.Created, e.LastUpdated
,0 as OwningOrgId
,'' as OwningOrganization
,''	as SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,0 as PublishedByOrgId
FROM dbo.Entity e -- entity for the base
Left JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.WorkRole base			ON e.EntityUid = base.RowId
--Left Join Organization o on base.OwningAgentUID = o.RowId
where base.EntityStateId > 1
*/
GO
grant select on [Entity_Summary] to public
go

