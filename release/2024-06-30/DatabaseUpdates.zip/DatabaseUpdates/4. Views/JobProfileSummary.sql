Use credFinder
go
--use sandbox_credFinder
--go
--use staging_credFinder	
--go
--use flstaging_credFinder	
--go
/****** Object:  View [dbo].[JobProfileSummary]    Script Date: 7/29/2020 11:13:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*
USE [credFinder]
GO
USE [sandbox_credFinder]
GO

SELECT base.[Id]
      ,base.[RowId]
      ,base.[EntityId]
      ,base.[Name]
      ,base.[Description]
      ,base.[EntityStateId]
      ,base.[CTID]
      ,base.[PrimaryAgentUid]
      ,base.[PrimaryOrganizationId]
      ,base.[PrimaryOrganizationName]
      ,base.[PrimaryOrganizationCtid]
      ,base.[SubjectWebpage]
      ,base.[AbilityEmbodied]
      ,base.[Classification]
      ,base.[CodedNotation]
      ,base.[Comment]
      ,base.[Identifier]
      ,base.[KnowledgeEmbodied]
      ,base.[SkillEmbodied]
      ,base.[SameAs]
      ,base.[VersionIdentifier]
      ,base.[JsonProperties]
      ,base.[Created]
      ,base.[LastUpdated]
  FROM [dbo].[JobProfileSummary] a

GO



*/
/*
JobProfileSummary
Notes
- 
Mods
22-11-08 mparsons - new

*/
Alter VIEW [dbo].[JobProfileSummary]
AS
 
SELECT base.[Id]
	,base.[RowId]
	,b.Id as EntityId
	,base.[Name]
	,base.[Description]
	,base.[EntityStateId]
	,base.[CTID]
	,base.[PrimaryAgentUid]
	,isnull(primaryOrg.Id,0)	as PrimaryOrganizationId
	,isnull(primaryOrg.Name,'') as PrimaryOrganizationName
	,isnull(primaryOrg.CTID,'') as PrimaryOrganizationCtid
	,base.[SubjectWebpage]
	,base.[AbilityEmbodied]
	,base.[Classification]
	,base.[CodedNotation]
	,base.[Comment]
	,base.[Identifier]
	,base.[KnowledgeEmbodied]
	,base.[SkillEmbodied]
	,base.[SameAs]
	,base.[VersionIdentifier]
	,base.[JsonProperties]
	,base.[Created]
	,base.[LastUpdated]
	,base.[LifeCycleStatusTypeId]
	,cpv.Title as LifeCycleStatusType
	, (SELECT ehrs.[Name], ehrs.[Description] FROM [dbo].[Entity.HasResourceSummary] ehrs 
		where ehrs.EntityId = b.Id  and ehrs.EntityTypeId=17
		FOR XML RAW, ROOT('Competencies')) Competencies

--
  FROM [dbo].[JobProfile] base

INNER JOIN dbo.Entity AS b ON base.RowId = b.EntityUid 
-- join for primary
	Left join Organization primaryOrg on base.[PrimaryAgentUid] = primaryOrg.RowId and primaryOrg.EntityStateId > 1
	Left Join [Codes.PropertyValue] cpv on base.LifeCycleStatusTypeId = cpv.Id

where base.EntityStateId > 1

GO

grant select on [JobProfileSummary] to public
go


