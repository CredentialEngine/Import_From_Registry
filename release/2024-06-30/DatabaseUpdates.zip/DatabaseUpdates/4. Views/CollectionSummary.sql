
Use credFinder
go
use sandbox_credFinder
go
--use staging_credFinder	
--go
--use flstaging_credFinder	
--go

Alter View CollectionSummary
AS
SELECT  base.[Id]
	--need EntityId as a unique Id for a common elastic index
	,e.Id as EntityId
	,base.[Name]
	,base.[Description]
	,base.[EntityStateId]
	,base.[CTID]
	--
	,base.[OwningAgentUid]
	,isnull(b.ctid,'')  as OrganizationCTID
	,b.Id as OrganizationId
	,b.Name as OrganizationName
	,b.EntityStateId as OrganizationEntityStateId
	,case when IsNull(base.LifeCycleStatusTypeId,0) > 0 then base.LifeCycleStatusTypeId
	else 2648 end As LifeCycleStatusTypeId --default to production value for now

	,case when IsNull(base.LifeCycleStatusTypeId,0) > 0 then cpv.Title
	else 'Active' end As LifeCycleStatusType --
	--
	,base.[SubjectWebpage]
	,base.[CodedNotation]
	,base.[License]
	,base.[DateEffective]
	,base.[ExpirationDate]
	,base.[CredentialRegistryId]
	,base.[Created]
	,base.[LastUpdated]
	,base.[RowId]
	,base.[CollectionGraph]

  FROM [dbo].[Collection] base
  Inner join Entity e on base.rowId = e.EntityUid
  LEFT  JOIN dbo.Organization AS b ON base.OwningAgentUid = b.RowId
  left join [codes.PropertyValue] cpv on base.LifeCycleStatusTypeId = cpv.Id
where base.EntityStateId > 1
--
GO

grant select on CollectionSummary to public
go

