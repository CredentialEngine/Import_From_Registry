USE [credFinder]
GO

--use sandbox_credFinder	
--go

/****** View to Florida Report Summary for use in the Accounts reporting process ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
USE [credFinder]
GO

SELECT [Id]
      ,[CTID]
      ,[Name]
      ,[Description]
      ,[SubjectWebpage]
      ,[AgentType]
      ,[AgentSector]
      ,[Address1]
      ,[City]
      ,[PostalCode]
      ,[Region]
  FROM [dbo].[Florida.ReportsSummary]
GO



*/
CREATE View [dbo].[Florida.ReportsSummary]
As


SELECT [Id]
      ,[ReportType]
      ,[NotificationDate]
      ,[Publisher]
      ,[PublisherCTID]
      ,[Organization]
      ,[OrganizationCTID]
      ,[EntityType]
      ,[Totals]
  FROM [flstaging_credFinder].[dbo].[Reports.Summary]


GO
grant select on [Florida.ReportsSummary] to public
go

