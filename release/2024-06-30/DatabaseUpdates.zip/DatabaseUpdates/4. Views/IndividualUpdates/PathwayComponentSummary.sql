
/****** Object:  View [dbo].[PathwayComponentSummary]    Script Date: 8/26/2020 1:12:02 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
USE [credFinder]
GO
USE [sandbox_credFinder]
GO

SELECT [Id]
      ,[RowId]
      ,[ComponentTypeId]
      ,[PathwayComponentType]
      ,[EntityStateId]
      ,[CTID]
      ,[Name]
      ,[Description]
      ,[SubjectWebpage]
      ,[ProxyFor]
      ,[ProxyForName]
      ,[ProxyForEntityType]
      ,[ProxyForDescription]
      ,[CodedNotation]
      ,[CredentialType]
      ,[ComponentCategory]
      ,[ProgramTerm]
      ,[HasProgressionLevel]
      ,[PathwayCTID]
      ,[Created]
      ,[LastUpdated]
      ,[Properties]
      ,[SourceData]
  FROM [dbo].[PathwayComponentSummary]
    where [ProxyFor]is not null 
GO




*/
Alter VIEW [dbo].[PathwayComponentSummary]
AS

SELECT  a.[Id]
	,a.[RowId]
	,a.[ComponentTypeId]
	,f.Title AS PathwayComponentType
	,a.[EntityStateId]
	,a.[CTID]
	,a.[Name]
	,a.[Description]
	,a.[SubjectWebpage]
	,a.[ProxyFor]
	--NOTE: the following details should already be in the Properties JSON!
	,ec.Name as ProxyForName, ec.EntityType  as ProxyForEntityType, ec.Description as ProxyForDescription
	,a.[CodedNotation]
	,a.[CredentialType]
	,a.[ComponentCategory]
	,a.[ProgramTerm]
	,a.[HasProgressionLevel]
	,a.[PathwayCTID]
	,a.[Created]
	,a.[LastUpdated]
	,a.[Properties]
	,a.[SourceData]
  FROM [dbo].[PathwayComponent] a

  INNER JOIN dbo.Entity AS e ON a.RowId = e.EntityUid
  INNER JOIN dbo.[Codes.PathwayComponentType] AS f ON a.ComponentTypeId = f.Id
  Left join Entity_Cache ec on a.ProxyFor = ec.CTID

--would likely use a CSV
--INNER JOIN dbo.[Entity.HasPathwayComponent] AS ehpc on e.Id = ehpc.EntityId
--INNER JOIN  dbo.[Codes.PathwayComponentRelationship] AS g ON ehpc.ComponentRelationshipTypeId = g.Id
	
where a.EntityStateId > 1
GO

grant select on [PathwayComponentSummary] to public
go



