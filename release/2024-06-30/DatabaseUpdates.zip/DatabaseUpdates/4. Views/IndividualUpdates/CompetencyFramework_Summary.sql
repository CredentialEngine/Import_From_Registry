
/*

SELECT top 500
	[Id]
      ,[Name]
      ,[Description]
      ,[EntityStateId]
      ,[CTID]
      ,[OrganizationCTID]
      ,[OrganizationId]
      ,[OrganizationName]
      ,[FrameworkUri]
      ,[SourceUrl]
      ,[ExistsInRegistry]
      ,[CredentialRegistryId]
      ,[ReferencedByAssessments]
      ,[ReferencedByLearningOpportunities]
      ,[ReferencedByCredentials]
      ,[Created]
      ,[LastUpdated]
      ,[RowId]
      ,[CompetencyFrameworkGraph]
  FROM [dbo].[CompetencyFramework_Summary]
  --where ctid = 'ce-bccf8721-c455-4a5f-9314-791641a70868'
  where CTID is not null

GO




*/
/*
Competency Framework summary 
- only includes data in the registry

*/
Alter view CompetencyFramework_Summary
as

SELECT a.[Id]
      ,a.[Name]
	  ,a.Description
      ,a.[EntityStateId]
      ,a.[CTID]
	  --organization
      ,a.[OrganizationCTID]
	  ,IsNUll(b.id,0)		As OrganizationId
	  ,IsNull(b.Name,'')	as OrganizationName
      ,a.[FrameworkUri]
      ,a.[SourceUrl]
      ,isnull(a.[ExistsInRegistry],0) as [ExistsInRegistry]
      ,a.[CredentialRegistryId]
	  ,IsNull(AlignedAsmts.total,0) as ReferencedByAssessments
	  ,IsNull(AlignedLopps.total,0) as ReferencedByLearningOpportunities
	  ,IsNull(AlignedCreds.total,0) as ReferencedByCredentials
      ,a.[Created]
      ,a.[LastUpdated]
      ,a.[RowId]
	  ,a.CompetencyFrameworkGraph
	  ,a.CompetenciesStore
	  ,a.TotalCompetencies

  FROM [dbo].[CompetencyFramework] a
  left Join Organization b on a.OrganizationCTID = b.CTID
  -- this expensive to include aligned totals - is it being used anywhere?
  left Join (
	  Select alignedTotals.CompetencyFrameworkId,  COUNT(*) as total
	  from (

		Select a.CompetencyFrameworkId, c.Id,  COUNT(*) as total
		from [Entity.Competency] a
		Inner join Entity b on a.EntityId = b.Id
		Inner join Assessment c on b.EntityUid = c.RowId
		where c.EntityStateId = 3 and b.EntityTypeId = 3
		group by a.CompetencyFrameworkId, c.id
		--order by 1,2
		) as alignedTotals
		group by alignedTotals.CompetencyFrameworkId
		--order by 1

  ) as AlignedAsmts on a.id = AlignedAsmts.CompetencyFrameworkId
--
  left Join (
	  Select alignedTotals.CompetencyFrameworkId,  COUNT(*) as total
	  from (

		Select a.CompetencyFrameworkId, c.Id,  COUNT(*) as total
		from [Entity.Competency] a
		Inner join Entity b on a.EntityId = b.Id
		Inner join LearningOpportunity c on b.EntityUid = c.RowId
		where c.EntityStateId = 3 and b.EntityTypeId = 7
		group by a.CompetencyFrameworkId, c.id
		--order by 1,2
		) as alignedTotals
		group by alignedTotals.CompetencyFrameworkId
		--order by 1

  ) as AlignedLopps on a.id = AlignedLopps.CompetencyFrameworkId
  --
  left Join (
	  Select alignedTotals.CompetencyFrameworkId,  COUNT(*) as total
	  from (

		Select a.CompetencyFrameworkId, a.ParentEntityBaseId,  COUNT(*) as total
		from [ConditionProfile_RequiredCompetencies] a
		Inner join Credential c on a.ParentEntityUid = c.RowId
		where a.ParentEntityTypeId = 1
		group by a.CompetencyFrameworkId, a.ParentEntityBaseId
		--order by 1,2
		) as alignedTotals
		group by alignedTotals.CompetencyFrameworkId
		--order by 1

  ) as AlignedCreds on a.id = AlignedCreds.CompetencyFrameworkId
  where 
  --Why? - changed to include references
  --OR maybe incorrect. If a ctid exists, should mean was published
  ( a.EntityStateId > 1 )
  --and [ExistsInRegistry] = 1 
  go

  grant select on CompetencyFramework_Summary to public

  go