
/****** Object:  View [dbo].[PathwaySummary]    Script Date: 12/16/2020 1:11:13 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*
USE [credFinder]
GO

SELECT [Id]
      ,[RowId]
      ,[CTID]
      ,[Description]
      ,[EntityStateId]
      ,[SubjectWebpage]
      ,[OwningAgentUid]
      ,[OrganizationId]
      ,[OrganizationName]
      ,[OrganizationCTID]
      ,[CredentialRegistryId]
      ,[EntityLastUpdated]
      ,[Created]
      ,[LastUpdated]
	  ,ResourceDetail
  FROM [dbo].[PathwaySummary]
order by lastupdated desc 
GO




*/
Alter VIEW [dbo].[PathwaySummary]
AS

SELECT base.[Id]
	,base.[RowId]
	,base.[CTID]
	,base.[Name]
	,base.[Description]
	,base.[EntityStateId]
	,base.[SubjectWebpage]
	,IsNull(base.LifeCycleStatusTypeId,0)	as LifeCycleStatusTypeId
	,cpv.Title		as LifeCycleStatusType
	,base.[OwningAgentUid]
	,b.Id as OrganizationId
	,b.Name      as OrganizationName
	,b.CTID as OrganizationCTID
	,base.[CredentialRegistryId]
	,base.hasProgressionModel
	,base.[LatestVersion]
	,base.[PreviousVersion]
	,base.[NextVersion]
	,base.VersionIdentifier
	,base.Properties
	,ec.LastUpdated as EntityLastUpdated
	,base.[Created]	,base.[LastUpdated]
	,ec.ResourceDetail
	  --

  FROM [dbo].[Pathway] base
Left join dbo.Organization b on base.OwningAgentUid = b.RowId
INNER JOIN dbo.Entity_Cache AS ec ON base.RowId = ec.EntityUid
--Left Join EntityProperty_Summary	statusProperty on base.RowId = statusProperty.EntityUid and statusProperty.CategoryId = 84
  left join [codes.PropertyValue] cpv on base.LifeCycleStatusTypeId = cpv.Id

where base.EntityStateId > 1

GO
grant select on [PathwaySummary] to public
go

