
/****** Object:  View [dbo].[EntityCompetencyFramework_Items_Summary]    Script Date: 10/6/2017 4:16:31 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*

SELECT [EntityId]
,FrameworkName
, FrameworkCtid
      ,[Competency]
      ,COUNT(*) AS cnt
  FROM [dbo].[EntityCompetencyFramework_Items_Summary]
  group by 
  [EntityId]
      ,FrameworkName
	  , FrameworkCtid
	  , [Competency]
	  having count(*) > 1
order by 1,2,3


SELECT 
	distinct
		[EntityId]
      ,EntityTypeId, [EntityType]
      ,[EntityBaseId]
	  ,ConnectionTypeId
	  ,ConditionEntityTypeId
	  ,ConditionEntityBaseId
      ,[EntityName]
     -- ,[EntityCompetencyFrameworkItemId]
      ,[FrameworkName]
	  ,ExistsInRegistry
      ,[SourceUrl]
      --,[FrameworkCtid]
      --,[FrameworkUri]

      --,[EntityCompetencyId]
      ,[Competency]
      --,[TargetNodeDescription]
      --,[TargetNode]
      --,[CodedNotation]
      ,[Created]
      --,[Weight]
  FROM [dbo].[EntityCompetencyFramework_Items_Summary]
  where 
  entityid = 2364654
  --EntityTypeId = 7
  --and
  competency like 'Identify the components of included draft %'
  and ExistsInRegistry= 1
  --and ConditionEntityTypeId = 1
  --EntityBaseId = 991 OR ConditionEntityBaseId = 592
  --entityid = 28573   or 
  --connectiontypeid > 1
--where baseId = 12
order by [EntityId]
      ,[EntityType]
      ,[EntityBaseId], FrameworkName, Competency

*/
/*

Modifications
20-04-20 mparsons - replace EducationFrameworks with CompetencyFrameworks
20-06-12 mparsons - added: ExistsInRegistry
23-01-08 mparsons - Added Alignment to Entity.Competency
*/
Alter VIEW [dbo].[EntityCompetencyFramework_Items_Summary]
AS

SELECT DISTINCT    
	e.Id as EntityId
	,e.EntityTypeId
	,c.Title as EntityType
	, e.EntityBaseId 
	--as BaseId
	,e.EntityBaseName As EntityName
	,IsNUll(b.Id,0) AS EntityCompetencyFrameworkItemId
	,case when Isnull(b.Name,'') = '' then Isnull(a.FrameworkName,'None')
		else b.Name end as FrameworkName
	--, Isnull(b.FrameworkName,'None') as FrameworkName
	--, a.FrameworkName As F2
	--ultimately, want to stop using FrameworkUrl
	--,case when Isnull(b.FrameworkUrl,'') = '' then Isnull(a.FrameworkUrl,'None')
	--	else b.FrameworkUrl end as FrameworkUrl
	,b.[ExistsInRegistry]
	,b.FrameworkUri
	,case 
		when len(isnull(b.SourceUrl,'')) > 10 then b.SourceUrl
		when Len(Isnull(b.FrameworkUri,'')) > 10 AND charindex('/ce-',b.FrameworkUri) = 0 then b.FrameworkUri
		else '' end as SourceUrl
	--,b.SourceUrl

	,b.CTID as FrameworkCtid
	,a.Id AS EntityCompetencyId
	,a.Alignment
	,a.TargetNodeName AS Competency -- alias to prevent breaking
	,a.TargetNodeDescription
	,a.TargetNode
	,a.TargetNodeCTID
	--, b.TargetDescription	-- not used 
	,a.CodedNotation
	,a.Created
	,a.Weight
	--, b.AlignmentDate  --not used
	,IsNull(ecp.ConnectionTypeId,0)  As ConnectionTypeId
	,IsNull(cpEntity.EntityTypeId,0) As ConditionEntityTypeId
	,IsNull(cpEntity.EntityBaseId,0) As ConditionEntityBaseId

FROM       dbo.[Entity.Competency] a
LEFT JOIN dbo.CompetencyFramework b			ON a.CompetencyFrameworkId = b.id

INNER JOIN dbo.Entity				e	ON a.EntityId = e.Id
Inner Join dbo.[Codes.EntityTypes]	c	on e.EntityTypeId = c.Id

--required comps will be under a condition profile
Left Join [Entity.ConditionProfile] ecp on e.EntityUid = ecp.RowId
Left Join Entity			cpEntity	on ecp.EntityId = cpEntity.Id 
--may want to change this to > 1 at some point
where IsNull(b.EntityStateId,2) > 1

--SELECT        
--	a.EntityId, 
--	a.Id AS EntityCompetencyFrameworkId, 
--  a.EducationalFrameworkName, 
--	a.AlignmentType, a.AlignmentTypeId,
--	b.Id AS EntityCompetencyFrameworkItemId, 
--  b.Name, 
--	b.Name AS Competency, -- alias to prevent breaking
--	b.Description, 
--	b.TargetName, 
--	b.TargetDescription,
--  b.TargetUrl, 
--	b.CodedNotation
--FROM            dbo.[Entity.CompetencyFramework] a
--INNER JOIN dbo.[Entity.CompetencyFrameworkItem] b ON a.Id = b.EntityFrameworkId
go

grant select on [EntityCompetencyFramework_Items_Summary] to public

GO
