
/****** Object:  View [dbo].[Entity_ConditionProfilesConnectionsCSV]    Script Date: 8/22/2017 7:10:31 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




/*

SELECT [ParentId]
      ,[ParentEntityTypeId]
      ,[Profiles]
      ,[CredentialsList]
  FROM [dbo].[Entity_ConditionProfilesConnectionsCSV]
  where  ParentEntityTypeId= 3
 ParentId= 518
GO



1~Requires~1141~21st Century Skills for Workplace Success~| 1~Requires~31~Certified ISO/IEC 27005 Risk Manager~| 1~Requires~1140~Employment Readiness~| 1~Requires~1179~A Simple Cerificate Credential~| 1~Requires~17~Bachelor of Science in Computer Science~| 1~Requires~1140~Employment Readiness~| 1~Requires~31~Certified ISO/IEC 27005 Risk Manager~| 1~Requires~1209~Master of Science in Project Management~| 1~Requires~1164~CompTIA Security+~

2~Recommends~1141~21st Century Skills for Workplace Success~| 2~Recommends~31~Certified ISO/IEC 27005 Risk Manager~| 2~Recommends~1140~Employment Readiness~| 2~Recommends~1179~A Simple Cerificate Credential~| 2~Recommends~17~Bachelor of Science in Computer Science~| 2~Recommends~1140~Employment Readiness~| 2~Recommends~31~Certified ISO/IEC 27005 Risk Manager~| 2~Recommends~1209~Master of Science in Project Management~| 2~Recommends~1164~CompTIA Security+~

*/
/*

May want a version that is clearly for connections

Modifications

*/


ALTER  VIEW [dbo].[Entity_ConditionProfilesConnectionsCSV]
AS

SELECT     distinct
ParentId, 
base.ParentEntityTypeId,
    CASE
          WHEN Profiles IS NULL THEN ''
          WHEN len(Profiles) = 0 THEN ''
          ELSE left(Profiles,len(Profiles)-1)
    END AS Profiles
    ,CASE
          WHEN CredentialsList IS NULL THEN ''
          WHEN len(CredentialsList) = 0 THEN ''
          ELSE left(CredentialsList,len(CredentialsList)-1)
    END AS CredentialsList

From dbo.[Entity_ConditionProfileTotals] base


CROSS APPLY (
    SELECT convert(varchar, ConnectionTypeId) + '~' + ConnectionType  + '~' + ConnectionTypeSchemaName   + '~' + convert(varchar, ProfilesCount) + '| '
		From dbo.[Entity_ConditionProfileTotals] 
    WHERE base.ParentId = ParentId
	and base.ParentEntityTypeId = ParentEntityTypeId

    FOR XML Path('') 
		) D (Profiles)

CROSS APPLY (
    SELECT convert(varchar, ConnectionTypeId) + '~' + ConnectionType  + '~' + convert(varchar, TargetCredentialId) + '~' + TargetCredential    + '~' + '| '
		From dbo.[Entity_ConditionProfile_Credential] 
    WHERE base.ParentId = ParentId
	and base.ParentEntityTypeId = ParentEntityTypeId
    FOR XML Path('') 
		) E (CredentialsList)

where Isnull(base.ConditionSubTypeId,1) in (2,3,4)  --5  = alternate condition
AND Profiles is not null

GO
grant select on Entity_ConditionProfilesConnectionsCSV to public
go

