


/****** Object:  View [dbo].[TransferIntermediarySummary]    Script Date: 7/29/2020 11:13:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*
USE [credFinder]
GO
USE [sandbox_credFinder]
GO

SELECT [Id]
      ,[RowId]
      ,[EntityStateId]
      ,[Name]
      ,[Description]
      ,[SubjectWebpage]
      ,[CTID]
      ,[OwningAgentUid]
      ,[OrganizationCTID]
      ,[OrganizationId]
      ,[OrganizationName]
      ,[HasTransferValueProfiles]
      ,[CredentialRegistryId]
      ,[CodedNotation]
      ,[CreditValueJson]
      ,[IntermediaryForJson]
      ,[Subject]
      ,[Created]
      ,[LastUpdated]
  FROM [dbo].[TransferIntermediarySummary]

GO



GO


*/
/*
TransferIntermediarySummary
Notes
- 
Mods
22-01-27 mparsons - added
22-02-12 mparsons - added TVP totals

*/
Alter VIEW [dbo].[TransferIntermediarySummary]
AS


SELECT 
	base.[Id]
	,base.[RowId]
	,e.Id as EntityId
	,base.[EntityStateId]
	,base.[Name]
	,base.[Description]
	,base.[SubjectWebpage]
	,base.[CTID]
	--
	,base.[OwningAgentUid]
	,isnull(b.ctid,'')  as OrganizationCTID
	,b.Id as OrganizationId
	,b.Name as OrganizationName
	--
	,IsNull(tvp.total,0) as HasTransferValueProfiles
	--TBD
	,base.[CredentialRegistryId]
	,base.[CodedNotation]
	,base.[CreditValueJson]
	,base.[IntermediaryForJson]
	,base.[Subject]
	,base.[Created]
	,base.[LastUpdated]
	--

	
--
  FROM [dbo].[TransferIntermediary] base

INNER JOIN dbo.Entity AS e ON base.RowId = e.EntityUid 
LEFT  JOIN dbo.Organization AS b ON base.OwningAgentUid = b.RowId


--================================
Left Join (
	SELECT [TransferIntermediaryId] ,Count(*)  as total
  FROM [dbo].[TransferIntermediary.TransferValue]
  group by [TransferIntermediaryId]
	) tvp on base.Id = tvp.[TransferIntermediaryId]
--
where base.EntityStateId > 1

GO

grant select on [TransferIntermediarySummary] to public
go


