

/****** Object:  View [dbo].[ConditionProfile_RequiredCompetencies]    Script Date: 3/22/2018 7:18:54 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*

SELECT 
--top 1000
a.[ParentEntityId]
      ,a.[ParentEntityUid]
      ,a.[ParentEntityTypeId]
      ,a.[ParentEntityBaseId]
      ,a.[ParentEntityName]
	  ,c.CTID as parentCTID
      ,a.[EntityConditionProfileId]
      ,a.[CompetencyFrameworkId]
      ,a.[FrameworkName]
      ,a.[TargetNodeName]
	  ,a.TargetNodeCTID
      ,a.[AlignmentType]
	  	,a.CompetencyCategory
	,a.CompetencyLabel
	,a.competencyCreatedDate
  FROM [dbo].[ConditionProfile_RequiredCompetencies] a
  inner join Credential c on a.ParentEntityUid = c.RowId
  where c.EntityStateId = 3
  --where a.[FrameworkName] = 'BCSP: CHST Examination'
  --or IsNull(a.CompetencyLabel,'') <> ''
  order by a.[ParentEntityName], a.[FrameworkName], a.competencyCreatedDate
GO




*/
/*

Modifications
23-01-08 mparsons - Added Alignment to Entity.Competency
*/
ALTER VIEW [dbo].[ConditionProfile_RequiredCompetencies]
AS
SELECT        
	c.EntityId AS ParentEntityId, 
	cpParentEntity.EntityUid AS ParentEntityUid, 
	cpParentEntity.EntityTypeId AS ParentEntityTypeId, 
	cpParentEntity.EntityBaseId AS ParentEntityBaseId, 
	cpParentEntity.EntityBaseName AS ParentEntityName, 
	c.Id AS EntityConditionProfileId,
	a.Id as entityCompetencyId
	,a.CompetencyFrameworkId
	,a.FrameworkName
    --a.EducationFrameworkId
	, a.TargetNodeName
	,a.TargetNodeCTID
	,a.Alignment as AlignmentType
	,cfc.CompetencyCategory
	,cfc.CompetencyLabel
	,cfc.Created as competencyCreatedDate
FROM            dbo.[Entity.Competency]		AS a 
--may not have a framework. Why? Collections. 
--Left JOIN dbo.CompetencyFramework cf ON a.CompetencyFrameworkId = cf.id
Left Join [CompetencyFramework.Competency] cfc on a.TargetNodeCTID = cfc.CTID
INNER JOIN dbo.Entity						AS b ON a.EntityId = b.Id 
INNER JOIN dbo.[Entity.ConditionProfile]	AS c ON b.EntityUid = c.RowId 
INNER JOIN dbo.Entity						AS cpParentEntity ON c.EntityId = cpParentEntity.Id

GO
grant select on [ConditionProfile_RequiredCompetencies] to public
go


