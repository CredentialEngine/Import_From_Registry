
/*

SELECT [Publisher],[PublisherCTID]	,[Organization]	,[OrganizationCTID]	,count(*) as Total FROM [dbo].[Entity_CacheSummary]  Where LastUpdated < '2021-01-01' group by   [Publisher]	,[PublisherCTID]	,[Organization]	,[OrganizationCTID]
  order by Publisher, Organization

  go
SELECT [Publisher],[PublisherCTID]	,[Organization]	,[OrganizationCTID], EntityType	,count(*) as Total FROM [dbo].[Entity_CacheSummary]  Where LastUpdated < '2021-01-01' group by   [Publisher]	,[PublisherCTID]	,[Organization]	,[OrganizationCTID], EntityType
  order by Publisher, Organization,EntityType

  go

  --just data owner
  SELECT [Organization]	,[OrganizationCTID], EntityType	,count(*) as Total FROM [dbo].[Entity_CacheSummary]  
  Where LastUpdated < '2021-01-01' 
  and [PublisherCTID] =[OrganizationCTID]
  group by   [Organization]	,[OrganizationCTID], EntityType
  order by Organization,EntityType

    --just TPP
  SELECT [Publisher],[PublisherCTID], EntityType	,count(*) as Total FROM [dbo].[Entity_CacheSummary]  
  Where LastUpdated < '2021-01-01' 
  and [PublisherCTID] <> [OrganizationCTID]
  group by   [Publisher],[PublisherCTID], EntityType
  order by 1,EntityType

  go


INSERT INTO [dbo].[Work.Query]
           ([ReportType]
           ,[Publisher]
           ,[PublisherCTID]
           ,[Organization]
           ,[OrganizationCTID]
           ,[EntityType]
           ,[Category]
           ,[Name]
           ,[CTID]
           ,[Description]
          ,[DateCreated]
           ,[LastUpdated]
		   ,[Variable1]
           ,[Variable2]
           ,[Variable3]
         --  ,[IsProcessed]
		   )


SELECT 'CurrencyReport 18 months'
	,[Publisher]
	,[PublisherCTID]
	,[Organization]
	,[OrganizationCTID]
	-- ,[OwningOrgId]
	--  ,[EntityTypeId]
	,[EntityType]
	,[CTDLType]
	--    ,[BaseId]
	,[Name]
	,[CTID]
	,[Description]
		,[Created]
	,[LastUpdated]

	,Status		as Variable1
	,[PublishMethodURI] as Variable2

	  ,[SubjectWebpage] 
	--  ,[ImageUrl]
	-- ,[CacheDate]
  FROM [dbo].[Entity_CacheSummary]

  Where
-- EntityTypeId = 1  and 
LastUpdated < '2021-01-01'
  order by Publisher, Organization,[EntityTypeId], Name
GO

*/

/*
Entity Cache summary view for use by currency reporting
Notes
- this is fairly slow
- also may want to avoid the join to the Accounts table to get the publisher
Options
- daily generation of a reports table
- generate a table for unique publisher - data owners (as main reason for slowness)

Status ********************
- have to consider the credential and lifecycle status. That is either exclude deprecated, etc or make configurable
 Modifications 
22-05-01 mostly replace by ResourceCurrency_Summary
22-06-01 just a note that this only includes top level full resources (EntityStateId=3)
23-08-04 mparsons - TODO, establish the publisher in the import
23-11-01 mparsons - there were inconsistencies using [Import.PendingRequest] for third party filtering.
					Changed to use Entity.AgentRelationship to be consistent
*/
Alter View Entity_CacheSummary 
as 

SELECT  
	case when tpp.Name is not null then tpp.Name else 'Missing - get from accounts' end as Publisher,
	case when tpp.Name is not null then tpp.CTID else '' end as PublisherCTID

	,b.Name as Organization
	,b.CTID as OrganizationCTID
	,a.[OwningOrgId]
	,a.[EntityTypeId]
	,a.[EntityType]
	,et.SchemaName as CTDLType
	--  ,a.[EntityUid]
     
	--,a.[EntityStateId]
	,a.[BaseId]
	,a.[Name]
	,a.[LastUpdated]
	,a.[Description]
	,a.[CTID]
	,latestImport.PublishMethodURI
	,a.[Created]
	--future use to indicate if resource has an active status
	--,'Active' As Status
	,a.[SubjectWebpage]
	,a.[ImageUrl]
      
	,a.[CacheDate]  
      
--		select count(*)
FROM [dbo].[Entity_Cache] a
inner join Organization b on a.OwningOrgId = b.id
--this should not be necessary, as entityType is present
left join [Codes.EntityTypes] et on a.EntityTypeId = et.id 

--TODO need to eliminate this to make performant
--	would have to remove PublishMethodURI. This may be used in one of the reports
  left join (
		Select PublisherCTID, DataOwnerCTID, EntityCtid, max(a.PublishMethodURI)  PublishMethodURI
		from [Import.PendingRequest] a
		where a.PublishMethodURI  like 'publishMethod%'
		group by PublisherCTID, DataOwnerCTID, EntityCtid 
) latestImport on a.CTID = latestImport.EntityCtid 
--left join dbo.Organization tpp on latestImport.PublisherCTID = tpp.CTID

Left join [Entity.AgentRelationship] ear on a.Id = ear.EntityId and ear.RelationshipTypeId = 30
Left join Organization tpp on ear.AgentUid = tpp.RowId

where isnull(a.[parentEntityId],0) = 0
AND a.EntityStateId = 3

go

  grant select on Entity_CacheSummary to public
  go

