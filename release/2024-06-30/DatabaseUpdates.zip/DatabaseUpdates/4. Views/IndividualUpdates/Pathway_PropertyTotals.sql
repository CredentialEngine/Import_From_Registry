

/****** Object:  View [dbo].[Pathway_PropertyTotals]    Script Date: 5/31/2020 9:35:03 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
--generate totals for columns with data
asn:hasProgressionModel
ceasn:hasChild
ceterms:ctid
ceterms:description
ceterms:hasDestinationComponent
ceterms:industryType
ceterms:keyword
ceterms:name
ceterms:occupationType
ceterms:offeredBy
ceterms:ownedBy
ceterms:subject
ceterms:subjectWebpage

USE [sandbox_credFinder]
GO

SELECT [Total]
      ,[Name]
      ,[Description]
      ,[SubjectWebpage]
      ,[CTID]
      ,[HasDestinationComponent]
      ,[HasChild]
      ,[HasProgressionModel]
      ,[OwnedBy]
      ,[OfferedBy]
      ,[AssessmentComponents]
      ,[BasicComponents]
      ,[CocurricularComponents]
      ,[CompentencyComponents]
      ,[CourseComponents]
      ,[CredentialComponents]
      ,[ExtraCurricularComponents]
      ,[JobComponents]
      ,[WorkExperienceComponents]
      ,[SelectComponents]
      ,[OccupationType]
      ,[IndustryType]
      ,[Subject]
      ,[Keyword]
      ,[DevelopmentProcess]
  FROM [dbo].[Pathway_PropertyTotals]

GO




*/
Alter VIEW [dbo].[Pathway_PropertyTotals]
AS

select 

		sum(case when Len(IsNull(a.Name, '')) > 0 then 1 else 0 end) as Total
		, sum(case when Len(IsNull(a.Name, '')) > 0 then 1 else 0 end) as Name
		, sum(case when Len(IsNull(a.Description, '')) > 0 then 1 else 0 end) as Description
		, sum(case when Len(IsNull(a.SubjectWebpage, '')) > 0 then 1 else 0 end) as SubjectWebpage
		, sum(case when Len(IsNull(a.CTID, '')) > 0 then 1 else 0 end) as CTID
		, sum(case when Len(IsNull(a.LifeCycleStatusType, '')) > 0 then 1 else 0 end) as LifeCycleStatusType

		, sum(case when Len(IsNull(a.VersionIdentifier, '')) > 0 then 1 else 0 end) as VersionIdentifier
		, sum(case when Len(IsNull(a.LatestVersion, '')) > 0 then 1 else 0 end) as LatestVersion
		, sum(case when Len(IsNull(a.PreviousVersion, '')) > 0 then 1 else 0 end) as PreviousVersion
		, sum(case when Len(IsNull(a.NextVersion, '')) > 0 then 1 else 0 end) as NextVersion

		--dest component (should be all)
		,sum(case when IsNull(destComp.ComponentRelationshipTypeId,0) > 0 then 1 else 0 end) HasDestinationComponent
		-- HasChild
		,sum(case when IsNull(hasChild.ComponentRelationshipTypeId,0) > 0 then 1 else 0 end) HasChild

		--
		, sum(case when Len(IsNull(a.hasProgressionModel, '')) > 0 then 1 else 0 end) as HasProgressionModel
		-- BYs
		,sum(case when IsNull(ownedBy.RelationshipTypeId,0) > 0 then 1 else 0 end)		OwnedBy
		,sum(case when IsNull(offeredBy.RelationshipTypeId,0) > 0 then 1 else 0 end)	OfferedBy
		---- components
		,sum(case when IsNull(asmtComponent.ComponentTypeId,0) > 0 then 1 else 0 end) AssessmentComponents
		,sum(case when IsNull(basicComponent.ComponentTypeId,0) > 0 then 1 else 0 end) BasicComponents
		,sum(case when IsNull(cocurricularComponent.ComponentTypeId,0) > 0 then 1 else 0 end) CocurricularComponents
		,sum(case when IsNull(competencyComponent.ComponentTypeId,0) > 0 then 1 else 0 end) CompentencyComponents
		,sum(case when IsNull(courseComponent.ComponentTypeId,0) > 0 then 1 else 0 end) CourseComponents
		,sum(case when IsNull(credentialComponent.ComponentTypeId,0) > 0 then 1 else 0 end) CredentialComponents
		,sum(case when IsNull(extraCurricularComponent.ComponentTypeId,0) > 0 then 1 else 0 end) ExtraCurricularComponents
		,sum(case when IsNull(jobComponent.ComponentTypeId,0) > 0 then 1 else 0 end) JobComponents
		,sum(case when IsNull(workExpComponent.ComponentTypeId,0) > 0 then 1 else 0 end) WorkExperienceComponents
		--,sum(case when IsNull(selectComponent.ComponentTypeId,0) > 0 then 1 else 0 end) SelectComponents
		,sum(case when IsNull(multiComponent.ComponentTypeId,0) > 0 then 1 else 0 end) MultiComponents
		,sum(case when IsNull(collectionComponent.ComponentTypeId,0) > 0 then 1 else 0 end) CollectionComponents
		---- 
		,sum(case when IsNull(occ.CategoryId,0) > 0 then 1 else 0 end) OccupationType			--##
		,sum(case when IsNull(ind.CategoryId,0) > 0 then 1 else 0 end) IndustryType			--##		
		,sum(case when IsNull(prg.CategoryId,0) > 0 then 1 else 0 end) ProgramType			--##

		----general
		,sum(case when IsNull(subjects.EntityBaseId,0) > 0 then 1 else 0 end) Subject
		,sum(case when IsNull(keywords.EntityBaseId,0) > 0 then 1 else 0 end) Keyword
		-- Process Profiles --------------------------------------------------------------
		,sum(case when IsNull(devProfile.EntityBaseId,0)	> 0 then 1 else 0 end) DevelopmentProcess

	-- ========================================================
	--select count(*)
  from PathwaySummary a
  inner join entity b on a.RowId = b.EntityUid
--
   left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  ComponentRelationshipTypeId  FROM dbo.[Entity.HasPathwayComponent] inner join entity on EntityId = entity.Id where entity.EntityTypeId=8 and ComponentRelationshipTypeId=1
  ) destComp on a.Id = destComp.EntityBaseId
   left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  ComponentRelationshipTypeId  FROM dbo.[Entity.HasPathwayComponent] inner join entity on EntityId = entity.Id where entity.EntityTypeId=8 and ComponentRelationshipTypeId=3
  ) hasChild on a.Id = destComp.EntityBaseId

  --combine owns/offers =========================================================
   left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  RelationshipTypeId  FROM dbo.[Entity.AgentRelationship] inner join entity on EntityId = entity.Id where entity.EntityTypeId=8 and RelationshipTypeId=6
  ) ownedBy on a.Id = ownedBy.EntityBaseId

  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  RelationshipTypeId  FROM dbo.[Entity.AgentRelationship] inner join entity on EntityId = entity.Id where entity.EntityTypeId=8 and RelationshipTypeId=7
  ) offeredBy on a.Id = offeredBy.EntityBaseId
  left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM dbo.[Entity_ReferenceFramework_Summary]
	  where EntityTypeId=8 and [CategoryId] = 11
  ) occ on a.Id = occ.EntityBaseId
  left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM dbo.[Entity_ReferenceFramework_Summary]
	  where EntityTypeId=8 and [CategoryId] = 10
  ) ind on a.Id = ind.EntityBaseId
  left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM dbo.[Entity_ReferenceFramework_Summary]
	  where EntityTypeId=8 and [CategoryId] = 23
  ) prg on a.Id = ind.EntityBaseId
-- 
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.Reference] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=8 and [CategoryId] = 34
	  and Len(IsNull(a.TextValue,'')) > 0
  ) subjects on a.Id = subjects.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.Reference] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=8 and [CategoryId] = 35
	  and Len(IsNull(a.TextValue,'')) > 0
  ) keywords on a.Id = keywords.EntityBaseId
-- pathway component types
  left join (
	  SELECT distinct  a.PathwayCTID, a.ComponentTypeId   FROM [PathwayComponent] a where a.ComponentTypeId=1 
  ) asmtComponent on a.CTID = asmtComponent.PathwayCTID
  left join (
	  SELECT distinct  a.PathwayCTID, a.ComponentTypeId   FROM [PathwayComponent] a where a.ComponentTypeId=2 
  ) basicComponent on a.CTID = basicComponent.PathwayCTID
  left join (
	  SELECT distinct  a.PathwayCTID, a.ComponentTypeId   FROM [PathwayComponent] a where a.ComponentTypeId=3 
  ) cocurricularComponent on a.CTID = cocurricularComponent.PathwayCTID
  left join (
	  SELECT distinct  a.PathwayCTID, a.ComponentTypeId   FROM [PathwayComponent] a where a.ComponentTypeId=4 
  ) competencyComponent on a.CTID = competencyComponent.PathwayCTID
  left join (
	  SELECT distinct  a.PathwayCTID, a.ComponentTypeId   FROM [PathwayComponent] a where a.ComponentTypeId=5 
  ) courseComponent on a.CTID = courseComponent.PathwayCTID
  left join (
	  SELECT distinct  a.PathwayCTID, a.ComponentTypeId   FROM [PathwayComponent] a where a.ComponentTypeId=6 
  ) credentialComponent on a.CTID = credentialComponent.PathwayCTID
  left join (
	  SELECT distinct  a.PathwayCTID, a.ComponentTypeId   FROM [PathwayComponent] a where a.ComponentTypeId=7 
  ) extraCurricularComponent on a.CTID = extraCurricularComponent.PathwayCTID
  left join (
	  SELECT distinct  a.PathwayCTID, a.ComponentTypeId   FROM [PathwayComponent] a where a.ComponentTypeId=8 
  ) jobComponent on a.CTID = jobComponent.PathwayCTID
  left join (
	  SELECT distinct  a.PathwayCTID, a.ComponentTypeId   FROM [PathwayComponent] a where a.ComponentTypeId=9 
  ) workExpComponent on a.CTID = workExpComponent.PathwayCTID
  --left join (
	 -- SELECT distinct  a.PathwayCTID, a.ComponentTypeId   FROM [PathwayComponent] a where a.ComponentTypeId=10 
  --) selectComponent on a.CTID = selectComponent.PathwayCTID
  left join (
	  SELECT distinct  a.PathwayCTID, a.ComponentTypeId   FROM [PathwayComponent] a where a.ComponentTypeId=12 
  ) multiComponent on a.CTID = multiComponent.PathwayCTID
  left join (
	  SELECT distinct  a.PathwayCTID, a.ComponentTypeId   FROM [PathwayComponent] a where a.ComponentTypeId=13 
  ) collectionComponent on a.CTID = collectionComponent.PathwayCTID
-- Process profiles---------------------------------------------------------------------
  --2-dev
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ProcessProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=8 and a.ProcessTypeId=2 
  ) devProfile on a.Id = devProfile.EntityBaseId
 
--======================
where a.EntityStateId = 3 
GO

