
/****** Object:  View [dbo].[Organization_RecipientRolesCSV]    Script Date: 8/17/2017 2:59:54 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




/*

SELECT [OrganizationId]
      ,[Name]
      ,[OwnedBy]
      ,[OfferedBy]
  FROM [dbo].[Organization_RecipientRolesCSV]
GO



*/

Alter VIEW [dbo].[Organization_RecipientRolesCSV]
AS

SELECT     distinct

c.Id as OrganizationId
,c.Name

    ,CASE
          WHEN AccreditedBy IS NULL THEN ''
          WHEN len(AccreditedBy) = 0 THEN ''
          ELSE left(AccreditedBy,len(AccreditedBy)-1)
    END AS AccreditedBy
		,CASE
          WHEN ApprovedBy IS NULL THEN ''
          WHEN len(ApprovedBy) = 0 THEN ''
          ELSE left(ApprovedBy,len(ApprovedBy)-1)
    END AS ApprovedBy
		,CASE
          WHEN RecognizedBy IS NULL THEN ''
          WHEN len(RecognizedBy) = 0 THEN ''
          ELSE left(RecognizedBy,len(RecognizedBy)-1)
    END AS RecognizedBy
		,CASE
          WHEN RegulatedBy IS NULL THEN ''
          WHEN len(RegulatedBy) = 0 THEN ''
          ELSE left(RegulatedBy,len(RegulatedBy)-1)
    END AS RegulatedBy
		
FROM [dbo].[Entity.AgentRelationship] base
Inner join Entity e on base.EntityId = e.Id
Inner join Organization c on e.EntityUid = c.RowId 

-- get accreditedBy orgs  ====================================================
CROSS APPLY (
    SELECT convert(varchar,e.Id)  + '~ ' + e.Name + ' |'
    FROM dbo.[Entity.AgentRelationship] ear  
		Inner join Organization e on ear.AgentUid = e.RowId 
		inner join [Codes.CredentialAgentRelationship] b on ear.RelationshipTypeId = b.id and b.IsActive = 1

    WHERE base.EntityId = ear.EntityId
		And e.EntityStateId > 1
		And ear.RelationshipTypeId in (1)
    FOR XML Path('') 
) acBy (AccreditedBy)

-- get approvedBy orgs  ====================================================
CROSS APPLY (
    SELECT convert(varchar,e.Id)  + '~ ' + e.Name + ' |'
    FROM dbo.[Entity.AgentRelationship] ear  
		Inner join Organization e on ear.AgentUid = e.RowId 
		inner join [Codes.CredentialAgentRelationship] b on ear.RelationshipTypeId = b.id and b.IsActive = 1

    WHERE base.EntityId = ear.EntityId
		And e.EntityStateId > 1
		And ear.RelationshipTypeId in (7)
    FOR XML Path('') 
) appBy (ApprovedBy)

-- get RecognizedBy orgs  ====================================================
CROSS APPLY (
    SELECT convert(varchar,e.Id)  + '~ ' + e.Name + ' |'
    FROM dbo.[Entity.AgentRelationship] ear  
		Inner join Organization e on ear.AgentUid = e.RowId 
		inner join [Codes.CredentialAgentRelationship] b on ear.RelationshipTypeId = b.id and b.IsActive = 1

    WHERE base.EntityId = ear.EntityId
		And e.EntityStateId > 1
		And ear.RelationshipTypeId in (10)
    FOR XML Path('') 
) rcBy (RecognizedBy)

-- get RegulatedBy orgs  ====================================================
CROSS APPLY (
    SELECT convert(varchar,e.Id)  + '~ ' + e.Name + ' |'
    FROM dbo.[Entity.AgentRelationship] ear  
		Inner join Organization e on ear.AgentUid = e.RowId 
		inner join [Codes.CredentialAgentRelationship] b on ear.RelationshipTypeId = b.id and b.IsActive = 1

    WHERE base.EntityId = ear.EntityId
		And e.EntityStateId > 1
		And ear.RelationshipTypeId in (12)
    FOR XML Path('') 
) rgBy (RegulatedBy)

where (len(AccreditedBy) > 0 OR len(ApprovedBy) > 0  OR len(RecognizedBy) > 0  OR len(RegulatedBy) > 0 )


GO


