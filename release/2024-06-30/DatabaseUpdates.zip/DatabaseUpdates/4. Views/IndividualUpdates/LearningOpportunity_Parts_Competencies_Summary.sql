

/****** Object:  View [dbo].[LearningOpportunity_Parts_Competencies_Summary]    Script Date: 10/6/2017 4:36:54 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*


SELECT [LearningOpportunityId]
      ,[LearningOpportunity]
      ,[LearningOpportunityRowId]
				,ParentLearningOppEntityId


      ,[LearningOpportunity_PartId]
			,LO_PartEntityId
      ,[LearningOpportunity_PartRowId]
      ,[LearningOpportunity_Part]
      ,[LearningOpportunity_Part_Description]
      ,[LearningOpportunity_PartStatusId]
      ,[LearningOpportunity_Part_ManagingOrgId]

      ,[AlignmentType]
      ,[AlignmentTypeId]
      ,[Name]
      ,[Description]
      ,[CodedNotation]
      ,[TargetName]
      ,[TargetDescription]
      ,[TargetUrl]
  FROM [dbo].[LearningOpportunity_Parts_Competencies_Summary]
GO

Moving competencies from child to parent



*/
Alter VIEW [dbo].[LearningOpportunity_Parts_Competencies_Summary]
AS
/*
	LearningOpportunity_Parts_Summary
								LO (parent LO)
									Entity
										Entity.LO
											LO (child LO)
			ENTITY
					entity.Competency
	*/

SELECT [LearningOpportunityId]
		,[LearningOpportunity]
		,[LearningOpportunityRowId]
		,ParentLearningOppEntityId

		,[LearningOpportunity_PartId]
		,[LearningOpportunity_PartRowId]
		,[LearningOpportunity_Part]
		,[LearningOpportunity_Part_Description]
		,LO_PartEntityId
		--,[LearningOpportunity_PartStatusId]
		--,[LearningOpportunity_Part_ManagingOrgId]		

		,partComp.EntityCompetencyFrameworkItemId
		--		,partComp.AlignmentType, partComp.AlignmentTypeId
		,partComp.Competency, partComp.TargetNodeDescription
		,partComp.CodedNotation
		,partComp.TargetNode
		,partComp.Created  as CompetencyCreated

  FROM [dbo].[LearningOpportunity_Parts_Summary] base
	inner join Entity 
			on base.[LearningOpportunity_PartRowId] = Entity.EntityUid
	inner join [EntityCompetencyFramework_Items_Summary] partComp 
			on Entity.Id = partComp.EntityId


GO


