


/****** Object:  View [dbo].[ProgressionModelSummary]    Script Date: 8/24/2020 2:51:11 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*

USE [sandbox_credFinder]
GO

SELECT [Id]
      ,[EntityStateId]
      ,[Name]
      ,[CTID]
      ,[Description]
      ,[EntityId]
      ,[EntityLastUpdated]
      ,[OrganizationId]
      ,[OrganizationName]
      ,[OrganizationCTID]
      ,[OwningAgentUid]
      ,[Source]
      ,[PublicationStatusType]
      ,[CredentialRegistryId]
      ,[Created]
      ,[LastUpdated]
      ,[RowId]
  FROM [dbo].[ProgressionModelSummary]

GO



========================================================
23-07-17 mparsons - added 

*/
Alter VIEW [dbo].[ProgressionModelSummary]
AS

SELECT base.[Id]
	,base.EntityStateId
	,base.[Name]
	,isnull(base.CTID,'') As CTID 
	,base.[Description]
	,e.id as EntityId
	,e.LastUpdated as EntityLastUpdated
	,base.OrganizationId
	--owning org
	,owningOrg.Name as OrganizationName
	,owningOrg.ctid as OrganizationCTID
	,owningOrg.RowId as OwningAgentUid
	--

	,base.Source
	,base.PublicationStatusType
	,isnull(base.CredentialRegistryId,'') As CredentialRegistryId	

	,base.[Created]
	,base.[LastUpdated]
	,base.RowId
	--=====================================
	
  FROM [dbo].ProgressionModel base
  inner join Entity e on base.RowId = e.EntityUid
-- join for owner
	Left join Organization owningOrg on base.OrganizationId = owningOrg.Id

where  base.EntityStateId = 3

GO
grant select on [ProgressionModelSummary] to public
go
