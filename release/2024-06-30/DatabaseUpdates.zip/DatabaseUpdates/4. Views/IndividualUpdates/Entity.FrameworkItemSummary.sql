
/****** Object:  View [dbo].[Entity.FrameworkItemSummary]    Script Date: 8/16/2017 9:37:53 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*

SELECT [Id]
      ,EntityTypeId, [EntityId]
      ,[Entity]
	  ,Name, EntityUid
      ,[CategoryId]
      ,[PropertyCategory]
      ,[SchemaName]
      ,[CodeId]
	  ,FrameworkGroup, FrameworkGroupTitle
      ,[FrameworkCode]
      ,[Title]
      ,[Description]
      ,[URL]
  FROM [dbo].[Entity.FrameworkItemSummary]
	where CategoryId in( 11,10)
order by 2,3,CategoryId

SELECT [EntityId] FROM [dbo].[Entity.FrameworkItemSummary] where CategoryId = 10 and FrameworkCode= ''

*/

--	`NOT CURRENTLY BEING USED!!!!!!!!!!!!!!!!!!!!!!!!
Alter VIEW [dbo].[Entity.FrameworkItemSummary]
AS

SELECT  
	efi.Id,     
	base.EntityTypeId, 
	efi.EntityId, 
	cet.Title As Entity, 
	case 
		when base.EntityTypeId = 1 then c.Name
		when base.EntityTypeId = 2 then o.Name
		when base.EntityTypeId = 3 then am.Name
		when base.EntityTypeId = 7 then lo.Name
		else '' end as Name,
	case 
		when base.EntityTypeId = 1 then c.Id
		when base.EntityTypeId = 2 then o.Id
		when base.EntityTypeId = 3 then am.Id
		when base.EntityTypeId = 7 then lo.Id
		else 0 end as ParentId,
	base.EntityUid,
	efi.CategoryId, 
	cpc.Title AS PropertyCategory, 
	cpc.SchemaName,
	0 As CodeId,
	--efi.CodeId, 

	case when len(Isnull(efi.CodedNotation,'')) > 1 then left(efi.CodedNotation,2)
	else '' end as CodeGroup,
	--case 
	--	when efi.CategoryId = 10 then dbo.NAICS.[NaicsGroup]
	--	when efi.CategoryId = 11 then dbo.ONET_SOC.[JobFamily]
	--	else '' end as CodeGroup,

	--case 
	--	when efi.CategoryId = 10 then dbo.NAICS.NaicsCode
	--	when efi.CategoryId = 11 then dbo.ONET_SOC.OnetSocCode
	--	when efi.CategoryId = 23 then cip.CIPCode
	--	else '' end as FrameworkCode,
	case when len(Isnull(efi.CodedNotation,'')) > 1 then efi.CodedNotation
	else '' end as FrameworkCode,

	case 
		when efi.CategoryId = 10 then naicsHdr.NaicsTitle
		when efi.CategoryId = 11 then jf.Description
		when efi.CategoryId = 23 then cipHdr.[CIPTitle]
		else '' end as FrameworkGroupTitle,
'' as FrameworkGroupTitle2,
	case 
		when efi.CategoryId = 10 then left(dbo.NAICS.NaicsCode,3)
		when efi.CategoryId = 11 then left(dbo.ONET_SOC.OnetSocCode,2)
		when efi.CategoryId = 23 then left(cip.CIPCode,2)
		else '' end as FrameworkGroup,
			case when len(Isnull(efi.CodedNotation,'')) > 1 then left(efi.CodedNotation,2)
	else '' end as FrameworkGroup2,
	efi.name as Title,
	--'' as Description2,
	
	--case 
	--	when efi.CategoryId = 10 then dbo.NAICS.NaicsTitle
	--	when efi.CategoryId = 11 then dbo.ONET_SOC.Title
	--	when efi.CategoryId = 23 then cip.CIPTitle
	--	else '' end as Title,
	case 
		when efi.CategoryId = 10 then dbo.NAICS.NaicsTitle
		when efi.CategoryId = 11 then dbo.ONET_SOC.Description
		when efi.CategoryId = 23 then cip.CIPDefinition
		else '' end as Description,

	efi.targetNode as Url2,
	case 
		when efi.CategoryId = 10 then dbo.NAICS.URL
		when efi.CategoryId = 11 then dbo.ONET_SOC.URL
		when efi.CategoryId = 23 then cip.Url
		else '' end as URL
	
FROM dbo.Entity base
Inner join dbo.[Codes.EntityTypes]		cet on base.EntityTypeId = cet.Id
INNER JOIN dbo.[Entity.FrameworkItem]	efi ON base.Id = efi.EntityId 
--INNER JOIN dbo.[Entity_ReferenceFramework_Summary]	efi ON base.Id = efi.EntityId 

INNER JOIN dbo.[Codes.PropertyCategory] cpc ON efi.CategoryId = cpc.Id

-- =================================================================== 
Left JOIN dbo.NAICS		ON efi.CodedNotation = dbo.NAICS.NaicsCode and efi.CategoryId = 10
--Left JOIN dbo.NAICS	naicsHdr	ON efi.CodedNotation = dbo.NAICS.NaicsCode and efi.CategoryId = 10
--Left JOIN dbo.NAICS		ON efi.CodeId = dbo.NAICS.Id and efi.CategoryId = 10
left join [dbo].NAICS naicsHdr on left(NAICS.NaicsCode,3) = naicsHdr.NaicsCode   AND len(naicsHdr.NaicsCode) = 3

-- ===================================================================
Left JOIN dbo.ONET_SOC	ON efi.CodedNotation = dbo.ONET_SOC.OnetSocCode and efi.CategoryId = 11

--Left JOIN dbo.ONET_SOC	ON efi.CodeId = dbo.ONET_SOC.Id and efi.CategoryId = 11
lEFT join [ONET_SOC.JobFamily]	jf on left(ONET_SOC.OnetSocCode,2) = jf.[JobFamilyId] 

-- ===================================================================
Left JOIN dbo.CIPCode2010 cip	ON efi.CodedNotation = cip.CIPCode and efi.CategoryId = 23
--Left JOIN dbo.[CIPCode2010]		cip ON efi.CodeId = cip.Id and efi.CategoryId = 23
left join [dbo].[CIPCode2010] cipHdr on left(cip.[CIPCode],2) = cipHdr.[CIPCode]   AND len(cipHdr.[CIPCode]) = 2
-- ===================================================================

left join Credential c						on base.EntityUid = c.RowId  and base.EntityTypeId = 1 

left join Organization o						on base.EntityUid = o.RowId 
	and base.EntityTypeId = 2 

left join Assessment am	on base.EntityUid = am.RowId 
	and base.EntityTypeId = 3 

left join LearningOpportunity lo	on base.EntityUid = lo.RowId 
	and base.EntityTypeId = 7 

--where efi.CodeId is not null
where efi.CategoryId in (10,11,23)
--actually may not use the following in order to handle 'others'
--AND isnull(efi.CodedNotation,'') <> ''

GO

grant select on [Entity.FrameworkItemSummary] to public
go
