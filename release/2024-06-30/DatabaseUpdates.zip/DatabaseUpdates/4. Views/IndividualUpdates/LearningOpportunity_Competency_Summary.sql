

/****** Object:  View [dbo].[LearningOpportunity_Competency_Summary]    Script Date: 10/6/2017 4:16:47 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*


SELECT [EntityId]
      ,[LearningOpportunity]
      ,[LearningOpportunityId]
      ,[Name]
      ,[Description]
      ,[TargetName]
      ,[TargetDescription]
      ,[TargetUrl]
      ,[CodedNotation]
      ,[AlignmentType]
  FROM [dbo].[LearningOpportunity_Competency_Summary]
GO
distinct
select * from LearningOpportunity_summary base
where 
( base.Id in (SELECT  LearningOpportunityId FROM [dbo].LearningOpportunity_Competency_Summary  where AlignmentType = 'teaches' AND (([Name] like '%design%' OR [Description] like '%design%')) ) )

*/
/*
LearningOpportunity_Competency_Summary
- list of teaches competencies for a learning opportunity
Modifications
21-05-02 mparsons - stop using: EntityCompetencyFramework_Items_Summary
					- too many joins result

*/
Alter VIEW [dbo].[LearningOpportunity_Competency_Summary]
AS
  /*
     entity.Competency
			 entity (for parent LO)
				LearningOpportunity parent

    			entity.LearningOpp (under the LearningOpportunity entity - for 
    				entity (parent LO)
							LearningOpportunity (rowId)

	*/

SELECT 
	---a.EntityCompetencyFrameworkItemId as Id,
	IsNUll(b.Id,0) AS Id
	,a.[EntityId]
	,l.Name as LearningOpportunity
	,l.Id as LearningOpportunityId
	,l.CTID as LearningOpportunityCTID
	,a.[FrameworkName]
	,a.TargetNodeName AS Competency
	,a.TargetNodeName AS Name 
	--,a.Competency
	--,a.Competency As Name
	,a.TargetNodeDescription
	,a.TargetNodeDescription as Description
	,TargetNode
	,[CodedNotation]
	,a.Alignment as AlignmentType
	,a.Created  as CompetencyCreated
	--  ,'teaches' as [AlignmentType]
	--,AlignmentTypeId
     
	,parentLopp.Id as ParentLearningOpportunityId
	,parentLopp.Name as ParentLearningOpportunity
	  --,parentLopp.Organization as ParentOrganization
--	select *
  --FROM  [EntityCompetencyFramework_Items_Summary] a
FROM       dbo.[Entity.Competency] a
--may not have a framework. Why? Collections. 
Left JOIN dbo.CompetencyFramework b ON a.CompetencyFrameworkId = b.id
inner join Entity e			on a.EntityId = e.Id
inner join LearningOpportunity l on e.EntityUid = l.RowId

  --get related Entity.LearningOpportunity to get a parent lopp if present. 
  --	NOT SURE OF VALUE VS PERFORMANCE
  LEFT join [Entity.LearningOpportunity] entityLopp on l.Id = entityLopp.LearningOpportunityId
  --get parent (most likely comp is at a embedded Lopp level)
  left join Entity pe on entityLopp.EntityId = pe.Id
  left join LearningOpportunity parentLopp on pe.EntityUid = parentLopp.RowId

  where e.EntityTypeId = 7


GO


