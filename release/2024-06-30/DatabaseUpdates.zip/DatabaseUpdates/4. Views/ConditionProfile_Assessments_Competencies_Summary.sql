use credFinder
GO

use sandbox_credFinder
go

/****** Object:  View [dbo].[ConditionProfile_Assessments_Competencies_Summary]    Script Date: 10/6/2017 4:15:21 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*


SELECT [CredentialId]
      ,[ConnectionTypeId]
      ,[RowId]
      ,[nodeLevel]
      ,[AssessmentId]
      ,[Assessment]
			,EntityCompetencyId
      ,[Competency]
      ,[TargetNodeDescription]
      --,[AlignmentType]
      --,[AlignmentTypeId]
  FROM [dbo].[ConditionProfile_Assessments_Competencies_Summary]
where credentialId = 62
order by EntityCompetencyId


select * from credential_summary base
where 
( base.Id in (SELECT CredentialId FROM [dbo].[ConditionProfile_LearningOpp_Competencies_Summary]  where AlignmentType = 'teaches' AND ({0}) ) )

*/

/*


17-10-10 mparsons - commented out ConnectionTypeId and RowId (of condition profile) to avoid duplicates where same lopp is referrenced in multiple conditions
23-07-11 mparsons - need to review this. Appears to be for credentials
*/
Alter VIEW [dbo].[ConditionProfile_Assessments_Competencies_Summary]
AS
--do we want to limit this to a particular connection type - probably just requirements

SELECT DISTINCT 
	base.CredentialId, 
	--base.ConnectionTypeId, 
	--base.RowId, 
	'level1' as nodeLevel,
	competencies.AssessmentId, 
	competencies.Assessment,
	competencies.Id As CompetencyFrameworkItemId,
	competencies.EntityCompetencyId,
	competencies.Competency, 
	competencies.TargetNodeDescription, 
	competencies.CompetencyCreated

FROM            
		dbo.Credential_ConditionProfile AS base  
--base.EntityId is the Id for the Entity.ConditionProfile Entity
/*
	Credential
		Entity
			Entity.ConditionProfile
				Entity
					Entity.Assessment

*/
INNER JOIN dbo.[Entity.Assessment] AS b					ON base.EntityId = b.EntityId 
INNER JOIN dbo.Assessment_Competency_Summary AS competencies ON b.AssessmentId = competencies.AssessmentId

--where base.CredentialId= 62
go
grant select on [ConditionProfile_Assessments_Competencies_Summary] to public


GO


