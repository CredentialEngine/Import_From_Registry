
/****** Object:  View [dbo].[Assessment_Summary]    Script Date: 5/31/2020 9:44:06 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*

USE [credFinder]
GO

SELECT [Id]
      ,[Name]
      ,[Description]
      ,[OrgId]
      ,[Organization]
      ,[DateEffective]
      ,[SubjectWebpage]
      ,[EntityStateId]
      ,[CTID]
      ,[CredentialRegistryId]
      ,[cerEnvelopeUrl]
      ,[IdentificationCode]
      ,[availableOnlineAt]
      ,[AvailabilityListing]
      ,[AssessmentExampleUrl]
      ,[ProcessStandards]
      ,[ScoringMethodExample]
      ,[ExternalResearch]

      ,[RequiresCount]
      ,[RecommendsCount]
      ,[isRequiredForCount]
      ,[IsRecommendedForCount]
      ,[IsAdvancedStandingForCount]
      ,[AdvancedStandingFromCount]
      ,[isPreparationForCount]
      ,[PreparationFromCount]

      --,[ConnectionsList]
      --,[CredentialsList]
	  ,Org_QAAgentAndRoles
	        ,[Created]
      ,[LastUpdated]
      ,[RowId]
  FROM [dbo].[Assessment_Summary]
  where EntityStateId= 2

  and len(Org_QAAgentAndRoles) > 0
where IsAdvancedStandingForCount> 0





*/
ALTER VIEW [dbo].[Assessment_Summary]
AS

SELECT base.[Id]
	,base.[Name]
	,base.[Description]
	,base.EntityStateId
	,isnull(base.CTID,'') As CTID 	
	--owning org
	,isnull(owningOrg.Id,0) as OrgId
	,isnull(owningOrg.Name,'') as Organization
	,isnull(owningOrg.CTID,'') as OwningOrganizationCtid
	,base.OwningAgentUid
	,[DateEffective]
	-- ,[OrgId]      ,base.[AgentUid]
	,base.SubjectWebpage 

	,base.CredentialRegistryId   
	--,case when len(isnull(base.CredentialRegistryId,'')) = 36 then
	--'<a href="http://lr-staging.learningtapestry.com/ce-registry/envelopes/' + base.CredentialRegistryId + '" target="_blank">cerEnvelope</a>'
	--else '' End As cerEnvelopeUrl  
	,'' As cerEnvelopeUrl 
	,case when IsNull(base.LifeCycleStatusTypeId,0) > 0 then base.LifeCycleStatusTypeId
	else 0 end As LifeCycleStatusTypeId --default to production value for now

	,case when IsNull(base.LifeCycleStatusTypeId,0) > 0 then cpv.Title
	else '' end As LifeCycleStatusType 

	,[IdentificationCode]
	,base.availableOnlineAt
	,base.AvailabilityListing
	,base.AssessmentExampleUrl
	,base.ProcessStandards
	,base.ScoringMethodExample
	,base.ExternalResearch
	,base.IsNonCredit
	,base.[Created]
	,base.[LastUpdated]
	,base.RowId

	,IsNull(c1.Nbr,0) As RequiresCount
	,IsNull(c2.Nbr,0) As RecommendsCount
	,IsNull(c3.Nbr,0) As isRequiredForCount
	,IsNull(c4.Nbr,0) As IsRecommendedForCount
	,IsNull(c6.Nbr,0) As IsAdvancedStandingForCount
	,IsNull(c7.Nbr,0) As AdvancedStandingFromCount
	,IsNull(c8.Nbr,0) As isPreparationForCount
	,IsNull(c9.Nbr,0) As PreparationFromCount
    
		--actual connection type (no credential info)
	,isnull(connectionsCsv.Profiles,'') As ConnectionsList	
	--connection type, plus Id, and name of credential - need to handle other entities		
	,isnull(connectionsCsv.CredentialsList,'') As CredentialsList	

--	24-02-22 - not much of a difference after removing these
	--,0 As RequiresCount
	--,0 As RecommendsCount
	--,0 As isRequiredForCount
	--,0 As IsRecommendedForCount
	--,0 As IsAdvancedStandingForCount
	--,0 As AdvancedStandingFromCount
	--,0 As isPreparationForCount
	--,0 As PreparationFromCount
	--,'' as ConnectionsList


	--,isnull(qaRoles.Org_QAAgentAndRoles,'') As Org_QAAgentAndRoles
	,'' as Org_QAAgentAndRoles
  FROM [dbo].[Assessment] base
  left join [codes.PropertyValue] cpv on base.LifeCycleStatusTypeId = cpv.Id
-- join for owner
	Left join Organization owningOrg on base.OwningAgentUid = owningOrg.RowId and owningOrg.EntityStateId > 1
	--24-02-18 mp - this is wrong, LifeCycleStatusTypeId is on base. It was a fall back
	--Left Join EntityProperty_Summary	statusProperty on base.RowId = statusProperty.EntityUid and statusProperty.CategoryId = 84		--LifeCycleStatus


	-- ===================== condition profiles ====================================
	--conditionProfiles - Post-Award Connections (Requirements)\
	left join (
		Select ParentId, Count(*) As Nbr from Entity_ConditionProfileTargetsSummary 
		where ParentEntityTypeId= 3 
		AND ConnectionTypeId = 1 and isnull(ConditionSubTypeId, 1) = 2
		group by ParentId

	) c1 on base.Id = c1.ParentId
--conditionProfiles - Attainment Recommendations
left join (
	Select ParentId, Count(*) As Nbr from Entity_ConditionProfileTargetsSummary where ParentEntityTypeId= 3 
	AND ConnectionTypeId = 2 and isnull(ConditionSubTypeId, 1) = 2
	group by ParentId
	) c2						on base.Id = c2.ParentId
	left join (
	Select ParentId, Count(*) As Nbr from Entity_ConditionProfileTargetsSummary where ParentEntityTypeId= 3 
	AND ConnectionTypeId = 3 group by ParentId
	) c3						on base.Id = c3.ParentId
		
	--conditionProfiles - Post-Award Connections (Recommendations)
	left join (
	Select ParentId, Count(*) As Nbr from Entity_ConditionProfileTargetsSummary where ParentEntityTypeId= 3 
	AND ConnectionTypeId = 4 group by ParentId
	) c4						on base.Id = c4.ParentId

	--conditionProfiles - Advanced Standing For
	left join (
	Select ParentId, Count(*) As Nbr from Entity_ConditionProfileTargetsSummary where ParentEntityTypeId= 3 
	AND ConnectionTypeId = 6 group by ParentId
	) c6						on base.Id = c6.ParentId
								
		
	--conditionProfiles - Advanced Standing From
	left join (
	Select ParentId, Count(*) As Nbr from Entity_ConditionProfileTargetsSummary where ParentEntityTypeId= 3 
	AND ConnectionTypeId = 7 group by ParentId
	) c7						on base.Id = c7.ParentId
		
		
	--======== connection Profiles  Preparation For=======
	left join (
	Select ParentId, Count(*) As Nbr from Entity_ConditionProfileTargetsSummary where ParentEntityTypeId= 3 
	AND ConnectionTypeId = 8 group by ParentId
	) c8						on base.Id = c8.ParentId

	--conditionProfiles - Preparation From
	left join (
	Select ParentId, Count(*) As Nbr from Entity_ConditionProfileTargetsSummary where ParentEntityTypeId= 3 
	AND ConnectionTypeId = 9 group by ParentId
	) c9						on base.Id = c9.ParentId		

	--connections ? how different from the above
	left join Entity_ConditionProfilesConnectionsCSV connectionsCsv 
				on connectionsCsv.ParentEntityTypeId = 3 
				AND base.id = connectionsCsv.ParentId

--TODO - Entity_QARolesCSV uses entity_summary (many unions), need to change this
	--left join [Entity_QARolesCSV] qaRoles 
	--			on qaRoles.EntityTypeId = 3 
	--			AND base.id = qaRoles.BaseId
where base.EntityStateId >= 2

GO

grant select on [Assessment_Summary] to public
go


Alter View CollectionSummary
AS
SELECT  base.[Id]
	--need EntityId as a unique Id for a common elastic index
	,e.Id as EntityId
	,base.[Name]
	,base.[Description]
	,base.[EntityStateId]
	,base.[CTID]
	--
	,base.[OwningAgentUid]
	,isnull(b.ctid,'')  as OrganizationCTID
	,b.Id as OrganizationId
	,b.Name as OrganizationName
	,b.EntityStateId as OrganizationEntityStateId
	,case when IsNull(base.LifeCycleStatusTypeId,0) > 0 then base.LifeCycleStatusTypeId
	else 2648 end As LifeCycleStatusTypeId --default to production value for now

	,case when IsNull(base.LifeCycleStatusTypeId,0) > 0 then cpv.Title
	else 'Active' end As LifeCycleStatusType --
	--
	,base.[SubjectWebpage]
	,base.[CodedNotation]
	,base.[License]
	,base.[DateEffective]
	,base.[ExpirationDate]
	,base.[CredentialRegistryId]
	,base.[Created]
	,base.[LastUpdated]
	,base.[RowId]
	,base.[CollectionGraph]

  FROM [dbo].[Collection] base
  Inner join Entity e on base.rowId = e.EntityUid
  LEFT  JOIN dbo.Organization AS b ON base.OwningAgentUid = b.RowId
  left join [codes.PropertyValue] cpv on base.LifeCycleStatusTypeId = cpv.Id
where base.EntityStateId > 1
--
GO

grant select on CollectionSummary to public
go


/*

SELECT top 500
	[Id]
      ,[Name]
      ,[Description]
      ,[EntityStateId]
      ,[CTID]
      ,[OrganizationCTID]
      ,[OrganizationId]
      ,[OrganizationName]
      ,[FrameworkUri]
      ,[SourceUrl]
      ,[ExistsInRegistry]
      ,[CredentialRegistryId]
      ,[ReferencedByAssessments]
      ,[ReferencedByLearningOpportunities]
      ,[ReferencedByCredentials]
      ,[Created]
      ,[LastUpdated]
      ,[RowId]
      ,[CompetencyFrameworkGraph]
  FROM [dbo].[CompetencyFramework_Summary]
  --where ctid = 'ce-bccf8721-c455-4a5f-9314-791641a70868'
  where CTID is not null

GO




*/
/*
Competency Framework summary 
- only includes data in the registry

*/
Alter view CompetencyFramework_Summary
as

SELECT a.[Id]
      ,a.[Name]
	  ,a.Description
      ,a.[EntityStateId]
      ,a.[CTID]
	  --organization
      ,a.[OrganizationCTID]
	  ,IsNUll(b.id,0)		As OrganizationId
	  ,IsNull(b.Name,'')	as OrganizationName
      ,a.[FrameworkUri]
      ,a.[SourceUrl]
      ,isnull(a.[ExistsInRegistry],0) as [ExistsInRegistry]
      ,a.[CredentialRegistryId]
	  ,IsNull(AlignedAsmts.total,0) as ReferencedByAssessments
	  ,IsNull(AlignedLopps.total,0) as ReferencedByLearningOpportunities
	  ,IsNull(AlignedCreds.total,0) as ReferencedByCredentials
      ,a.[Created]
      ,a.[LastUpdated]
      ,a.[RowId]
	  ,a.CompetencyFrameworkGraph
	  ,a.CompetenciesStore
	  ,a.TotalCompetencies

  FROM [dbo].[CompetencyFramework] a
  left Join Organization b on a.OrganizationCTID = b.CTID
  -- this expensive to include aligned totals - is it being used anywhere?
  left Join (
	  Select alignedTotals.CompetencyFrameworkId,  COUNT(*) as total
	  from (

		Select a.CompetencyFrameworkId, c.Id,  COUNT(*) as total
		from [Entity.Competency] a
		Inner join Entity b on a.EntityId = b.Id
		Inner join Assessment c on b.EntityUid = c.RowId
		where c.EntityStateId = 3 and b.EntityTypeId = 3
		group by a.CompetencyFrameworkId, c.id
		--order by 1,2
		) as alignedTotals
		group by alignedTotals.CompetencyFrameworkId
		--order by 1

  ) as AlignedAsmts on a.id = AlignedAsmts.CompetencyFrameworkId
--
  left Join (
	  Select alignedTotals.CompetencyFrameworkId,  COUNT(*) as total
	  from (

		Select a.CompetencyFrameworkId, c.Id,  COUNT(*) as total
		from [Entity.Competency] a
		Inner join Entity b on a.EntityId = b.Id
		Inner join LearningOpportunity c on b.EntityUid = c.RowId
		where c.EntityStateId = 3 and b.EntityTypeId = 7
		group by a.CompetencyFrameworkId, c.id
		--order by 1,2
		) as alignedTotals
		group by alignedTotals.CompetencyFrameworkId
		--order by 1

  ) as AlignedLopps on a.id = AlignedLopps.CompetencyFrameworkId
  --
  left Join (
	  Select alignedTotals.CompetencyFrameworkId,  COUNT(*) as total
	  from (

		Select a.CompetencyFrameworkId, a.ParentEntityBaseId,  COUNT(*) as total
		from [ConditionProfile_RequiredCompetencies] a
		Inner join Credential c on a.ParentEntityUid = c.RowId
		where a.ParentEntityTypeId = 1
		group by a.CompetencyFrameworkId, a.ParentEntityBaseId
		--order by 1,2
		) as alignedTotals
		group by alignedTotals.CompetencyFrameworkId
		--order by 1

  ) as AlignedCreds on a.id = AlignedCreds.CompetencyFrameworkId
  where 
  --Why? - changed to include references
  --OR maybe incorrect. If a ctid exists, should mean was published
  ( a.EntityStateId > 1 )
  --and [ExistsInRegistry] = 1 
  go

  grant select on CompetencyFramework_Summary to public

  go
/****** Object:  View [dbo].[ConditionProfile_Assessments_Competencies_Summary]    Script Date: 10/6/2017 4:15:21 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*


SELECT [CredentialId]
      ,[ConnectionTypeId]
      ,[RowId]
      ,[nodeLevel]
      ,[AssessmentId]
      ,[Assessment]
			,EntityCompetencyId
      ,[Competency]
      ,[TargetNodeDescription]
      --,[AlignmentType]
      --,[AlignmentTypeId]
  FROM [dbo].[ConditionProfile_Assessments_Competencies_Summary]
where credentialId = 62
order by EntityCompetencyId


select * from credential_summary base
where 
( base.Id in (SELECT CredentialId FROM [dbo].[ConditionProfile_LearningOpp_Competencies_Summary]  where AlignmentType = 'teaches' AND ({0}) ) )

*/

/*


17-10-10 mparsons - commented out ConnectionTypeId and RowId (of condition profile) to avoid duplicates where same lopp is referrenced in multiple conditions
23-07-11 mparsons - need to review this. Appears to be for credentials
*/
Alter VIEW [dbo].[ConditionProfile_Assessments_Competencies_Summary]
AS
--do we want to limit this to a particular connection type - probably just requirements

SELECT DISTINCT 
	base.CredentialId, 
	--base.ConnectionTypeId, 
	--base.RowId, 
	'level1' as nodeLevel,
	competencies.AssessmentId, 
	competencies.Assessment,
	competencies.Id As CompetencyFrameworkItemId,
	competencies.EntityCompetencyId,
	competencies.Competency, 
	competencies.TargetNodeDescription, 
	competencies.CompetencyCreated

FROM            
		dbo.Credential_ConditionProfile AS base  
--base.EntityId is the Id for the Entity.ConditionProfile Entity
/*
	Credential
		Entity
			Entity.ConditionProfile
				Entity
					Entity.Assessment

*/
INNER JOIN dbo.[Entity.Assessment] AS b					ON base.EntityId = b.EntityId 
INNER JOIN dbo.Assessment_Competency_Summary AS competencies ON b.AssessmentId = competencies.AssessmentId

--where base.CredentialId= 62
go
grant select on [ConditionProfile_Assessments_Competencies_Summary] to public


GO




/****** Object:  View [dbo].[ConditionProfile_RequiredCompetencies]    Script Date: 3/22/2018 7:18:54 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*

SELECT 
--top 1000
a.[ParentEntityId]
      ,a.[ParentEntityUid]
      ,a.[ParentEntityTypeId]
      ,a.[ParentEntityBaseId]
      ,a.[ParentEntityName]
	  ,c.CTID as parentCTID
      ,a.[EntityConditionProfileId]
      ,a.[CompetencyFrameworkId]
      ,a.[FrameworkName]
      ,a.[TargetNodeName]
	  ,a.TargetNodeCTID
      ,a.[AlignmentType]
	  	,a.CompetencyCategory
	,a.CompetencyLabel
	,a.competencyCreatedDate
  FROM [dbo].[ConditionProfile_RequiredCompetencies] a
  inner join Credential c on a.ParentEntityUid = c.RowId
  where c.EntityStateId = 3
  --where a.[FrameworkName] = 'BCSP: CHST Examination'
  --or IsNull(a.CompetencyLabel,'') <> ''
  order by a.[ParentEntityName], a.[FrameworkName], a.competencyCreatedDate
GO




*/
/*

Modifications
23-01-08 mparsons - Added Alignment to Entity.Competency
*/
ALTER VIEW [dbo].[ConditionProfile_RequiredCompetencies]
AS
SELECT        
	c.EntityId AS ParentEntityId, 
	cpParentEntity.EntityUid AS ParentEntityUid, 
	cpParentEntity.EntityTypeId AS ParentEntityTypeId, 
	cpParentEntity.EntityBaseId AS ParentEntityBaseId, 
	cpParentEntity.EntityBaseName AS ParentEntityName, 
	c.Id AS EntityConditionProfileId,
	a.Id as entityCompetencyId
	,a.CompetencyFrameworkId
	,a.FrameworkName
    --a.EducationFrameworkId
	, a.TargetNodeName
	,a.TargetNodeCTID
	,a.Alignment as AlignmentType
	,cfc.CompetencyCategory
	,cfc.CompetencyLabel
	,cfc.Created as competencyCreatedDate
FROM            dbo.[Entity.Competency]		AS a 
--may not have a framework. Why? Collections. 
--Left JOIN dbo.CompetencyFramework cf ON a.CompetencyFrameworkId = cf.id
Left Join [CompetencyFramework.Competency] cfc on a.TargetNodeCTID = cfc.CTID
INNER JOIN dbo.Entity						AS b ON a.EntityId = b.Id 
INNER JOIN dbo.[Entity.ConditionProfile]	AS c ON b.EntityUid = c.RowId 
INNER JOIN dbo.Entity						AS cpParentEntity ON c.EntityId = cpParentEntity.Id

GO
grant select on [ConditionProfile_RequiredCompetencies] to public
go



/****** Object:  View [dbo].[CredentialingAction_Summary]    Script Date: 7/29/2020 11:13:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*

SELECT [Id]
      ,[RowId]
      ,[EntityId]
      ,[CTID]
      ,[EntityStateId]
      ,[ActionTypeId]
      ,[Name]
      ,[Description]
      ,[ActingAgentUid]
      ,[PrimaryOrganizationId]
      ,[PrimaryOrganizationName]
      ,[PrimaryOrganizationCtid]
      ,[ActionStatusId]
      ,[StartDate]
      ,[EndDate]
      ,[EvidenceOfAction]
      ,[ResultingAward]
      ,[Created]
      ,[LastUpdated]
  FROM [dbo].[CredentialingAction_Summary]

GO


*/
/*
CredentialingAction_Summary
Notes
- 
Mods
22-11-08 mparsons - new

*/
Create VIEW [dbo].[CredentialingAction_Summary]
AS

SELECT a.[Id]
      ,a.[RowId]
	   	,e.Id as EntityId
      ,a.[CTID]
      ,a.[EntityStateId]
      ,a.[ActionTypeId]
	  ,actionType.Name as ActionType
	  ,actionType.SchemaName as ActionTypeSchema
      ,a.[Name]
      ,a.[Description]
      ,a.[ActingAgentUid]
	  		,isnull(primaryOrg.Id,0)	as PrimaryOrganizationId
		,isnull(primaryOrg.Name,'') as PrimaryOrganizationName
		,isnull(primaryOrg.CTID,'') as PrimaryOrganizationCtid
      ,a.ActionStatusTypeId
	  ,actionStatus.Title as ActionStatusType
	  ,actionStatus.SchemaName as ActionStatusSchemaName
      ,a.[StartDate]
      ,a.[EndDate]
	  --get object - hasResource?
	  --get partcipants
      ,a.[EvidenceOfAction]
      ,a.[ResultingAward]
      ,a.[Created]
      ,a.[LastUpdated]

	  	--typically only one
	, CASE
			WHEN Credentials IS NULL THEN ''
			WHEN len(Credentials) = 0 THEN ''
			ELSE left(Credentials,len(Credentials)-1)
		END AS Instrument

FROM [dbo].[CredentialingAction] a
INNER JOIN dbo.Entity AS e						ON a.RowId = e.EntityUid 
Left Join [Codes.PropertyValue] actionStatus	on a.ActionStatusTypeId = actionStatus.Id
--Left Join [Codes.PropertyValue] actionType		on a.ActionTypeId = actionType.Id
Left Join [Codes.CredentialingActionType] actionType	on a.ActionTypeId = actionType.Id
-- join for primary
Left join Organization primaryOrg on a.ActingAgentUid = primaryOrg.RowId and primaryOrg.EntityStateId > 1

--TBD on use of entity.credential or hasResource!!! or on the table if really only one
CROSS APPLY (
	SELECT 
		convert(varchar,caec.CredentialId) + '~ ' + convert(varchar,cac.Name) + ', '
	FROM dbo.[Entity.Credential] caec
	Inner Join Credential cac on caec.credentialId = cac.Id
	INNER JOIN dbo.Entity cae ON caec.EntityId = cae.Id 
	WHERE (a.EntityStateId = 3) 
	AND e.Id = caec.EntityId
	FOR XML Path('') 
) creds (Credentials)

GO

grant select on [CredentialingAction_Summary] to public
go







/****** Object:  View [dbo].[Credential_ConditionProfile]    Script Date: 8/22/2017 5:26:56 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*

SELECT DISTINCT
	 [CredentialId]
     -- ,[CredentialRowId]
      ,[parentEntityId]
      ,a.[Name] As Credential
      ,a.[EntityId]
     -- ,[EntityTypeId]
    --  ,[EntityUid]
      ,[EntityConditionProfileId]
      --,[ConnectionTypeId]
      --,[ConditionSubTypeId]
      --,[ConnectionType]
      ,[ConnectionTypeSchemaName]
      --,a.[RowId]
	  ,ConditionDescription
      ,[HasTargetCredential]
      ,[HasTargetAssessment]
	  ,ISNULL(asmt.Id, 0) AS AssessmentId
	  ,asmt.Name as Assessment, asmt.SubjectWebpage as AssessmentSubjectWebpage

      ,[HasLearningOpportunity]
	  ,ISNULL(lo.Id, 0) AS LearningOpportunityId
	  ,lo.Name as LearningOpportunity, lo.SubjectWebpage as LearningOpportunitySubjectWebpage
  FROM [dbo].[Credential_ConditionProfile] a

	inner join [Credential_BasicSummary] c on a.CredentialId = c.Id
	Inner Join [Indiana.OrganizationSummary] d on c.OwningAgentUid = d.RowId
	Left JOIN dbo.[Entity.LearningOpportunity] elo ON a.EntityId = elo.EntityId 
	Left join LearningOpportunity lo on elo.LearningOpportunityId = lo.Id and lo.EntityStateId > 1

	Left JOIN dbo.[Entity.Assessment] ea ON a.EntityId = ea.EntityId 
	Left join Assessment asmt on ea.AssessmentId = asmt.Id and asmt.EntityStateId > 1
where 
	ConnectionTypeId= 1 and ConditionSubTypeId = 1 -- requires only


*/
/*
NOTE: should this be excluding connection profiles????
	Cannot at this time, as used in the view Credential_PartsSummary

Entity.ConditionProfile a
	Entity condProfEntity	on a.RowId = condProfEntity.EntityUid (entity for condition, not parent)
	Entity credEntity		on a.EntityId  = credEntity.Id
	credential c			on c.RowId = credEntity.EntityUid

*/
Alter VIEW [dbo].[Credential_ConditionProfile]
AS
SELECT        
	c.Id AS CredentialId
	, c.RowId as CredentialRowId
	, a.EntityId as parentEntityId
	, c.Name
	, condProfEntity.Id As EntityId		-- entityId for the Entity for the ConditionProfile
	, condProfEntity.EntityTypeId		--?? always cond profile
	, credEntity.EntityUid					--mixing Entity references!!!
	, a.Id AS EntityConditionProfileId
	, a.ConnectionTypeId
	, isnull(a.ConditionSubTypeId,1) as ConditionSubTypeId
	, a.Description as ConditionDescription
	, cpv.Title as ConnectionType
	, cpv.SchemaName as ConnectionTypeSchemaName

	--temp for testing
	--, ec.CredentialId as TargetCredential
	, a.RowId		--Can use to join Entity.Assessment and Entity.LearningOpportunity 
							--RowId = Entity.EntitUid and Entity.Id = child.EntityId
	-- AS EntityConditionProfileRowId
	,case when exists (select a.credentialId from [Entity.Credential] a 
		inner join Credential b on a.CredentialId = b.Id and b.EntityStateId > 1 
		where a.EntityId = condProfEntity.id) then 1			else 0 end As HasTargetCredential
	,case when exists (select AssessmentId from [Entity.Assessment] a
		inner join Assessment b on a.AssessmentId = b.Id and b.EntityStateId > 1 
		where a.EntityId = condProfEntity.id) then 1			else 0 end As HasTargetAssessment
	,case when exists (select LearningOpportunityId from [Entity.LearningOpportunity] a
		inner join LearningOpportunity b on a.LearningOpportunityId = b.Id and b.EntityStateId > 1 
		where a.EntityId = condProfEntity.id) then 1			else 0 end As HasLearningOpportunity


FROM	dbo.[Entity.ConditionProfile] a
--entity of parent/credential
INNER JOIN dbo.Entity credEntity			ON a.EntityId = credEntity.Id		
INNER JOIN dbo.Credential c					ON credEntity.EntityUid = c.RowId

Inner Join [Codes.PropertyValue] cpv	on a.ConnectionTypeId = cpv.Id
--entity for cond profile
INNER JOIN dbo.Entity condProfEntity	ON a.RowId = condProfEntity.EntityUid		
--temp for testing:
--Left Join [Entity.Credential] ec on condProfEntity.Id = ec.EntityId

where c.EntityStateId > 1

GO
grant select on [Credential_ConditionProfile] to public
go



/****** Object:  View [dbo].[Credential_Export]    Script Date: 10/4/2023 2:51:53 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*

SELECT top 1000
[CTID]
      ,[OwnedBy]
      ,[CredentialRecordId]
      ,[CredentialName]
      ,[Description]
      ,[CredentialType]
      ,[CredentialStatus]
      ,[Webpage]
      ,[AvailableOnlineAt]
      ,[AvailabilityListing]
      ,[AlternateName]
      ,[CodedNotation]
      ,[CredentialId]
      ,[CredentialImage]
      ,[Language]
      ,[DateEffective]
      ,[Keywords]
      ,[Subjects]
      ,[AudienceLevelType]
      ,[IndustryType]
      ,[NAICS List]
      ,[OccupationType]
      ,[O*NET List]
      ,[InstructionalProgramType]
      ,[CIP List]
      ,[AvailableAt]
      ,[DegreeMajor]
      ,[OfferedBy]
      ,[AccreditedBy]
      ,[ApprovedBy]
      ,[RecognizedBy]
      ,[CopyrightHolder]
      ,[ProcessStandards]
      ,[ProcessStandards Description]
      ,[Estimated Duration]
      ,[Cost: Internal Identifier]
      ,[Cost: External Identifier]
      ,[Cost: Name]
      ,[Cost: Description]
      ,[Cost: Details Url]
      ,[Cost: Currency Type]
      ,[Cost: Types List]
      ,[ConditionProfile: Condition Type]
      ,[ConditionProfile: Internal Identifier]
      ,[ConditionProfile: External Identifier]
      ,[ConditionProfile: Name]
      ,[ConditionProfile: Description]
      ,[ConditionProfile: Subject Webpage]
      ,[ConditionProfile: Submission Of Items]
      ,[ConditionProfile: Condition Items]
      ,[ConditionProfile: Experience]
      ,[ConditionProfile: Years Of Experience]
      ,[ConditionProfile: CreditHourType]
      ,[ConditionProfile: CreditHourValue]
      ,[ConditionProfile: CreditUnitType]
      ,[ConditionProfile: CreditUnitValue]
      ,[ConditionProfile: CreditUnitTypeDescription]
  FROM [dbo].[Credential_Export]

  order by [CredentialName]
GO



*/

/****** Object:  View [dbo].[Entity.ProgramsCSV]    Script Date: 7/3/2018 5:24:47 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*


SELECT [EntityId]
      ,[Programs]
  FROM [dbo].[Entity.ProgramsCSV]
order by 1,2


*/

/*
Needed for [Credential_Export]
modifications

*/
Create VIEW [dbo].[Entity.ProgramsCSV]
AS

SELECT     distinct
base.EntityId, 
    CASE
          WHEN Programs IS NULL THEN ''
          WHEN len(Programs) = 0 THEN ''
          ELSE left(Programs,len(Programs)-1)
    END AS Programs,
    CASE
          WHEN CipList IS NULL THEN ''
          WHEN len(CipList) = 0 THEN ''
          ELSE left(CipList,len(CipList)-1)
    END AS CipList,
	CASE
          WHEN Others IS NULL THEN ''
          WHEN len(Others) = 0 THEN ''
          ELSE left(Others,len(Others)-1)
    END AS Others
FROM [dbo].[Entity_ReferenceFramework_Summary] base

CROSS APPLY (
--SELECT cp.FrameworkCode  + '~' + cp.Title + '| '
    SELECT convert(varchar, cp.CodedNotation) + '~' + cp.Name  + '| '
	 FROM dbo.[Entity_ReferenceFramework_Summary] cp 
 
    WHERE cp.CategoryId = 23
	and base.EntityId = cp.EntityId
    FOR XML Path('') ) D (Programs)
--' ( ' + cp.FrameworkCode + ' )'  +

CROSS APPLY (
    SELECT cp.CodedNotation  + '| '
    FROM dbo.[Entity_ReferenceFramework_Summary] cp 
    WHERE cp.CategoryId = 23
	and base.EntityId = cp.EntityId
	and isnull(cp.CodedNotation,'') <> ''

    FOR XML Path('') ) codes (CipList)


CROSS APPLY (
    SELECT cp.Name  + '| '
    FROM dbo.[Entity_ReferenceFramework_Summary] cp 

    WHERE cp.CategoryId = 23
	and base.EntityId = cp.EntityId
	and isnull(cp.CodedNotation,'') = ''

    FOR XML Path('') ) er (Others)

WHERE base.CategoryId = 23
and base.Id is not null
AND (Programs is not null Or Others is not null)

GO

grant select on [Entity.ProgramsCSV] to public
go

/*
export view for credentials

-- =========================================================
18-09-20 mparsons - created a lite version of the export
*/
Create VIEW [dbo].[Credential_Export]
AS

select distinct
	a.CTID
	,b.ctid as 'OwnedBy'
	,a.Id as CredentialRecordId
	,a.Name As 'CredentialName'
	,a.Description
	--,replace(a.Description, '"','`') as Description

	--,'Roles'
	,replace(a .CredentialTypeSchema, 'ceterms:','') as 'CredentialType'
	,cstat.Property as  'CredentialStatus'
	, a.SubjectWebpage as 'Webpage'
	, isnull(c.AvailableOnlineAt,'') 'AvailableOnlineAt'
	, isnull(c.AvailabilityListing,'') 'AvailabilityListing'
	, isnull(c.AlternateName,'') 'AlternateName'
	, isnull(c.CodedNotation,'') 'CodedNotation'
	, isnull(c.CredentialId,'')  'CredentialId'
	, isnull(c.ImageUrl,'') 'CredentialImage'
	-- ============= languages ================
	, IsNull(STUFF(
	(	
		SELECT '|' +  Replace([TextValue], 'English (en)', 'en') AS [text()] 
		FROM [dbo].[Entity.Reference] els
		where CategoryId = 65 AND els.EntityId = a.EntityId 
		FOR XML Path('')
		), 1,1,''
	),'') as 'Language'

	-- ===========================================
	, case when c.EffectiveDate < '1950-01-01' then ''
		when c.EffectiveDate is null then ''
		else  convert(varchar(10),c.EffectiveDate,120)  end  'DateEffective'
	, IsNull(STUFF(
		(	
		SELECT '|' + ISNULL([TextValue], '') AS [text()]  FROM [dbo].[Entity.Reference] keywords 
		where [CategoryId]= 35  and keywords.EntityId = a.EntityId
		FOR XML Path('') ), 1,1,''
	),'') as 'Keywords'


	, IsNull(esub.DirectSubjects,'') 'Subjects'

	, IsNull(STUFF(
		(	
		SELECT '|' + Replace(ISNULL(eps.PropertySchemaName, ''),'audLevel:','') AS [text()] 
		FROM [dbo].[EntityProperty_Summary] eps 
		where eps.EntityTypeId = 1 AND eps.CategoryId = 4 AND eps.EntityId = a.EntityId 
		FOR XML Path('')
		), 1,1,''
	),'') as 'AudienceLevelType'

	,IsNull(enaics.Naics,'')		'IndustryType'
	,IsNull(enaics.NaicsList,'')	'NAICS List'
	,IsNull(eoccupations.Occupations,'')    'OccupationType'
	,IsNull(eoccupations.OnetList,'')  'O*NET List'
		,isnull(ePrograms.Programs,'')    'InstructionalProgramType'
	,isnull(ePrograms.CipList,'')  'CIP List'
	,IsNull(STUFF(
		(	
		SELECT '|' + convert(varchar,addresses.Id) AS [text()]  FROM [dbo].[Entity.Address] addresses 
		where addresses.EntityId = a.EntityId
		FOR XML Path('')
		), 1,1,''
	),'') as 'AvailableAt'
	, IsNull(STUFF(
		(	
		SELECT '|' + ISNULL([TextValue], '') AS [text()]  FROM [dbo].[Entity.Reference] keywords 
		where [CategoryId]= 63  and keywords.EntityId = a.EntityId
		FOR XML Path('') ), 1,1,''
	),'') as 'DegreeMajor'
	

	--consider combining roles into one column with a new pattern
	--user could be confused by the use of CTID
	--SELECT '|' + convert(varchar(50),earOrg.Ctid) AS [text()]  FROM [dbo].[Entity.AgentRelationship] ear
	, IsNull(STUFF(
		(	
		SELECT '|' + case when isnull(earOrg.CTID,'') = '' then earOrg.Name + '~' + earOrg.SubjectWebpage else earOrg.CTID end AS [text()] FROM [dbo].[Entity.AgentRelationship] ear
		Inner Join Organization earOrg on ear.agentUid = earOrg.rowId 
		where ear.EntityId = a.EntityId AND ear.RelationshipTypeId = 7
		--and earorg.Id = 4652
		FOR XML Path('')
		), 1,1,''
	),'') as 'OfferedBy'
	, IsNull(STUFF(
		(	
		SELECT '|' + case when isnull(earOrg.CTID,'') = '' then earOrg.Name + '~' + earOrg.SubjectWebpage else earOrg.CTID end AS [text()] FROM [dbo].[Entity.AgentRelationship] ear
		Inner Join Organization earOrg on ear.agentUid = earOrg.rowId 
		where ear.EntityId = a.EntityId AND ear.RelationshipTypeId = 1
		FOR XML Path('')
		), 1,1,''
	),'') as 'AccreditedBy'
	, IsNull(STUFF(
		(	
		SELECT '|' + case when isnull(earOrg.CTID,'') = '' then earOrg.Name + '~' + earOrg.SubjectWebpage else earOrg.CTID end AS [text()] FROM [dbo].[Entity.AgentRelationship] ear
		Inner Join Organization earOrg on ear.agentUid = earOrg.rowId 
		where ear.EntityId = a.EntityId AND ear.RelationshipTypeId = 2
		FOR XML Path('')
		), 1,1,''
	),'') as 'ApprovedBy'
	, IsNull(STUFF(
		(	
		SELECT '|' + case when isnull(earOrg.CTID,'') = '' then earOrg.Name + '~' + earOrg.SubjectWebpage else earOrg.CTID end AS [text()] FROM [dbo].[Entity.AgentRelationship] ear
		Inner Join Organization earOrg on ear.agentUid = earOrg.rowId 
		where ear.EntityId = a.EntityId AND ear.RelationshipTypeId = 10
		FOR XML Path('')
		), 1,1,''
	),'') as 'RecognizedBy'

	,isnull(cpr.ctid,'') 'CopyrightHolder'
	,IsNull(c.ProcessStandards,'') 'ProcessStandards'
	,Isnull(c.ProcessStandardsDescription,'') 'ProcessStandards Description'

	--should be single at this time
	--, STUFF(
	--	(	
	--	SELECT '|' + ISNULL([FromDuration], '') AS [text()]  FROM [dbo].[Entity.DurationProfile] duration 
	--	where duration.EntityId = a.EntityId
	--	FOR XML Path('')
	--	), 1,1,''
	--) as 'Estimated Duration'
	,case 
		when dp.FromYears > 0 then convert(varchar, dp.FromYears) + ' Years'
		when dp.FromMonths > 0 then convert(varchar, dp.FromMonths) + ' Months'
		when dp.FromWeeks > 0 then convert(varchar, dp.FromWeeks) + ' Weeks'
		when dp.FromDays > 0 then convert(varchar, dp.FromDays) + ' Days'
		when dp.FromHours > 0 then convert(varchar, dp.fromhours) + ' Hours'
		when dp.FromMinutes > 0 then convert(varchar, dp.FromMinutes) + ' Minutes'
		else ISNULL([FromDuration], '') end as 'Estimated Duration'

	-- === single cost ===========================================================================
	, case when costs.RowId is null then '' else convert(varchar(50),costs.RowId) end as 'Cost: Internal Identifier'
	, ''  as 'Cost: External Identifier'
	, IsNUll(costs.ProfileName,'') as 'Cost: Name'
	, IsNUll(costs.Description,'') as 'Cost: Description'
	, IsNUll(costs.DetailsUrl,'') as 'Cost: Details Url'
	, IsNUll(currencies.AlphabeticCode,'') as 'Cost: Currency Type'
	, IsNull(STUFF(
	(	
		SELECT '|' + costType.Title + '~' + Convert(varchar(25),ISNULL(cpi.price,0)) AS [text()]  FROM [dbo].[Entity.CostProfileItem] cpi 
		inner Join [Codes.PropertyValue] costType on cpi.CostTypeId = costType.Id
		where costs.Id = cpi.CostProfileId
		FOR XML Path('') 	), 1,1,'' 	),'') as 'Cost: Types List'
	--,costs.Created as CostProfileCreated
	-- ============= condition ====================================
	--will need to distinguish between condition types. Should only allow requires now - and not a connection!
	--, ecp.ConnectionTypeId as 'ConditionProfile: ConditionTypeId'
	, replace(cpType.SchemaName,'ceterms:','') as 'ConditionProfile: Condition Type'
	, case when ecp.RowId is null then '' else convert(varchar(50),ecp.RowId) end as 'ConditionProfile: Internal Identifier'
	, ''  as 'ConditionProfile: External Identifier'
	, IsNull(ecp.Name,'') as 'ConditionProfile: Name'
	, IsNull(ecp.Description,'') as 'ConditionProfile: Description'
	, IsNull(ecp.SubjectWebpage,'') as 'ConditionProfile: Subject Webpage'

	, IsNull(STUFF(
	(	
	SELECT '|' + eref.TextValue AS [text()]  FROM [dbo].[Entity.Reference] eref
	where eref.CategoryId = 57
	AND eref.EntityId = cpEntity.Id 
	FOR XML Path('')
	), 1,1,'' ),'') as 'ConditionProfile: Submission Of Items'
			
	, IsNull(STUFF(
	(	
	SELECT '|' + eref.TextValue AS [text()]  FROM [dbo].[Entity.Reference] eref
	where eref.CategoryId = 28
	AND eref.EntityId = cpEntity.Id 
	FOR XML Path('')
	), 1,1,'' 	),'') as 'ConditionProfile: Condition Items'
	, IsNull(ecp.Experience,'')  as 'ConditionProfile: Experience'
	, IsNUll(ecp.YearsOfExperience,0)  as 'ConditionProfile: Years Of Experience'
	--,ecp.Created as ConditionProfileCreated

	--TODO - how to include targets (asmts, etc)

	, IsNUll(ecp.CreditHourType,0)  as 'ConditionProfile: CreditHourType'
	, IsNUll(ecp.CreditHourValue,0)  as 'ConditionProfile: CreditHourValue'
	, IsNUll(creditUnitType.Title,'')  as 'ConditionProfile: CreditUnitType'
	, IsNUll(ecp.CreditUnitValue,0)  as 'ConditionProfile: CreditUnitValue'
	, IsNUll(ecp.CreditUnitTypeDescription,0)  as 'ConditionProfile: CreditUnitTypeDescription'


from Credential_Summary a 
inner join Organization b			on a.owningOrganizationId = b.Id 
inner join credential c				on a.Id = c.id
Inner Join [EntityProperty_Summary] cstat	on a.EntityId = cstat.EntityId and cstat.CategoryId = 39
Left join Organization cpr			on c.CopyrightHolder = cpr.RowId 
left join [Entity.NaicsCSV] enaics	on a.EntityId = enaics.EntityId
left join [Entity.OccupationsCSV] eoccupations on a.EntityId = eoccupations.EntityId
left join [Entity.ProgramsCSV] ePrograms on a.EntityId = ePrograms.EntityId
--Left Join [Codes.Language] lang		on c.InLanguageId = lang.Id
Left Join [Entity_SubjectsCSV] esub on a.EntityId = esub.EntityId

Left Join [Entity.ConditionProfile] ecp on a.EntityId = ecp.EntityId 
		and ecp.ConnectionTypeId in ( 1,2,5)
		and IsNull(ecp.ConditionSubTypeId,1) = 1
	--	AND @IncludingConditionProfile = 1
Left Join Entity cpEntity on ecp.RowId = cpEntity.EntityUid
Left Join [Codes.ConditionProfileType] cpType		on ecp.ConnectionTypeId = cpType.Id
--Left Join  [Import.IdentifierToObjectXref] cpsxr	on ecp.RowId = cpsxr.TargetRowId
Left Join [Codes.PropertyValue] creditUnitType on ecp.CreditUnitTypeId = creditUnitType.Id
Left Join [Entity.DurationProfile] dp on a.EntityId = dp.EntityId

-- cost
Left Join [Entity.CostProfile] costs on a.EntityId = costs.EntityId 
--Left Join  [Import.IdentifierToObjectXref] costsxr on costs.RowId = costsxr.TargetRowId
Left Join [Codes.Currency] currencies on costs.CurrencyTypeId = currencies.NumericCode

where a.EntityStateId > 1

--Order by a.Name


GO




/****** Object:  View [dbo].[Credential_PartsSummary]    Script Date: 9/20/2017 5:44:15 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
select * from [Credential_PartsSummary] where id in (23, 644)

*/

/*
Summary view for credential parts - used to populate the cache


*/
Alter VIEW [dbo].[Credential_PartsSummary]
AS

SELECT  Distinct      
	base.Id, 
	base.RowId as EntityUid,
	base.RowId,
	base.EntityStateId,
	--base.Name, 
	--base.AlternateName,
	--base.Description, 
 
	base.OwningAgentUid,

	--==== external data =========================
	entity.Id as EntityId,
	isnull(credTypeProperty.Title,'') As CredentialType,
	isnull(credTypeProperty.SchemaName,'') As CredentialTypeSchema,
	base.CredentialTypeId,
	--added virtual property, as the name can change and don't want buried in code
	case when isnull(credTypeProperty.SchemaName,'') = 'qualityAssuranceCredential' then 1 else 0 end As IsAQACredential,

	--CASE
 --       WHEN EXISTS (SELECT RelationshipTypeId FROM [Entity.QA_Action] A inner join Entity b on a.entityId = b.Id WHERE base.RowId = b.EntityUid ) THEN 1
 --       ELSE 0
 --       END as HasQualityAssurance ,
	0 as HasQualityAssurance ,
	--OwningOrgs
	orgs.OwningOrgs,
	orgs.OfferingOrgs,
	
	IsNull(f.Nbr,0) As LearningOppsCompetenciesCount,
	IsNull(g.Nbr,0) As AssessmentsCompetenciesCount,
	IsNull(h.Nbr,0) As RequiresCompetenciesCount,
	--0 As LearningOppsCompetenciesCount,
	--0 As AssessmentsCompetenciesCount,

	IsNull(qa.Nbr,0) As QARolesCount,
	isnull(qaRolesCsv.Roles,'') As QARolesList,
	isnull(qaRolesCsv.AgentAndRoles,'') As AgentAndRoles,

	--for owning org
	isnull(qaRolesCsv.OrgQARoles,'') As Org_QARolesList,
	isnull(qaRolesCsv.Org_QAAgentAndRoles,'') As Org_QAAgentAndRoles,

	isnull(dlist.HasParts,'') As HasPartList,
	isnull(eList.IsPartOf,'') As IsPartOfList,

	IsNull(d.Nbr,0) As HasPartCount,
	IsNull(e.Nbr,0) As IsPartOfCount

	,IsNull(c11.Nbr,0) As EntryConditionCount
	,IsNull(c10.Nbr,0) As CorequisiteConditionCount	

	,IsNull(c1.Nbr,0) As RequiresCount
	,IsNull(c2.Nbr,0) As RecommendsCount
	,IsNull(c3.Nbr,0) As RequiredForCount
	,IsNull(c4.Nbr,0) As IsRecommendedForCount
	--,IsNull(c5.Nbr,0) As RenewalCount
	,IsNull(c6.Nbr,0) As IsAdvancedStandingForCount
	,IsNull(c7.Nbr,0) As AdvancedStandingFromCount
	,IsNull(c8.Nbr,0) As PreparationForCount
	,IsNull(c9.Nbr,0) As PreparationFromCount

FROM            
		dbo.Credential base 
Inner Join Entity entity				on base.RowId = entity.EntityUid

Left Join [Entity.AgentRelationship_CredentialOwnersOffersCSV] orgs on base.Id = orgs.credentialId
--qa roles
left join [Credential_QARolesCSV] qaRolesCsv	on base.id = qaRolesCsv.CredentialId
left join [Codes.PropertyValue] credTypeProperty on base.CredentialTypeId = credTypeProperty.Id 

--left join [EntityProperty_Summary] credTypeProperty on base.Id = credTypeProperty.EntityBaseId and credTypeProperty.[EntityTypeId]= 1
--			and credTypeProperty.CategoryId = 2
--Left Join Organization managingOrg on base.ManagingOrgId = managingOrg.Id

--embedded credentials (HasPart)
left join (
	Select ParentCredentialId, Count(*) As Nbr from [Credential_EmbeddedCredentials_Summary] group by ParentCredentialId
	) d							on base.Id = d.ParentCredentialId
-- IS embedded credentials (IsPartOf)
left join (
	Select EmbeddedCredentialId, Count(*) As Nbr from [Credential_EmbeddedCredentials_Summary] group by EmbeddedCredentialId
	) e							on base.Id = e.EmbeddedCredentialId

--hasParts
left join [Credential_HasPart_IsPartOf] dList	on base.id = dlist.CredentialId
--IsPartOf
left join [Credential_HasPart_IsPartOf] eList	on base.id = elist.CredentialId


--competencies from learning opps
left join (
	Select CredentialId, Count(*) As Nbr from [ConditionProfile_LearningOpp_Competencies_Summary] group by CredentialId
	) f							on base.Id = f.CredentialId

--competencies from assessments
left join (
	Select CredentialId, Count(*) As Nbr from ConditionProfile_Assessments_Competencies_Summary group by CredentialId
	) g							on base.Id = g.CredentialId
--requires competencies from conditions
left join (
	Select a.EntityBaseId As CredentialId, Count(*) As Nbr from Entity a		-- entity for credential
			Inner Join [Entity.ConditionProfile] b on a.Id = b.EntityId		-- condition profiles for credential
			Inner Join Entity cpEntity on b.RowId = cpEntity.EntityUid		-- entity for condition profile
			Inner Join [Entity.Competency] c on cpEntity.id = c.EntityId
			where b.ConnectionTypeId = 1
			group by a.EntityBaseId
	) h on base.Id = h.CredentialId


--QA Roles 
left join (
	Select SourceEntityBaseId, Count(*) As Nbr from [Entity_Relationship_AgentSummary] where IsQARole = 1 group by SourceEntityBaseId
	) qa						on base.Id = qa.SourceEntityBaseId

-- ===========================================================================
--conditionProfiles - Attainment Requirements
--just counts of existence (should use Exists, if don't care about number?
--24-04-10 MP - turns out we may care about the actual number in some cases
left join (
	Select CredentialId, Count(*) As Nbr from [Credential_ConditionProfile] 
	where HasTargetCredential= 1 
	AND ConnectionTypeId = 1 and isnull(ConditionSubTypeId, 1) = 2
	group by CredentialId
	) c1 on base.Id = c1.CredentialId
--conditionProfiles - Attainment Recommendations
left join (
	Select CredentialId, Count(*) As Nbr from [Credential_ConditionProfile] where HasTargetCredential= 1 
	AND ConnectionTypeId = 2 and isnull(ConditionSubTypeId, 0) = 2
	group by CredentialId
	) c2						on base.Id = c2.CredentialId
		
--conditionProfiles - Post-Award Connections (Requirements)
left join (
	Select CredentialId, Count(*) As Nbr from [Credential_ConditionProfile] where HasTargetCredential= 1 
	AND ConnectionTypeId = 3 group by CredentialId
	) c3						on base.Id = c3.CredentialId
		
--conditionProfiles - Post-Award Connections (Recommendations)
left join (
	Select CredentialId, Count(*) As Nbr from [Credential_ConditionProfile] where HasTargetCredential= 1 
	AND ConnectionTypeId = 4 group by CredentialId
	) c4						on base.Id = c4.CredentialId
		
--conditionProfiles - Renewal Requirements
left join (
	Select CredentialId, Count(*) As Nbr from [Credential_ConditionProfile] where HasTargetCredential= 1 
	AND ConnectionTypeId = 5 group by CredentialId
	) c5						on base.Id = c5.CredentialId
		
		
--conditionProfiles - Advanced Standing For
left join (
	Select CredentialId, Count(*) As Nbr from [Credential_ConditionProfile] where HasTargetCredential= 1 
	AND ConnectionTypeId = 6 group by CredentialId
	) c6						on base.Id = c6.CredentialId
								
		
--conditionProfiles - Advanced Standing From
left join (
	Select CredentialId, Count(*) As Nbr from [Credential_ConditionProfile] where HasTargetCredential= 1 
	AND ConnectionTypeId = 7 group by CredentialId
	) c7						on base.Id = c7.CredentialId
		
		
--conditionProfiles - Preparation For
left join (
	Select CredentialId, Count(*) As Nbr from [Credential_ConditionProfile] where HasTargetCredential= 1 
	AND ConnectionTypeId = 8 group by CredentialId
	) c8						on base.Id = c8.CredentialId

--conditionProfiles - Preparation From
left join (
	Select CredentialId, Count(*) As Nbr from [Credential_ConditionProfile] where HasTargetCredential= 1 
	AND ConnectionTypeId = 9 group by CredentialId
	) c9						on base.Id = c9.CredentialId								


--conditionProfiles - CorequisiteConditionCount
left join (
	Select CredentialId, Count(*) As Nbr from [Credential_ConditionProfile] where HasTargetCredential= 1 
	AND ConnectionTypeId = 10 group by CredentialId
	) c10						on base.Id = c10.CredentialId	

--conditionProfiles - EntryCondition
left join (
	Select CredentialId, Count(*) As Nbr from [Credential_ConditionProfile] where HasTargetCredential= 1 
	AND ConnectionTypeId = 11 group by CredentialId
	) c11						on base.Id = c11.CredentialId	

go

grant select on Credential_PartsSummary to public
GO


/****** Object:  View [dbo].[Credential_Summary]    Script Date: 8/16/2017 9:32:00 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
use credFinder
GO
drop table Credential_Summary_Cache
go


SELECT [Id]
    -- ,count(*) As Nbr
from Credential_Summary
group by Id having count(*) > 1


truncate table Credential_Summary_Cache
go
insert Credential_Summary_Cache
--2 secs
set statistics IO On
set statistics IO Off
use credFinder
GO


SELECT top 500
base.[Id]
      ,base.[EntityId]
      ,base.[EntityUid]
      ,base.[RowId]
      ,base.[Name]
      ,base.[EntityStateId]
      ,base.[OwningAgentUid]
      ,base.[OrgEntityStateId]
      ,base.[OwningOrganizationId]
      --,base.[OwningOrganization]
      --,base.[CredentialTypeId]
      --,base.[CredentialType]
      --,base.[CredentialTypeSchema]
      --,base.[AlternateName]
      --,base.[Description]
      --,base.[SubjectWebpage]
      --,base.[CTID]
      --,base.[CredentialRegistryId]
      --,base.[cerEnvelopeUrl]
      --,base.[Version]
      --,base.[LatestVersionUrl]
      --,base.[ReplacesVersionUrl]
      --,base.[PreviousVersion]
      --,base.[DateEffective]
      --,base.[availableOnlineAt]
      --,base.[AvailabilityListing]
      --,base.[CredentialId]
      --,base.[Created]
      --,base.[LastUpdated]
      --,base.[IsAQACredential]
      --,base.[HasQualityAssurance]
      --,base.[OwningOrgs]
      --,base.[LearningOppsCompetenciesCount]
      --,base.[AssessmentsCompetenciesCount]
      --,base.[QARolesCount]
      --,base.[QARolesList]
      --,base.[QAOrgRolesList]
      --,base.[AgentAndRoles]
      --,base.[HasPartList]
      --,base.[IsPartOfList]
      --,base.[HasPartCount]
      --,base.[IsPartOfCount]
      --,base.[RequiresCount]
      --,base.[RecommendsCount]
      --,base.[isRequiredForCount]
      --,base.[IsRecommendedForCount]
      --,base.[IsAdvancedStandingForCount]
      --,base.[AdvancedStandingFromCount]
      --,base.[isPreparationForCount]
      --,base.[isPreparationFromCount]
      --,base.[entryConditionCount]
      --,base.[corequisiteConditionCount]
	,ea.Nbr as AvailableAddresses
	, (SELECT b.RowId, b.Id, b.EntityId, base.EntityUid, base.EntityTypeId, base.EntityBaseId, base.EntityBaseName, b.Id AS EntityAddressId, b.Name, b.IsPrimaryAddress, b.Address1, b.Address2, b.City, b.Region, b.PostOfficeBoxNumber, b.PostalCode, b.Country, b.Latitude, b.Longitude, b.Created, b.LastUpdated FROM dbo.Entity AS a INNER JOIN dbo.[Entity.Address] AS b ON base.Id = b.EntityId where base.[EntityUid] = base.[RowId] 
		FOR XML RAW, ROOT('Addresses')) Addresses

		-- addresses for owning org - will only be used if there is no address for the credential
	, (SELECT b.RowId, b.Id, b.EntityId, base.EntityUid, base.EntityTypeId, base.EntityBaseId, base.EntityBaseName, b.Id AS EntityAddressId, b.Name, b.IsPrimaryAddress, b.Address1, b.Address2, b.City, b.Region, b.PostOfficeBoxNumber, b.PostalCode, b.Country, b.Latitude, b.Longitude, b.Created, b.LastUpdated FROM dbo.Entity AS a INNER JOIN dbo.[Entity.Address] AS b ON base.Id = b.EntityId where base.[EntityUid] = base.OwningAgentUid 
		FOR XML RAW, ROOT('OrgAddresses')) OrgAddresses

  FROM [dbo].[Credential_Summary] base
--where base.OwningOrganization like 'Placeholder%'

	Inner join Entity e on base.Id = e.EntityBaseId and e.EntityTypeId = 1

	left Join (select EntityId, count(*) as nbr from [Entity.Address] group by EntityId ) ea on base.EntityId = ea.EntityId
	
	left join Credential_ConditionProfilesCSV connectionsCsv on base.id = connectionsCsv.CredentialId

	-- ========== check for a verifiable badge claim ========== 
	Left Join (SELECT c.CredentialId, count(*) as Total
		FROM [Entity.VerificationProfile] a
		inner join entity vpEntity							on base.RowId = vpEntity.EntityUid
		inner join  [dbo].[Entity.Credential] c on vpEntity.Id = c.EntityId
		inner join  [dbo].[Entity.Property] ep  on vpEntity.Id = ep.EntityId
		inner join [Codes.PropertyValue] b			on ep.PropertyValueId = b.Id
		where 	b.SchemaName = 'claimType:BadgeClaim'
		group by c.CredentialId

	) badgeClaims on base.Id = badgeClaims.CredentialId

	left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.CostProfile] a Inner join Entity b ON base.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId
	) costProfiles	on base.Id = costProfiles.EntityBaseId  


-- ========== total cost items - just for credential, no child items ========== 


-- ========== total cost items - just for credential, AND child items ========== 

	left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.CommonCost] a Inner join Entity b ON base.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId
		) CommonCost	on base.Id = CommonCost.EntityBaseId     
	left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.CommonCondition] a Inner join Entity b ON base.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId
		) CommonCondition	on base.Id = CommonCondition.EntityBaseId     
	--left join (
	--	Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.FinancialAlignmentProfile] a Inner join Entity b ON base.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId 
	--	) FinancialAid	on base.Id = FinancialAid.EntityBaseId 
	left join (
	Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.FinancialAssistanceProfile] a Inner join Entity b ON base.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId 
	) FinancialAid	on base.Id = FinancialAid.EntityBaseId  
		--renewals ----------------------------
	left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.ConditionProfile] a 
			Inner join Entity b ON base.EntityId = b.Id 
			inner Join Credential c on b.EntityUid = c.RowId
		where c.EntityStateId = 3
	  and base.ConnectionTypeId = 5 and isnull(base.ConditionSubTypeId,0) = 1
		Group By b.EntityBaseId 
		) Renewals	on base.Id = Renewals.EntityBaseId 
	--embedded ----------------------------
	left join (
	Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.Credential] a Inner join Entity b ON base.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId 
	) EmbeddedCredentials	on base.Id = EmbeddedCredentials.EntityBaseId 

	--targets
	left join (
		SELECT parentId as EntityBaseId, Sum(HasTargetAssessment) As HasTargetAssessments, Sum(HasTargetCredential) As HasTargetCredentials, Sum(HasLearningOpportunity) as HasLearningOpportunities FROM [dbo].[Entity_ConditionProfileTargetsSummary] where ParentEntityTypeId = 1 and ConnectionTypeId = 1 and (HasTargetAssessment > 0 OR HasTargetCredential > 0 OR HasLearningOpportunity > 0) group by parentId
		) reqTargets	on base.Id = reqTargets.EntityBaseId 

	left join (
		SELECT parentId as EntityBaseId, Sum(HasTargetAssessment) As HasTargetAssessments, Sum(HasTargetCredential) As HasTargetCredentials, Sum(HasLearningOpportunity) as HasLearningOpportunities FROM [dbo].[Entity_ConditionProfileTargetsSummary] where ParentEntityTypeId = 1 and ConnectionTypeId = 2 and (HasTargetAssessment > 0 OR HasTargetCredential > 0 OR HasLearningOpportunity > 0) group by parentId
		) recommendedTargets	on base.Id = recommendedTargets.EntityBaseId 
	left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.ProcessProfile] a Inner join Entity b ON base.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId
		) processProfiles	on base.Id = processProfiles.EntityBaseId     
	left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.RevocationProfile] a Inner join Entity b ON base.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId
		) revocationProfiles	on base.Id = revocationProfiles.EntityBaseId   
	left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.ReferenceFramework] a Inner join Entity b ON base.EntityId = b.Id Where b.EntityTypeId = 1 and CategoryId = 11 Group By b.EntityBaseId 
		) HasOccupations	on base.Id = HasOccupations.EntityBaseId   
	left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.ReferenceFramework] a Inner join Entity b ON base.EntityId = b.Id Where b.EntityTypeId = 1 and CategoryId = 10 Group By b.EntityBaseId 
		) HasIndustries	on base.Id = HasIndustries.EntityBaseId 
	
	--left join (
	--	Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.ReferenceFramework] a Inner join Entity b ON base.EntityId = b.Id Where b.EntityTypeId = 1 and CategoryId = 23 Group By b.EntityBaseId 
	--	) CIPCounts on base.Id = CIPCounts.EntityBaseId 
--SLOWish
	left Join ( 
		SELECT     distinct base.Id, 
		CASE WHEN Languages IS NULL THEN ''           WHEN len(Languages) = 0 THEN ''          ELSE left(Languages,len(Languages)-1)     END AS Languages
		From dbo.credential base
		CROSS APPLY ( SELECT base.TextValue + '| '
			FROM [dbo].[Entity.Reference] a inner join [Entity] b on base.EntityId = b.Id 
			where b.EntityTypeId= 1 AND base.CategoryId = 65
			and base.Id = b.EntityBaseId FOR XML Path('')  ) D (Languages)
		where Languages is not null
	) Languages on base.Id = Languages.Id

	left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.ConditionProfile] a Inner join Entity b ON base.EntityId = b.Id Where b.EntityTypeId = 1 Group By b.EntityBaseId 
		) HasConditionProfile	on base.Id = HasConditionProfile.EntityBaseId 
	 left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.DurationProfile] a Inner join Entity b ON base.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId 
		) HasDuration	on base.Id = HasDuration.EntityBaseId  
-- =======================================================
	left join (SELECT [ParentEntityUid] ,sum([AverageMinutes]) as [AverageMinutes] 
	  FROM [dbo].[Entity_Duration_EntityAverage] group by [ParentEntityUid]
	  )  duration on base.EntityUid = duration.ParentEntityUid 





	where id in (79, 1042)
  where organizationName like '%train%' or owingOrganization like 'train%'
   or organizationName is null
order by Id

select *
from   [dbo].[Credential_Summary] base
where base.CredentialType = 'License'

*/

/*
Summary view for credentials
NOTE: ONLY USED FOR SEARCH

ALSO note that uses [Credential.SummaryCache]

-- =========================================================
16-10-27 mparsons - changed to use a join of credential and Credential.SummaryCache.
									- the latter is regulary populated, but will always have the base data available
17-10-10 mparsons - added owningOrganization and OwningOrganizationId to Credential.SummaryCache, and using here 
22-04-26 mparsons - added languages here - need to remove from the proc!
22-11-17 mparsons - need to remove use of Credential.SummaryCache - may be a challenge
*/
Alter VIEW [dbo].[Credential_Summary]
AS

SELECT  Distinct    
-- === IDs ===
	base.Id, 
	e.Id as EntityId,
	base.RowId as EntityUid,
	base.RowId,
	isnull(base.CTID,'') As CTID, 
	-- common data not sync'd to Credential.SummaryCache
	base.Name, 
	base.EntityStateId,
	--
	base.CredentialTypeId,
	--friendly label for a credential type
	isnull(credTypeProperty.Title,'') As CredentialType,
	-- ctdl schema name
	isnull(credTypeProperty.SchemaName,'') As CredentialTypeSchema,
	--added virtual property, as the name can change and don't want buried in code. Added here for consistency, though will always be zero based on the where clause
	case when isnull(credTypeProperty.SchemaName,'') = 'qualityAssuranceCredential' then 1 else 0 end As IsAQACredential,
	-- new
	base.CredentialStatusTypeId,
	credStatus.Title as CredentialStatus,
	--retain temporarily
	base.CredentialStatusTypeId as CredentialStatusId,
	--
	--isnull(statusProperty.Property,'') As CredentialStatus,
	--isnull(statusProperty.PropertyValueId,'') As CredentialStatusId,
	-- ==== owning org =================================
	base.OwningAgentUid,
	owningOrg.EntityStateId as OrgEntityStateId,
	isnull(owningOrg.Id,0) as OwningOrganizationId,
	isnull(owningOrg.Name,'') as OwningOrganization,
	isnull(owningOrg.CTID,'') as OwningOrganizationCTID,
	-- =====================================

	--or
	--0	isnull(parts.IsAQACredential, 0) As IsAQACredential, 

	isnull(base.AlternateName,'') As AlternateName, 
	isnull(base.Description,'') As [Description], 
	Isnull(base.ImageUrl,'') as ImageUrl,
	isnull(base.SubjectWebpage,'') As SubjectWebpage, 
	--21-12-17 changed to use DateEffective. Retail alias for a bit
	base.EffectiveDate as DateEffective, 
	--base.EffectiveDate, 
	base.ExpirationDate,

	isnull(base.CredentialRegistryId,'') As CredentialRegistryId, 
	case when len(isnull(base.CredentialRegistryId,'')) = 36 then
	'<a href="https://credentialengineregistry.org/ce-registry/envelopes/' + base.CredentialRegistryId + '" target="_blank">cerEnvelope</a>'
	else '' End As cerEnvelopeUrl,

	isnull(base.Version,'') As Version, 
	isnull(base.LatestVersionUrl,'') As LatestVersionUrl, 

	isnull(base.ReplacesVersionUrl,'') As ReplacesVersionUrl, 
	isnull(base.ReplacesVersionUrl,'') As PreviousVersion, 


	isnull(base.availableOnlineAt,'') As availableOnlineAt, 
	isnull(base.AvailabilityListing,'') As AvailabilityListing, 
	base.CredentialId,
	base.Created, 
	--isnull(base.CreatedById,0) as CreatedById,		
	base.LastUpdated, 
	e.LastUpdated as EntityLastUpdated,
	parts.LastSyncDate,
	--json stuff in progress
	base.JsonProperties,
	base.IsNonCredit,
	--==== external data =========================
	isnull(Languages.Languages,'') As Languages,	
	isnull(parts.HasQualityAssurance, 0) As HasQualityAssurance, 

	--empty stuff needed by search proc
	--this is an old view, needs to be scrubbed.
	'' As OwningOrgs, 
	'' as OfferingOrgs,
	0 as totalCost,
	0 as NumberOfCostProfileItems,
	'' As NaicsList,
	'' As LevelsList,
	'' As OccupationsList,
	'' as SubjectsList,

	'' as ConnectionsList,
	'' as CredentialsList,
	'' as badgeClaimsCount,
	'' as AvailableAddresses,


	-- === content from Credential.SummaryCache==================
		--isnull(parts.CredentialType,'') As CredentialType, 
	--isnull(parts.CredentialTypeSchema,'') As CredentialTypeSchema, 
	--isnull(parts.CredentialTypeId,0) As CredentialTypeId, 
	isnull(parts.LearningOppsCompetenciesCount,0) As LearningOppsCompetenciesCount, 
	isnull(parts.AssessmentsCompetenciesCount,0) As AssessmentsCompetenciesCount, 
	isnull(parts.RequiresCompetenciesCount,0) As RequiresCompetenciesCount, 
	isnull(parts.QARolesCount,0) As QARolesCount 
	,parts.QARolesList
	,parts.AgentAndRoles
	,parts.QAOrgRolesList
	,parts.QAAgentAndRoles
	
	,parts.HasPartList
	,parts.IsPartOfList

	,isnull(parts.HasPartCount,0) As HasPartCount, 
	isnull(parts.IsPartOfCount,0) As IsPartOfCount, 
	isnull(parts.RequiresCount,0) As RequiresCount, 
	isnull(parts.RecommendsCount,0) As RecommendsCount, 
	isnull(parts.RequiredForCount,0) As isRequiredForCount, 
	isnull(parts.IsRecommendedForCount,0) As IsRecommendedForCount, 
	isnull(parts.IsAdvancedStandingForCount,0) As IsAdvancedStandingForCount, 
	isnull(parts.AdvancedStandingFromCount,0) As AdvancedStandingFromCount, 
	isnull(parts.PreparationForCount,0) As isPreparationForCount, 
	isnull(parts.PreparationFromCount,0) As isPreparationFromCount,
	isnull(parts.EntryConditionCount,0) As entryConditionCount  ,
	isnull(parts.CorequisiteConditionCount,0) As corequisiteConditionCount 	
	--

FROM dbo.Credential base 
Inner Join Entity								e	on base.RowId = e.EntityUid
left join [Codes.PropertyValue] credTypeProperty	on base.CredentialTypeId = credTypeProperty.Id 
Left join [Credential.SummaryCache]			parts	on base.Id = parts.CredentialId
Left Join Organization					owningOrg	on base.OwningAgentUid = owningOrg.RowId and owningOrg.EntityStateId > 1
Left Join [Codes.PropertyValue] credStatus			on base.CredentialStatusTypeId = credStatus.Id

--Left Join EntityProperty_Summary statusProperty on base.RowId = statusProperty.EntityUid and statusProperty.CategoryId = 39

--AND isnull(credTypeProperty.SchemaName,'') <> 'ceterms:QualityAssuranceCredential'
	left Join ( 
		SELECT     distinct base.Id, 
		CASE WHEN Languages IS NULL THEN ''           WHEN len(Languages) = 0 THEN ''          ELSE left(Languages,len(Languages)-1)     END AS Languages
		From dbo.credential base
		CROSS APPLY ( SELECT a.Title + '| ' + a.TextValue + '| '
			FROM [dbo].[Entity.Reference] a inner join [Entity] b on a.EntityId = b.Id 
			where b.EntityTypeId= 1 AND a.CategoryId = 65
			and base.Id = b.EntityBaseId FOR XML Path('')  ) D (Languages)
		where Languages is not null
	) Languages on base.Id = Languages.Id

where base.EntityStateId >= 2
--order by 1


GO
grant select on Credential_Summary to public
go



/****** Object:  View [dbo].[DataSetProfileSummary]    Script Date: 5/31/2021 2:14:30 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
--Drop VIEW [dbo].[DataSetProfileSummary]
/*



SELECT top (500)
[Id]
      ,[RowId]
      ,[EntityStateId]
      ,[CTID]
      ,[Name]
      ,[Description]
      ,[Source]
      ,[DataProviderUID]
      ,[DataProviderName]
      ,[DataProviderId]
      ,[DataProviderCTID]
      ,[EntityId]
      ,[Created]
      ,[LastUpdated]
      ,[InternalDSPEntityId]
      ,[DataSuppressionPolicy]

      ,[SubjectIdentification]
      ,[DistributionFile]
      ,[CredentialId]
      ,[AssessmentId]
      ,[LearningOpportunityId]
      ,[Credentials]
      ,[LearningOpportunities]
	  ,DataSetTimePeriodJson
  FROM [dbo].[DataSetProfileSummary]
  where DataSetTimePeriodJson like '%employment%'
GO


  where CredentialId is not null
GO





*/
Alter VIEW [dbo].[DataSetProfileSummary]
AS
SELECT        
	base.Id, base.RowId, base.EntityStateId, 
	base.CTID, 
	base.Name, 
	base.Description, 
	base.Source, 
	base.DataProviderUID, 
	isnull(d.Name,'') AS DataProviderName, 
	d.Id AS DataProviderId, 
	d.CTID as DataProviderCTID,
	b.Id as EntityId, 

	base.Created, base.LastUpdated,
	-- if is not null, then an internal DSP
	--	and what does this mean?
	edsp.EntityId as InternalDSPEntityId,
	base.DataSuppressionPolicy,
	base.SubjectIdentification,
	base.DistributionFile,
	base.DataSetTimePeriodJson,
	--
	ec.CacheDate As EntityLastUpdated,
	isnull(ec.ResourceDetail,'') as ResourceDetail,
	-- ============================
	c.CredentialId,
	ea.AssessmentId,
	el.LearningOpportunityId
	--typically only one
	, CASE
			WHEN Credentials IS NULL THEN ''
			WHEN len(Credentials) = 0 THEN ''
			ELSE left(Credentials,len(Credentials)-1)
		END AS Credentials
	, CASE
			WHEN LearningOpportunities IS NULL THEN ''
			WHEN len(LearningOpportunities) = 0 THEN ''
			ELSE left(LearningOpportunities,len(LearningOpportunities)-1)
		END AS LearningOpportunities


FROM dbo.DataSetProfile base  
INNER JOIN  dbo.Entity b on base.RowId = b.EntityUid
Inner Join [Entity_Cache] ec on base.RowId = ec.EntityUID
Left Join Organization d on base.DataProviderUID = d.RowId
-- use a left join on [Entity.DataSetProfile] to control getting external only or all, where eDSP.id is not null
Left JOIN dbo.[Entity.DataSetProfile] AS edsp  ON base.Id = edsp.DataSetProfileId


--
Left JOIN dbo.[Entity.Credential] AS c  ON b.Id = c.EntityId 
Left JOIN dbo.[Entity.Assessment] AS ea  ON b.Id = ea.EntityId 
Left JOIN dbo.[Entity.LearningOpportunity] AS el  ON b.Id = el.EntityId 

--

CROSS APPLY (
	SELECT 
		convert(varchar,caec.CredentialId) + '~ ' + convert(varchar,cac.Name) + ', '
	FROM dbo.[Entity.Credential] caec
	Inner Join Credential cac on caec.credentialId = cac.Id
	INNER JOIN dbo.Entity cae ON caec.EntityId = cae.Id 
	WHERE (base.EntityStateId = 3) 
	AND b.Id = caec.EntityId
	FOR XML Path('') 
) creds (Credentials)


CROSS APPLY (
	SELECT 
		convert(varchar,caec.LearningOpportunityId) + '~ ' + convert(varchar,cac.Name) + ', '
	FROM dbo.[Entity.LearningOpportunity] caec
	Inner Join LearningOpportunity cac on caec.LearningOpportunityId = cac.Id
	INNER JOIN dbo.Entity cae ON caec.EntityId = cae.Id 
	WHERE (base.EntityStateId = 3) 
	AND b.Id = caec.EntityId
	FOR XML Path('') 
) lopps (LearningOpportunities)

where base.EntityStateId = 3
GO
grant select on [DataSetProfileSummary] to public
go



/****** Object:  View [dbo].[Entity.FrameworkItemSummary]    Script Date: 8/16/2017 9:37:53 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*

SELECT [Id]
      ,EntityTypeId, [EntityId]
      ,[Entity]
	  ,Name, EntityUid
      ,[CategoryId]
      ,[PropertyCategory]
      ,[SchemaName]
      ,[CodeId]
	  ,FrameworkGroup, FrameworkGroupTitle
      ,[FrameworkCode]
      ,[Title]
      ,[Description]
      ,[URL]
  FROM [dbo].[Entity.FrameworkItemSummary]
	where CategoryId in( 11,10)
order by 2,3,CategoryId

SELECT [EntityId] FROM [dbo].[Entity.FrameworkItemSummary] where CategoryId = 10 and FrameworkCode= ''

*/

--	
Alter VIEW [dbo].[Entity.FrameworkItemSummary]
AS

SELECT  
	efi.Id,     
	base.EntityTypeId, 
	efi.EntityId, 
	cet.Title As Entity, 
	case 
		when base.EntityTypeId = 1 then c.Name
		when base.EntityTypeId = 2 then o.Name
		when base.EntityTypeId = 3 then am.Name
		when base.EntityTypeId = 7 then lo.Name
		else '' end as Name,
	case 
		when base.EntityTypeId = 1 then c.Id
		when base.EntityTypeId = 2 then o.Id
		when base.EntityTypeId = 3 then am.Id
		when base.EntityTypeId = 7 then lo.Id
		else 0 end as ParentId,
	base.EntityUid,
	efi.CategoryId, 
	cpc.Title AS PropertyCategory, 
	cpc.SchemaName,
	0 As CodeId,
	--efi.CodeId, 

	case when len(Isnull(efi.CodedNotation,'')) > 1 then left(efi.CodedNotation,2)
	else '' end as CodeGroup,

	case when len(Isnull(efi.CodedNotation,'')) > 1 then efi.CodedNotation
	else '' end as FrameworkCode,

	case 
		when efi.CategoryId = 10 then naicsHdr.NaicsTitle
		when efi.CategoryId = 11 then jf.Description
		when efi.CategoryId = 23 then cipHdr.[CIPTitle]
		else '' end as FrameworkGroupTitle,
'' as FrameworkGroupTitle2,
	case 
		when efi.CategoryId = 10 then left(dbo.NAICS.NaicsCode,3)
		when efi.CategoryId = 11 then left(dbo.ONET_SOC.OnetSocCode,2)
		when efi.CategoryId = 23 then left(cip.CIPCode,2)
		else '' end as FrameworkGroup,
			case when len(Isnull(efi.CodedNotation,'')) > 1 then left(efi.CodedNotation,2)
	else '' end as FrameworkGroup2,
	efi.name as Title,
	--'' as Description2,
	
	--case 
	--	when efi.CategoryId = 10 then dbo.NAICS.NaicsTitle
	--	when efi.CategoryId = 11 then dbo.ONET_SOC.Title
	--	when efi.CategoryId = 23 then cip.CIPTitle
	--	else '' end as Title,
	case 
		when efi.CategoryId = 10 then dbo.NAICS.NaicsTitle
		when efi.CategoryId = 11 then dbo.ONET_SOC.Description
		when efi.CategoryId = 23 then cip.CIPDefinition
		else '' end as Description,

	efi.targetNode as Url2,
	case 
		when efi.CategoryId = 10 then dbo.NAICS.URL
		when efi.CategoryId = 11 then dbo.ONET_SOC.URL
		when efi.CategoryId = 23 then cip.Url
		else '' end as URL
	
FROM dbo.Entity base
Inner join dbo.[Codes.EntityTypes]		cet on base.EntityTypeId = cet.Id
INNER JOIN dbo.[Entity.FrameworkItem]	efi ON base.Id = efi.EntityId 
--INNER JOIN dbo.[Entity_ReferenceFramework_Summary]	efi ON base.Id = efi.EntityId 

INNER JOIN dbo.[Codes.PropertyCategory] cpc ON efi.CategoryId = cpc.Id

-- =================================================================== 
Left JOIN dbo.NAICS		ON efi.CodedNotation = dbo.NAICS.NaicsCode and efi.CategoryId = 10
--Left JOIN dbo.NAICS	naicsHdr	ON efi.CodedNotation = dbo.NAICS.NaicsCode and efi.CategoryId = 10
--Left JOIN dbo.NAICS		ON efi.CodeId = dbo.NAICS.Id and efi.CategoryId = 10
left join [dbo].NAICS naicsHdr on left(NAICS.NaicsCode,3) = naicsHdr.NaicsCode   AND len(naicsHdr.NaicsCode) = 3

-- ===================================================================
Left JOIN dbo.ONET_SOC	ON efi.CodedNotation = dbo.ONET_SOC.OnetSocCode and efi.CategoryId = 11

--Left JOIN dbo.ONET_SOC	ON efi.CodeId = dbo.ONET_SOC.Id and efi.CategoryId = 11
lEFT join [ONET_SOC.JobFamily]	jf on left(ONET_SOC.OnetSocCode,2) = jf.[JobFamilyId] 

-- ===================================================================
Left JOIN dbo.CIPCode2010 cip	ON efi.CodedNotation = cip.CIPCode and efi.CategoryId = 23
--Left JOIN dbo.[CIPCode2010]		cip ON efi.CodeId = cip.Id and efi.CategoryId = 23
left join [dbo].[CIPCode2010] cipHdr on left(cip.[CIPCode],2) = cipHdr.[CIPCode]   AND len(cipHdr.[CIPCode]) = 2
-- ===================================================================

left join Credential c						on base.EntityUid = c.RowId  and base.EntityTypeId = 1 

left join Organization o						on base.EntityUid = o.RowId 
	and base.EntityTypeId = 2 

left join Assessment am	on base.EntityUid = am.RowId 
	and base.EntityTypeId = 3 

left join LearningOpportunity lo	on base.EntityUid = lo.RowId 
	and base.EntityTypeId = 7 

--where efi.CodeId is not null
where efi.CategoryId in (10,11,23)
--actually may not use the following in order to handle 'others'
--AND isnull(efi.CodedNotation,'') <> ''

GO

grant select on [Entity.FrameworkItemSummary] to public
go

/*

SELECT a.[Id]
      ,a.[EntityId]
      ,a.[EntityTypeId]
      ,a.[ResourceId]
      ,a.[RelationshipTypeId]
      ,a.[Created]
      ,a.[EntityType]
      ,a.[Name]
      ,a.[Description]
      ,a.[CTID]
      ,a.[SubjectWebpage]
      ,a.[EntityStateId]
      ,a.[OwningOrgId]
      ,a.[PublishedByOrgId]
      ,a.[Organization]
      ,a.[parentName]
      ,a.[parentCTID]
      ,a.[parentDescription]
      ,a.[parentEntityTypeId]
  FROM [dbo].[Entity.HasResourceSummary] a

  inner join LearningOpportunity lopp on a.EntityUID = lopp.RowId
  --inner join transferValueProfile tv on a.EntityUid = tv.RowId

  where a.[RelationshipTypeId]in (17,18)
GO





*/
ALTER VIEW [dbo].[Entity.HasResourceSummary] 
AS
SELECT a.[Id]
      ,a.[EntityId]
      ,a.[EntityTypeId]
      ,a.[ResourceId]
	  ,a.RelationshipTypeId
      ,a.[Created]
	  ,ec.EntityType, ec.Name, ec.Description, ec.CTID, ec.SubjectWebpage as SubjectWebpage
	  ,ec.EntityStateId
	  ,ec.EntityUid
	  ,ec.OwningOrgId		as ResourceOwningOrgId
	  --TEMP
	  ,ec.OwningOrgId		as OwningOrgId
	  ,IsNull(c.Name,'')	as ResourceOrganizationName
	  ,ec.PublishedByOrgId	as PublishedByOrgId 
	   
	  --TBD this the parent of Entity.HasResource
	  ,parentCache.EntityTypeId as ParentEntityTypeId
	  ,parentCache.EntityStateId as ParentEntityStateId
	  ,parentCache.Id		as ParentEntityId
	  ,parentCache.Name		as ParentName
	  ,parentCache.CTID		as ParentCTID
	  ,parentCache.Description	as ParentDescription
	  
	  --
	  ,parentOrg.Id				As ParentPrimaryOrganizationId
	  ,parentOrg.EntityStateId	as ParentPrimaryOrgEntityStateId
	  ,parentOrg.[Name]			As ParentPrimaryOrganizationName 
	  --TEMP
	  ,parentOrg.[Name] As Organization 
	  ,parentOrg.Description	As ParentPrimaryOrganizationDesc
	   ,ec.parentEntityUid as EntityParentUid --to get the UId of the parent in case of competencies and concepts

  FROM [dbo].[Entity.HasResource] a 
  --inner join Entity e on a.EntityId = e.Id
  --entity_cache for the destination resource
  inner join Entity_Cache ec on a.EntityTypeId = ec.EntityTypeId and a.ResourceId = ec.BaseId
  Left Join Organization c on ec.OwningOrgId = c.Id 

  --should we do the joins for parent here or have a separate process
  inner join Entity_Cache parentCache on a.EntityId = parentCache.Id
  Left Join Organization parentOrg on parentCache.OwningOrgId = parentOrg.Id 

  where ec.EntityStateId > 1


GO
grant select on [Entity.HasResourceSummary] to public 
go



/****** Object:  View [dbo].[EntityCompetencyFramework_Items_Summary]    Script Date: 10/6/2017 4:16:31 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*

SELECT [EntityId]
,FrameworkName
, FrameworkCtid
      ,[Competency]
      ,COUNT(*) AS cnt
  FROM [dbo].[EntityCompetencyFramework_Items_Summary]
  group by 
  [EntityId]
      ,FrameworkName
	  , FrameworkCtid
	  , [Competency]
	  having count(*) > 1
order by 1,2,3


SELECT 
	distinct
		[EntityId]
      ,EntityTypeId, [EntityType]
      ,[EntityBaseId]
	  ,ConnectionTypeId
	  ,ConditionEntityTypeId
	  ,ConditionEntityBaseId
      ,[EntityName]
     -- ,[EntityCompetencyFrameworkItemId]
      ,[FrameworkName]
	  ,ExistsInRegistry
      ,[SourceUrl]
      --,[FrameworkCtid]
      --,[FrameworkUri]

      --,[EntityCompetencyId]
      ,[Competency]
      --,[TargetNodeDescription]
      --,[TargetNode]
      --,[CodedNotation]
      ,[Created]
      --,[Weight]
  FROM [dbo].[EntityCompetencyFramework_Items_Summary]
  where 
  entityid = 2364654
  --EntityTypeId = 7
  --and
  competency like 'Identify the components of included draft %'
  and ExistsInRegistry= 1
  --and ConditionEntityTypeId = 1
  --EntityBaseId = 991 OR ConditionEntityBaseId = 592
  --entityid = 28573   or 
  --connectiontypeid > 1
--where baseId = 12
order by [EntityId]
      ,[EntityType]
      ,[EntityBaseId], FrameworkName, Competency

*/
/*

Modifications
20-04-20 mparsons - replace EducationFrameworks with CompetencyFrameworks
20-06-12 mparsons - added: ExistsInRegistry
23-01-08 mparsons - Added Alignment to Entity.Competency
*/
Alter VIEW [dbo].[EntityCompetencyFramework_Items_Summary]
AS

SELECT DISTINCT    
	e.Id as EntityId
	,e.EntityTypeId
	,c.Title as EntityType
	, e.EntityBaseId 
	--as BaseId
	,e.EntityBaseName As EntityName
	,IsNUll(b.Id,0) AS EntityCompetencyFrameworkItemId
	,case when Isnull(b.Name,'') = '' then Isnull(a.FrameworkName,'None')
		else b.Name end as FrameworkName
	--, Isnull(b.FrameworkName,'None') as FrameworkName
	--, a.FrameworkName As F2
	--ultimately, want to stop using FrameworkUrl
	--,case when Isnull(b.FrameworkUrl,'') = '' then Isnull(a.FrameworkUrl,'None')
	--	else b.FrameworkUrl end as FrameworkUrl
	,b.[ExistsInRegistry]
	,b.FrameworkUri
	,case 
		when len(isnull(b.SourceUrl,'')) > 10 then b.SourceUrl
		when Len(Isnull(b.FrameworkUri,'')) > 10 AND charindex('/ce-',b.FrameworkUri) = 0 then b.FrameworkUri
		else '' end as SourceUrl
	--,b.SourceUrl

	,b.CTID as FrameworkCtid
	,a.Id AS EntityCompetencyId
	,a.Alignment
	,a.TargetNodeName AS Competency -- alias to prevent breaking
	,a.TargetNodeDescription
	,a.TargetNode
	,a.TargetNodeCTID
	--, b.TargetDescription	-- not used 
	,a.CodedNotation
	,a.Created
	,a.Weight
	--, b.AlignmentDate  --not used
	,IsNull(ecp.ConnectionTypeId,0)  As ConnectionTypeId
	,IsNull(cpEntity.EntityTypeId,0) As ConditionEntityTypeId
	,IsNull(cpEntity.EntityBaseId,0) As ConditionEntityBaseId

FROM       dbo.[Entity.Competency] a
LEFT JOIN dbo.CompetencyFramework b			ON a.CompetencyFrameworkId = b.id

INNER JOIN dbo.Entity				e	ON a.EntityId = e.Id
Inner Join dbo.[Codes.EntityTypes]	c	on e.EntityTypeId = c.Id

--required comps will be under a condition profile
Left Join [Entity.ConditionProfile] ecp on e.EntityUid = ecp.RowId
Left Join Entity			cpEntity	on ecp.EntityId = cpEntity.Id 
--may want to change this to > 1 at some point
where IsNull(b.EntityStateId,2) > 1

--SELECT        
--	a.EntityId, 
--	a.Id AS EntityCompetencyFrameworkId, 
--  a.EducationalFrameworkName, 
--	a.AlignmentType, a.AlignmentTypeId,
--	b.Id AS EntityCompetencyFrameworkItemId, 
--  b.Name, 
--	b.Name AS Competency, -- alias to prevent breaking
--	b.Description, 
--	b.TargetName, 
--	b.TargetDescription,
--  b.TargetUrl, 
--	b.CodedNotation
--FROM            dbo.[Entity.CompetencyFramework] a
--INNER JOIN dbo.[Entity.CompetencyFrameworkItem] b ON a.Id = b.EntityFrameworkId
go

grant select on [EntityCompetencyFramework_Items_Summary] to public

GO

/*

SELECT [Publisher],[PublisherCTID]	,[Organization]	,[OrganizationCTID]	,count(*) as Total FROM [dbo].[Entity_CacheSummary]  Where LastUpdated < '2021-01-01' group by   [Publisher]	,[PublisherCTID]	,[Organization]	,[OrganizationCTID]
  order by Publisher, Organization

  go
SELECT [Publisher],[PublisherCTID]	,[Organization]	,[OrganizationCTID], EntityType	,count(*) as Total FROM [dbo].[Entity_CacheSummary]  Where LastUpdated < '2021-01-01' group by   [Publisher]	,[PublisherCTID]	,[Organization]	,[OrganizationCTID], EntityType
  order by Publisher, Organization,EntityType

  go

  --just data owner
  SELECT [Organization]	,[OrganizationCTID], EntityType	,count(*) as Total FROM [dbo].[Entity_CacheSummary]  
  Where LastUpdated < '2021-01-01' 
  and [PublisherCTID] =[OrganizationCTID]
  group by   [Organization]	,[OrganizationCTID], EntityType
  order by Organization,EntityType

    --just TPP
  SELECT [Publisher],[PublisherCTID], EntityType	,count(*) as Total FROM [dbo].[Entity_CacheSummary]  
  Where LastUpdated < '2021-01-01' 
  and [PublisherCTID] <> [OrganizationCTID]
  group by   [Publisher],[PublisherCTID], EntityType
  order by 1,EntityType

  go


INSERT INTO [dbo].[Work.Query]
           ([ReportType]
           ,[Publisher]
           ,[PublisherCTID]
           ,[Organization]
           ,[OrganizationCTID]
           ,[EntityType]
           ,[Category]
           ,[Name]
           ,[CTID]
           ,[Description]
          ,[DateCreated]
           ,[LastUpdated]
		   ,[Variable1]
           ,[Variable2]
           ,[Variable3]
         --  ,[IsProcessed]
		   )


SELECT 'CurrencyReport 18 months'
	,[Publisher]
	,[PublisherCTID]
	,[Organization]
	,[OrganizationCTID]
	-- ,[OwningOrgId]
	--  ,[EntityTypeId]
	,[EntityType]
	,[CTDLType]
	--    ,[BaseId]
	,[Name]
	,[CTID]
	,[Description]
		,[Created]
	,[LastUpdated]

	,Status		as Variable1
	,[PublishMethodURI] as Variable2

	  ,[SubjectWebpage] 
	--  ,[ImageUrl]
	-- ,[CacheDate]
  FROM [dbo].[Entity_CacheSummary]

  Where
-- EntityTypeId = 1  and 
LastUpdated < '2021-01-01'
  order by Publisher, Organization,[EntityTypeId], Name
GO

*/

/*
Entity Cache summary view for use by currency reporting
Notes
- this is fairly slow
- also may want to avoid the join to the Accounts table to get the publisher
Options
- daily generation of a reports table
- generate a table for unique publisher - data owners (as main reason for slowness)

Status ********************
- have to consider the credential and lifecycle status. That is either exclude deprecated, etc or make configurable
 Modifications 
22-05-01 mostly replace by ResourceCurrency_Summary
22-06-01 just a note that this only includes top level full resources (EntityStateId=3)
23-08-04 mparsons - TODO, establish the publisher in the import
23-11-01 mparsons - there were inconsistencies using [Import.PendingRequest] for third party filtering.
					Changed to use Entity.AgentRelationship to be consistent
*/
Alter View Entity_CacheSummary 
as 

SELECT  
	case when tpp.Name is not null then tpp.Name else 'Missing - get from accounts' end as Publisher,
	case when tpp.Name is not null then tpp.CTID else '' end as PublisherCTID

	,b.Name as Organization
	,b.CTID as OrganizationCTID
	,a.[OwningOrgId]
	,a.[EntityTypeId]
	,a.[EntityType]
	,et.SchemaName as CTDLType
	--  ,a.[EntityUid]
     
	--,a.[EntityStateId]
	,a.[BaseId]
	,a.[Name]
	,a.[LastUpdated]
	,a.[Description]
	,a.[CTID]
	,latestImport.PublishMethodURI
	,a.[Created]
	--future use to indicate if resource has an active status
	--,'Active' As Status
	,a.[SubjectWebpage]
	,a.[ImageUrl]
      
	,a.[CacheDate]  
      
--		select count(*)
FROM [dbo].[Entity_Cache] a
inner join Organization b on a.OwningOrgId = b.id
--this should not be necessary, as entityType is present
left join [Codes.EntityTypes] et on a.EntityTypeId = et.id 

--TODO need to eliminate this to make performant
--	would have to remove PublishMethodURI. This may be used in one of the reports
  left join (
		Select PublisherCTID, DataOwnerCTID, EntityCtid, max(a.PublishMethodURI)  PublishMethodURI
		from [Import.PendingRequest] a
		where a.PublishMethodURI  like 'publishMethod%'
		group by PublisherCTID, DataOwnerCTID, EntityCtid 
) latestImport on a.CTID = latestImport.EntityCtid 
--left join dbo.Organization tpp on latestImport.PublisherCTID = tpp.CTID

Left join [Entity.AgentRelationship] ear on a.Id = ear.EntityId and ear.RelationshipTypeId = 30
Left join Organization tpp on ear.AgentUid = tpp.RowId

where isnull(a.[parentEntityId],0) = 0
AND a.EntityStateId = 3

go

  grant select on Entity_CacheSummary to public
  go


/****** Object:  View [dbo].[Entity_ConditionProfilesConnectionsCSV]    Script Date: 8/22/2017 7:10:31 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




/*

SELECT [ParentId]
      ,[ParentEntityTypeId]
      ,[Profiles]
      ,[CredentialsList]
  FROM [dbo].[Entity_ConditionProfilesConnectionsCSV]
  where  ParentEntityTypeId= 3
 ParentId= 518
GO



1~Requires~1141~21st Century Skills for Workplace Success~| 1~Requires~31~Certified ISO/IEC 27005 Risk Manager~| 1~Requires~1140~Employment Readiness~| 1~Requires~1179~A Simple Cerificate Credential~| 1~Requires~17~Bachelor of Science in Computer Science~| 1~Requires~1140~Employment Readiness~| 1~Requires~31~Certified ISO/IEC 27005 Risk Manager~| 1~Requires~1209~Master of Science in Project Management~| 1~Requires~1164~CompTIA Security+~

2~Recommends~1141~21st Century Skills for Workplace Success~| 2~Recommends~31~Certified ISO/IEC 27005 Risk Manager~| 2~Recommends~1140~Employment Readiness~| 2~Recommends~1179~A Simple Cerificate Credential~| 2~Recommends~17~Bachelor of Science in Computer Science~| 2~Recommends~1140~Employment Readiness~| 2~Recommends~31~Certified ISO/IEC 27005 Risk Manager~| 2~Recommends~1209~Master of Science in Project Management~| 2~Recommends~1164~CompTIA Security+~

*/
/*

May want a version that is clearly for connections

Modifications

*/


ALTER  VIEW [dbo].[Entity_ConditionProfilesConnectionsCSV]
AS

SELECT     distinct
ParentId, 
base.ParentEntityTypeId,
    CASE
          WHEN Profiles IS NULL THEN ''
          WHEN len(Profiles) = 0 THEN ''
          ELSE left(Profiles,len(Profiles)-1)
    END AS Profiles
    ,CASE
          WHEN CredentialsList IS NULL THEN ''
          WHEN len(CredentialsList) = 0 THEN ''
          ELSE left(CredentialsList,len(CredentialsList)-1)
    END AS CredentialsList

From dbo.[Entity_ConditionProfileTotals] base


CROSS APPLY (
    SELECT convert(varchar, ConnectionTypeId) + '~' + ConnectionType  + '~' + ConnectionTypeSchemaName   + '~' + convert(varchar, ProfilesCount) + '| '
		From dbo.[Entity_ConditionProfileTotals] 
    WHERE base.ParentId = ParentId
	and base.ParentEntityTypeId = ParentEntityTypeId

    FOR XML Path('') 
		) D (Profiles)

CROSS APPLY (
    SELECT convert(varchar, ConnectionTypeId) + '~' + ConnectionType  + '~' + convert(varchar, TargetCredentialId) + '~' + TargetCredential    + '~' + '| '
		From dbo.[Entity_ConditionProfile_Credential] 
    WHERE base.ParentId = ParentId
	and base.ParentEntityTypeId = ParentEntityTypeId
    FOR XML Path('') 
		) E (CredentialsList)

where Isnull(base.ConditionSubTypeId,1) in (2,3,4)  --5  = alternate condition
AND Profiles is not null

GO
grant select on Entity_ConditionProfilesConnectionsCSV to public
go


/****** Object:  View [dbo].[Entity_ConditionProfileTargetsSummary]    Script Date: 8/22/2017 5:26:56 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*


SELECT [CredentialId]
      ,[CredentialRowId]
      ,[parentEntityId]
      ,[Name]
      ,a.[EntityId]
      ,[EntityTypeId]
      ,[EntityUid]
      ,[EntityConditionProfileId]
      ,[ConnectionTypeId]
      ,[ConnectionType],ConnectionTypeSchemaName
    
      ,[RowId]
  FROM [dbo].[Entity_ConditionProfile] a
	--INNER JOIN dbo.[Entity.LearningOpportunity] b ON a.EntityId = condProfParentEntity.EntityId 
where CredentialId= 1141

SELECTUSE [credFinder_ProdSync]
GO

SELECT parentId, Sum(HasTargetAssessment) As HasTargetAssessment, Sum(HasTargetCredential) As HasTargetCredential, Sum(HasLearningOpportunity) as HasLearningOpportunity FROM [dbo].[Entity_ConditionProfileTargetsSummary] where ParentEntityTypeId = 1 and ConnectionTypeId = 1 and (HasTargetAssessment > 0 OR HasTargetCredential > 0 OR HasLearningOpportunity > 0) 
group by parentId

 -- where [ConditionSubTypeId] in (2,3,4) 
  
  order by ParentEntityTypeId, parentId



SELECT [ParentId]
      ,[ParentEntityTypeId]
     -- ,[ParentRowId]
      ,[parentEntityId]
      ,[Name]
	        ,[HasTargetCredential]
      ,[HasTargetAssessment]
      ,[HasLearningOpportunity]
      ,[EntityId]
      ,[EntityTypeId]
      ,[EntityUid]
      ,[EntityConditionProfileId]
      ,[ConnectionTypeId]
      ,[ConditionSubTypeId]
      ,[ConnectionType]
      ,[ConnectionTypeSchemaName]
      ,[RowId]

  FROM [dbo].[Entity_ConditionProfileTargetsSummary]

 -- where [ConditionSubTypeId] in (2,3,4) 
  
  order by ParentEntityTypeId, parentId
*/
/*
Entity.ConditionProfile a
	Entity b on a.RowId = condProfEntity.EntityUid (entity for condition, not parent)
	Entity e 
	credential c
		Entity b on c.RowId = condProfEntity.EntityUid


List where a condition profile has at least one of a target credential, assessment or lopp.
This will include connection type condtions, as well as basic conditions - for now.
Filter on ConditionSubTypeId > 1 to get connections
Used in:
- Assessment_Summary
- LearningOpportunity_Summary
- Entity_ConditionProfileTotals
*/
Alter VIEW [dbo].[Entity_ConditionProfileTargetsSummary]
AS

SELECT        
	condProfParentEntity.EntityBaseId	AS ParentId
	, condProfParentEntity.EntityTypeId as ParentEntityTypeId
	, condProfParentEntity.EntityUid	as ParentRowId
	, a.EntityId as parentEntityId
	, condProfParentEntity.EntityBaseName as Name
	, condProfEntity.Id As EntityId
	, condProfEntity.EntityTypeId		--?? always cond profile
	, condProfParentEntity.EntityUid					--mixing Entity references!!!

	, a.Id AS EntityConditionProfileId
	, a.ConnectionTypeId
	, isnull(a.ConditionSubTypeId,1) as ConditionSubTypeId
	, cpv.Title as ConnectionType
	, cpv.SchemaName as ConnectionTypeSchemaName

	, a.RowId				--Can use to join Entity.Assessment and Entity.LearningOpportunity 
							--RowId = Entity.EntitUid and Entity.Id = child.EntityId
	-- AS EntityConditionProfileRowId
	,IsNull( credTotals.total,0) as HasTargetCredential
	,IsNull( asmtTotals.total,0) as HasTargetAssessment
	,IsNull( loppTotals.total,0) as HasLearningOpportunity
	--,case when exists (select a.CredentialId from [Entity.Credential] a inner join Credential b on a.CredentialId = b.Id where b.EntityStateId > 1 and EntityId = condProfEntity.id) then 1			else 0 end As HasTargetCredential

	--,case when exists (select a.AssessmentId from [Entity.Assessment] a inner join Assessment b on a.AssessmentId = b.Id where b.EntityStateId > 1 and a.EntityId = condProfEntity.id) then 1 else 0 end As HasTargetAssessment

	--,case when exists (select LearningOpportunityId from [Entity.LearningOpportunity] a inner join LearningOpportunity b on a.LearningOpportunityId = b.Id where b.EntityStateId > 1 and EntityId = condProfEntity.id) then 1 else 0 end As HasLearningOpportunity


FROM            
		dbo.[Entity.ConditionProfile] a
INNER JOIN dbo.Entity condProfParentEntity ON a.EntityId = condProfParentEntity.Id	--entity of parent/credential

Inner Join [Codes.PropertyValue] cpv	on a.ConnectionTypeId = cpv.Id
INNER JOIN dbo.Entity condProfEntity	ON a.RowId = condProfEntity.EntityUid		--entity for cond profile

--temp for testing:
Left Join (Select EntityId, count(*) as Total from [Entity.Credential] ec group by EntityId) credTotals
	on condProfEntity.Id = credTotals.EntityId
Left Join (Select EntityId, count(*) as Total from [Entity.Assessment] ec group by EntityId) asmtTotals
	on condProfEntity.Id = asmtTotals.EntityId
Left Join (Select EntityId, count(*) as Total from [Entity.LearningOpportunity] ec group by EntityId) loppTotals
	on condProfEntity.Id = loppTotals.EntityId
--where c.Id = 1
--need actual counts now, so changing
--confirm we only want requires or recommended for this context

where a.ConnectionTypeId < 3
/*
exists (select a.credentialId	from [Entity.Credential] a inner join Credential b on a.CredentialId = b.id 
			where b.EntityStateId > 1 AND a.EntityId = condProfEntity.id) 
OR	exists (select a.AssessmentId	from [Entity.Assessment] a inner join Assessment b on a.AssessmentId = b.Id		
			where b.EntityStateId > 1 and a.EntityId = condProfEntity.id) 
OR	exists (select a.LearningOpportunityId from [Entity.LearningOpportunity] a inner join LearningOpportunity b on a.LearningOpportunityId = b.Id  
			where b.EntityStateId > 1 and a.EntityId = condProfEntity.id) 
*/

GO
grant select on [Entity_ConditionProfileTargetsSummary] to public
go


/****** Object:  View [dbo].[Entity_DurationProfileSummary]    Script Date: 9/6/2023 3:47:48 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*

SELECT top 1000
b.[EntityId]
      ,b.[EntityTypeId], EntityBaseId
      ,b.[EntityUid]
      ,b.[TypeId]
	  ,b.[FromDuration]
      ,b.[ToDuration]
      ,b.[FromYears]
      ,b.[FromMonths]
      ,b.[FromWeeks]
      ,b.[FromDays]
      ,b.[FromHours]
      ,b.[FromMinutes]
      ,b.[ToYears]
      ,b.[ToMonths]
      ,b.[ToWeeks]
      ,b.[ToDays]
      ,b.[ToHours]
      ,b.[ToMinutes]
      ,b.[DurationComment]
      ,b.[DurationSummary]

  FROM [dbo].[Entity_DurationProfileSummary] b

GO



*/
ALTER VIEW [dbo].[Entity_DurationProfileSummary]
AS
SELECT        
	e.Id as EntityId
	, e.EntityTypeId, e.EntityBaseId
	, e.EntityUid
	, edp.TypeId
	, edp.FromYears, edp.FromMonths, edp.FromWeeks, edp.FromDays, edp.FromHours, edp.FromMinutes
	, edp.ToYears, edp.ToMonths, edp.ToWeeks, edp.ToDays, edp.ToHours, edp.ToMinutes
	, edp.DurationComment, edp.DurationSummary, edp.FromDuration, edp.ToDuration
FROM dbo.Entity AS e 
INNER JOIN dbo.[Entity.DurationProfile] AS edp ON e.Id = edp.EntityId
GO



/****** Object:  View [dbo].[Entity_Summary]    Script Date: 7/26/2017 10:52:55 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*

SELECT [Id]
      ,[EntityTypeId]      ,[EntityType]
	  ,EntitySubTypeId
      ,[EntityUid]
      ,[parentEntityId]
      ,[parentEntityUid]
      ,[parentEntityType]
      ,[parentEntityTypeId]
      ,[BaseId]
      ,[Name]
      ,[Description]
      ,[Created]
      ,[LastUpdated]
      ,[OwningOrgId]
      ,[OwningOrganization]
      ,[SubjectWebpage]
      ,[ImageUrl]
      ,[CTID]
      ,[EntityStateId]
  FROM [dbo].[Entity_Summary]
  where EntityTypeId= 7
  or EntitySubTypeId= 37
GO




where id = 334


 -- where parententityuid = 'C10E0233-16E9-4790-9F77-AC4C0A33E901'
order by 
      [EntityType]
      ,[Name]


*/
/*
Modifications
17-08-22 mparsons - added to workIT
20-04-20 mparsons - replace EducationFrameworks with CompetencyFrameworks
21-05-29 mparsons - add OccupationProfile, JobProfile
21-11-24 mparsons - updated to use specific entityTypeIds for lopp classes - need to test implications
22-02-23 mparsons - Added collection. For credential, removed the inner join to credential type. 
22-03-01 mparsons - Added transfer intermediary
22-06-01 mparsons - now excluding non-top level resources
22-06-14 mparsons - added dataSet profile
22-07-07 mparsons - need to distinguish between the base type and a subtype. Use the base type (i.e. 7 for lopps) for main reporting
***** trying to move away from using this. Though may be useful for a full build ****
***** can we get rid of the non top level resources (ex. condition profiles, addresses)
24-02-15 mparsons - changed to just entity_cache
*/
Alter VIEW [dbo].[Entity_Summary]
AS
SELECT a.[Id]
      ,a.[EntityTypeId]
      ,a.[EntityType]
	  --TBD
	  ,a.EntityTypeId as EntitySubTypeId
      ,a.[EntityUid]
      ,a.[EntityStateId]
      ,a.[CTID]
      ,a.[parentEntityId]
      ,a.[parentEntityUid]
      ,a.[parentEntityType]
      ,a.[parentEntityTypeId]
      ,a.[BaseId]
      ,a.[Name]
      ,a.[Description]
      ,a.[SubjectWebpage]
      ,a.[OwningOrgId]
	  ,isnull(org.Name,'') as OwningOrganization --should be primaryOrg
      ,a.[ImageUrl]
      ,a.[Created]
      ,a.[LastUpdated]
      ,a.[CacheDate]
      ,a.[PublishedByOrgId]
      --,a.[ResourceDetail]
      --,a.[AgentRelationshipsForEntity]
      ,a.[IsActive]
  FROM [dbo].[Entity_Cache] a
  Left Join Organization org on a.OwningOrgId = org.Id

GO
grant select on [Entity_Summary] to public
go


/****** Object:  View [dbo].[JobProfileSummary]    Script Date: 7/29/2020 11:13:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*


SELECT base.[Id]
      ,base.[RowId]
      ,base.[EntityId]
      ,base.[Name]
      ,base.[Description]
      ,base.[EntityStateId]
      ,base.[CTID]
      ,base.[PrimaryAgentUid]
      ,base.[PrimaryOrganizationId]
      ,base.[PrimaryOrganizationName]
      ,base.[PrimaryOrganizationCtid]
      ,base.[SubjectWebpage]
      ,base.[AbilityEmbodied]
      ,base.[Classification]
      ,base.[CodedNotation]
      ,base.[Comment]
      ,base.[Identifier]
      ,base.[KnowledgeEmbodied]
      ,base.[SkillEmbodied]
      ,base.[SameAs]
      ,base.[VersionIdentifier]
      ,base.[JsonProperties]
      ,base.[Created]
      ,base.[LastUpdated]
  FROM [dbo].[JobProfileSummary] a

GO



*/
/*
JobProfileSummary
Notes
- 
Mods
22-11-08 mparsons - new

*/
Alter VIEW [dbo].[JobProfileSummary]
AS
 
SELECT base.[Id]
	,base.[RowId]
	,b.Id as EntityId
	,base.[Name]
	,base.[Description]
	,base.[EntityStateId]
	,base.[CTID]
	,base.[PrimaryAgentUid]
	,isnull(primaryOrg.Id,0)	as PrimaryOrganizationId
	,isnull(primaryOrg.Name,'') as PrimaryOrganizationName
	,isnull(primaryOrg.CTID,'') as PrimaryOrganizationCtid
	,base.[SubjectWebpage]
	,base.[AbilityEmbodied]
	,base.[Classification]
	,base.[CodedNotation]
	,base.[Comment]
	,base.[Identifier]
	,base.[KnowledgeEmbodied]
	,base.[SkillEmbodied]
	,base.[SameAs]
	,base.[VersionIdentifier]
	,base.[JsonProperties]
	,base.[Created]
	,base.[LastUpdated]
	,base.[LifeCycleStatusTypeId]
	,cpv.Title as LifeCycleStatusType
	, (SELECT ehrs.[Name], ehrs.[Description] FROM [dbo].[Entity.HasResourceSummary] ehrs 
		where ehrs.EntityId = b.Id  and ehrs.EntityTypeId=17
		FOR XML RAW, ROOT('Competencies')) Competencies

--
  FROM [dbo].[JobProfile] base

INNER JOIN dbo.Entity AS b ON base.RowId = b.EntityUid 
-- join for primary
	Left join Organization primaryOrg on base.[PrimaryAgentUid] = primaryOrg.RowId and primaryOrg.EntityStateId > 1
	Left Join [Codes.PropertyValue] cpv on base.LifeCycleStatusTypeId = cpv.Id

where base.EntityStateId > 1

GO

grant select on [JobProfileSummary] to public
go




/****** Object:  View [dbo].[LearningOpportunity_Competency_Summary]    Script Date: 10/6/2017 4:16:47 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*


SELECT [EntityId]
      ,[LearningOpportunity]
      ,[LearningOpportunityId]
      ,[Name]
      ,[Description]
      ,[TargetName]
      ,[TargetDescription]
      ,[TargetUrl]
      ,[CodedNotation]
      ,[AlignmentType]
  FROM [dbo].[LearningOpportunity_Competency_Summary]
GO
distinct
select * from LearningOpportunity_summary base
where 
( base.Id in (SELECT  LearningOpportunityId FROM [dbo].LearningOpportunity_Competency_Summary  where AlignmentType = 'teaches' AND (([Name] like '%design%' OR [Description] like '%design%')) ) )

*/
/*
LearningOpportunity_Competency_Summary
- list of teaches competencies for a learning opportunity
Modifications
21-05-02 mparsons - stop using: EntityCompetencyFramework_Items_Summary
					- too many joins result

*/
Alter VIEW [dbo].[LearningOpportunity_Competency_Summary]
AS
  /*
     entity.Competency
			 entity (for parent LO)
				LearningOpportunity parent

    			entity.LearningOpp (under the LearningOpportunity entity - for 
    				entity (parent LO)
							LearningOpportunity (rowId)

	*/

SELECT 
	---a.EntityCompetencyFrameworkItemId as Id,
	IsNUll(b.Id,0) AS Id
	,a.[EntityId]
	,l.Name as LearningOpportunity
	,l.Id as LearningOpportunityId
	,l.CTID as LearningOpportunityCTID
	,a.[FrameworkName]
	,a.TargetNodeName AS Competency
	,a.TargetNodeName AS Name 
	--,a.Competency
	--,a.Competency As Name
	,a.TargetNodeDescription
	,a.TargetNodeDescription as Description
	,TargetNode
	,[CodedNotation]
	,a.Alignment as AlignmentType
	,a.Created  as CompetencyCreated
	--  ,'teaches' as [AlignmentType]
	--,AlignmentTypeId
     
	,parentLopp.Id as ParentLearningOpportunityId
	,parentLopp.Name as ParentLearningOpportunity
	  --,parentLopp.Organization as ParentOrganization
--	select *
  --FROM  [EntityCompetencyFramework_Items_Summary] a
FROM       dbo.[Entity.Competency] a
--may not have a framework. Why? Collections. 
Left JOIN dbo.CompetencyFramework b ON a.CompetencyFrameworkId = b.id
inner join Entity e			on a.EntityId = e.Id
inner join LearningOpportunity l on e.EntityUid = l.RowId

  --get related Entity.LearningOpportunity to get a parent lopp if present. 
  --	NOT SURE OF VALUE VS PERFORMANCE
  LEFT join [Entity.LearningOpportunity] entityLopp on l.Id = entityLopp.LearningOpportunityId
  --get parent (most likely comp is at a embedded Lopp level)
  left join Entity pe on entityLopp.EntityId = pe.Id
  left join LearningOpportunity parentLopp on pe.EntityUid = parentLopp.RowId

  where e.EntityTypeId = 7


GO




/****** Object:  View [dbo].[LearningOpportunity_Parts_Competencies_Summary]    Script Date: 10/6/2017 4:36:54 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*


SELECT [LearningOpportunityId]
      ,[LearningOpportunity]
      ,[LearningOpportunityRowId]
				,ParentLearningOppEntityId


      ,[LearningOpportunity_PartId]
			,LO_PartEntityId
      ,[LearningOpportunity_PartRowId]
      ,[LearningOpportunity_Part]
      ,[LearningOpportunity_Part_Description]
      ,[LearningOpportunity_PartStatusId]
      ,[LearningOpportunity_Part_ManagingOrgId]

      ,[AlignmentType]
      ,[AlignmentTypeId]
      ,[Name]
      ,[Description]
      ,[CodedNotation]
      ,[TargetName]
      ,[TargetDescription]
      ,[TargetUrl]
  FROM [dbo].[LearningOpportunity_Parts_Competencies_Summary]
GO

Moving competencies from child to parent



*/
Alter VIEW [dbo].[LearningOpportunity_Parts_Competencies_Summary]
AS
/*
	LearningOpportunity_Parts_Summary
								LO (parent LO)
									Entity
										Entity.LO
											LO (child LO)
			ENTITY
					entity.Competency
	*/

SELECT [LearningOpportunityId]
		,[LearningOpportunity]
		,[LearningOpportunityRowId]
		,ParentLearningOppEntityId

		,[LearningOpportunity_PartId]
		,[LearningOpportunity_PartRowId]
		,[LearningOpportunity_Part]
		,[LearningOpportunity_Part_Description]
		,LO_PartEntityId
		--,[LearningOpportunity_PartStatusId]
		--,[LearningOpportunity_Part_ManagingOrgId]		

		,partComp.EntityCompetencyFrameworkItemId
		--		,partComp.AlignmentType, partComp.AlignmentTypeId
		,partComp.Competency, partComp.TargetNodeDescription
		,partComp.CodedNotation
		,partComp.TargetNode
		,partComp.Created  as CompetencyCreated

  FROM [dbo].[LearningOpportunity_Parts_Summary] base
	inner join Entity 
			on base.[LearningOpportunity_PartRowId] = Entity.EntityUid
	inner join [EntityCompetencyFramework_Items_Summary] partComp 
			on Entity.Id = partComp.EntityId


GO



/****** Object:  View [dbo].[LearningOpportunity_PropertyTotals]    Script Date: 5/31/2020 9:40:24 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- group 2
/*
Add
Learning Method Description
Assessment Method Description
Coded Notation
VersionIdentifier


HasPart
IsPartOf
OfferedIN

Modifications
22-01-11 mparsons - add LifeCycleStatusType
22-10-08 mparsons - add alternameName
23-09-27 mparsons - add prerequisite
*/
ALTER VIEW [dbo].[LearningOpportunity_PropertyTotals]
AS
select 

	sum(case when Len(IsNull(a.Name, '')) > 0 then 1 else 0 end) as Total
	, sum(case when Len(IsNull(a.Name, '')) > 0 then 1 else 0 end) as Name
	, sum(case when Len(IsNull(a.Description, '')) > 0 then 1 else 0 end) as Description
	, sum(case when Len(IsNull(a.SubjectWebpage, '')) > 0 then 1 else 0 end) as SubjectWebpage
	, sum(case when Len(IsNull(a.CTID, '')) > 0 then 1 else 0 end) as CTID
	 , sum(case when Len(IsNull(a.LifeCycleStatusType, '')) > 0 then 1 else 0 end) as LifeCycleStatusType

	,sum(case when Len(IsNull(a.AvailabilityListing,'')) > 0 then 1 else 0 end) HasAvailabilityListing
	,sum(case when Len(IsNull(a.availableOnlineAt,'')) > 0 then 1 else 0 end) HasAvailableOnlineAt
	,sum(case when IsNull(a.DateEffective,'') > '1900-01-01 00:00:00.000' then 1 else 0 end) HasDateEffective
	,sum(case when Len(IsNull(a.IdentificationCode,'')) > 0 then 1 else 0 end) HasCodedNotation
	,sum(case when Len(IsNull(a.SCED,'')) > 0 then 1 else 0 end) HasSCED

	,sum(case when Len(IsNull(tbl.DeliveryTypeDescription,'')) > 0 then 1 else 0 end) HasDeliveryTypeDescription	
	,sum(case when Len(IsNull(tbl.LearningMethodDescription,'')) > 0 then 1 else 0 end) HasLearningMethodDescription
	,sum(case when Len(IsNull(tbl.AssessmentMethodDescription,'')) > 0 then 1 else 0 end) HasAssessmentMethodDescription

	,sum(case when Len(tbl.CreditUnitTypeId) > 0 then 1 else 0 end) HasCreditUnitType	
	,sum(case when Len(tbl.CreditUnitValue) > 0 then 1 else 0 end) HasCreditUnitValue	
	,sum(case when Len(tbl.CreditUnitMaxValue) > 0 then 1 else 0 end) HasCreditUnitMaxValue	
	,sum(case when Len(IsNull(tbl.CreditUnitTypeDescription,'')) > 0 then 1 else 0 end) HasCreditUnitTypeDescription	
	--
	,sum(case when IsNull(cip.CategoryId,0) > 0 then 1 else 0 end) HasInstructionalPgms		--##
	,sum(case when IsNull(occ.CategoryId,0) > 0 then 1 else 0 end) HasOccupations			--##
	,sum(case when IsNull(ind.CategoryId,0) > 0 then 1 else 0 end) HasIndustries			--##
	--
	,sum(case when IsNull(audienceLevelType.CategoryId,0) > 0 then 1 else 0 end) HasAudienceLevelType
	,sum(case when IsNull(audience.CategoryId,0) > 0 then 1 else 0 end) HasAudience
	,sum(case when IsNull(delType.CategoryId,0) > 0 then 1 else 0 end) HasDeliveryMethodType
	,sum(case when IsNull(learningMethod.CategoryId,0) > 0 then 1 else 0 end) HasLearningMethodType
	--
	,sum(case when IsNull(Competencies.EntityBaseId,0) > 0 then 1 else 0 end) HasCompetencies
	,sum(case when IsNull(Address.EntityBaseId,0) > 0 then 1 else 0 end) HasAddress
	,sum(case when IsNull(Costs.EntityBaseId,0) > 0 then 1 else 0 end) HasCosts
	,sum(case when IsNull(Duration.EntityBaseId,0) > 0 then 1 else 0 end) HasDuration
	,sum(case when IsNull(jurisdictions.EntityBaseId,0) > 0 then 1 else 0 end) HasJurisdictions
	,sum(case when IsNull(identifiers.EntityBaseId,0) > 0 then 1 else 0 end) HasIdentifier
	,sum(case when IsNull(videntifiers.EntityBaseId,0) > 0 then 1 else 0 end) HasVersionIdentifier
	--
	,sum(case when IsNull(commonCosts.EntityBaseId,0) > 0 then 1 else 0 end) HasCommonCosts
	,sum(case when IsNull(commonConditions.EntityBaseId,0) > 0 then 1 else 0 end) HasCommonConditions
	--
	,sum(case when IsNull(HasPart.EntityBaseId,0) > 0 then 1 else 0 end) HasPart
	,sum(case when IsNull(HasPrerequisite.EntityBaseId,0) > 0 then 1 else 0 end) HasPrerequisite

	--conditions
		--
	,sum(case when IsNull(requires.EntityBaseId,0) > 0 then 1 else 0 end) HasRequires
	,sum(case when IsNull(recommends.EntityBaseId,0) > 0 then 1 else 0 end) HasRecommends
	,sum(case when IsNull(coreq.EntityBaseId,0) > 0 then 1 else 0 end) HasCorequisites
	,sum(case when IsNull(entryLvl.EntityBaseId,0) > 0 then 1 else 0 end) HasEntryConditions

	--connections
	--,sum(case when IsNull(RequiresCount,0) > 0 then 1 else 0 end) HasRequires
	--,sum(case when IsNull(RecommendsCount,0) > 0 then 1 else 0 end) HasRecommends
	,sum(case when IsNull(isRequiredForCount,0) > 0 then 1 else 0 end) HasIsRequiredFor
	,sum(case when IsNull(IsRecommendedForCount,0) > 0 then 1 else 0 end) HasRecommendedFor
	,sum(case when IsNull(IsAdvancedStandingForCount,0) > 0 then 1 else 0 end) HasIsAdvancedStandingFor
	,sum(case when IsNull(AdvancedStandingFromCount,0) > 0 then 1 else 0 end) HasAdvancedStandingFrom
	,sum(case when IsNull(isPreparationForCount,0) > 0 then 1 else 0 end) HasIsPreparationFor
	,sum(case when IsNull(PreparationFromCount,0) > 0 then 1 else 0 end) HasPreparationFrom
	-- BYs
	,sum(case when IsNull(ownedBy.RelationshipTypeId,0) > 0 then 1 else 0 end) HasOwnedBy
	,sum(case when IsNull(offeredBy.RelationshipTypeId,0) > 0 then 1 else 0 end) HasOfferedBy
	,sum(case when IsNull(accreditedBy.RelationshipTypeId,0) > 0 then 1 else 0 end) HasAccreditedBy
	,sum(case when IsNull(approvedBy.RelationshipTypeId,0) > 0 then 1 else 0 end) HasApprovedBy
	,sum(case when IsNull(recognizedBy.RelationshipTypeId,0) > 0 then 1 else 0 end) HasRecognizedBy
	,sum(case when IsNull(RegulatedBy.RelationshipTypeId,0) > 0 then 1 else 0 end) HasRegulatedBy

	,sum(case when IsNull(finAssistance.EntityBaseId,0) > 0 then 1 else 0 end) HasFinancialAssistance
	,sum(case when IsNull(languages.EntityBaseId,0) > 0 then 1 else 0 end) HasLanguages
	,sum(case when IsNull(subjects.EntityBaseId,0) > 0 then 1 else 0 end) HasSubjects
	,sum(case when IsNull(keywords.EntityBaseId,0) > 0 then 1 else 0 end) HasKeywords
	,sum(case when IsNull(alternateNames.EntityBaseId,0) > 0 then 1 else 0 end) HasAlternateNames
	--INs --------------------------------------------------------------
	,sum(case when IsNull(accreditedIN.[AssertedInTypeId],0) > 0	then 1 else 0 end) HasAccreditedIn
	,sum(case when IsNull(approvedIN.[AssertedInTypeId],0) > 0		then 1 else 0 end) HasApprovedIN
	,sum(case when IsNull(offeredIN.[AssertedInTypeId],0) > 0		then 1 else 0 end) HasOfferedIN
	,sum(case when IsNull(recognizedIN.[AssertedInTypeId],0) > 0	then 1 else 0 end) HasRecognizedIN
	,sum(case when IsNull(RegulatedIN.[AssertedInTypeId],0) > 0		then 1 else 0 end) HasRegulatedIN

	-- Process Profiles --------------------------------------------------------------
	--,sum(case when IsNull(adminProfile.EntityBaseId,0) > 0 then 1 else 0 end) HasAdminProcessProfile
	--,sum(case when IsNull(appealProfile.EntityBaseId,0) > 0 then 1 else 0 end) HasAppealProcessProfile
	--,sum(case when IsNull(complaintProfile.EntityBaseId,0) > 0 then 1 else 0 end) HasComplaintProcessProfile
	----,sum(case when IsNull(criteriaProfile.EntityBaseId,0) > 0 then 1 else 0 end) HasCriteriaProcessProfile
	--,sum(case when IsNull(devProfile.EntityBaseId,0) > 0 then 1 else 0 end) HasDevProcessProfile
	--,sum(case when IsNull(mtceProfile.EntityBaseId,0) > 0 then 1 else 0 end) HasMtceProcessProfile
	--,sum(case when IsNull(reviewProfile.EntityBaseId,0) > 0 then 1 else 0 end) HasReviewProcessProfile
	--,sum(case when IsNull(revokeProfile.EntityBaseId,0) > 0 then 1 else 0 end) HasRevokeProcessProfile

  from LearningOpportunity_Summary a
  inner join LearningOpportunity tbl on a.Id = tbl.Id
  inner join entity b on a.RowId = b.EntityUid
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  RelationshipTypeId  FROM [dbo].[Entity.AgentRelationship] inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and RelationshipTypeId=6
  ) ownedBy on a.Id = ownedBy.EntityBaseId

  -- BYs---------------------------------------------------------------------
  left join (
	  SELECT distinct Entity.EntityBaseId,  EntityId,  RelationshipTypeId  FROM [dbo].[Entity.AgentRelationship] inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and RelationshipTypeId=1
  ) accreditedBy on a.Id = accreditedBy.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  RelationshipTypeId  FROM [dbo].[Entity.AgentRelationship] inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and RelationshipTypeId=2
  ) approvedBy on a.Id = approvedBy.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  RelationshipTypeId  FROM [dbo].[Entity.AgentRelationship] inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and RelationshipTypeId=7
  ) offeredBy on a.Id = offeredBy.EntityBaseId

  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  RelationshipTypeId  FROM [dbo].[Entity.AgentRelationship] inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and RelationshipTypeId=10
  ) recognizedBy on a.Id = recognizedBy.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  RelationshipTypeId  FROM [dbo].[Entity.AgentRelationship] inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and RelationshipTypeId=12
  ) RegulatedBy on a.Id = RegulatedBy.EntityBaseId
  -- address---------------------------------------------------------------------
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.Address] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7
  ) Address on a.Id = Address.EntityBaseId
  ---------------------------------------------------------------------
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.CostProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7
  ) Costs on a.Id = Costs.EntityBaseId
  ---------------------------------------------------------------------
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.DurationProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7
  ) Duration on a.Id = Duration.EntityBaseId
  -------------------------------------
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.IdentifierValue] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7  and a.[IdentityValueTypeId] = 2
  ) identifiers on a.Id = identifiers.EntityBaseId
    left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.IdentifierValue] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and a.[IdentityValueTypeId] = 1
  ) videntifiers on a.Id = videntifiers.EntityBaseId
    -- hasPart---------------------------------------------------------------------
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.LearningOpportunity] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 AND a.RelationshipTypeId = 1
  ) HasPart on a.Id = HasPart.EntityBaseId
    -- Prerequisite---------------------------------------------------------------------
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.LearningOpportunity] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 AND a.RelationshipTypeId = 5
  ) HasPrerequisite on a.Id = HasPrerequisite.EntityBaseId
  --manifests---------------------------------------------------------------------
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.CostManifest] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 
  ) commonCosts on a.Id = commonCosts.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.CommonCondition] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7
  ) commonConditions on a.Id = commonConditions.EntityBaseId
-----------------------------------------------------------------------
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.FinancialAssistanceProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7
  ) finAssistance on a.Id = finAssistance.EntityBaseId
-----------------------------------------------------------------------
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.Competency] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7
  ) Competencies on a.Id = Competencies.EntityBaseId
  -----------------------------------------------------------------------
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.JurisdictionProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7
  ) jurisdictions on a.Id = jurisdictions.EntityBaseId
  -- frameworks -------------------------------------------------------------------
left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM [dbo].[Entity_ReferenceFramework_Summary]
	  where [EntityTypeId]= 7 and [CategoryId] = 23
  ) cip on a.Id = cip.EntityBaseId
  left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM [dbo].[Entity_ReferenceFramework_Summary]
	  where [EntityTypeId]= 7 and [CategoryId] = 11
  ) occ on a.Id = occ.EntityBaseId
  left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM [dbo].[Entity_ReferenceFramework_Summary]
	  where [EntityTypeId]= 7 and [CategoryId] = 10
  ) ind on a.Id = ind.EntityBaseId
  --properties---------------------------------------------------------------------
    left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM [dbo].[EntityProperty_Summary]  where [EntityTypeId]= 7 and [CategoryId] = 4
  ) audienceLevelType on a.Id = audienceLevelType.EntityBaseId
    left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM [dbo].[EntityProperty_Summary]  where [EntityTypeId]= 7 and [CategoryId] = 14
  ) audience on a.Id = audience.EntityBaseId
    left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM [dbo].[EntityProperty_Summary]  where [EntityTypeId]= 7 and [CategoryId] = 21
  ) delType on a.Id = delType.EntityBaseId
    left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM [dbo].[EntityProperty_Summary]  where [EntityTypeId]= 7 and [CategoryId] = 53
  ) learningMethod on a.Id = learningMethod.EntityBaseId

  --INs ---------------------------------------------------------------------
   left join (
	  SELECT distinct Entity.EntityBaseId,  EntityId,  [AssertedInTypeId]  FROM [dbo].[Entity.JurisdictionProfile] inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and  JProfilePurposeId = 3 and [AssertedInTypeId] = 1
  ) accreditedIN on a.Id = accreditedIN.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  [AssertedInTypeId]  FROM [dbo].[Entity.JurisdictionProfile] inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and  JProfilePurposeId = 3 and [AssertedInTypeId] = 2
  ) approvedIN on a.Id = approvedIN.EntityBaseId
    --
    left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  [AssertedInTypeId]  FROM [dbo].[Entity.JurisdictionProfile] inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and  JProfilePurposeId = 3 and [AssertedInTypeId] = 7
  ) offeredIN on a.Id = offeredIN.EntityBaseId
  --
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  [AssertedInTypeId]  FROM [dbo].[Entity.JurisdictionProfile] inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and  JProfilePurposeId = 3 and [AssertedInTypeId] = 10
  ) recognizedIN on a.Id = recognizedIN.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  [AssertedInTypeId]  FROM [dbo].[Entity.JurisdictionProfile] inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and  JProfilePurposeId = 3 and [AssertedInTypeId] = 12
  ) RegulatedIN on a.Id = RegulatedIN.EntityBaseId

-- condition profiles---------------------------------------------------------------------
  --requires
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ConditionProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and a.ConnectionTypeId=1 and isnull(ConditionSubTypeId, 0) = 1 
  ) requires on a.Id = requires.EntityBaseId
  --recommends
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ConditionProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and a.ConnectionTypeId=2 and isnull(ConditionSubTypeId, 0) = 1
  ) recommends on a.Id = recommends.EntityBaseId
  --co-requisite
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ConditionProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and a.ConnectionTypeId=10
  ) coreq on a.Id = coreq.EntityBaseId
-- entry condition
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ConditionProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and a.ConnectionTypeId=11
  ) entryLvl on a.Id = entryLvl.EntityBaseId
  --[Entity.Reference]---------------------------------------------------------------------
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.Reference] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and [CategoryId] = 65
  ) languages on a.Id = languages.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.Reference] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and [CategoryId] = 34
	  and Len(IsNull(a.TextValue,'')) > 0
  ) subjects on a.Id = subjects.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.Reference] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and [CategoryId] = 35
	  and Len(IsNull(a.TextValue,'')) > 0
  ) keywords on a.Id = keywords.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.Reference] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and [CategoryId] = 38
	  and Len(IsNull(a.TextValue,'')) > 0
  ) alternateNames on a.Id = alternateNames.EntityBaseId 
-- Process profiles---------------------------------------------------------------------
--  --1-admin
--  left join (
--	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ProcessProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and a.ProcessTypeId=1 
--  ) adminProfile on a.Id = requires.EntityBaseId
--  --2
--  left join (
--	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ProcessProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and a.ProcessTypeId=2 
--  ) devProfile on a.Id = requires.EntityBaseId
--  --3
--  left join (
--	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ProcessProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and a.ProcessTypeId=3 
--  ) mtceProfile on a.Id = requires.EntityBaseId
----4
--  left join (
--	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ProcessProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and a.ProcessTypeId=4
--  ) appealProfile on a.Id = requires.EntityBaseId
--  --5
--  left join (
--	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ProcessProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and a.ProcessTypeId=5
--  ) complaintProfile on a.Id = requires.EntityBaseId
-- --6 CRITERIA- obsolete
--  --left join (
--	 -- SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ProcessProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and a.ProcessTypeId=6 
--  --) criteriaProfile on a.Id = requires.EntityBaseId
----7
--  left join (
--	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ProcessProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and a.ProcessTypeId=7
--  ) reviewProfile on a.Id = requires.EntityBaseId
--  --8
--  left join (
--	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ProcessProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and a.ProcessTypeId=8
--  ) revokeProfile on a.Id = requires.EntityBaseId

where a.EntityStateId = 3
GO


/****** Object:  View [dbo].[LearningOpportunity_Summary]    Script Date: 8/16/2017 10:06:44 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*


SELECT top (1000)
[Id]
      ,[RowId]
      ,[Name]
      ,[Description]
      ,[OrgId]
      ,[Organization]
      ,[SubjectWebpage]
      ,[DateEffective]
      ,[EntityStateId]
      ,[CTID]
      ,[CredentialRegistryId]
      ,[cerEnvelopeUrl]
      ,[Created]
      ,[LastUpdated]
      ,[IdentificationCode]
      ,[availableOnlineAt]
      ,[AvailabilityListing]
      ,[RequiresCount]
      ,[RecommendsCount]
      ,[isRequiredForCount]
      ,[IsRecommendedForCount]
      ,[IsAdvancedStandingForCount]
      ,[AdvancedStandingFromCount]
      ,[isPreparationForCount]
      ,[PreparationFromCount]
      ,[ConnectionsList]
      ,[CredentialsList]
      ,[Org_QAAgentAndRoles]
  FROM [dbo].[LearningOpportunity_Summary] base
  where base.id > 34000 and base.id < 36000
  order by base.Id

  where len(Org_QAAgentAndRoles) > 0

where 
 ( base.RowId in ( SELECT  b.EntityUid FROM [dbo].[Entity.Address] a inner join Entity b on base.EntityId = b.Id    where [Longitude] < -75.69581015624999 and [Longitude] > -144.60206015625 and [Latitude] < 55.563635054119175 and [Latitude] > 7.772301325445006 ) ) 

 
*/

/*
Learning opportunity summary
NOT used in code, only by search, elastic search, and other views

Do not bulk up if not necessary
*/
Alter VIEW [dbo].[LearningOpportunity_Summary]
AS

SELECT 
base.[Id]
	,base.RowId 
	,base.EntityTypeId as LearningEntityTypeId
	,case when base.EntityTypeId= 36 then 'Learning Program'
		when base.EntityTypeId = 37 then 'Course'
		else 'Learning Opportunity' end as LearningEntityType
	,e.Id as EntityId
	,base.EntityStateId
	,isnull(base.CTID,'') As CTID 
	,base.[Name]
	,base.[Description]
	,IsNull(base.LifeCycleStatusTypeId,0)	as LifeCycleStatusTypeId
	,cpv.Title		as LifeCycleStatusType
	--owning org
	,isnull(owningOrg.Id,0) as OrgId
	,isnull(owningOrg.Name,'') as Organization
	,isnull(owningOrg.CTID,'') as OwningOrganizationCtid
	,base.OwningAgentUid
	,base.SubjectWebpage
	,base.[DateEffective]

	,base.CredentialRegistryId
	,case when len(isnull(base.CredentialRegistryId,'')) = 36 then
	'<a href="http://lr-staging.learningtapestry.com/ce-registry/envelopes/' + base.CredentialRegistryId + '" target="_blank">cerEnvelope</a>'
	else '' End As cerEnvelopeUrl
	
	,base.[Created]
	,base.[LastUpdated]

	--else isnull(statusProperty.Property,'') end As LifeCycleStatusType --
	,base.[IdentificationCode]
	,base.SCED
	,base.availableOnlineAt
	,base.AvailabilityListing

	,base.IsNonCredit

	,IsNull(c1.Nbr,0) As RequiresCount
	,IsNull(c2.Nbr,0) As RecommendsCount
	----don't add these until a use case for elastic
	--,IsNull(Corequisite.Nbr,0) As CorequisiteConditionCount
	--,IsNull(EntryCondition.Nbr,0) As EntryConditionConditionCount

	,IsNull(c3.Nbr,0) As isRequiredForCount
	,IsNull(c4.Nbr,0) As IsRecommendedForCount
	,IsNull(c6.Nbr,0) As IsAdvancedStandingForCount
	,IsNull(c7.Nbr,0) As AdvancedStandingFromCount
	,IsNull(c8.Nbr,0) As isPreparationForCount
	,IsNull(c9.Nbr,0) As PreparationFromCount

	--actual connection type (no credential info)
	,isnull(connectionsCsv.Profiles,'') As ConnectionsList			
	,isnull(connectionsCsv.CredentialsList,'') As CredentialsList	--connection type, plus Id, and name of credential
	,isnull(qaRoles.Org_QAAgentAndRoles,'') As Org_QAAgentAndRoles

	--,skip for now, a little heavy?
	--,isnull(e.AgentRelationshipsForEntity,'') as AgentRelationshipsForEntity
	--,isnull(e.ResourceDetail,'') as ResourceDetail

  FROM [dbo].[LearningOpportunity] base
    Inner Join Entity_Cache e on base.RowId = e.EntityUid

  left join [codes.PropertyValue] cpv on base.LifeCycleStatusTypeId = cpv.Id
 --   Left Join Organization managingOrg on base.ManagingOrgId = managingOrg.Id
 -- join for owner - note may be changing
	Left join Organization owningOrg on base.OwningAgentUid = owningOrg.RowId and owningOrg.EntityStateId > 1
--	Left Join EntityProperty_Summary	statusProperty on base.RowId = statusProperty.EntityUid and statusProperty.CategoryId = 84

	--connections/conditionProfiles  - Post-Award Connections (Requirements)
left join (
	Select ParentId, Count(*) As Nbr from Entity_ConditionProfileTargetsSummary where ParentEntityTypeId= 7 AND ConnectionTypeId = 1 
	and isnull(ConditionSubTypeId, 1) in (1,2)
	--AND HasTargetCredential= 1 --don't think applicable
	group by ParentId
	) c1 on base.Id = c1.ParentId
--connections/conditionProfiles - Attainment Recommendations
left join (
	Select ParentId, Count(*) As Nbr from Entity_ConditionProfileTargetsSummary where ParentEntityTypeId= 7 AND ConnectionTypeId = 2 
	and isnull(ConditionSubTypeId, 1) in (1,2)
	--AND HasTargetCredential= 1 
	group by ParentId
	) c2						on base.Id = c2.ParentId
--Corequisite
left join (
	Select ParentId, Count(*) As Nbr from Entity_ConditionProfileTargetsSummary where ParentEntityTypeId= 7 AND ConnectionTypeId = 10 
	and isnull(ConditionSubTypeId, 1) in (1,2)
	--AND HasTargetCredential= 1 
	group by ParentId
	) Corequisite						on base.Id = Corequisite.ParentId

--Entry Condition
left join (
	Select ParentId, Count(*) As Nbr from Entity_ConditionProfileTargetsSummary where ParentEntityTypeId= 7 AND ConnectionTypeId = 11 
	and isnull(ConditionSubTypeId, 1) in (1,2)
	--AND HasTargetCredential= 1 
	group by ParentId
	) EntryCondition						on base.Id = EntryCondition.ParentId
	--============================================================================
	--Post-Award Connections (Is Required For)
	left join (
	Select ParentId, Count(*) As Nbr from Entity_ConditionProfileTargetsSummary where ParentEntityTypeId= 7 AND ConnectionTypeId = 3 
	group by ParentId
	--AND HasTargetCredential = 1 
	) c3						on base.Id = c3.ParentId
		
	--connections/conditionProfiles - Post-Award Connections (Is Recommended For)
	left join (
	Select ParentId, Count(*) As Nbr from Entity_ConditionProfileTargetsSummary where ParentEntityTypeId= 7 AND ConnectionTypeId = 4
	--AND HasTargetCredential = 1 
	 group by ParentId
	) c4						on base.Id = c4.ParentId

	--connections/conditionProfiles - Advanced Standing For
	left join (
	Select ParentId, Count(*) As Nbr from Entity_ConditionProfileTargetsSummary where ParentEntityTypeId= 7 AND ConnectionTypeId = 6 
	--AND HasTargetCredential= 1 
	group by ParentId
	) c6						on base.Id = c6.ParentId
								
		
	--connections/conditionProfiles - Advanced Standing From
	left join (
	Select ParentId, Count(*) As Nbr from Entity_ConditionProfileTargetsSummary where ParentEntityTypeId= 7 AND ConnectionTypeId = 7 
	--AND HasTargetCredential= 1 
	group by ParentId
	) c7						on base.Id = c7.ParentId
		
		
	--connections/conditionProfiles - Preparation For
	left join (
	Select ParentId, Count(*) As Nbr from Entity_ConditionProfileTargetsSummary where ParentEntityTypeId= 7 AND ConnectionTypeId = 8 
	--AND HasTargetCredential= 1 
	group by ParentId
	) c8						on base.Id = c8.ParentId

	--connections/conditionProfiles - Preparation From
	left join (
	Select ParentId, Count(*) As Nbr from Entity_ConditionProfileTargetsSummary where ParentEntityTypeId= 7 AND ConnectionTypeId = 9
	AND HasTargetCredential= 1 
	group by ParentId
	) c9						on base.Id = c9.ParentId	

	--why do we have this after the latter?
	left join Entity_ConditionProfilesConnectionsCSV connectionsCsv 
				on connectionsCsv.ParentEntityTypeId = 7 
				AND base.id = connectionsCsv.ParentId
--TODO - Entity_QARolesCSV uses entity_summary (many unions), need to change this
	left join [Entity_QARolesCSV] qaRoles 
				on qaRoles.EntityTypeId = 7 
				AND base.id = qaRoles.BaseId

where base.EntityStateId >= 2
GO
grant select on LearningOpportunity_Summary to public
go



 
/****** Object:  View [dbo].[OccupationProfileSummary]    Script Date: 7/29/2020 11:13:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*
OccupationProfileSummary
Notes
- 
Mods
22-11-08 mparsons - new

*/
Alter VIEW [dbo].[OccupationProfileSummary]
AS
 
SELECT base.[Id]
		,base.[RowId]
		,b.Id as EntityId
		,base.[Name]
		,base.[Description]
		,base.[EntityStateId]
		,base.[CTID]
		,base.[PrimaryAgentUid]
		,isnull(primaryOrg.Id,0)	as PrimaryOrganizationId
		,isnull(primaryOrg.Name,'') as PrimaryOrganizationName
		,isnull(primaryOrg.CTID,'') as PrimaryOrganizationCtid

		,base.[SubjectWebpage]
		,base.[AbilityEmbodied]
		,base.[Classification]
		,base.[CodedNotation]
		,base.[Comment]
		,base.[Identifier]
		,base.[KnowledgeEmbodied]
		,base.[SkillEmbodied]
		,base.[SameAs]
		,base.[VersionIdentifier]
		,base.[JsonProperties]
		,base.[Created]
		,base.[LastUpdated]
		,base.[LifeCycleStatusTypeId]
		,cpv.Title as LifeCycleStatusType
		,(	SELECT ehrs.[Name], ehrs.[Description] 
			FROM [dbo].[Entity.HasResourceSummary] ehrs 
			where ehrs.EntityId = b.Id  and ehrs.EntityTypeId=17
			FOR XML RAW, ROOT('Competencies')
		) Competencies

FROM [dbo].[OccupationProfile] base
INNER JOIN dbo.Entity AS b ON base.RowId = b.EntityUid 
-- join for primary
Left join Organization primaryOrg on base.[PrimaryAgentUid] = primaryOrg.RowId and primaryOrg.EntityStateId > 1
Left Join [Codes.PropertyValue] cpv on base.LifeCycleStatusTypeId = cpv.Id

where base.EntityStateId > 1


GO

grant select on [OccupationProfileSummary] to public
go



/****** Object:  View [dbo].[Occupation_PropertyTotals]    Script Date: 5/31/2020 9:35:03 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


 

 
/****** Object:  View [dbo].[Organization_RecipientRolesCSV]    Script Date: 8/17/2017 2:59:54 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




/*

SELECT [OrganizationId]
      ,[Name]
      ,[OwnedBy]
      ,[OfferedBy]
  FROM [dbo].[Organization_RecipientRolesCSV]
GO



*/

Alter VIEW [dbo].[Organization_RecipientRolesCSV]
AS

SELECT     distinct

c.Id as OrganizationId
,c.Name

    ,CASE
          WHEN AccreditedBy IS NULL THEN ''
          WHEN len(AccreditedBy) = 0 THEN ''
          ELSE left(AccreditedBy,len(AccreditedBy)-1)
    END AS AccreditedBy
		,CASE
          WHEN ApprovedBy IS NULL THEN ''
          WHEN len(ApprovedBy) = 0 THEN ''
          ELSE left(ApprovedBy,len(ApprovedBy)-1)
    END AS ApprovedBy
		,CASE
          WHEN RecognizedBy IS NULL THEN ''
          WHEN len(RecognizedBy) = 0 THEN ''
          ELSE left(RecognizedBy,len(RecognizedBy)-1)
    END AS RecognizedBy
		,CASE
          WHEN RegulatedBy IS NULL THEN ''
          WHEN len(RegulatedBy) = 0 THEN ''
          ELSE left(RegulatedBy,len(RegulatedBy)-1)
    END AS RegulatedBy
		
FROM [dbo].[Entity.AgentRelationship] base
Inner join Entity e on base.EntityId = e.Id
Inner join Organization c on e.EntityUid = c.RowId 

-- get accreditedBy orgs  ====================================================
CROSS APPLY (
    SELECT convert(varchar,e.Id)  + '~ ' + e.Name + ' |'
    FROM dbo.[Entity.AgentRelationship] ear  
		Inner join Organization e on ear.AgentUid = e.RowId 
		inner join [Codes.CredentialAgentRelationship] b on ear.RelationshipTypeId = b.id and b.IsActive = 1

    WHERE base.EntityId = ear.EntityId
		And e.EntityStateId > 1
		And ear.RelationshipTypeId in (1)
    FOR XML Path('') 
) acBy (AccreditedBy)

-- get approvedBy orgs  ====================================================
CROSS APPLY (
    SELECT convert(varchar,e.Id)  + '~ ' + e.Name + ' |'
    FROM dbo.[Entity.AgentRelationship] ear  
		Inner join Organization e on ear.AgentUid = e.RowId 
		inner join [Codes.CredentialAgentRelationship] b on ear.RelationshipTypeId = b.id and b.IsActive = 1

    WHERE base.EntityId = ear.EntityId
		And e.EntityStateId > 1
		And ear.RelationshipTypeId in (7)
    FOR XML Path('') 
) appBy (ApprovedBy)

-- get RecognizedBy orgs  ====================================================
CROSS APPLY (
    SELECT convert(varchar,e.Id)  + '~ ' + e.Name + ' |'
    FROM dbo.[Entity.AgentRelationship] ear  
		Inner join Organization e on ear.AgentUid = e.RowId 
		inner join [Codes.CredentialAgentRelationship] b on ear.RelationshipTypeId = b.id and b.IsActive = 1

    WHERE base.EntityId = ear.EntityId
		And e.EntityStateId > 1
		And ear.RelationshipTypeId in (10)
    FOR XML Path('') 
) rcBy (RecognizedBy)

-- get RegulatedBy orgs  ====================================================
CROSS APPLY (
    SELECT convert(varchar,e.Id)  + '~ ' + e.Name + ' |'
    FROM dbo.[Entity.AgentRelationship] ear  
		Inner join Organization e on ear.AgentUid = e.RowId 
		inner join [Codes.CredentialAgentRelationship] b on ear.RelationshipTypeId = b.id and b.IsActive = 1

    WHERE base.EntityId = ear.EntityId
		And e.EntityStateId > 1
		And ear.RelationshipTypeId in (12)
    FOR XML Path('') 
) rgBy (RegulatedBy)

where (len(AccreditedBy) > 0 OR len(ApprovedBy) > 0  OR len(RecognizedBy) > 0  OR len(RegulatedBy) > 0 )


GO



/****** Object:  View [dbo].[Organization_Summary]    Script Date: 8/16/2017 9:51:51 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
use credFinder
GO
SELECT [Id]
      ,[EntityId]
      ,[Name]
      ,[Description]
      ,[EntityStateId]
      ,[Address1]      ,[Address2]      ,[City]      ,[Region]      ,[PostalCode]      ,[Country]      ,[Latitude]      ,[Longitude]
      ,[SubjectWebpage]
      ,[ImageURL]
      ,[RowId]
      ,[CTID]
      ,[CredentialRegistryId]      ,[cerEnvelopeUrl]
      ,[AvailabilityListing]
      ,[IsAQAOrganization]
      ,[Created]      ,[LastUpdated]
      ,[JsonProperties]
      ,[CredentialCount]
      ,[AssessmentCount]
      ,[LearningOpportunityCount]
      ,[FrameworkCount]
      ,[PathwayCount]
      ,[PathwaySetCount]
      ,[TransferValueCount]
  FROM [dbo].[Organization_Summary]
  where id in (1576) 
GO


where CredentialCount> 0

*/

/*
	Organization Summary

	Mods
	17-02-20 mparsons - added use of ISQAOrganization
	17-10-04 mparsons - need to consider creating an organization_cache
										- this would be useful for address handling as well
	21-04-30 mparsons - the lopps should be owns/offers (others will have to change as well)
						- OR NOT - these counts don't seem to be used.
	23-08-15 mparsons - added additional filter eas.EntityTypeId = 2 with [Entity_AddressSummary]
*/
Alter VIEW [dbo].[Organization_Summary]
AS
SELECT        
	isnull(o.Id, -10) As Id, 
	e.Id as EntityId,
	o.Name, o.Description,
	o.EntityTypeId,
	o.EntityStateId,
	--Address1, Address2, City, Region, PostalCode, Country, o.Latitude, o.Longitude,
	oa.Address1, oa.Address2, oa.City, oa.Region, oa.PostalCode, oa.Country, oa.Latitude, oa.Longitude,
	--need to get from Entity.Reference now!
	--'' as Email, 

	--'' As MainPhoneNumber, 
	o.SubjectWebpage, ImageURL, o.RowId,
	isnull(o.CTID,'') As CTID, 
	o.CredentialRegistryId,
	
	case when len(isnull(o.CredentialRegistryId,'')) = 36 then
	'<a href="http://lr-staging.learningtapestry.com/ce-registry/envelopes/' + o.CredentialRegistryId + '" target="_blank">cerEnvelope</a>'
	else '' End As cerEnvelopeUrl,
	isnull(o.AvailabilityListing,'') As AvailabilityListing, 

	--isnull(orgTypesQA.ServiceCount, 0) As QAServiceCount,
	--case when isnull(orgTypesQA.ServiceCount, 0) > 0 then 1 else 0 end As IsAQAOrganization,
	case 
		when isnull(ISQAOrganization,0) =1 then 1
		when isnull(orgTypesQA.propertyCount, 0) > 0 then 1 
		else 0 end As IsAQAOrganization,

	--isnull(orgMbrs.Total,0) as OrgMbrsCount,
	o.Created, o.LastUpdated
 -- o.CreatedById, o.LastUpdatedById
 	--json stuff in progress
	,o.JsonProperties
	,case when IsNull(o.LifeCycleStatusTypeId,0) > 0 then o.LifeCycleStatusTypeId
	else isnull(statusProperty.PropertyValueId,2648) end As LifeCycleStatusTypeId --default to production value for now

	,case when IsNull(o.LifeCycleStatusTypeId,0) > 0 then cpv.Title
	else isnull(statusProperty.Property,'') end As LifeCycleStatusType --
 	--counts
	,isnull(creds.Owns, 0) As CredentialCount
	,isnull(asmts.Owns, 0) As AssessmentCount
	,isnull(lopps.Owns, 0) As LearningOpportunityCount
	,isnull(frameworks.Owns, 0) As FrameworkCount

	,isnull(pathways.Owns, 0) As PathwayCount
	,isnull(pathwaySets.Owns, 0) As PathwaySetCount
	,isnull(tvps.Owns, 0) As TransferValueCount


FROM            dbo.Organization o
Inner join Entity e on o.RowId = e.EntityUid
left join [codes.PropertyValue] cpv on o.LifeCycleStatusTypeId = cpv.Id
Left Join EntityProperty_Summary	statusProperty on o.RowId = statusProperty.EntityUid and statusProperty.CategoryId = 84

-- 17-10-02 mparsons - may be better to get a count, and retrieve server side as needed?
--20-07-17 mparsons - or store as json on organization and expand as needed for elastic
left join [Entity_AddressSummary] oa on oa.EntityAddressId = (
    select top 1 eas.EntityAddressId from [Entity_AddressSummary] eas
    where eas.EntityBaseId = o.Id and eas.EntityTypeId = 2
    order by eas.Created desc
    --limit 1
)
Left Join (
	select OwningAgentUid, count(*) As Owns from [Credential] 
	where EntityStateId = 3
	group by OwningAgentUid 
	) creds on o.RowId = creds.OwningAgentUid
--Left Join (
--	select AgentUid, count(*) As CredentialCount from [CredentialAgentRelationships_Summary] 
--	where RelationshipTypeId in ( 6)
--	group by AgentUid 
--	) creds on o.RowId = creds.AgentUid

left join (
	select EntityBaseId, count(*) As propertyCount from [dbo].[EntityProperty_Summary] eps 
	where [CategoryId]= 7 and [PropertySchemaName]= 'orgType:QualityAssurance' group by EntityBaseId
	) orgTypesQA on o.Id = orgTypesQA.EntityBaseId
--	
Left Join (
	select OwningAgentUid, count(*) As Owns from Assessment 
	where EntityStateId = 3
	group by OwningAgentUid 
	) asmts on o.RowId = asmts.OwningAgentUid
--	
--21-04-30 chg to include offers - or do we really need this here? Not used in elastic
Left Join (

	select c.AgentUid,  count(*) As Owns from LearningOpportunity a
	inner join Entity b on a.RowId = b.EntityUid
	inner join [Entity.AgentRelationship] c on b.id = c.EntityId
	--inner join Organization d on c.AgentUid = d.RowId
	where a.EntityStateId >= 2 and c.RelationshipTypeId in (6,7)
	--and a.id in (754,756, 757, 687,781)
	group by c.AgentUid 
) lopps on  o.RowId = lopps.AgentUid
--	
--Left Join (
--	select OwningAgentUid, count(*) As Owns from LearningOpportunity 
--	where EntityStateId = 3
--	group by OwningAgentUid 
--	) lopps on o.RowId = lopps.OwningAgentUid


--	
Left Join (
	select OrganizationCTID, count(*) As Owns from CompetencyFramework 
	where EntityStateId = 3
	group by OrganizationCTID 
	) frameworks on o.CTID = frameworks.OrganizationCTID
--	
Left Join (
	select OwningAgentUid, count(*) As Owns from Pathway 
	where EntityStateId = 3
	group by OwningAgentUid 
	) pathways on o.RowId = pathways.OwningAgentUid
--	
Left Join (
	select OwningAgentUid, count(*) As Owns from PathwaySet 
	where EntityStateId = 3
	group by OwningAgentUid 
	) pathwaySets on o.RowId = pathwaySets.OwningAgentUid
--	
Left Join (
	select OwningAgentUid, count(*) As Owns from TransferValueProfile 
	where EntityStateId = 3
	group by OwningAgentUid 
	) tvps on o.RowId = tvps.OwningAgentUid


--Left Join (
--	select ParentOrgId, count(*) As Total from [Organization.Member] 
--	group by ParentOrgId 
--	) orgMbrs on o.Id = orgMbrs.ParentOrgId
--

GO
grant select on [Organization_Summary] to public
go



/****** Object:  View [dbo].[Organization_Summary_export]    Script Date: 8/16/2017 9:51:51 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
use credFinder
GO


SELECT top(1000)
[Id] as FinderId

	,[EntityId]
	,[CTID]
	,[EntityStateId]
	,[Name]
	,[Description]
	,OrganizationClass
	-- ,[EntityTypeId]

	--  ,[LifeCycleStatusTypeId]
	,[LifeCycleStatusType]
	,[OrganizationType]
	,[SectorType]
	,[Address1]
	-- ,[Address2]
	,[City]
	,[Region]
	,[PostalCode]
	,[Country]
	,[Latitude]
	,[Longitude]
	,[SubjectWebpage]
	,[ImageURL]
	--  ,[RowId]
	--  ,[cerEnvelopeUrl]
	,[AvailabilityListing]
	-- ,[IsAQAOrganization]
	,[Created]
	,[LastUpdated]
	,[JsonProperties]

  FROM [dbo].[Organization_Summary_export]

  order by name
GO


GO


where CredentialCount> 0

*/


/****** Object:  View [dbo].[PathwayComponentSummary]    Script Date: 8/26/2020 1:12:02 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
USE [credFinder]
GO
USE [sandbox_credFinder]
GO

SELECT [Id]
      ,[RowId]
      ,[ComponentTypeId]
      ,[PathwayComponentType]
      ,[EntityStateId]
      ,[CTID]
      ,[Name]
      ,[Description]
      ,[SubjectWebpage]
      ,[ProxyFor]
      ,[ProxyForName]
      ,[ProxyForEntityType]
      ,[ProxyForDescription]
      ,[CodedNotation]
      ,[CredentialType]
      ,[ComponentCategory]
      ,[ProgramTerm]
      ,[HasProgressionLevel]
      ,[PathwayCTID]
      ,[Created]
      ,[LastUpdated]
      ,[Properties]
      ,[SourceData]
  FROM [dbo].[PathwayComponentSummary]
    where [ProxyFor]is not null 
GO




*/
Alter VIEW [dbo].[PathwayComponentSummary]
AS

SELECT  a.[Id]
	,a.[RowId]
	,a.[ComponentTypeId]
	,f.Title AS PathwayComponentType
	,a.[EntityStateId]
	,a.[CTID]
	,a.[Name]
	,a.[Description]
	,a.[SubjectWebpage]
	,a.[ProxyFor]
	--NOTE: the following details should already be in the Properties JSON!
	,ec.Name as ProxyForName, ec.EntityType  as ProxyForEntityType, ec.Description as ProxyForDescription
	,a.[CodedNotation]
	,a.[CredentialType]
	,a.[ComponentCategory]
	,a.[ProgramTerm]
	,a.[HasProgressionLevel]
	,a.[PathwayCTID]
	,a.[Created]
	,a.[LastUpdated]
	,a.[Properties]
	,a.[SourceData]
  FROM [dbo].[PathwayComponent] a

  INNER JOIN dbo.Entity AS e ON a.RowId = e.EntityUid
  INNER JOIN dbo.[Codes.PathwayComponentType] AS f ON a.ComponentTypeId = f.Id
  Left join Entity_Cache ec on a.ProxyFor = ec.CTID

--would likely use a CSV
--INNER JOIN dbo.[Entity.HasPathwayComponent] AS ehpc on e.Id = ehpc.EntityId
--INNER JOIN  dbo.[Codes.PathwayComponentRelationship] AS g ON ehpc.ComponentRelationshipTypeId = g.Id
	
where a.EntityStateId > 1
GO

grant select on [PathwayComponentSummary] to public
go




/****** Object:  View [dbo].[PathwaySetSummary]    Script Date: 9/8/2020 2:15:42 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
USE [credFinder]
GO

SELECT [Id]
      ,[RowId]
      ,[CTID]
      ,[Name]
	  ,HasPathwaysCount
      ,[Description]
      ,[EntityStateId]
      ,[SubjectWebpage]
      ,[OwningAgentUid]
      ,[OrganizationId]
      ,[OrganizationName]
      ,[OrganizationCTID]
      ,[CredentialRegistryId]
      ,[EntityLastUpdated]
      ,[Created]
      ,[LastUpdated]
	  ,HasPathways, HasPathways2
  FROM [dbo].[PathwaySetSummary]

GO




*/
Alter VIEW [dbo].[PathwaySetSummary]
AS

SELECT base.[Id]
      ,base.[RowId]
      ,base.[CTID]
      ,base.[Name]
      ,base.[Description]
      ,base.[EntityStateId]
      ,base.[SubjectWebpage]
      ,base.[OwningAgentUid]
	  ,b.Id as OrganizationId
	  ,b.Name      as OrganizationName
	  ,b.CTID as OrganizationCTID
	  ,base.[CredentialRegistryId]
	  ,c.LastUpdated as EntityLastUpdated
      ,base.[Created]
      ,base.[LastUpdated]
	  --
	  ,pathways.cnt as HasPathwaysCount
	  --
	  	,(SELECT DISTINCT a.PathwayId, b.Name as Pathway
		FROM [dbo].[Entity.HasPathway] a Inner Join Pathway b on a.PathwayId = b.Id
		WHERE c.EntityTypeId= 23 AND a.EntityId = c.Id
		FOR XML RAW, ROOT('HasPathways')) HasPathways
	, IsNull(STUFF(
		(	
		SELECT '|' + convert(varchar,a.PathwayId)+'~'+b.Name AS [text()] 
		FROM [dbo].[Entity.HasPathway] a Inner Join Pathway b on a.PathwayId = b.Id
		WHERE c.EntityTypeId= 23 AND a.EntityId = c.Id
		FOR XML Path('')
		), 1,1,''
	),'') as HasPathways2
  FROM [dbo].[PathwaySet] base
Inner join dbo.Organization b on base.OwningAgentUid = b.RowId
INNER JOIN dbo.Entity AS c ON base.RowId = c.EntityUid

left Join (
	Select b.EntityUid, count(*) as cnt 
	from dbo.[Entity.HasPathway] a 
	inner join Entity b on a.EntityId = b.Id 
	group by b.EntityUid) as pathways on base.RowId = pathways.EntityUid
where base.EntityStateId > 1
GO
grant select on [PathwaySetSummary] to public
go
/*
<HasPathways><row PathwayId="186" Pathway="UpSkill! SA Pathway- Skillbooster"/><row PathwayId="187" Pathway="UpSkill! SA Pathway- Certificate +"/></HasPathways>

187~UpSkill! SA Pathway- Certificate +|186~UpSkill! SA Pathway- Skillbooster

*/

/****** Object:  View [dbo].[PathwaySummary]    Script Date: 12/16/2020 1:11:13 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*
USE [credFinder]
GO

SELECT [Id]
      ,[RowId]
      ,[CTID]
      ,[Description]
      ,[EntityStateId]
      ,[SubjectWebpage]
      ,[OwningAgentUid]
      ,[OrganizationId]
      ,[OrganizationName]
      ,[OrganizationCTID]
      ,[CredentialRegistryId]
      ,[EntityLastUpdated]
      ,[Created]
      ,[LastUpdated]
	  ,ResourceDetail
  FROM [dbo].[PathwaySummary]
order by lastupdated desc 
GO




*/
Alter VIEW [dbo].[PathwaySummary]
AS

SELECT base.[Id]
	,base.[RowId]
	,base.[CTID]
	,base.[Name]
	,base.[Description]
	,base.[EntityStateId]
	,base.[SubjectWebpage]
	,IsNull(base.LifeCycleStatusTypeId,0)	as LifeCycleStatusTypeId
	,cpv.Title		as LifeCycleStatusType
	,base.[OwningAgentUid]
	,b.Id as OrganizationId
	,b.Name      as OrganizationName
	,b.CTID as OrganizationCTID
	,base.[CredentialRegistryId]
	,base.hasProgressionModel
	,base.[LatestVersion]
	,base.[PreviousVersion]
	,base.[NextVersion]
	,base.VersionIdentifier
	,base.Properties
	,ec.LastUpdated as EntityLastUpdated
	,base.[Created]	,base.[LastUpdated]
	,ec.ResourceDetail
	  --

  FROM [dbo].[Pathway] base
Left join dbo.Organization b on base.OwningAgentUid = b.RowId
INNER JOIN dbo.Entity_Cache AS ec ON base.RowId = ec.EntityUid
--Left Join EntityProperty_Summary	statusProperty on base.RowId = statusProperty.EntityUid and statusProperty.CategoryId = 84
  left join [codes.PropertyValue] cpv on base.LifeCycleStatusTypeId = cpv.Id

where base.EntityStateId > 1

GO
grant select on [PathwaySummary] to public
go



/****** Object:  View [dbo].[Pathway_PropertyTotals]    Script Date: 5/31/2020 9:35:03 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
--generate totals for columns with data
asn:hasProgressionModel
ceasn:hasChild
ceterms:ctid
ceterms:description
ceterms:hasDestinationComponent
ceterms:industryType
ceterms:keyword
ceterms:name
ceterms:occupationType
ceterms:offeredBy
ceterms:ownedBy
ceterms:subject
ceterms:subjectWebpage

USE [sandbox_credFinder]
GO

SELECT [Total]
      ,[Name]
      ,[Description]
      ,[SubjectWebpage]
      ,[CTID]
      ,[HasDestinationComponent]
      ,[HasChild]
      ,[HasProgressionModel]
      ,[OwnedBy]
      ,[OfferedBy]
      ,[AssessmentComponents]
      ,[BasicComponents]
      ,[CocurricularComponents]
      ,[CompentencyComponents]
      ,[CourseComponents]
      ,[CredentialComponents]
      ,[ExtraCurricularComponents]
      ,[JobComponents]
      ,[WorkExperienceComponents]
      ,[SelectComponents]
      ,[OccupationType]
      ,[IndustryType]
      ,[Subject]
      ,[Keyword]
      ,[DevelopmentProcess]
  FROM [dbo].[Pathway_PropertyTotals]

GO




*/
Alter VIEW [dbo].[Pathway_PropertyTotals]
AS

select 

		sum(case when Len(IsNull(a.Name, '')) > 0 then 1 else 0 end) as Total
		, sum(case when Len(IsNull(a.Name, '')) > 0 then 1 else 0 end) as Name
		, sum(case when Len(IsNull(a.Description, '')) > 0 then 1 else 0 end) as Description
		, sum(case when Len(IsNull(a.SubjectWebpage, '')) > 0 then 1 else 0 end) as SubjectWebpage
		, sum(case when Len(IsNull(a.CTID, '')) > 0 then 1 else 0 end) as CTID
		, sum(case when Len(IsNull(a.LifeCycleStatusType, '')) > 0 then 1 else 0 end) as LifeCycleStatusType

		, sum(case when Len(IsNull(a.VersionIdentifier, '')) > 0 then 1 else 0 end) as VersionIdentifier
		, sum(case when Len(IsNull(a.LatestVersion, '')) > 0 then 1 else 0 end) as LatestVersion
		, sum(case when Len(IsNull(a.PreviousVersion, '')) > 0 then 1 else 0 end) as PreviousVersion
		, sum(case when Len(IsNull(a.NextVersion, '')) > 0 then 1 else 0 end) as NextVersion

		--dest component (should be all)
		,sum(case when IsNull(destComp.ComponentRelationshipTypeId,0) > 0 then 1 else 0 end) HasDestinationComponent
		-- HasChild
		,sum(case when IsNull(hasChild.ComponentRelationshipTypeId,0) > 0 then 1 else 0 end) HasChild

		--
		, sum(case when Len(IsNull(a.hasProgressionModel, '')) > 0 then 1 else 0 end) as HasProgressionModel
		-- BYs
		,sum(case when IsNull(ownedBy.RelationshipTypeId,0) > 0 then 1 else 0 end)		OwnedBy
		,sum(case when IsNull(offeredBy.RelationshipTypeId,0) > 0 then 1 else 0 end)	OfferedBy
		---- components
		,sum(case when IsNull(asmtComponent.ComponentTypeId,0) > 0 then 1 else 0 end) AssessmentComponents
		,sum(case when IsNull(basicComponent.ComponentTypeId,0) > 0 then 1 else 0 end) BasicComponents
		,sum(case when IsNull(cocurricularComponent.ComponentTypeId,0) > 0 then 1 else 0 end) CocurricularComponents
		,sum(case when IsNull(competencyComponent.ComponentTypeId,0) > 0 then 1 else 0 end) CompentencyComponents
		,sum(case when IsNull(courseComponent.ComponentTypeId,0) > 0 then 1 else 0 end) CourseComponents
		,sum(case when IsNull(credentialComponent.ComponentTypeId,0) > 0 then 1 else 0 end) CredentialComponents
		,sum(case when IsNull(extraCurricularComponent.ComponentTypeId,0) > 0 then 1 else 0 end) ExtraCurricularComponents
		,sum(case when IsNull(jobComponent.ComponentTypeId,0) > 0 then 1 else 0 end) JobComponents
		,sum(case when IsNull(workExpComponent.ComponentTypeId,0) > 0 then 1 else 0 end) WorkExperienceComponents
		--,sum(case when IsNull(selectComponent.ComponentTypeId,0) > 0 then 1 else 0 end) SelectComponents
		,sum(case when IsNull(multiComponent.ComponentTypeId,0) > 0 then 1 else 0 end) MultiComponents
		,sum(case when IsNull(collectionComponent.ComponentTypeId,0) > 0 then 1 else 0 end) CollectionComponents
		---- 
		,sum(case when IsNull(occ.CategoryId,0) > 0 then 1 else 0 end) OccupationType			--##
		,sum(case when IsNull(ind.CategoryId,0) > 0 then 1 else 0 end) IndustryType			--##		
		,sum(case when IsNull(prg.CategoryId,0) > 0 then 1 else 0 end) ProgramType			--##

		----general
		,sum(case when IsNull(subjects.EntityBaseId,0) > 0 then 1 else 0 end) Subject
		,sum(case when IsNull(keywords.EntityBaseId,0) > 0 then 1 else 0 end) Keyword
		-- Process Profiles --------------------------------------------------------------
		,sum(case when IsNull(devProfile.EntityBaseId,0)	> 0 then 1 else 0 end) DevelopmentProcess

	-- ========================================================
	--select count(*)
  from PathwaySummary a
  inner join entity b on a.RowId = b.EntityUid
--
   left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  ComponentRelationshipTypeId  FROM dbo.[Entity.HasPathwayComponent] inner join entity on EntityId = entity.Id where entity.EntityTypeId=8 and ComponentRelationshipTypeId=1
  ) destComp on a.Id = destComp.EntityBaseId
   left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  ComponentRelationshipTypeId  FROM dbo.[Entity.HasPathwayComponent] inner join entity on EntityId = entity.Id where entity.EntityTypeId=8 and ComponentRelationshipTypeId=3
  ) hasChild on a.Id = destComp.EntityBaseId

  --combine owns/offers =========================================================
   left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  RelationshipTypeId  FROM dbo.[Entity.AgentRelationship] inner join entity on EntityId = entity.Id where entity.EntityTypeId=8 and RelationshipTypeId=6
  ) ownedBy on a.Id = ownedBy.EntityBaseId

  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  RelationshipTypeId  FROM dbo.[Entity.AgentRelationship] inner join entity on EntityId = entity.Id where entity.EntityTypeId=8 and RelationshipTypeId=7
  ) offeredBy on a.Id = offeredBy.EntityBaseId
  left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM dbo.[Entity_ReferenceFramework_Summary]
	  where EntityTypeId=8 and [CategoryId] = 11
  ) occ on a.Id = occ.EntityBaseId
  left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM dbo.[Entity_ReferenceFramework_Summary]
	  where EntityTypeId=8 and [CategoryId] = 10
  ) ind on a.Id = ind.EntityBaseId
  left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM dbo.[Entity_ReferenceFramework_Summary]
	  where EntityTypeId=8 and [CategoryId] = 23
  ) prg on a.Id = ind.EntityBaseId
-- 
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.Reference] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=8 and [CategoryId] = 34
	  and Len(IsNull(a.TextValue,'')) > 0
  ) subjects on a.Id = subjects.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.Reference] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=8 and [CategoryId] = 35
	  and Len(IsNull(a.TextValue,'')) > 0
  ) keywords on a.Id = keywords.EntityBaseId
-- pathway component types
  left join (
	  SELECT distinct  a.PathwayCTID, a.ComponentTypeId   FROM [PathwayComponent] a where a.ComponentTypeId=1 
  ) asmtComponent on a.CTID = asmtComponent.PathwayCTID
  left join (
	  SELECT distinct  a.PathwayCTID, a.ComponentTypeId   FROM [PathwayComponent] a where a.ComponentTypeId=2 
  ) basicComponent on a.CTID = basicComponent.PathwayCTID
  left join (
	  SELECT distinct  a.PathwayCTID, a.ComponentTypeId   FROM [PathwayComponent] a where a.ComponentTypeId=3 
  ) cocurricularComponent on a.CTID = cocurricularComponent.PathwayCTID
  left join (
	  SELECT distinct  a.PathwayCTID, a.ComponentTypeId   FROM [PathwayComponent] a where a.ComponentTypeId=4 
  ) competencyComponent on a.CTID = competencyComponent.PathwayCTID
  left join (
	  SELECT distinct  a.PathwayCTID, a.ComponentTypeId   FROM [PathwayComponent] a where a.ComponentTypeId=5 
  ) courseComponent on a.CTID = courseComponent.PathwayCTID
  left join (
	  SELECT distinct  a.PathwayCTID, a.ComponentTypeId   FROM [PathwayComponent] a where a.ComponentTypeId=6 
  ) credentialComponent on a.CTID = credentialComponent.PathwayCTID
  left join (
	  SELECT distinct  a.PathwayCTID, a.ComponentTypeId   FROM [PathwayComponent] a where a.ComponentTypeId=7 
  ) extraCurricularComponent on a.CTID = extraCurricularComponent.PathwayCTID
  left join (
	  SELECT distinct  a.PathwayCTID, a.ComponentTypeId   FROM [PathwayComponent] a where a.ComponentTypeId=8 
  ) jobComponent on a.CTID = jobComponent.PathwayCTID
  left join (
	  SELECT distinct  a.PathwayCTID, a.ComponentTypeId   FROM [PathwayComponent] a where a.ComponentTypeId=9 
  ) workExpComponent on a.CTID = workExpComponent.PathwayCTID
  --left join (
	 -- SELECT distinct  a.PathwayCTID, a.ComponentTypeId   FROM [PathwayComponent] a where a.ComponentTypeId=10 
  --) selectComponent on a.CTID = selectComponent.PathwayCTID
  left join (
	  SELECT distinct  a.PathwayCTID, a.ComponentTypeId   FROM [PathwayComponent] a where a.ComponentTypeId=12 
  ) multiComponent on a.CTID = multiComponent.PathwayCTID
  left join (
	  SELECT distinct  a.PathwayCTID, a.ComponentTypeId   FROM [PathwayComponent] a where a.ComponentTypeId=13 
  ) collectionComponent on a.CTID = collectionComponent.PathwayCTID
-- Process profiles---------------------------------------------------------------------
  --2-dev
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ProcessProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=8 and a.ProcessTypeId=2 
  ) devProfile on a.Id = devProfile.EntityBaseId
 
--======================
where a.EntityStateId = 3 
GO




/****** Object:  View [dbo].[ProgressionModelSummary]    Script Date: 8/24/2020 2:51:11 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*

USE [sandbox_credFinder]
GO

SELECT [Id]
      ,[EntityStateId]
      ,[Name]
      ,[CTID]
      ,[Description]
      ,[EntityId]
      ,[EntityLastUpdated]
      ,[OrganizationId]
      ,[OrganizationName]
      ,[OrganizationCTID]
      ,[OwningAgentUid]
      ,[Source]
      ,[PublicationStatusType]
      ,[CredentialRegistryId]
      ,[Created]
      ,[LastUpdated]
      ,[RowId]
  FROM [dbo].[ProgressionModelSummary]

GO



========================================================
23-07-17 mparsons - added 

*/
Alter VIEW [dbo].[ProgressionModelSummary]
AS

SELECT base.[Id]
	,base.EntityStateId
	,base.[Name]
	,isnull(base.CTID,'') As CTID 
	,base.[Description]
	,e.id as EntityId
	,e.LastUpdated as EntityLastUpdated
	,base.OrganizationId
	--owning org
	,owningOrg.Name as OrganizationName
	,owningOrg.ctid as OrganizationCTID
	,owningOrg.RowId as OwningAgentUid
	--

	,base.Source
	,base.PublicationStatusType
	,isnull(base.CredentialRegistryId,'') As CredentialRegistryId	

	,base.[Created]
	,base.[LastUpdated]
	,base.RowId
	--=====================================
	
  FROM [dbo].ProgressionModel base
  inner join Entity e on base.RowId = e.EntityUid
-- join for owner
	Left join Organization owningOrg on base.OrganizationId = owningOrg.Id

where  base.EntityStateId = 3

GO
grant select on [ProgressionModelSummary] to public
go

/****** Object:  View [dbo].[RubricSummary]    Script Date: 3/4/2024 8:39:02 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



/*
USE [credFinder]
GO
USE [sandbox_credFinder]
GO

SELECT base.[Id]
      ,base.[RowId]
      ,base.[Name]
      ,base.[Description]
      ,base.[EntityStateId]
      ,base.[CTID]
	        ,base.[PrimaryAgentUid]
      ,base.[PrimaryOrganizationId]
      ,base.[PrimaryOrganizationName]
      ,base.[PrimaryOrganizationCtid]
      ,base.[AbilityEmbodied]
      ,base.[Classification]
      ,base.[CodedNotation]
      ,base.[Comment]
      ,base.[Identifier]
      ,base.[KnowledgeEmbodied]
      ,base.[SkillEmbodied]
   
      ,base.[VersionIdentifier]
      ,base.[JsonProperties]
      ,base.[Created]
      ,base.[LastUpdated]
  FROM [dbo].[RubricSummary] a

*/
/*
RubricSummary
Notes
- 
Mods
22-11-08 mparsons - new

*/
CREATE VIEW [dbo].[RubricSummary]
AS
 
SELECT base.[Id]
      ,base.[RowId]
	  	,e.Id as EntityId

      ,base.[Name]
      ,base.[Description]
      ,base.[EntityStateId]
      ,base.[CTID]
		,base.[PrimaryAgentUid]
		,isnull(primaryOrg.Id,0)	as PrimaryOrganizationId
		,isnull(primaryOrg.Name,'') as PrimaryOrganizationName
		,isnull(primaryOrg.CTID,'') as PrimaryOrganizationCtid
		,base.[SubjectWebpage]
		,IsNull(RubricCriterion.total, 0) as RubricCriterionCount
		,IsNUll(RubricLevel.total,0) as RubricLevelCount
      ,base.[Creator]
      ,base.[AltCodedNotation]
      ,base.[CodedNotation]
      ,base.[ConceptKeyword]
      ,base.[DateCopyrighted]
      ,base.[DateCreated]
      ,base.[DateModified]
      ,base.[DateValidFrom]
      ,base.[DateValidUntil]
      ,base.[DerivedFrom]
      ,base.[Identifier]
      ,base.[InLanguage]
      ,base.[LatestVersion]
      ,base.[PreviousVersion]
      ,base.[NextVersion]
      ,base.[License]
      ,base.[LifeCycleStatusTypeId]
	  ,cpv.Title as LifeCycleStatusType
     -- ,base.[PublicationStatusType]
      ,base.[Publisher]
      ,base.[PublisherName]
      ,base.[Rights]
      ,base.[Subject]
      ,base.[VersionIdentifier]
      ,base.[Created]
      ,base.[LastUpdated]
      ,base.[JsonProperties]

--
  FROM [dbo].[Rubric] base

INNER JOIN dbo.Entity AS e ON base.RowId = e.EntityUid 
Left Join [Codes.PropertyValue] cpv on base.LifeCycleStatusTypeId = cpv.Id
-- join for primary
	Left join Organization primaryOrg on base.[PrimaryAgentUid] = primaryOrg.RowId and primaryOrg.EntityStateId > 1
Left Join (Select RubricId, count(*) as total from RubricCriterion group by RubricId) as RubricCriterion on base.Id = RubricCriterion.RubricId
Left Join (Select RubricId, count(*) as total from RubricLevel group by RubricId) as RubricLevel on base.Id = RubricLevel.RubricId

where base.EntityStateId > 1

GO
grant select on [RubricSummary] to public
go



/****** Object:  View [dbo].[Rubric_PropertyTotals]    Script Date: 5/31/2020 9:35:03 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/****** Object:  View [dbo].[ScheduledOfferingSummary]    Script Date: 7/29/2020 11:13:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*
USE [credFinder]
GO
USE [sandbox_credFinder]
GO

SELECT [Id]
      ,[RowId]
      ,[EntityStateId]
      ,[Name]
      ,[Description]
      ,[SubjectWebpage]
      ,[CTID]
      ,[OwningAgentUid]
      ,[OrganizationCTID]
      ,[OrganizationId]
      ,[OrganizationName]
      ,[HasTransferValueProfiles]
      ,[CredentialRegistryId]
      ,[CodedNotation]
      ,[CreditValueJson]
      ,[IntermediaryForJson]
      ,[Subject]
      ,[Created]
      ,[LastUpdated]
  FROM [dbo].[ScheduledOfferingSummary]

GO



GO


*/
/*
ScheduledOfferingSummary
Notes
- 
Mods
23-04-05 mparsons - new


*/
Alter VIEW [dbo].[ScheduledOfferingSummary]
AS


SELECT  base.[Id]
		,e.Id as EntityId
		,base.[RowId]
		,base.[CTID]
		,base.[EntityStateId]
		,base.[Name]
		,base.[Description]
		,base.[OfferedBy]
		,base.[SubjectWebpage]
		,base.[DeliveryTypeDescription]
		,base.[AvailableOnlineAt]
		,base.[AvailabilityListing]
		,base.[AlternateName]
		,base.[Created]
		,base.[LastUpdated]

		,isnull(b.ctid,'')  as OrganizationCTID
		,b.Id as OrganizationId
		,b.Name as OrganizationName
	--
		,IsNull(aggregateDataProfile.Nbr,0) As AggregateDataProfileCount
--
  FROM [dbo].[ScheduledOffering] base

INNER JOIN dbo.Entity AS e ON base.RowId = e.EntityUid 
LEFT  JOIN dbo.Organization AS b ON base.[OfferedBy] = b.RowId

--=========
left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.AggregateDataProfile] a Inner join Entity b ON a.EntityId = b.Id Where b.EntityTypeId = 15  Group By b.EntityBaseId
		) aggregateDataProfile	on base.Id = aggregateDataProfile.EntityBaseId 
where base.EntityStateId > 1
GO

grant select on [ScheduledOfferingSummary] to public
go



/****** Object:  View [dbo].[TaskProfileSummary]    Script Date: 7/29/2020 11:13:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*
USE [credFinder]
GO
USE [sandbox_credFinder]
GO

SELECT base.[Id]
      ,base.[RowId]
      ,base.[Name]
      ,base.[Description]
      ,base.[EntityStateId]
      ,base.[CTID]
	        ,base.[PrimaryAgentUid]
      ,base.[PrimaryOrganizationId]
      ,base.[PrimaryOrganizationName]
      ,base.[PrimaryOrganizationCtid]
      ,base.[AbilityEmbodied]
      ,base.[Classification]
      ,base.[CodedNotation]
      ,base.[Comment]
      ,base.[Identifier]
      ,base.[KnowledgeEmbodied]
      ,base.[SkillEmbodied]
   
      ,base.[VersionIdentifier]
      ,base.[JsonProperties]
      ,base.[Created]
      ,base.[LastUpdated]
  FROM [dbo].[TaskProfileSummary] a

*/
/*
TaskProfileSummary
Notes
- 
Mods
22-11-08 mparsons - new

*/
Alter VIEW [dbo].[TaskProfileSummary]
AS
 
SELECT base.[Id]
      ,base.[RowId]
	  ,b.Id as EntityId
      ,base.[Name]
      ,base.[Description]
      ,base.[EntityStateId]
		,base.[CTID]
		,base.[PrimaryAgentUid]
		,isnull(primaryOrg.Id,0)	as PrimaryOrganizationId
		,isnull(primaryOrg.Name,'') as PrimaryOrganizationName
		,isnull(primaryOrg.CTID,'') as PrimaryOrganizationCtid

      ,base.[AbilityEmbodied]
      ,base.[Classification]
      ,base.[CodedNotation]
      ,base.[Comment]
      ,base.[Identifier]
      ,base.[KnowledgeEmbodied]
      ,base.[SkillEmbodied]

      ,base.[VersionIdentifier]
      ,base.[JsonProperties]
      ,base.[Created]
      ,base.[LastUpdated]
	   ,base.[LifeCycleStatusTypeId]
	  ,cpv.Title as LifeCycleStatusType
	  ,(SELECT ehrs.[Name], ehrs.[Description] FROM [dbo].[Entity.HasResourceSummary] ehrs 
		where ehrs.EntityId = b.Id  and ehrs.EntityTypeId=17
		FOR XML RAW, ROOT('Competencies')) Competencies

--
  FROM [dbo].[TaskProfile] base

INNER JOIN dbo.Entity AS b ON base.RowId = b.EntityUid 
-- join for primary
	Left join Organization primaryOrg on base.[PrimaryAgentUid] = primaryOrg.RowId and primaryOrg.EntityStateId > 1
	Left Join [Codes.PropertyValue] cpv on base.LifeCycleStatusTypeId = cpv.Id

where base.EntityStateId > 1



GO

grant select on [TaskProfileSummary] to public
go





/****** Object:  View [dbo].[TransferIntermediarySummary]    Script Date: 7/29/2020 11:13:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*
USE [credFinder]
GO
USE [sandbox_credFinder]
GO

SELECT [Id]
      ,[RowId]
      ,[EntityStateId]
      ,[Name]
      ,[Description]
      ,[SubjectWebpage]
      ,[CTID]
      ,[OwningAgentUid]
      ,[OrganizationCTID]
      ,[OrganizationId]
      ,[OrganizationName]
      ,[HasTransferValueProfiles]
      ,[CredentialRegistryId]
      ,[CodedNotation]
      ,[CreditValueJson]
      ,[IntermediaryForJson]
      ,[Subject]
      ,[Created]
      ,[LastUpdated]
  FROM [dbo].[TransferIntermediarySummary]

GO



GO


*/
/*
TransferIntermediarySummary
Notes
- 
Mods
22-01-27 mparsons - added
22-02-12 mparsons - added TVP totals

*/
Alter VIEW [dbo].[TransferIntermediarySummary]
AS


SELECT 
	base.[Id]
	,base.[RowId]
	,e.Id as EntityId
	,base.[EntityStateId]
	,base.[Name]
	,base.[Description]
	,base.[SubjectWebpage]
	,base.[CTID]
	--
	,base.[OwningAgentUid]
	,isnull(b.ctid,'')  as OrganizationCTID
	,b.Id as OrganizationId
	,b.Name as OrganizationName
	--
	,IsNull(tvp.total,0) as HasTransferValueProfiles
	--TBD
	,base.[CredentialRegistryId]
	,base.[CodedNotation]
	,base.[CreditValueJson]
	,base.[IntermediaryForJson]
	,base.[Subject]
	,base.[Created]
	,base.[LastUpdated]
	--

	
--
  FROM [dbo].[TransferIntermediary] base

INNER JOIN dbo.Entity AS e ON base.RowId = e.EntityUid 
LEFT  JOIN dbo.Organization AS b ON base.OwningAgentUid = b.RowId


--================================
Left Join (
	SELECT [TransferIntermediaryId] ,Count(*)  as total
  FROM [dbo].[TransferIntermediary.TransferValue]
  group by [TransferIntermediaryId]
	) tvp on base.Id = tvp.[TransferIntermediaryId]
--
where base.EntityStateId > 1

GO

grant select on [TransferIntermediarySummary] to public
go




/****** Object:  View [dbo].[TransferValueProfileSummary]    Script Date: 7/29/2020 11:13:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*
USE [credFinder]
GO


SELECT [Id]
      ,[EntityStateId]
      ,[Name]
      ,[Description]
      ,[SubjectWebpage]
      ,[OwningAgentUid]
      ,[OrganizationId]
      ,[OrganizationName]
      ,[OrganizationCTID]
      ,[LifecycleStatusType]
      ,[CredentialRegistryId]
      ,[StartDate]
      ,[EndDate]
      ,[CodedNotation]
      ,[IdentifierJson]
	  ,TransferIntermediariesFor
      ,[TransferValueJson]
      ,[TransferValueForJson]
      ,[TransferValueFromJson]
      ,[Created]
      ,[LastUpdated]
      ,[TransferValueForCredentialsCount]
      ,[TransferValueFromCredentialsCount]
      ,[TransferValueForAssessmentsCount]
      ,[TransferValueFromAssessmentsCount]
      ,[TransferValueForLoppsCount]
      ,[TransferValueFromLoppsCount]
  ,TransferValueHasDevProcessCount
  FROM [dbo].[TransferValueProfileSummary]
  order by lastupdated desc 
GO


*/
/*
TransferValueProfileSummary
Notes
- eventually will use a full join to organization
Mods
21-06-01 mparsons - add list of credentials for and from.
					- not sure if we really only need counts - especially where we will eventually need to add asmts, and lopps.
22-10-08 mparsons - add TransferIntermediariesFor
*/
ALTER VIEW [dbo].[TransferValueProfileSummary]
AS
SELECT        
	base.Id, 
	base.RowId,
	tvpEntity.Id as EntityId,

	base.CTID,
	base.EntityStateId, 
	base.Name, 
	base.Description, 
	base.SubjectWebpage, 
	base.OwningAgentUid, 
	b.Id AS OrganizationId, 
	b.Name AS OrganizationName, 
	b.CTID AS OrganizationCTID
	,case when IsNull(base.LifeCycleStatusTypeId,0) > 0 then base.LifeCycleStatusTypeId
	else 2648 end As LifeCycleStatusTypeId --default to production value for now

	,case when IsNull(base.LifeCycleStatusTypeId,0) > 0 then cpv.Title
	else 'Active' end As LifeCycleStatusType ,
	base.CredentialRegistryId, 
	base.StartDate,  base.EndDate, 
	base.CodedNotation, 
	base.IdentifierJson, 
	base.TransferValueJson, 
	base.TransferValueForJson, 
	base.TransferValueFromJson, 
	base.Created, base.LastUpdated
	-- list where in transfer intermediary
	--,isnull(TransferIntermediariesFor, '') as TransferIntermediariesFor
	--OR
		--collection member
 	, (SELECT titv.TransferIntermediaryId  FROM [dbo].[TransferIntermediary.TransferValue] titv where titv.TransferValueProfileId = base.Id
		FOR XML RAW, ROOT('TransferIntermediariesFor')
	) TransferIntermediariesFor

	--do we really only need a count?
	,isnull(tvForCredentials.total,0) as TransferValueForCredentialsCount
	,isnull(tvFromCredentials.total,0) as TransferValueFromCredentialsCount
	--
	,isnull(tvForAssessments.total,0) as TransferValueForAssessmentsCount
	,isnull(tvFromAssessments.total,0) as TransferValueFromAssessmentsCount
	--
	,isnull(tvForLopps.total,0) as TransferValueForLoppsCount
	,isnull(tvFromLopps.total,0) as TransferValueFromLoppsCount
	--
	,isnull(tvHasDevProcess.total,0) as TransferValueHasDevProcessCount

	--the cross applies will be expensive later
	--, CASE
	--	WHEN CredentialsFor IS NULL THEN ''
	--	WHEN len(CredentialsFor) = 0 THEN ''
	--	ELSE left(CredentialsFor,len(CredentialsFor)-1)
	--END AS CredentialsFor
	--, CASE
	--	WHEN CredentialsFrom IS NULL THEN ''
	--	WHEN len(CredentialsFrom) = 0 THEN ''
	--	ELSE left(CredentialsFrom,len(CredentialsFrom)-1)
	--END AS CredentialsFrom

FROM            dbo.TransferValueProfile base 
INNER JOIN dbo.Entity AS tvpEntity ON base.RowId = tvpEntity.EntityUid 
left join [codes.PropertyValue] cpv on base.LifeCycleStatusTypeId = cpv.Id
LEFT  JOIN dbo.Organization AS b ON base.OwningAgentUid = b.RowId
--

--CROSS APPLY (
--	SELECT 
--		convert(varchar,titv.TransferIntermediaryId)  + ', '
--	FROM dbo.[TransferIntermediary.TransferValue] titv
--	WHERE titv.TransferValueProfileId = base.Id
--	FOR XML Path('') 
--) tiFor (TransferIntermediariesFor)
--===============
Left Join (
	SELECT caecFor.EntityId, COUNT(*) as total
	FROM dbo.[Entity.Credential] caecFor
	INNER JOIN dbo.Entity caecForEntity ON caecFor.EntityId = caecForEntity.Id 
	WHERE caecFor.RelationshipTypeId = 1 
	group by caecFor.EntityId
	) tvForCredentials on tvpEntity.Id = tvForCredentials.EntityId
--
Left Join (
	SELECT caecFor.EntityId, COUNT(*) as total
	FROM dbo.[Entity.Credential] caecFor
	INNER JOIN dbo.Entity caecForEntity ON caecFor.EntityId = caecForEntity.Id 
	WHERE caecFor.RelationshipTypeId = 2
	group by caecFor.EntityId
	) tvFromCredentials on tvpEntity.Id = tvFromCredentials.EntityId
--===============

Left Join (
	SELECT caecFor.EntityId, COUNT(*) as total
	FROM dbo.[Entity.Assessment] caecFor
	INNER JOIN dbo.Entity caecForEntity ON caecFor.EntityId = caecForEntity.Id 
	WHERE caecFor.RelationshipTypeId = 1 
	group by caecFor.EntityId
	) tvForAssessments on tvpEntity.Id = tvForAssessments.EntityId
--
Left Join (
	SELECT caecFor.EntityId, COUNT(*) as total
	FROM dbo.[Entity.Assessment] caecFor
	INNER JOIN dbo.Entity caecForEntity ON caecFor.EntityId = caecForEntity.Id 
	WHERE caecFor.RelationshipTypeId = 2
	group by caecFor.EntityId
	) tvFromAssessments on tvpEntity.Id = tvFromAssessments.EntityId
--===============

Left Join (
	SELECT caecFor.EntityId, COUNT(*) as total
	FROM dbo.[Entity.LearningOpportunity] caecFor
	INNER JOIN dbo.Entity caecForEntity ON caecFor.EntityId = caecForEntity.Id 
	WHERE caecFor.RelationshipTypeId = 1 
	group by caecFor.EntityId
	) tvForLopps on tvpEntity.Id = tvForLopps.EntityId
--
Left Join (
	SELECT caecFor.EntityId, COUNT(*) as total
	FROM dbo.[Entity.LearningOpportunity] caecFor
	INNER JOIN dbo.Entity caecForEntity ON caecFor.EntityId = caecForEntity.Id 
	WHERE caecFor.RelationshipTypeId = 2
	group by caecFor.EntityId
	) tvFromLopps on tvpEntity.Id = tvFromLopps.EntityId
--===============

Left Join (
	SELECT epp.EntityId, COUNT(*) as total
	FROM dbo.[Entity.ProcessProfile] epp
	INNER JOIN dbo.Entity e ON epp.EntityId = e.Id 
	group by epp.EntityId
	) tvHasDevProcess on tvpEntity.Id = tvHasDevProcess.EntityId
--=== how to distinguish FOR and FROM
--For = RelationshipTypeId = 1
--from = RelationshipTypeId = 2

--CROSS APPLY (
--	SELECT 
--		convert(varchar,caecFor.CredentialId) + '~ ' + convert(varchar,cacFor.Name) + ', '
--	FROM dbo.[Entity.Credential] caecFor
--	Inner Join Credential cacFor on caecFor.credentialId = cacFor.Id
--	INNER JOIN dbo.Entity caecForEntity ON caecFor.EntityId = caecForEntity.Id 
--	WHERE caecFor.RelationshipTypeId = 1 AND (base.EntityStateId = 3) 
--	AND tvpEntity.Id = caecFor.EntityId
--	FOR XML Path('') 
--) credsFor (CredentialsFor)

--CROSS APPLY (
--	SELECT 
--		convert(varchar,caecFrom.CredentialId) + '~ ' + convert(varchar,cacFrom.Name) + ', '
--	FROM dbo.[Entity.Credential] caecFrom
--	Inner Join Credential cacFrom on caecFrom.credentialId = cacFrom.Id
--	INNER JOIN dbo.Entity cae ON caecFrom.EntityId = cae.Id 
--	WHERE caecFrom.RelationshipTypeId = 2 AND (base.EntityStateId = 3) 
--	AND tvpEntity.Id = caecFrom.EntityId
--	FOR XML Path('') 
--) credsFrom (CredentialsFrom)

where base.EntityStateId > 1
GO

grant select on [TransferValueProfileSummary] to public
go





/****** Object:  View [dbo].[WorkRoleProfileSummary]    Script Date: 7/29/2020 11:13:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*
USE [credFinder]
GO
USE [sandbox_credFinder]
GO

SELECT base.[Id]
      ,base.[RowId]
      ,base.[Name]
      ,base.[Description]
      ,base.[EntityStateId]
      ,base.[CTID]
	        ,base.[PrimaryAgentUid]
      ,base.[PrimaryOrganizationId]
      ,base.[PrimaryOrganizationName]
      ,base.[PrimaryOrganizationCtid]
      ,base.[AbilityEmbodied]
      ,base.[Classification]
      ,base.[CodedNotation]
      ,base.[Comment]
      ,base.[Identifier]
      ,base.[KnowledgeEmbodied]
      ,base.[SkillEmbodied]
   
      ,base.[VersionIdentifier]
      ,base.[JsonProperties]
      ,base.[Created]
      ,base.[LastUpdated]
  FROM [dbo].[WorkRoleProfileSummary] a

*/
/*
WorkRoleProfileSummary
Notes
- 
Mods
22-11-08 mparsons - new

*/
Alter VIEW [dbo].[WorkRoleProfileSummary]
AS
 
SELECT base.[Id]
      ,base.[RowId]
	  	,e.Id as EntityId

      ,base.[Name]
      ,base.[Description]
      ,base.[EntityStateId]
      ,base.[CTID]
		,base.[PrimaryAgentUid]
		,isnull(primaryOrg.Id,0)	as PrimaryOrganizationId
		,isnull(primaryOrg.Name,'') as PrimaryOrganizationName
		,isnull(primaryOrg.CTID,'') as PrimaryOrganizationCtid
      ,base.[AbilityEmbodied]
      ,base.[Classification]
      ,base.[CodedNotation]
      ,base.[Comment]
      ,base.[Identifier]
      ,base.[KnowledgeEmbodied]
      ,base.[SkillEmbodied]

      ,base.[VersionIdentifier]
      ,base.[JsonProperties]
      ,base.[Created]
      ,base.[LastUpdated]
	  ,base.[LifeCycleStatusTypeId]
	  ,cpv.Title as LifeCycleStatusType
	  ,(SELECT ehrs.[Name], ehrs.[Description] FROM [dbo].[Entity.HasResourceSummary] ehrs 
		where ehrs.EntityId = e.Id  and ehrs.EntityTypeId=17
		FOR XML RAW, ROOT('Competencies')) Competencies

--
  FROM [dbo].[WorkRole] base

INNER JOIN dbo.Entity AS e ON base.RowId = e.EntityUid 
-- join for primary
	Left join Organization primaryOrg on base.[PrimaryAgentUid] = primaryOrg.RowId and primaryOrg.EntityStateId > 1
	Left Join [Codes.PropertyValue] cpv on base.LifeCycleStatusTypeId = cpv.Id


where base.EntityStateId > 1


GO

grant select on [WorkRoleProfileSummary] to public
go


