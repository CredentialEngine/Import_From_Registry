use credFinder
GO

/****** Object:  View [dbo].[LearningOpportunity_Parts_Summary]    Script Date: 10/6/2017 4:37:59 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*


SELECT [LearningOpportunityId]
      ,[LearningOpportunity]
      ,[LearningOpportunityIdRowId]
      ,[LO_partId]
      ,[LO_partRowId]
      ,[LO_part]
      ,[LO_part_Description]
      ,[LO_partStatusId]
      ,[LO_part_ManagingOrgId]
  FROM [dbo].[LearningOpportunity_Parts_Summary]
GO

*/
CREATE VIEW [dbo].[LearningOpportunity_Parts_Summary]
AS
  /*
		LearningOpportunity
			ENTITY
					entity.LearningOpp
						LearningOpportunity (rowId)

	*/
SELECT        
	base.Id				AS LearningOpportunityId, 
	base.Name			AS LearningOpportunity, 
	base.RowId		AS LearningOpportunityRowId,
	pe.Id as ParentLearningOppEntityId, 
	LO_part.Id		AS [LearningOpportunity_PartId], 
	LO_part.RowId AS [LearningOpportunity_PartRowId], 
	LO_part.Name	AS [LearningOpportunity_Part], 
	LO_part.Description AS [LearningOpportunity_Part_Description], 

	cEntity.Id as LO_PartEntityId

FROM dbo.LearningOpportunity base
INNER JOIN dbo.Entity pe
			ON base.RowId = pe.EntityUid 
INNER JOIN dbo.[Entity.LearningOpportunity] elo
			ON pe.Id = elo.EntityId 
INNER JOIN dbo.LearningOpportunity AS LO_part 
			ON elo.LearningOpportunityId = LO_part.Id
INNER JOIN dbo.Entity cEntity
			ON LO_part.RowId = cEntity.EntityUid 

GO

grant select on [LearningOpportunity_Parts_Summary] to public
go