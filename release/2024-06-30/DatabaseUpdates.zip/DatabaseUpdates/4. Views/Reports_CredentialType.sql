use credfinder
go


use sandbox_credFinder
go

--use staging_credFinder
--go
--use flstaging_credFinder
--go

 -- change CE_Accounts.dbo.Organization to sandbox_CE_Accounts.dbo.Organization

--use staging_credFinder
--go
 -- change CE_Accounts.dbo.Organization to staging_CE_Accounts.dbo.Organization


 /*
 NOTE: Change the CE-Account reference for each env 

 Modifications 
 23-11-01 mparsons - there were inconsistencies using [Import.PendingRequest] for third party filtering.
					Changed to use Entity.AgentRelationship to be consistent
					- ***Also no longer need to refer to Accounts views***
 */
 Alter View Reports_CredentialType
 as 
select distinct
	c.Name,
	c.CTID,
	c.Description,
	c.LastUpdated,
	c.SubjectWebpage,
	c.CredentialType as CredentialType,
	c.CredentialTypeId as CredentialTypeId,
	c.OwningOrganization as DataOwner,
	o.CTID as DataOwnerCTID,
	tpp.Name  as Publisher,
	tpp.CTID as  PublisherCTID
	from [dbo].[Credential_BasicSummary] as C
	left join dbo.Organization o on c.OwningOrganizationId = o.Id

	Left join [Entity.AgentRelationship] ear on c.EntityId = ear.EntityId and ear.RelationshipTypeId = 30
	Left join Organization tpp on ear.AgentUid = tpp.RowId


	--left join (
	--	Select PublisherCTID, DataOwnerCTID, EntityCtid
	--	from [Import.PendingRequest] a
	--	group by PublisherCTID, DataOwnerCTID, EntityCtid
	--	) latestImport on c.CTID = latestImport.EntityCtid
	--left join sandbox_ce_Accounts.dbo.Organization tpp on latestImport.PublisherCTID = f.CTID
	--left join staging_ce_Accounts.dbo.Organization tpp on latestImport.PublisherCTID = f.CTID
	--left join CE_Accounts.dbo.Organization tpp on latestImport.PublisherCTID = f.CTID
	where c.EntityStateId=3
	go
	grant select on Reports_CredentialType to public
	go