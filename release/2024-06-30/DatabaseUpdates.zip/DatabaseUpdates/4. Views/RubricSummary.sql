Use credFinder
go
--use sandbox_credFinder
--go
--use staging_credFinder	
--go
--use flstaging_credFinder	
--go
/****** Object:  View [dbo].[RubricSummary]    Script Date: 3/4/2024 8:39:02 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



/*
USE [credFinder]
GO
USE [sandbox_credFinder]
GO

SELECT base.[Id]
      ,base.[RowId]
      ,base.[Name]
      ,base.[Description]
      ,base.[EntityStateId]
      ,base.[CTID]
	        ,base.[PrimaryAgentUid]
      ,base.[PrimaryOrganizationId]
      ,base.[PrimaryOrganizationName]
      ,base.[PrimaryOrganizationCtid]
      ,base.[AbilityEmbodied]
      ,base.[Classification]
      ,base.[CodedNotation]
      ,base.[Comment]
      ,base.[Identifier]
      ,base.[KnowledgeEmbodied]
      ,base.[SkillEmbodied]
   
      ,base.[VersionIdentifier]
      ,base.[JsonProperties]
      ,base.[Created]
      ,base.[LastUpdated]
  FROM [dbo].[RubricSummary] a

*/
/*
RubricSummary
Notes
- 
Mods
22-11-08 mparsons - new

*/
ALTER VIEW [dbo].[RubricSummary]
AS
 
SELECT base.[Id]
      ,base.[RowId]
	  	,e.Id as EntityId

      ,base.[Name]
      ,base.[Description]
      ,base.[EntityStateId]
      ,base.[CTID]
		,base.[PrimaryAgentUid]
		,isnull(primaryOrg.Id,0)	as PrimaryOrganizationId
		,isnull(primaryOrg.Name,'') as PrimaryOrganizationName
		,isnull(primaryOrg.CTID,'') as PrimaryOrganizationCtid
		,base.[SubjectWebpage]
		,IsNull(RubricCriterion.total, 0) as RubricCriterionCount
		,IsNUll(RubricLevel.total,0) as RubricLevelCount
      ,base.[Creator]
      ,base.[AltCodedNotation]
      ,base.[CodedNotation]
      ,base.[ConceptKeyword]
      ,base.[DateCopyrighted]
      ,base.[DateCreated]
      ,base.[DateModified]
      ,base.[DateValidFrom]
      ,base.[DateValidUntil]
      ,base.[DerivedFrom]
      ,base.[Identifier]
      ,base.[InLanguage]
      ,base.[LatestVersion]
      ,base.[PreviousVersion]
      ,base.[NextVersion]
      ,base.[License]
      ,base.[LifeCycleStatusTypeId]
	  ,cpv.Title as LifeCycleStatusType
     -- ,base.[PublicationStatusType]
      ,base.[Publisher]
      ,base.[PublisherName]
      ,base.[Rights]
      ,base.[Subject]
      ,base.[VersionIdentifier]
      ,base.[Created]
      ,base.[LastUpdated]
      ,base.[JsonProperties]

--
  FROM [dbo].[Rubric] base

INNER JOIN dbo.Entity AS e ON base.RowId = e.EntityUid 
Left Join [Codes.PropertyValue] cpv on base.LifeCycleStatusTypeId = cpv.Id
-- join for primary
	Left join Organization primaryOrg on base.[PrimaryAgentUid] = primaryOrg.RowId and primaryOrg.EntityStateId > 1
Left Join (Select RubricId, count(*) as total from RubricCriterion group by RubricId) as RubricCriterion on base.Id = RubricCriterion.RubricId
Left Join (Select RubricId, count(*) as total from RubricLevel group by RubricId) as RubricLevel on base.Id = RubricLevel.RubricId

where base.EntityStateId > 1

GO
grant select on [RubricSummary] to public
go


