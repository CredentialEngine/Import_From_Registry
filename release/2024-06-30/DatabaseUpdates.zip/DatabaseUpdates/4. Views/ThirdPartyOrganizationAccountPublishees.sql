USE credFinder
GO

use sandbox_credFinder	
go
-- ***********************************************************
-- be sure to set the correct accounts database
-- ***********************************************************

/****** Object:  View [dbo].[ThirdPartyOrganizationAccountPublishees]    Script Date: 11/1/2023 4:47:34 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*


SELECT 
--distinct  
a.[Id]
      ,a.[EntityId]
      ,a.[EntityLastUpdated]
      ,a.[Name]
      ,a.[SubjectWebpage]
      ,a.[RowId]
      ,a.[CTID]
      ,a.[IsAQAOrganization]
      ,a.[PublisheeOrganization]
	  , c.description
      ,a.[PublisheeOrganizationId]
	  	        ,a.[publisheeOrganizationUID]
      ,a.[PublisheeOrganizationCTID]
  FROM [dbo].[ThirdPartyOrganizationAccountPublishees] a
  inner join organization b on a.CTID = b.CTID
  inner join organization c on a.PublisheeOrganizationCTID = c.CTID
 --where a.[PublisheeOrganizationCTID] = 'ce-81139f6f-0b81-4519-a629-37a6b9505830'
  where b.CTID = 'ce-852041b4-8a84-47aa-95cf-5b69cb62ee10'

-- publishees with multiple publishers

SELECT 
--distinct 
	a.[Id]
      --,a.[EntityId]
      --,a.[EntityLastUpdated]
	        ,a.[PublisheeOrganization]
      ,a.[PublisheeOrganizationId]
	  ,a.publisheeOrganizationUID
      ,a.[PublisheeOrganizationCTID]
      ,a.[Name] as ThirdPartyPublisher

      ,a.[RowId]
      ,a.[CTID]
      ,a.[IsAQAOrganization]

  FROM [dbo].[ThirdPartyOrganizationAccountPublishees] a
  inner join organization b on a.CTID = b.CTID
  Inner join (
SELECT a.[PublisheeOrganization]
      ,a.[PublisheeOrganizationId]
      ,a.[PublisheeOrganizationCTID]
	  ,count(*) as totals
  FROM [dbo].[ThirdPartyOrganizationAccountPublishees] a
  group by a.[PublisheeOrganization]
      ,a.[PublisheeOrganizationId]
      ,a.[PublisheeOrganizationCTID]
	  having count(*) > 1
) pWMultiple on a.[PublisheeOrganizationCTID] = pWMultiple.[PublisheeOrganizationCTID]

order by a.[PublisheeOrganization],a.[Name]

GO

*/

/*
Organizations with active third party relationships in accounts
NOTE: used as a filter for TPP related queries
Mods
23-11-01 mparsons - added to finder

*/
Alter VIEW [dbo].[ThirdPartyOrganizationAccountPublishees]
AS

SELECT       Distinct 
	isnull(base.Id, -10) As Id
	, e.Id as EntityId
	, e.LastUpdated as EntityLastUpdated
	, base.Name
	--, base.Description
	--, base.StatusId
	, base.SubjectWebpage
	, base.RowId
	, isnull(base.CTID,'') As CTID

	,case 
		when isnull(base.ISQAOrganization,0) =1 then 1
		else 0 end As IsAQAOrganization

	--base.Created, base.LastUpdated, 
	--base.CreatedById, base.LastUpdatedById
	,dataOwner.Name as PublisheeOrganization
	,dataOwner.Id	as PublisheeOrganizationId
	,dataOwner.RowId	as PublisheeOrganizationUID
	,dataOwner.CTID as PublisheeOrganizationCTID
	-- ======================================================
	, app.ThirdPartyMayPublishOrganization

FROM dbo.Organization base			-- the third party publisher
Inner join Entity e on base.RowId = e.EntityUid
-- be sure to set the correct accounts database
--inner join	ce_Accounts.dbo.ApprovedPublishingPermissions app on base.CTID = app.DataPublisherCTID
inner join	sandbox_ce_Accounts.dbo.ApprovedPublishingPermissions app on base.CTID = app.DataPublisherCTID
--inner join	staging_ce_Accounts.dbo.ApprovedPublishingPermissions app on base.CTID = app.DataPublisherCTID
--			***********
inner join dbo.Organization dataOwner on app.DataOwnerCTID = dataOwner.CTID

WHERE base.entityStateId > 1
--22-09-25 NO this is only useful for getting a list of Publishees. This view is/was also being used to find the correct TPP when publishing creds, etc. 
--		In the IOWA case, it should have worked though?
--	Currently is commented in prod/sandbox
--and app.ThirdPartyMayPublishOrganization= 1

GO
grant select on  [ThirdPartyOrganizationAccountPublishees] to public 
go

