USE [credFinder]
GO

use sandbox_credFinder	
go


/****** Object:  View [dbo].[Florida.ReportsSummaryHistory]    Script Date: 4/23/2024 9:48:18 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
USE [credFinder]
GO

SELECT [Id]
      ,[CTID]
      ,[Name]
      ,[Description]
      ,[SubjectWebpage]
      ,[AgentType]
      ,[AgentSector]
      ,[Address1]
      ,[City]
      ,[PostalCode]
      ,[Region]
  FROM [dbo].[Florida.ReportSummaryHistory]
GO



*/
CREATE View [dbo].[Florida.ReportsSummaryHistory]
As

SELECT [Id]
      ,[ReportType]
      ,[NotificationDate]
      ,[Publisher]
      ,[PublisherCTID]
      ,[Organization]
      ,[OrganizationCTID]
      ,[EntityType]
      ,[Totals]
  FROM [flstaging_credFinder].[dbo].[Reports.SummaryHistory]
GO




GO
grant select on [Florida.ReportsSummaryHistory] to public
go

