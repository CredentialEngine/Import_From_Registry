use credFinder
GO

--use sandbox_credFinder
--go

--use staging_credFinder
--go


/****** Object:  View [dbo].[Entity_ConditionProfileTargetsSummary]    Script Date: 8/22/2017 5:26:56 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*


SELECT [CredentialId]
      ,[CredentialRowId]
      ,[parentEntityId]
      ,[Name]
      ,a.[EntityId]
      ,[EntityTypeId]
      ,[EntityUid]
      ,[EntityConditionProfileId]
      ,[ConnectionTypeId]
      ,[ConnectionType],ConnectionTypeSchemaName
    
      ,[RowId]
  FROM [dbo].[Entity_ConditionProfile] a
	--INNER JOIN dbo.[Entity.LearningOpportunity] b ON a.EntityId = condProfParentEntity.EntityId 
where CredentialId= 1141

SELECTUSE [credFinder_ProdSync]
GO

SELECT parentId, Sum(HasTargetAssessment) As HasTargetAssessment, Sum(HasTargetCredential) As HasTargetCredential, Sum(HasLearningOpportunity) as HasLearningOpportunity FROM [dbo].[Entity_ConditionProfileTargetsSummary] where ParentEntityTypeId = 1 and ConnectionTypeId = 1 and (HasTargetAssessment > 0 OR HasTargetCredential > 0 OR HasLearningOpportunity > 0) 
group by parentId

 -- where [ConditionSubTypeId] in (2,3,4) 
  
  order by ParentEntityTypeId, parentId



SELECT [ParentId]
      ,[ParentEntityTypeId]
     -- ,[ParentRowId]
      ,[parentEntityId]
      ,[Name]
	        ,[HasTargetCredential]
      ,[HasTargetAssessment]
      ,[HasLearningOpportunity]
      ,[EntityId]
      ,[EntityTypeId]
      ,[EntityUid]
      ,[EntityConditionProfileId]
      ,[ConnectionTypeId]
      ,[ConditionSubTypeId]
      ,[ConnectionType]
      ,[ConnectionTypeSchemaName]
      ,[RowId]

  FROM [dbo].[Entity_ConditionProfileTargetsSummary]

 -- where [ConditionSubTypeId] in (2,3,4) 
  
  order by ParentEntityTypeId, parentId
*/
/*
Entity.ConditionProfile a
	Entity b on a.RowId = condProfEntity.EntityUid (entity for condition, not parent)
	Entity e 
	credential c
		Entity b on c.RowId = condProfEntity.EntityUid


List where a condition profile has at least one of a target credential, assessment or lopp.
This will include connection type condtions, as well as basic conditions - for now.
Filter on ConditionSubTypeId > 1 to get connections
Used in:
- Assessment_Summary
- LearningOpportunity_Summary
- Entity_ConditionProfileTotals
*/
Alter VIEW [dbo].[Entity_ConditionProfileTargetsSummary]
AS

SELECT        
	condProfParentEntity.EntityBaseId	AS ParentId
	, condProfParentEntity.EntityTypeId as ParentEntityTypeId
	, condProfParentEntity.EntityUid	as ParentRowId
	, a.EntityId as parentEntityId
	, condProfParentEntity.EntityBaseName as Name
	, condProfEntity.Id As EntityId
	, condProfEntity.EntityTypeId		--?? always cond profile
	, condProfParentEntity.EntityUid					--mixing Entity references!!!

	, a.Id AS EntityConditionProfileId
	, a.ConnectionTypeId
	, isnull(a.ConditionSubTypeId,1) as ConditionSubTypeId
	, cpv.Title as ConnectionType
	, cpv.SchemaName as ConnectionTypeSchemaName

	, a.RowId				--Can use to join Entity.Assessment and Entity.LearningOpportunity 
							--RowId = Entity.EntitUid and Entity.Id = child.EntityId
	-- AS EntityConditionProfileRowId
	,IsNull( credTotals.total,0) as HasTargetCredential
	,IsNull( asmtTotals.total,0) as HasTargetAssessment
	,IsNull( loppTotals.total,0) as HasLearningOpportunity
	--,case when exists (select a.CredentialId from [Entity.Credential] a inner join Credential b on a.CredentialId = b.Id where b.EntityStateId > 1 and EntityId = condProfEntity.id) then 1			else 0 end As HasTargetCredential

	--,case when exists (select a.AssessmentId from [Entity.Assessment] a inner join Assessment b on a.AssessmentId = b.Id where b.EntityStateId > 1 and a.EntityId = condProfEntity.id) then 1 else 0 end As HasTargetAssessment

	--,case when exists (select LearningOpportunityId from [Entity.LearningOpportunity] a inner join LearningOpportunity b on a.LearningOpportunityId = b.Id where b.EntityStateId > 1 and EntityId = condProfEntity.id) then 1 else 0 end As HasLearningOpportunity


FROM            
		dbo.[Entity.ConditionProfile] a
INNER JOIN dbo.Entity condProfParentEntity ON a.EntityId = condProfParentEntity.Id	--entity of parent/credential

Inner Join [Codes.PropertyValue] cpv	on a.ConnectionTypeId = cpv.Id
INNER JOIN dbo.Entity condProfEntity	ON a.RowId = condProfEntity.EntityUid		--entity for cond profile

--temp for testing:
Left Join (Select EntityId, count(*) as Total from [Entity.Credential] ec group by EntityId) credTotals
	on condProfEntity.Id = credTotals.EntityId
Left Join (Select EntityId, count(*) as Total from [Entity.Assessment] ec group by EntityId) asmtTotals
	on condProfEntity.Id = asmtTotals.EntityId
Left Join (Select EntityId, count(*) as Total from [Entity.LearningOpportunity] ec group by EntityId) loppTotals
	on condProfEntity.Id = loppTotals.EntityId
--where c.Id = 1
--need actual counts now, so changing
--confirm we only want requires or recommended for this context

where a.ConnectionTypeId < 3
/*
exists (select a.credentialId	from [Entity.Credential] a inner join Credential b on a.CredentialId = b.id 
			where b.EntityStateId > 1 AND a.EntityId = condProfEntity.id) 
OR	exists (select a.AssessmentId	from [Entity.Assessment] a inner join Assessment b on a.AssessmentId = b.Id		
			where b.EntityStateId > 1 and a.EntityId = condProfEntity.id) 
OR	exists (select a.LearningOpportunityId from [Entity.LearningOpportunity] a inner join LearningOpportunity b on a.LearningOpportunityId = b.Id  
			where b.EntityStateId > 1 and a.EntityId = condProfEntity.id) 
*/

GO
grant select on [Entity_ConditionProfileTargetsSummary] to public
go

