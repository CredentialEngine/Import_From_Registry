USE [credFinder]
GO
use sandbox_credFinder
go

--USE staging_credFinder
--GO

--use flstaging_credFinder 
--go
/****** Object:  View [dbo].[CredentialingAction_Summary]    Script Date: 7/29/2020 11:13:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*
USE [credFinder]
GO
USE [sandbox_credFinder]
GO

SELECT [Id]
      ,[RowId]
      ,[EntityId]
      ,[CTID]
      ,[EntityStateId]
      ,[ActionTypeId]
      ,[Name]
      ,[Description]
      ,[ActingAgentUid]
      ,[PrimaryOrganizationId]
      ,[PrimaryOrganizationName]
      ,[PrimaryOrganizationCtid]
      ,[ActionStatusId]
      ,[StartDate]
      ,[EndDate]
      ,[EvidenceOfAction]
      ,[ResultingAward]
      ,[Created]
      ,[LastUpdated]
  FROM [dbo].[CredentialingAction_Summary]

GO


*/
/*
CredentialingAction_Summary
Notes
- 
Mods
22-11-08 mparsons - new

*/
Alter VIEW [dbo].[CredentialingAction_Summary]
AS

SELECT a.[Id]
      ,a.[RowId]
	   	,e.Id as EntityId
      ,a.[CTID]
      ,a.[EntityStateId]
      ,a.[ActionTypeId]
	  ,actionType.Name as ActionType
	  ,actionType.SchemaName as ActionTypeSchema
      ,a.[Name]
      ,a.[Description]
      ,a.[ActingAgentUid]
	  		,isnull(primaryOrg.Id,0)	as PrimaryOrganizationId
		,isnull(primaryOrg.Name,'') as PrimaryOrganizationName
		,isnull(primaryOrg.CTID,'') as PrimaryOrganizationCtid
      ,a.ActionStatusTypeId
	  ,actionStatus.Title as ActionStatusType
	  ,actionStatus.SchemaName as ActionStatusSchemaName
      ,a.[StartDate]
      ,a.[EndDate]
	  --get object - hasResource?
	  --get partcipants
      ,a.[EvidenceOfAction]
      ,a.[ResultingAward]
      ,a.[Created]
      ,a.[LastUpdated]

	  	--typically only one
	, CASE
			WHEN Credentials IS NULL THEN ''
			WHEN len(Credentials) = 0 THEN ''
			ELSE left(Credentials,len(Credentials)-1)
		END AS Instrument

FROM [dbo].[CredentialingAction] a
INNER JOIN dbo.Entity AS e						ON a.RowId = e.EntityUid 
Left Join [Codes.PropertyValue] actionStatus	on a.ActionStatusTypeId = actionStatus.Id
--Left Join [Codes.PropertyValue] actionType		on a.ActionTypeId = actionType.Id
Left Join [Codes.CredentialingActionType] actionType	on a.ActionTypeId = actionType.Id
-- join for primary
Left join Organization primaryOrg on a.ActingAgentUid = primaryOrg.RowId and primaryOrg.EntityStateId > 1

--TBD on use of entity.credential or hasResource!!! or on the table if really only one
CROSS APPLY (
	SELECT 
		convert(varchar,caec.CredentialId) + '~ ' + convert(varchar,cac.Name) + ', '
	FROM dbo.[Entity.Credential] caec
	Inner Join Credential cac on caec.credentialId = cac.Id
	INNER JOIN dbo.Entity cae ON caec.EntityId = cae.Id 
	WHERE (a.EntityStateId = 3) 
	AND e.Id = caec.EntityId
	FOR XML Path('') 
) creds (Credentials)

GO

grant select on [CredentialingAction_Summary] to public
go


