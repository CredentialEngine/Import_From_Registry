Use credFinder
go
--use sandbox_credFinder
--go
--use staging_credFinder	
--go
--use flstaging_credFinder	
--go

/****** Object:  View [dbo].[TransferValueProfileSummary]    Script Date: 7/29/2020 11:13:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*
USE [credFinder]
GO


SELECT [Id]
      ,[EntityStateId]
      ,[Name]
      ,[Description]
      ,[SubjectWebpage]
      ,[OwningAgentUid]
      ,[OrganizationId]
      ,[OrganizationName]
      ,[OrganizationCTID]
      ,[LifecycleStatusType]
      ,[CredentialRegistryId]
      ,[StartDate]
      ,[EndDate]
      ,[CodedNotation]
      ,[IdentifierJson]
	  ,TransferIntermediariesFor
      ,[TransferValueJson]
      ,[TransferValueForJson]
      ,[TransferValueFromJson]
      ,[Created]
      ,[LastUpdated]
      ,[TransferValueForCredentialsCount]
      ,[TransferValueFromCredentialsCount]
      ,[TransferValueForAssessmentsCount]
      ,[TransferValueFromAssessmentsCount]
      ,[TransferValueForLoppsCount]
      ,[TransferValueFromLoppsCount]
  ,TransferValueHasDevProcessCount
  FROM [dbo].[TransferValueProfileSummary]
  order by lastupdated desc 
GO


*/
/*
TransferValueProfileSummary
Notes
- eventually will use a full join to organization
Mods
21-06-01 mparsons - add list of credentials for and from.
					- not sure if we really only need counts - especially where we will eventually need to add asmts, and lopps.
22-10-08 mparsons - add TransferIntermediariesFor
*/
ALTER VIEW [dbo].[TransferValueProfileSummary]
AS
SELECT        
	base.Id, 
	base.RowId,
	tvpEntity.Id as EntityId,

	base.CTID,
	base.EntityStateId, 
	base.Name, 
	base.Description, 
	base.SubjectWebpage, 
	base.OwningAgentUid, 
	b.Id AS OrganizationId, 
	b.Name AS OrganizationName, 
	b.CTID AS OrganizationCTID
	,case when IsNull(base.LifeCycleStatusTypeId,0) > 0 then base.LifeCycleStatusTypeId
	else 2648 end As LifeCycleStatusTypeId --default to production value for now

	,case when IsNull(base.LifeCycleStatusTypeId,0) > 0 then cpv.Title
	else 'Active' end As LifeCycleStatusType ,
	base.CredentialRegistryId, 
	base.StartDate,  base.EndDate, 
	base.CodedNotation, 
	base.IdentifierJson, 
	base.TransferValueJson, 
	base.TransferValueForJson, 
	base.TransferValueFromJson, 
	base.Created, base.LastUpdated
	-- list where in transfer intermediary
	--,isnull(TransferIntermediariesFor, '') as TransferIntermediariesFor
	--OR
		--collection member
 	, (SELECT titv.TransferIntermediaryId  FROM [dbo].[TransferIntermediary.TransferValue] titv where titv.TransferValueProfileId = base.Id
		FOR XML RAW, ROOT('TransferIntermediariesFor')
	) TransferIntermediariesFor

	--do we really only need a count?
	,isnull(tvForCredentials.total,0) as TransferValueForCredentialsCount
	,isnull(tvFromCredentials.total,0) as TransferValueFromCredentialsCount
	--
	,isnull(tvForAssessments.total,0) as TransferValueForAssessmentsCount
	,isnull(tvFromAssessments.total,0) as TransferValueFromAssessmentsCount
	--
	,isnull(tvForLopps.total,0) as TransferValueForLoppsCount
	,isnull(tvFromLopps.total,0) as TransferValueFromLoppsCount
	--
	,isnull(tvHasDevProcess.total,0) as TransferValueHasDevProcessCount

	--the cross applies will be expensive later
	--, CASE
	--	WHEN CredentialsFor IS NULL THEN ''
	--	WHEN len(CredentialsFor) = 0 THEN ''
	--	ELSE left(CredentialsFor,len(CredentialsFor)-1)
	--END AS CredentialsFor
	--, CASE
	--	WHEN CredentialsFrom IS NULL THEN ''
	--	WHEN len(CredentialsFrom) = 0 THEN ''
	--	ELSE left(CredentialsFrom,len(CredentialsFrom)-1)
	--END AS CredentialsFrom

FROM            dbo.TransferValueProfile base 
INNER JOIN dbo.Entity AS tvpEntity ON base.RowId = tvpEntity.EntityUid 
left join [codes.PropertyValue] cpv on base.LifeCycleStatusTypeId = cpv.Id
LEFT  JOIN dbo.Organization AS b ON base.OwningAgentUid = b.RowId
--

--CROSS APPLY (
--	SELECT 
--		convert(varchar,titv.TransferIntermediaryId)  + ', '
--	FROM dbo.[TransferIntermediary.TransferValue] titv
--	WHERE titv.TransferValueProfileId = base.Id
--	FOR XML Path('') 
--) tiFor (TransferIntermediariesFor)
--===============
Left Join (
	SELECT caecFor.EntityId, COUNT(*) as total
	FROM dbo.[Entity.Credential] caecFor
	INNER JOIN dbo.Entity caecForEntity ON caecFor.EntityId = caecForEntity.Id 
	WHERE caecFor.RelationshipTypeId = 1 
	group by caecFor.EntityId
	) tvForCredentials on tvpEntity.Id = tvForCredentials.EntityId
--
Left Join (
	SELECT caecFor.EntityId, COUNT(*) as total
	FROM dbo.[Entity.Credential] caecFor
	INNER JOIN dbo.Entity caecForEntity ON caecFor.EntityId = caecForEntity.Id 
	WHERE caecFor.RelationshipTypeId = 2
	group by caecFor.EntityId
	) tvFromCredentials on tvpEntity.Id = tvFromCredentials.EntityId
--===============

Left Join (
	SELECT caecFor.EntityId, COUNT(*) as total
	FROM dbo.[Entity.Assessment] caecFor
	INNER JOIN dbo.Entity caecForEntity ON caecFor.EntityId = caecForEntity.Id 
	WHERE caecFor.RelationshipTypeId = 1 
	group by caecFor.EntityId
	) tvForAssessments on tvpEntity.Id = tvForAssessments.EntityId
--
Left Join (
	SELECT caecFor.EntityId, COUNT(*) as total
	FROM dbo.[Entity.Assessment] caecFor
	INNER JOIN dbo.Entity caecForEntity ON caecFor.EntityId = caecForEntity.Id 
	WHERE caecFor.RelationshipTypeId = 2
	group by caecFor.EntityId
	) tvFromAssessments on tvpEntity.Id = tvFromAssessments.EntityId
--===============

Left Join (
	SELECT caecFor.EntityId, COUNT(*) as total
	FROM dbo.[Entity.LearningOpportunity] caecFor
	INNER JOIN dbo.Entity caecForEntity ON caecFor.EntityId = caecForEntity.Id 
	WHERE caecFor.RelationshipTypeId = 1 
	group by caecFor.EntityId
	) tvForLopps on tvpEntity.Id = tvForLopps.EntityId
--
Left Join (
	SELECT caecFor.EntityId, COUNT(*) as total
	FROM dbo.[Entity.LearningOpportunity] caecFor
	INNER JOIN dbo.Entity caecForEntity ON caecFor.EntityId = caecForEntity.Id 
	WHERE caecFor.RelationshipTypeId = 2
	group by caecFor.EntityId
	) tvFromLopps on tvpEntity.Id = tvFromLopps.EntityId
--===============

Left Join (
	SELECT epp.EntityId, COUNT(*) as total
	FROM dbo.[Entity.ProcessProfile] epp
	INNER JOIN dbo.Entity e ON epp.EntityId = e.Id 
	group by epp.EntityId
	) tvHasDevProcess on tvpEntity.Id = tvHasDevProcess.EntityId
--=== how to distinguish FOR and FROM
--For = RelationshipTypeId = 1
--from = RelationshipTypeId = 2

--CROSS APPLY (
--	SELECT 
--		convert(varchar,caecFor.CredentialId) + '~ ' + convert(varchar,cacFor.Name) + ', '
--	FROM dbo.[Entity.Credential] caecFor
--	Inner Join Credential cacFor on caecFor.credentialId = cacFor.Id
--	INNER JOIN dbo.Entity caecForEntity ON caecFor.EntityId = caecForEntity.Id 
--	WHERE caecFor.RelationshipTypeId = 1 AND (base.EntityStateId = 3) 
--	AND tvpEntity.Id = caecFor.EntityId
--	FOR XML Path('') 
--) credsFor (CredentialsFor)

--CROSS APPLY (
--	SELECT 
--		convert(varchar,caecFrom.CredentialId) + '~ ' + convert(varchar,cacFrom.Name) + ', '
--	FROM dbo.[Entity.Credential] caecFrom
--	Inner Join Credential cacFrom on caecFrom.credentialId = cacFrom.Id
--	INNER JOIN dbo.Entity cae ON caecFrom.EntityId = cae.Id 
--	WHERE caecFrom.RelationshipTypeId = 2 AND (base.EntityStateId = 3) 
--	AND tvpEntity.Id = caecFrom.EntityId
--	FOR XML Path('') 
--) credsFrom (CredentialsFrom)

where base.EntityStateId > 1
GO

grant select on [TransferValueProfileSummary] to public
go


