use credFinder
GO
use sandbox_credFinder
go


/****** Object:  View [dbo].[Credential_PartsSummary]    Script Date: 9/20/2017 5:44:15 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
select * from [Credential_PartsSummary] where id in (23, 644)

*/

/*
Summary view for credential parts - used to populate the cache


*/
Alter VIEW [dbo].[Credential_PartsSummary]
AS

SELECT  Distinct      
	base.Id, 
	base.RowId as EntityUid,
	base.RowId,
	base.EntityStateId,
	--base.Name, 
	--base.AlternateName,
	--base.Description, 
 
	base.OwningAgentUid,

	--==== external data =========================
	entity.Id as EntityId,
	isnull(credTypeProperty.Title,'') As CredentialType,
	isnull(credTypeProperty.SchemaName,'') As CredentialTypeSchema,
	base.CredentialTypeId,
	--added virtual property, as the name can change and don't want buried in code
	case when isnull(credTypeProperty.SchemaName,'') = 'qualityAssuranceCredential' then 1 else 0 end As IsAQACredential,

	--CASE
 --       WHEN EXISTS (SELECT RelationshipTypeId FROM [Entity.QA_Action] A inner join Entity b on a.entityId = b.Id WHERE base.RowId = b.EntityUid ) THEN 1
 --       ELSE 0
 --       END as HasQualityAssurance ,
	0 as HasQualityAssurance ,
	--OwningOrgs
	orgs.OwningOrgs,
	orgs.OfferingOrgs,
	
	IsNull(f.Nbr,0) As LearningOppsCompetenciesCount,
	IsNull(g.Nbr,0) As AssessmentsCompetenciesCount,
	IsNull(h.Nbr,0) As RequiresCompetenciesCount,
	--0 As LearningOppsCompetenciesCount,
	--0 As AssessmentsCompetenciesCount,

	IsNull(qa.Nbr,0) As QARolesCount,
	isnull(qaRolesCsv.Roles,'') As QARolesList,
	isnull(qaRolesCsv.AgentAndRoles,'') As AgentAndRoles,

	--for owning org
	isnull(qaRolesCsv.OrgQARoles,'') As Org_QARolesList,
	isnull(qaRolesCsv.Org_QAAgentAndRoles,'') As Org_QAAgentAndRoles,

	isnull(dlist.HasParts,'') As HasPartList,
	isnull(eList.IsPartOf,'') As IsPartOfList,

	IsNull(d.Nbr,0) As HasPartCount,
	IsNull(e.Nbr,0) As IsPartOfCount

	,IsNull(c11.Nbr,0) As EntryConditionCount
	,IsNull(c10.Nbr,0) As CorequisiteConditionCount	

	,IsNull(c1.Nbr,0) As RequiresCount
	,IsNull(c2.Nbr,0) As RecommendsCount
	,IsNull(c3.Nbr,0) As RequiredForCount
	,IsNull(c4.Nbr,0) As IsRecommendedForCount
	--,IsNull(c5.Nbr,0) As RenewalCount
	,IsNull(c6.Nbr,0) As IsAdvancedStandingForCount
	,IsNull(c7.Nbr,0) As AdvancedStandingFromCount
	,IsNull(c8.Nbr,0) As PreparationForCount
	,IsNull(c9.Nbr,0) As PreparationFromCount

FROM            
		dbo.Credential base 
Inner Join Entity entity				on base.RowId = entity.EntityUid

Left Join [Entity.AgentRelationship_CredentialOwnersOffersCSV] orgs on base.Id = orgs.credentialId
--qa roles
left join [Credential_QARolesCSV] qaRolesCsv	on base.id = qaRolesCsv.CredentialId
left join [Codes.PropertyValue] credTypeProperty on base.CredentialTypeId = credTypeProperty.Id 

--left join [EntityProperty_Summary] credTypeProperty on base.Id = credTypeProperty.EntityBaseId and credTypeProperty.[EntityTypeId]= 1
--			and credTypeProperty.CategoryId = 2
--Left Join Organization managingOrg on base.ManagingOrgId = managingOrg.Id

--embedded credentials (HasPart)
left join (
	Select ParentCredentialId, Count(*) As Nbr from [Credential_EmbeddedCredentials_Summary] group by ParentCredentialId
	) d							on base.Id = d.ParentCredentialId
-- IS embedded credentials (IsPartOf)
left join (
	Select EmbeddedCredentialId, Count(*) As Nbr from [Credential_EmbeddedCredentials_Summary] group by EmbeddedCredentialId
	) e							on base.Id = e.EmbeddedCredentialId

--hasParts
left join [Credential_HasPart_IsPartOf] dList	on base.id = dlist.CredentialId
--IsPartOf
left join [Credential_HasPart_IsPartOf] eList	on base.id = elist.CredentialId


--competencies from learning opps
left join (
	Select CredentialId, Count(*) As Nbr from [ConditionProfile_LearningOpp_Competencies_Summary] group by CredentialId
	) f							on base.Id = f.CredentialId

--competencies from assessments
left join (
	Select CredentialId, Count(*) As Nbr from ConditionProfile_Assessments_Competencies_Summary group by CredentialId
	) g							on base.Id = g.CredentialId
--requires competencies from conditions
left join (
	Select a.EntityBaseId As CredentialId, Count(*) As Nbr from Entity a		-- entity for credential
			Inner Join [Entity.ConditionProfile] b on a.Id = b.EntityId		-- condition profiles for credential
			Inner Join Entity cpEntity on b.RowId = cpEntity.EntityUid		-- entity for condition profile
			Inner Join [Entity.Competency] c on cpEntity.id = c.EntityId
			where b.ConnectionTypeId = 1
			group by a.EntityBaseId
	) h on base.Id = h.CredentialId


--QA Roles 
left join (
	Select SourceEntityBaseId, Count(*) As Nbr from [Entity_Relationship_AgentSummary] where IsQARole = 1 group by SourceEntityBaseId
	) qa						on base.Id = qa.SourceEntityBaseId

-- ===========================================================================
--conditionProfiles - Attainment Requirements
--just counts of existence (should use Exists, if don't care about number?
--24-04-10 MP - turns out we may care about the actual number in some cases
left join (
	Select CredentialId, Count(*) As Nbr from [Credential_ConditionProfile] 
	where HasTargetCredential= 1 
	AND ConnectionTypeId = 1 and isnull(ConditionSubTypeId, 1) = 2
	group by CredentialId
	) c1 on base.Id = c1.CredentialId
--conditionProfiles - Attainment Recommendations
left join (
	Select CredentialId, Count(*) As Nbr from [Credential_ConditionProfile] where HasTargetCredential= 1 
	AND ConnectionTypeId = 2 and isnull(ConditionSubTypeId, 0) = 2
	group by CredentialId
	) c2						on base.Id = c2.CredentialId
		
--conditionProfiles - Post-Award Connections (Requirements)
left join (
	Select CredentialId, Count(*) As Nbr from [Credential_ConditionProfile] where HasTargetCredential= 1 
	AND ConnectionTypeId = 3 group by CredentialId
	) c3						on base.Id = c3.CredentialId
		
--conditionProfiles - Post-Award Connections (Recommendations)
left join (
	Select CredentialId, Count(*) As Nbr from [Credential_ConditionProfile] where HasTargetCredential= 1 
	AND ConnectionTypeId = 4 group by CredentialId
	) c4						on base.Id = c4.CredentialId
		
--conditionProfiles - Renewal Requirements
left join (
	Select CredentialId, Count(*) As Nbr from [Credential_ConditionProfile] where HasTargetCredential= 1 
	AND ConnectionTypeId = 5 group by CredentialId
	) c5						on base.Id = c5.CredentialId
		
		
--conditionProfiles - Advanced Standing For
left join (
	Select CredentialId, Count(*) As Nbr from [Credential_ConditionProfile] where HasTargetCredential= 1 
	AND ConnectionTypeId = 6 group by CredentialId
	) c6						on base.Id = c6.CredentialId
								
		
--conditionProfiles - Advanced Standing From
left join (
	Select CredentialId, Count(*) As Nbr from [Credential_ConditionProfile] where HasTargetCredential= 1 
	AND ConnectionTypeId = 7 group by CredentialId
	) c7						on base.Id = c7.CredentialId
		
		
--conditionProfiles - Preparation For
left join (
	Select CredentialId, Count(*) As Nbr from [Credential_ConditionProfile] where HasTargetCredential= 1 
	AND ConnectionTypeId = 8 group by CredentialId
	) c8						on base.Id = c8.CredentialId

--conditionProfiles - Preparation From
left join (
	Select CredentialId, Count(*) As Nbr from [Credential_ConditionProfile] where HasTargetCredential= 1 
	AND ConnectionTypeId = 9 group by CredentialId
	) c9						on base.Id = c9.CredentialId								


--conditionProfiles - CorequisiteConditionCount
left join (
	Select CredentialId, Count(*) As Nbr from [Credential_ConditionProfile] where HasTargetCredential= 1 
	AND ConnectionTypeId = 10 group by CredentialId
	) c10						on base.Id = c10.CredentialId	

--conditionProfiles - EntryCondition
left join (
	Select CredentialId, Count(*) As Nbr from [Credential_ConditionProfile] where HasTargetCredential= 1 
	AND ConnectionTypeId = 11 group by CredentialId
	) c11						on base.Id = c11.CredentialId	

go

grant select on Credential_PartsSummary to public
GO

