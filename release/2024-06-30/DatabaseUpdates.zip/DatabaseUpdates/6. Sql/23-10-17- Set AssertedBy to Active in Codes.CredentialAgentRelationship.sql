

UPDATE [dbo].[Codes.CredentialAgentRelationship]
SET [IsActive] = 1
WHERE SchemaTag='ceterms:assertedBy';
