
--	24-02-28 Reference.FrameworkItem-fix ONET Urls
--SELECT TOP (2000) [Id]
--      ,[CategoryId]
--      ,[CodeGroup]
--      ,[CodedNotation]
--      ,[Name]
--      ,[Description]
--      ,[TargetNode]
--      ,[RelatedTargetNode]
--      ,[ReferenceFrameworkId]
--      ,[Created]
--  FROM [credFinder].[dbo].[Reference.FrameworkItem]
--      where CategoryId = 11
--	  AND [TargetNode] like '%onetonline.org/%'
--  go

Update 

-- Select * from 
[dbo].[Reference.FrameworkItem]
 Set [TargetNode] = REPLACE([TargetNode], 'https://onetonline.org/','https://www.onetonline.org/')
    where CategoryId = 11
	AND [TargetNode] like 'https://onetonline.org/%'
  go
Update 
-- Select * from 
[dbo].[Reference.FrameworkItem]
   Set [TargetNode] = REPLACE([TargetNode], 'http://onetonline.org/','https://www.onetonline.org/')
    where CategoryId = 11
		AND [TargetNode] like 'http://onetonline.org/%'
  go

Update 
  -- Select * from 
[dbo].[Reference.FrameworkItem]
   Set [TargetNode] = REPLACE([TargetNode], 'http://www.onetonline.org/','https://www.onetonline.org/')
    where CategoryId = 11
		AND [TargetNode] like 'http://www.onetonline.org/%'
  go