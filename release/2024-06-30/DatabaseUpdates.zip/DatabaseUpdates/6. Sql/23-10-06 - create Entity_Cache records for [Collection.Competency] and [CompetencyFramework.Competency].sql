
--	23-10-06 - create Entity_Cache records for [Collection.Competency] and [CompetencyFramework.Competency]
/*
select * from entity_cache
where ctid = 'ce-950fc46c-14be-4cbc-9a83-ec6268053ee7'



*/

INSERT INTO [dbo].[Entity_Cache]
           ([Id]           ,[EntityTypeId]           ,[EntityType]           ,[EntityUid]
           ,[EntityStateId]           ,[CTID]
           ,[parentEntityId] ,[parentEntityUid] ,[parentEntityType] ,[parentEntityTypeId]
           ,[BaseId] ,[Name] ,[Description] ,[SubjectWebpage]
           ,[OwningOrgId]           ,[ImageUrl]
           ,[Created] ,[LastUpdated] ,[CacheDate]
           ,[PublishedByOrgId] ,[ResourceDetail] ,[AgentRelationshipsForEntity]
           ,[IsActive])

Select e.Id, e.EntityTypeId, cet.Title, e.EntityUid
,3, cc.CTID
, colEntity.Id, colEntity.EntityUid, 'Collection', 9
,cc.Id, case when len(cc.CompetencyText) > 300 then SUBSTRING(cc.CompetencyText,1,300) else cc.CompetencyText end, cc.CompetencyText ,NULL
,org.Id, NULL
,cc.Created, cc.LastUpdated, getdate()
, NULL, NULL, NULL, 1
from Entity e
Inner join [Codes.EntityTypes] cet on e.EntityTypeId = cet.Id
inner join [Collection.Competency] cc on e.EntityUid = cc.RowId
inner join Collection col on cc.CollectionId = col.Id
inner join Entity colEntity on col.RowId = colEntity.EntityUid
left join Organization org on col.OwningAgentUid = org.RowId

--Left Join [Entity_Cache] ec on cc.RowId = ec.EntityUid
Left Join [Entity_Cache] ec on cc.CTID = ec.CTID
where ec.Id is null 
GO

--			[CompetencyFramework.Competency]
INSERT INTO [dbo].[Entity_Cache]
           ([Id]           ,[EntityTypeId]           ,[EntityType]           ,[EntityUid]
           ,[EntityStateId]           ,[CTID]
           ,[parentEntityId] ,[parentEntityUid] ,[parentEntityType] ,[parentEntityTypeId]
           ,[BaseId] ,[Name] ,[Description] ,[SubjectWebpage]
           ,[OwningOrgId]           ,[ImageUrl]
           ,[Created] ,[LastUpdated] ,[CacheDate]
           ,[PublishedByOrgId] ,[ResourceDetail] ,[AgentRelationshipsForEntity]
           ,[IsActive])

Select e.Id, e.EntityTypeId, cet.Title, e.EntityUid
,3, cc.CTID
, colEntity.Id [parentEntityId], colEntity.EntityUid parentEntityUid, 'CompetencyFramework' parentEntityType, 10 parentEntityTypeId
,cc.Id, case when len(cc.CompetencyText) > 300 then SUBSTRING(cc.CompetencyText,1,300) else cc.CompetencyText end, cc.CompetencyText ,NULL
,org.Id, NULL
,cc.Created, cc.LastUpdated, getdate()
, NULL, NULL, NULL, 1
from Entity e
Inner join [Codes.EntityTypes] cet on e.EntityTypeId = cet.Id
inner join [CompetencyFramework.Competency] cc on e.EntityUid = cc.RowId
inner join [CompetencyFramework] col on cc.CompetencyFrameworkId = col.Id
inner join Entity colEntity on col.RowId = colEntity.EntityUid
left join Organization org on col.OrganizationCTID = org.CTID

--Left Join [Entity_Cache] ec on cc.RowId = ec.EntityUid
Left Join [Entity_Cache] ec on cc.CTID = ec.CTID
where ec.Id is null 
GO


