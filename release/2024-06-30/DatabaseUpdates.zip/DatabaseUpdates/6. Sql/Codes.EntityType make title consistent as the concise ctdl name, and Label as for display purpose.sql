
--		Codes.EntityType make title consistent as the concise ctdl name, and Label as for display purpose
/*
SELECT TOP (1000) [Id]
      ,[Title]
      ,[Description]
      ,[IsActive]
      ,[SchemaName]
      ,[Created]
      ,[Totals]
      ,[SortOrder]
      ,[IsTopLevelEntity]
      ,[Label]
  FROM [dbo].[Codes.EntityTypes]
  go

*/
--???
--update  [dbo].[Codes.EntityTypes]   set Title = 'LearningOpportunityProfile' where id = 7
--go
update  [dbo].[Codes.EntityTypes]   set Title = 'Job' where id = 32
go
update  [dbo].[Codes.EntityTypes]   set Title = 'Task' where id = 33
go
--could be confusing if used for validation
update  [dbo].[Codes.EntityTypes]   set Title = 'CredentialOrganization' where id = 2
go
update  [dbo].[Codes.EntityTypes]   set Title = 'ScheduledOffering' where id = 15
go
update  [dbo].[Codes.EntityTypes]   set Title = 'ConditionManifest' where id = 19
go
update  [dbo].[Codes.EntityTypes]   set Title = 'CostManifest' where id = 20
go
update  [dbo].[Codes.EntityTypes]   set Title = 'AccreditAction' where id = 22
go

update  [dbo].[Codes.EntityTypes]   set Title = 'PathwaySet' where id = 23
go
update  [dbo].[Codes.EntityTypes]   set Title = 'PathwayComponent' where id = 24
go

update  [dbo].[Codes.EntityTypes]   set Title = 'AggregateDataProfile' where id = 27
go

update  [dbo].[Codes.EntityTypes]   set Title = 'DataSetProfile' where id = 31
go


update  [dbo].[Codes.EntityTypes]   set Title = 'WorkRole' where id = 34
go

update  [dbo].[Codes.EntityTypes]   set Title = 'LearningProgram' where id = 36
go


update  [dbo].[Codes.EntityTypes]   set Title = 'SupportService' where id = 38
go

update  [dbo].[Codes.EntityTypes]   set Title = 'VerificationServiceProfile' where id = 41
go

