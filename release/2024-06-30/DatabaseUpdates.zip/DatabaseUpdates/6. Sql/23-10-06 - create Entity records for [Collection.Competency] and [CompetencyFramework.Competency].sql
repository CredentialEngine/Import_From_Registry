
-- 23-10-06 - create Entity records for [Collection.Competency] and [CompetencyFramework.Competency]
INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
           ,[EntityBaseId]
           ,[EntityBaseName]
           ,[LastUpdated])
select RowId, 18, cc.Created, cc.Id, 
case when len(cc.CompetencyText) > 600 then SUBSTRING(cc.CompetencyText,1,590) else cc.CompetencyText end, cc.LastUpdated
from [Collection.Competency] cc 
left join entity e on cc.RowId = e.entityUid 
where e.id is null 

go

INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
           ,[EntityBaseId]
           ,[EntityBaseName]
           ,[LastUpdated])
select RowId, 17, cc.Created, cc.Id, 
case when len(cc.CompetencyText) > 600 then SUBSTRING(cc.CompetencyText,1,590) else cc.CompetencyText end, cc.LastUpdated
from [CompetencyFramework.Competency] cc 
left join entity e on cc.RowId = e.entityUid 
where e.id is null 
