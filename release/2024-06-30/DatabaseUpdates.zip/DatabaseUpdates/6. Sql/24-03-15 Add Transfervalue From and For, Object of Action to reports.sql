
--delete from [dbo].[Counts.EntityStatistic]
--where id = 162

INSERT INTO [dbo].[Counts.EntityStatistic]
           ([Id]
           ,[EntityTypeId]
           ,[CategoryId]
           ,[Title]
           ,[Description]
           ,[SortOrder]
           ,[IsActive]
           ,[SchemaName]
           ,[Totals]
           ,[Created])
     VALUES
           (169
           ,1
		   ,58
           ,'Provides TransferValue For'
           ,''
           ,25
           ,1
           ,'credReport:ProvidesTransferValueFor'
           ,1
           ,GETDATE())
GO

INSERT INTO [dbo].[Counts.EntityStatistic]
           ([Id]
           ,[EntityTypeId]
           ,[CategoryId]
           ,[Title]
           ,[Description]
           ,[SortOrder]
           ,[IsActive]
           ,[SchemaName]
           ,[Totals]
           ,[Created])
     VALUES
           (170
           ,7
		   ,61
           ,'Provides TransferValue For'
           ,''
           ,25
           ,1
           ,'loppReport:ProvidesTransferValueFor'
           ,0
           ,GETDATE())
GO
INSERT INTO [dbo].[Counts.EntityStatistic]
           ([Id]
           ,[EntityTypeId]
           ,[CategoryId]
           ,[Title]
           ,[Description]
           ,[SortOrder]
           ,[IsActive]
           ,[SchemaName]
           ,[Totals]
           ,[Created])
     VALUES
           (171
           ,3
		   ,60
           ,'Provides TransferValue For'
           ,''
           ,25
           ,1
           ,'asmtReport:ProvidesTransferValueFor'
           ,0
           ,GETDATE())
GO
INSERT INTO [dbo].[Counts.EntityStatistic]
           ([Id]
           ,[EntityTypeId]
           ,[CategoryId]
           ,[Title]
           ,[Description]
           ,[SortOrder]
           ,[IsActive]
           ,[SchemaName]
           ,[Totals]
           ,[Created])
     VALUES
           (172
           ,1
		   ,58
           ,'Receives TransferValue From'
           ,''
           ,25
           ,1
           ,'credReport:ReceivesTransferValueFrom'
           ,1
           ,GETDATE())
GO

INSERT INTO [dbo].[Counts.EntityStatistic]
           ([Id]
           ,[EntityTypeId]
           ,[CategoryId]
           ,[Title]
           ,[Description]
           ,[SortOrder]
           ,[IsActive]
           ,[SchemaName]
           ,[Totals]
           ,[Created])
     VALUES
           (173
           ,7
		   ,61
           ,'Receives TransferValue From'
           ,''
           ,25
           ,1
           ,'loppReport:ReceivesTransferValueFrom'
           ,0
           ,GETDATE())
GO
INSERT INTO [dbo].[Counts.EntityStatistic]
           ([Id]
           ,[EntityTypeId]
           ,[CategoryId]
           ,[Title]
           ,[Description]
           ,[SortOrder]
           ,[IsActive]
           ,[SchemaName]
           ,[Totals]
           ,[Created])
     VALUES
           (174
           ,3
		   ,60
           ,'Receives TransferValue From'
           ,''
           ,25
           ,1
           ,'asmtReport:ReceivesTransferValueFrom'
           ,0
           ,GETDATE())
GO

INSERT INTO [dbo].[Counts.EntityStatistic]
           ([Id]
           ,[EntityTypeId]
           ,[CategoryId]
           ,[Title]
           ,[Description]
           ,[SortOrder]
           ,[IsActive]
           ,[SchemaName]
           ,[Totals]
           ,[Created])
     VALUES
           (175
           ,7
		   ,61
           ,'Has Object Of Action'
           ,''
           ,25
           ,1
           ,'loppReport:ObjectOfAction'
           ,0
           ,GETDATE())
GO
--

