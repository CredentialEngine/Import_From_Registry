
--	23-10-06 Chg entity type id for JurisdictionProfile
--	Codes.EntityTypes- Set Entity.JurisdictionProfile to 50 and convert data
--	Then set 18 to be collection comptencies
--	Then can convert existing to 41
--- TODO - same for ctdlEditor for consistency


--use sandbox_credFinder
--go

--use staging_credFinder
--go

--=========== create new entityTypeId for Entity.VS

select * from  [Codes.EntityTypes]
where id in (17,18,50)


INSERT INTO [dbo].[Codes.EntityTypes]
           ([Id]
           ,[Title]
           ,[Label]
           ,[Description]
           ,[IsActive]
           ,[SchemaName]
           ,[Created]
           ,[Totals]
           ,[SortOrder]
           ,[IsTopLevelEntity]
		   )

SELECT 50
      ,[Title] + '-COPY'
	  ,[Label] + '-COPY'
      ,[Description] + '-COPY'
      ,[IsActive]
      ,SchemaName + '-COPY'
      ,getdate() as created
      ,[Totals]
	  ,[SortOrder]
      ,0
	  
  FROM [dbo].[Codes.EntityTypes]
   WHERE [Id]=18
GO

--============================================
-- Change entity.VS entityTypeId to 99


UPDATE [dbo].[Entity]
   SET [EntityTypeId] = 50
		--change date????
    --  ,[LastUpdated] = GETDATE()
 WHERE [EntityTypeId]=18
GO

update  entity_cache
set entityTypeId = 50
where entityTypeId = 18

--chg 18 to competency from collection 
UPDATE [dbo].[Codes.EntityTypes]
   SET [Title] = 'CollectionCompetency'
   ,Description = 'Competency in a collection.'
    ,Label='Collection Competency'
	 ,SchemaName='ceasn:Competency'
      ,[IsTopLevelEntity] = 1
	    ,IsActive=1
 WHERE [Id]=18
GO
--fix naming for E.JP
UPDATE [dbo].[Codes.EntityTypes]
   SET [Title] = 'JurisdictionProfile'
   ,Description = 'Jurisdiction Profile'
   ,Label='Jurisdiction Profile'
   ,SchemaName='ceterms:JurisdictionProfile'
      ,[IsTopLevelEntity] = 0
	  ,IsActive=1
 WHERE [Id]=50
GO


--============================================
-- chg trigger 

/****** Object:  Trigger [dbo].[trgEntityJurisdictionProfileAfterInsert]    Script Date: 10/6/2023 1:04:55 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
ALTER TRIGGER [dbo].[trgEntityJurisdictionProfileAfterInsert] 
		ON  [dbo].[Entity.JurisdictionProfile]
FOR INSERT
AS  
    INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
					 ,EntityBaseId, EntityBaseName)
    SELECT RowId,50, getdate(), Id, isnull(Name,'Default Jurisdiction Profile')
    FROM inserted;


GO

