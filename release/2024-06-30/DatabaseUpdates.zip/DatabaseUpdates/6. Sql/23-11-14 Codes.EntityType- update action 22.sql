
-- 23-11-14 Codes.EntityType- update action 22
UPDATE [dbo].[Codes.EntityTypes]
   SET [Title] = 'CredentialingAction'
      ,[Description] = 'Action taken by an agent affecting the status of an object entity.'
      ,[IsActive] = 1
      ,[SchemaName] ='ceterms:CredentialingAction'
      ,[Totals] = 0
      ,[SortOrder] = 50
      ,[IsTopLevelEntity] = 1
      ,[Label] = 'Credentialing Action'
 WHERE Id = 22
GO



