

--23-12-07 Codes.PropertyCategory-Add placeholders for Condition Profile - Target Competency.  

/*
SELECT [Id]
      ,[Title]
      ,[Description]
      ,[SortOrder]
      ,[IsActive]
      ,[SchemaName]
      ,[SchemaUrl]
      ,[Created]
      ,[CodeName]
      ,[InterfaceType]
      ,[PropertyTableName]
      ,[IsConceptScheme]
      ,[SchemeFor]
  FROM [dbo].[Codes.PropertyCategory]
  where id > 100

--GO

*/

/*

These are categories for place holder filters like Other Filters. 
There are no property values for these, but don't want confusion where their default categoryId gets assigned to another property

*/
INSERT INTO [dbo].[Codes.PropertyCategory]
           ([Id]
           ,[Title],[Description]
           ,[SortOrder],[IsActive]
           ,[SchemaName],[SchemaUrl]
           ,[Created]
           ,[CodeName]
           ,[InterfaceType]
           ,[PropertyTableName]
           ,[IsConceptScheme]
           ,[SchemeFor])
     VALUES
           (103
           ,'Condition Profile - Target Competency','Not used in the finder, but added for consistency with the publisher (Entity.Reference for simple lists of competencies)'
           ,10,1
           ,'filter:targetCompetency', ''
           ,GETDATE()
           ,'targetCompetency'
           ,NULL
           ,NULL
           ,1
           ,'')
GO

