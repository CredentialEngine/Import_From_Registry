INSERT INTO [dbo].[Codes.AssertionType]
           ([Id]
           ,[Title]
           ,[Description]
           ,[SchemaTag]
           ,[ReverseRelation]
           ,[ReverseSchemaTag]
           ,[Created]
           ,[IsActive]
           ,[IsQARole]
           ,[IsOwnerAgentRole]
           ,[IsAgentToAgentRole]
           ,[IsEntityToAgentRole]
           ,[IsAssessmentAgentRole]
           ,[IsLearningOppAgentRole]
           ,[Totals]
           )
     VALUES
           (14
           ,'Registered By'
           ,'Entity is Registered with the related Agent'
           ,'ceterms:registeredBy'
           ,'Registered For'
           ,'ceterms:registeredBy'
           ,getdate()
           ,1
           ,0		--[IsQARole]
           ,0		--[IsOwnerAgentRole]
           ,0		--[IsAgentToAgentRole]
           ,0		--[IsEntityToAgentRole]
           ,0		--[IsAssessmentAgentRole]
           ,1		--[IsLearningOppAgentRole]
           ,0		--[Totals]
           )
GO