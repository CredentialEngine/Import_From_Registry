

--24-02-14 Codes.PropertyCategory add HasResourceRelationshipType
--NO NEEDS TI BE A SEPARATE TABLE

-- 74 should  exist as inActive, so just update
UPDATE [dbo].[Codes.PropertyCategory]
   SET [Title] = 'Has Resource Relationship Type'
      ,[Description] = 'Relationship types used in the Entity.HasResource table. Used in views and summaries for clarity.'
      ,[IsActive] = 1
      ,[SchemaName] = 'HasResourceRelationshipType'
      ,[SchemaUrl] = NULL
      ,[Created] = getdate()	
      ,[CodeName] = 'HasResourceRelationshipType'
      ,[InterfaceType] = 1
      ,[PropertyTableName] = 'Codes.PropertyValue'
      ,[IsConceptScheme] = 0
      ,[SchemeFor] = NULL
 WHERE id = 74
GO



INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId] ,[Title] ,[Description] 
		   ,[SortOrder] ,[IsActive] ,[SchemaName] ,[SchemaUrl] ,[ParentSchemaName] ,[Created] ,[Totals] ,[IsSubType1])
     VALUES
           (74 ,'Has Resource' ,'Default relationship. Typically used where the parent resource only has one resource type - but not very future proof.'
           ,25 ,1 ,'HasResource' ,NULL ,NULL ,GETDATE() ,0 ,0
		   )
GO
INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId] ,[Title] ,[Description] 
		   ,[SortOrder] ,[IsActive] ,[SchemaName] ,[SchemaUrl] ,[ParentSchemaName] ,[Created] ,[Totals] ,[IsSubType1])
     VALUES
           (74 ,'Has Specialization' ,'Typically for an occupation (More specialized profession, trade, or career field that is encompassed by the one being described).'
           ,25 ,1 ,'HasSpecialization' ,NULL ,NULL ,GETDATE() ,0 ,0
		   )
GO
INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId] ,[Title] ,[Description] 
		   ,[SortOrder] ,[IsActive] ,[SchemaName] ,[SchemaUrl] ,[ParentSchemaName] ,[Created] ,[Totals] ,[IsSubType1])
     VALUES
           (74 ,'IsSpecializationOf' ,'this is an inverse, so should not be storing the 3, rather looking up reverse using HasSpecialization??'
           ,25 ,1 ,'IsSpecializationOf' ,NULL ,NULL ,GETDATE() ,0 ,0
		   )
GO
INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId] ,[Title] ,[Description] 
		   ,[SortOrder] ,[IsActive] ,[SchemaName] ,[SchemaUrl] ,[ParentSchemaName] ,[Created] ,[Totals] ,[IsSubType1])
     VALUES
           (74 ,'HasResource' ,'Default relationship.'
           ,25 ,1 ,'HasResource' ,NULL ,NULL ,GETDATE() ,0 ,0
		   )
GO
INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId] ,[Title] ,[Description] 
		   ,[SortOrder] ,[IsActive] ,[SchemaName] ,[SchemaUrl] ,[ParentSchemaName] ,[Created] ,[Totals] ,[IsSubType1])
     VALUES
           (74 ,'HasResource' ,'Default relationship.'
           ,25 ,1 ,'HasResource' ,NULL ,NULL ,GETDATE() ,0 ,0
		   )
GO
INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId] ,[Title] ,[Description] 
		   ,[SortOrder] ,[IsActive] ,[SchemaName] ,[SchemaUrl] ,[ParentSchemaName] ,[Created] ,[Totals] ,[IsSubType1])
     VALUES
           (74 ,'HasResource' ,'Default relationship.'
           ,25 ,1 ,'HasResource' ,NULL ,NULL ,GETDATE() ,0 ,0
		   )
GO
INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId] ,[Title] ,[Description] 
		   ,[SortOrder] ,[IsActive] ,[SchemaName] ,[SchemaUrl] ,[ParentSchemaName] ,[Created] ,[Totals] ,[IsSubType1])
     VALUES
           (74 ,'HasResource' ,'Default relationship.'
           ,25 ,1 ,'HasResource' ,NULL ,NULL ,GETDATE() ,0 ,0
		   )
GO
INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId] ,[Title] ,[Description] 
		   ,[SortOrder] ,[IsActive] ,[SchemaName] ,[SchemaUrl] ,[ParentSchemaName] ,[Created] ,[Totals] ,[IsSubType1])
     VALUES
           (74 ,'HasResource' ,'Default relationship.'
           ,25 ,1 ,'HasResource' ,NULL ,NULL ,GETDATE() ,0 ,0
		   )
		   INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId] ,[Title] ,[Description] 
		   ,[SortOrder] ,[IsActive] ,[SchemaName] ,[SchemaUrl] ,[ParentSchemaName] ,[Created] ,[Totals] ,[IsSubType1])
     VALUES
           (74 ,'HasResource' ,'Default relationship.'
           ,25 ,1 ,'HasResource' ,NULL ,NULL ,GETDATE() ,0 ,0
		   )
GO
GO

