

--	24-02-19 [Codes.CredentialAgentRelationship] update IsEntityToAgentRole for roles 7,30
UPDATE [dbo].[Codes.CredentialAgentRelationship]
   SET [IsEntityToAgentRole] = 1
 WHERE Id in ( 7, 30)
GO


