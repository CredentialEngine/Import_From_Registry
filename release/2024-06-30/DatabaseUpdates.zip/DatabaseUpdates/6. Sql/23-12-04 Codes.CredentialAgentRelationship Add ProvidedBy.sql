
--	23-12-04 Codes.CredentialAgentRelationship Add ProvidedBy
/*
select * from [Codes.CredentialAgentRelationship]
Order by Id



*/
/*
delete 
--	select *
FROM            [Entity.AgentRelationship]
WHERE        (RelationshipTypeId IN (8))
go

delete 
--	select *
FROM            [Entity.Assertion]
WHERE        (AssertionTypeId IN (8))
go

delete FROM            [Codes.CredentialAgentRelationship]
WHERE  Id = 8
go

INSERT INTO [dbo].[Codes.CredentialAgentRelationship]
           ([Id]
           ,[Title]
           ,[Description]
           ,[SchemaTag]
           ,[ReverseRelation]
           ,[ReverseSchemaTag]
           ,[Created]
           ,[IsActive]
           ,[IsQARole]
           ,[IsOwnerAgentRole]
           ,[IsAgentToAgentRole]
           ,[IsEntityToAgentRole]
           ,[IsAssessmentAgentRole]
           ,[IsLearningOppAgentRole]
           ,[Totals]
           ,[CredentialTotals]
           ,[OrganizationTotals]
           ,[AssessmentTotals]
           ,[LoppTotals]
           ,[QAPerformedTotals])
     VALUES
           (8
           ,'Provided By'
           ,'Resource is Provided By the related Agent'
           ,'qdata:dataProvider'
           ,'Provided For'
           ,'qdata:dataProvider'
           ,getdate()
           ,1
           ,0		--[IsQARole]
           ,1		--[IsOwnerAgentRole]
           ,0		--[IsAgentToAgentRole]
           ,1		--[IsEntityToAgentRole]
           ,0		--[IsAssessmentAgentRole]
           ,0		--[IsLearningOppAgentRole]
           ,0		--[Totals]
           ,0
           ,0
           ,0
           ,0
           ,0)
GO
*/


INSERT INTO [dbo].[Codes.AssertionType]
           ([Id]
           ,[Title]
           ,[Description]
           ,[SchemaTag]
           ,[ReverseRelation]
           ,[ReverseSchemaTag]
           ,[Created]
           ,[IsActive]
           ,[IsQARole]
           ,[IsOwnerAgentRole]
           ,[IsAgentToAgentRole]
           ,[IsEntityToAgentRole]
           ,[IsAssessmentAgentRole]
           ,[IsLearningOppAgentRole]
           ,[Totals])
     VALUES
           (8
           ,'Provided By'
           ,'Resource is Provided By the related Agent'
           ,'qdata:dataProvider'
           ,'Provided For'
           ,'qdata:dataProvider'
           ,getdate()
           ,1
           ,0		--[IsQARole]
           ,1		--[IsOwnerAgentRole]
           ,0		--[IsAgentToAgentRole]
           ,1		--[IsEntityToAgentRole]
           ,0		--[IsAssessmentAgentRole]
           ,0		--[IsLearningOppAgentRole]
           ,0		--[Totals]
           )
GO

