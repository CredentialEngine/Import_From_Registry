

--23-12-22 Codes.PropertyCategory-Add placeholders for Other Filter and Region

/*
SELECT [Id]
      ,[Title]
      ,[Description]
      ,[SortOrder]
      ,[IsActive]
      ,[SchemaName]
      ,[SchemaUrl]
      ,[Created]
      ,[CodeName]
      ,[InterfaceType]
      ,[PropertyTableName]
      ,[IsConceptScheme]
      ,[SchemeFor]
  FROM [dbo].[Codes.PropertyCategory]

--GO

*/

/*

These are categories for place holder filters like Other Filters. 
There are no property values for these, but don't want confusion where their default categoryId gets assigned to another property

*/
INSERT INTO [dbo].[Codes.PropertyCategory]
           ([Id]
           ,[Title],[Description]
           ,[SortOrder],[IsActive]
           ,[SchemaName],[SchemaUrl]
           ,[Created]
           ,[CodeName]
           ,[InterfaceType]
           ,[PropertyTableName]
           ,[IsConceptScheme]
           ,[SchemeFor])
     VALUES
           (98
           ,'U.S. Regions','Placeholder for virtual category for US Regions'
           ,10,1
           ,'filter:UsRegion', ''
           ,GETDATE()
           ,'us_regions'
           ,NULL
           ,'Codes.PropertyValue'
           ,1
           ,'')
GO
INSERT INTO [dbo].[Codes.PropertyCategory]
           ([Id]
           ,[Title],[Description]
           ,[SortOrder],[IsActive]
           ,[SchemaName],[SchemaUrl]
           ,[Created]
           ,[CodeName]
           ,[InterfaceType]
           ,[PropertyTableName]
           ,[IsConceptScheme]
           ,[SchemeFor])
     VALUES
           (99
           ,'Other Filters','Placeholder for virtual category for Other Filters'
           ,10,1
           ,'filter:OtherFilters', ''
           ,GETDATE()
           ,'OtherFilters'
           ,NULL
           ,'Codes.PropertyValue'
           ,1
           ,'')
GO

