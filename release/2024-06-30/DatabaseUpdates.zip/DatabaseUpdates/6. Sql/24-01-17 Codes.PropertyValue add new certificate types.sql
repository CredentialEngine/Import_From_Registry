-- 24-01-17 Codes.PropertyValue add new certificate types
-- *******************************************************************************************************
--	NOTE: MAKE A COPY OF THIS IN THE FINDER SQL FOLDER AND INCLUDE WITH APPROPRIATE IMPORT RELEASE FOLDER
-- *******************************************************************************************************



/*

SELECT TOP (1000) [Id]
      ,[CategoryId]
      ,[Title]
      ,[Description]
      ,[SortOrder]
      ,[IsActive]
      ,[SchemaName]
      ,[SchemaUrl]
      ,[ParentSchemaName]
      ,[Created]
      ,[Totals]
      ,[IsSubType1]
  FROM [dbo].[Codes.PropertyValue]
  where isactive = 1
  AND CategoryId = 2
  order by title
  go
  */
--set IsActive appropriately before executing
--change sortOrder to make room


--Certificate of Participation should exist as inactive. Actual desc and schema has changed, so just delete
Delete from  [dbo].[Codes.PropertyValue]
 WHERE SchemaName='ceterms:ParticipationCertificate'

--========================
-- updates 
UPDATE [dbo].[Codes.PropertyValue]
   SET [Description] = 'Credential awarded at the Apprentice level for successful completion of an apprenticeship program in industry trades and professions.'
 WHERE schemaName = 'ceterms:ApprenticeshipCertificate'
GO

UPDATE [dbo].[Codes.PropertyValue]
   SET [Description] = 'Credential awarded at the Journeyman level for successful completion of an apprenticeship program in industry trades and professions'
 WHERE schemaName = 'ceterms:JourneymanCertificate'
GO

UPDATE [dbo].[Codes.PropertyValue]
   SET [Description] = 'Credential awarded at the Master level for demonstration of the highest level of skills and performance in industry trades and professions.', Title = 'Master Trade Certificate'
 WHERE schemaName = 'ceterms:MasterCertificate'
GO

UPDATE [dbo].[Codes.PropertyValue]
   SET [Description] = 'Credential which designates participation in, completion of, or demonstration of requisite knowledge and skills for a formal academic or training program, an occupation, or non-formal learning.'
 WHERE schemaName = 'ceterms:Certificate'
GO

-- additions

INSERT [dbo].[Codes.PropertyValue] ( [CategoryId], [Title], [Description], 
	[SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) 
VALUES ( 2, N'Certificate of Participation', N'Credential that acknowledges attendance and/or engagement in an activity.', 
	19, 1, N'ceterms:CertificateOfParticipation', NULL, 'Certificate Types', Getdate(), 0, 0)


INSERT [dbo].[Codes.PropertyValue] ( [CategoryId], [Title], [Description], 
	[SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) 
VALUES ( 2, N'Professional Certificate', N'Credential awarded for demonstrating competencies in a profession or particular occupational field, including job readiness.', 
	19, 1, N'ceterms:ProfessionalCertificate', NULL, 'Certificate Types', Getdate(), 0, 0)

INSERT [dbo].[Codes.PropertyValue] ( [CategoryId], [Title], [Description], 
	[SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) 
VALUES ( 2, N'Proficiency  Certificate', N'Credential awarded after assessment of skills in a specific area defined by a recognized body of experts, without regard for how the skills were learned. ', 
	19, 1, N'ceterms:ProficiencyCertificate', NULL, 'Certificate Types', Getdate(), 0, 0)

INSERT [dbo].[Codes.PropertyValue] ( [CategoryId], [Title], [Description], 
	[SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) 
VALUES ( 2, N'Work-Based Learning Certificate', N'Credential awarded for work-based learning and earn-and-learn models that meet standards and are applicable to industry, trades, occupations, and professions.', 
	19, 1, N'ceterms:WorkbasedLearningCertificate', NULL, 'Certificate Types', Getdate(), 0, 0)

	INSERT [dbo].[Codes.PropertyValue] ( [CategoryId], [Title], [Description], 
	[SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) 
VALUES ( 2, N'PreApprenticeship Certificate', N'Credential awarded to indicate readiness for an apprentice-level program.', 
	19, 1, N'ceterms:PreApprenticeshipCertificate', NULL, 'Certificate Types', Getdate(), 0, 0)


	INSERT [dbo].[Codes.PropertyValue] ( [CategoryId], [Title], [Description], 
	[SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) 
VALUES ( 2, N'Academic Certificate', N'Credential awarded for successful completion of a formal education program, demonstrating requisite knowledge and skills.', 
	19, 1, N'ceterms:AcademicCertificate', NULL, 'Certificate Types', Getdate(), 0, 0)

	INSERT [dbo].[Codes.PropertyValue] ( [CategoryId], [Title], [Description], 
	[SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) 
VALUES ( 2, N'Secondary Education Certificate', N'Credential for successful completion of a formal secondary-level education program that is less than a diploma and does not indicate completion of secondary education graduation requirements.', 
	19, 1, N'ceterms:SecondaryEducationCertificate', NULL, 'Certificate Types', Getdate(), 0, 0)

	
	INSERT [dbo].[Codes.PropertyValue] ( [CategoryId], [Title], [Description], 
	[SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) 
VALUES ( 2, N'Basic Technical Certificate', N'Credential awarded at a postsecondary level for successful completion of a formal education program that is completed within one semester, demonstrating competencies within a specific occupational area, indicating job readiness.', 
	19, 1, N'ceterms:BasicTechnicalCertificate', NULL, 'Certificate Types', Getdate(), 0, 0)
		
	INSERT [dbo].[Codes.PropertyValue] ( [CategoryId], [Title], [Description], 
	[SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) 
VALUES ( 2, N'Technical Level 1 Certificate', N'Credential award at a postsecondary level for successful completion of a formal education program that is more than one semester and less than 1 year, demonstrating competencies within a specific subject area or an occupational area indicating job readiness.', 
	19, 1, N'ceterms:TechnicalLevel1Certificate', NULL, 'Certificate Types', Getdate(), 0, 0)
			
	INSERT [dbo].[Codes.PropertyValue] ( [CategoryId], [Title], [Description], 
	[SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) 
VALUES ( 2, N'Technical Level 2 Certificate', N'Credential award at a postsecondary level for successful completion of a formal education program that is at least 1 year but less than 2 years, demonstrating competencies within a specific subject area or in an occupational area indicating job readiness.', 
	19, 1, N'ceterms:TechnicalLevel2Certificate', NULL, 'Certificate Types', Getdate(), 0, 0)
				
	INSERT [dbo].[Codes.PropertyValue] ( [CategoryId], [Title], [Description], 
	[SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) 
VALUES ( 2, N'Technical Level 3 Certificate', N'Credential award at a postsecondary level for successful completion of a formal education program that is at least 2 years but less than 4 years, demonstrating competencies within specific occupational areas indicating job readiness.', 
	19, 1, N'ceterms:TechnicalLevel3Certificate', NULL, 'Certificate Types', Getdate(), 0, 0)
				
			
	INSERT [dbo].[Codes.PropertyValue] ( [CategoryId], [Title], [Description], 
	[SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) 
VALUES ( 2, N'General Education Level 1 Certificate', N'Credential award at a postsecondary level for successful completion of general education courses that cover a broad range of foundational academic skills and takes less than 1 year.', 
	19, 1, N'ceterms:GeneralEducationLevel1Certificate', NULL, 'Certificate Types', Getdate(), 0, 0)
				
	INSERT [dbo].[Codes.PropertyValue] ( [CategoryId], [Title], [Description], 
	[SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) 
VALUES ( 2, N'General Education Level 2 Certificate', N'Credential award at a postsecondary level for successful completion of general education courses that takes at least 1 year that cover a broad range of foundational academic skills and takes less than 2 years to complete.', 
	19, 1, N'ceterms:GeneralEducationLevel2Certificate', NULL, 'Certificate Types', Getdate(), 0, 0)
				
	INSERT [dbo].[Codes.PropertyValue] ( [CategoryId], [Title], [Description], 
	[SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) 
VALUES ( 2, N'Higher EducationLevel 1 Certificate', N'Credential awarded at the postsecondary level for successful completion of a formal higher education program that takes about one year in a specific subject.', 
	19, 1, N'ceterms:HigherEducationLevel1Certificate', NULL, 'Certificate Types', Getdate(), 0, 0)
				
	INSERT [dbo].[Codes.PropertyValue] ( [CategoryId], [Title], [Description], 
	[SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) 
VALUES ( 2, N'Higher EducationLevel 2 Certificate', N'Credential awarded at the postsecondary level for successful completion of a formal higher education program that takes about two years in a specific subject.', 
	19, 1, N'ceterms:HigherEducationLevel2Certificate', NULL, 'Certificate Types', Getdate(), 0, 0)
				
	INSERT [dbo].[Codes.PropertyValue] ( [CategoryId], [Title], [Description], 
	[SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) 
VALUES ( 2, N'Post Baccalaureate Certificate', N'Credential award that requires completion of an organized program of study at a level beyond that of a bachelor''s degree, which is designed for persons who have completed a baccalaureate degree but does not meet the requirements of a master''s degree.', 
	19, 1, N'ceterms:PostBaccalaureateCertificate', NULL, 'Certificate Types', Getdate(), 0, 0)
					
	INSERT [dbo].[Codes.PropertyValue] ( [CategoryId], [Title], [Description], 
	[SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) 
VALUES ( 2, N'Post-Master Certificate', N'Credential award that requires completion of an organized program of study beyond that of a master''s degree, which is designed for persons who have completed a master''s degree but does not meet the requirements of a doctor''s degree.', 
	19, 1, N'ceterms:PostMasterCertificate', NULL, 'Certificate Types', Getdate(), 0, 0)

--========================


