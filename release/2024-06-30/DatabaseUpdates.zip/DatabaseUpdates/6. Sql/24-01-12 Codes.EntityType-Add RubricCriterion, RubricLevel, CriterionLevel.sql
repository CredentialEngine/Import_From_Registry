

/*


-- 24-01-12 Codes.EntityType-Add RubricCriterion, RubricLevel, CriterionLevel

44 - RubricCriterion
45 - CriterionLevel
46 - RubricLevel
*/



INSERT INTO [dbo].[Codes.EntityTypes]
           ([Id],[Title],Label, [Description],[IsActive], [SchemaName],[Created] , [IsTopLevelEntity], [Totals],[SortOrder])
     VALUES
           (44,'RubricCriterion','Rubric Criterion','Resource providing explicit criteria for ensuring specific and measurable evaluation.',1,'ceasn:RubricCriterion',GETDATE(), 0,0,50)
GO
INSERT INTO [dbo].[Codes.EntityTypes]
           ([Id],[Title],Label, [Description],[IsActive], [SchemaName],[Created] , [IsTopLevelEntity], [Totals],[SortOrder])
     VALUES
           (45,'CriterionLevel','Criterion Level','An individual component or specific element within a criterion that defines a particular aspect or standard for evaluation.',1,'ceasn:CriterionLevel',GETDATE(), 0,0,50)
GO
INSERT INTO [dbo].[Codes.EntityTypes]
           ([Id],[Title],Label, [Description],[IsActive], [SchemaName],[Created] , [IsTopLevelEntity], [Totals],[SortOrder])
     VALUES
           (46,'RubricLevel','Rubric Level','Identifiable point along a developmental progression of competence, achievement or temporal position.',1,'ceasn:RubricLevel',GETDATE(), 0,0,50)
GO