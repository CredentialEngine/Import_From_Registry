
INSERT INTO [dbo].[Codes.PathwayComponentType]
(
	[Id],
    [Title],
    [Description],
    [IsActive],
    [SchemaName],
    [ComponentIcon],
    [Created],
    [Totals],
    [ComponentClassTypeId]
)
VALUES
(
	12,
    'Collection Component',
    'Component which references an external collection..',
    1,
    'ceterms:CollectionComponent',
    'Collection-fa-sharp fa-solid fa-gears',
    getdate(),
    0,
    1
),
(
	13,	
    'Multi Component',
    'Component which is a proxy for multiple resources.',
    1,
    'ceterms:MultiComponent',
    'Multi-fa-solid fa-grid',
    getdate(),
    0,
    1
)
