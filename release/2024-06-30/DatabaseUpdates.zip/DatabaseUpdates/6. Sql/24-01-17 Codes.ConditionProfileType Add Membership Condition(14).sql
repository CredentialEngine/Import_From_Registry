

-- 24-01-17 Codes.ConditionProfileType Add Membership Condition(14)

/*
	delete from [Codes.ConditionProfileType] where id = 14 
*/

INSERT INTO [dbo].[Codes.ConditionProfileType]
           ([Id]
           ,[CategoryId]
           ,[Title]
           ,[ConditionManifestTitle]
           ,[Description]
           ,[SortOrder]
           ,[IsActive]
           ,[IsCommonCondtionType]
           ,[IsLearningOpportunityType]
           ,[IsAssessmentType]
           ,[IsCredentialsConnectionType]
           ,[SchemaName]
           ,[Created]
           ,[Totals]
           ,[CredentialTotals]
           ,[AssessmentTotals]
           ,[LoppTotals])

     VALUES
           (14
           ,15
           ,'Membership  Condition'
           ,'N/A'
           ,'Conditions and requirements to be included as a member.'
           ,25
           ,1
           ,0 -- [IsCommonCondtionType]
           ,0
           ,0
           ,0
           ,'ceterms:membershipCondition'
           ,GetDate()
           ,0
           ,0
           ,0
           ,0)
GO


