
/*
TBD

*/
--

INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId]           ,[Title]           ,[Description]
           ,[SortOrder]           ,[IsActive]
           ,[SchemaName]           
           ,[Created]           ,[Totals]           ,[IsSubType1])
     VALUES
           (58
           ,'Is Non Credit'
           ,''
           ,10,1
           ,'credReport:IsNonCredit'
           ,GETDATE(), 0, 0)
GO
--==== 
--
INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId]           ,[Title]           ,[Description]
           ,[SortOrder]           ,[IsActive]
           ,[SchemaName]           
           ,[Created]           ,[Totals]           ,[IsSubType1])
     VALUES
           (61
           ,'Is Non Credit'
           ,''
           ,10,1
           ,'loppReport:IsNonCredit'
           ,GETDATE(), 0, 0)
GO
