
-- 24-02-14 Update description of Deprecated and suspended
  update [Codes.PropertyValue]
  set Description = 'Awards of the credential have ceased.'
  where [SchemaName]= 'credentialStat:Deprecated'
  go
  update [Codes.PropertyValue]
  set Description = 'Awards of the credential are not available, but may resume.'
  where [SchemaName]= 'credentialStat:Suspended'
  go

  /*

SELECT TOP (1000) [Id]
      ,[CategoryId]
      ,[Title]
      ,[Description]
      ,[SortOrder]
      ,[IsActive]
      ,[SchemaName]
      ,[SchemaUrl]
      ,[ParentSchemaName]
      ,[Created]
      ,[Totals]
      ,[IsSubType1]
  FROM [dbo].[Codes.PropertyValue]
  where CategoryId = 39
  go

  */