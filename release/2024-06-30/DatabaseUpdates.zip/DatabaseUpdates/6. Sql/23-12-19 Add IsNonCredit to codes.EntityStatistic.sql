
--USE [sandbox_credFinder]
--GO
--delete from [dbo].[Counts.EntityStatistic]
--where id = 162

INSERT INTO [dbo].[Counts.EntityStatistic]
           ([Id]
           ,[EntityTypeId]
           ,[CategoryId]
           ,[Title]
           ,[Description]
           ,[SortOrder]
           ,[IsActive]
           ,[SchemaName]
           ,[Totals]
           ,[Created])
     VALUES
           (162
           ,1
		   ,58
           ,'Is Non Credit'
           ,''
           ,25
           ,1
           ,'credReport:IsNonCredit'
           ,1
           ,GETDATE())
GO
INSERT INTO [dbo].[Counts.EntityStatistic]
           ([Id]
           ,[EntityTypeId]
           ,[CategoryId]
           ,[Title]
           ,[Description]
           ,[SortOrder]
           ,[IsActive]
           ,[SchemaName]
           ,[Totals]
           ,[Created])
     VALUES
           (163
           ,7
		   ,61
           ,'Is Non Credit'
           ,''
           ,25
           ,1
           ,'loppReport:IsNonCredit'
           ,0
           ,GETDATE())
GO
--

