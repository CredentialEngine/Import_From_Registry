
/*
Add: conceptScheme for 
EvaluatorCategory


*/
-- =========================================================
--		 Evaluator Category
-- =========================================================
INSERT INTO [dbo].[Codes.PropertyCategory]
           ([Id],[Title] ,[Description]
           ,[SortOrder] ,[IsActive]
           ,[SchemaName] ,[SchemaUrl]
           ,[Created]
           ,[CodeName],[PropertyTableName],[IsConceptScheme],[SchemeFor])
     VALUES
           (102
           ,'Evaluator Category'
           ,'Category of agents that perform evaluation.'
           ,10           ,1
           ,'ceasn:EvaluatorCategory' ,'https://credreg.net/ctdlasn/terms/EvaluatorCategory'
           ,GETDATE()
           ,'EvaluatorCategory' ,'Codes.PropertyValue' ,1
           ,'ceasn:evaluatorType'		
		   )
GO
/** concepts ***
evalCat:Authority evalCat:Automated evalCat:External evalCat:Peer evalCat:Self

*/
INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId] ,[Title] ,[Description]
           ,[SortOrder] ,[IsActive]
           ,[SchemaName] ,[SchemaUrl] ,[ParentSchemaName]
           ,[Created] ,[Totals] ,[IsSubType1])
     VALUES
           (102 ,'Authority'
           ,'Evaluator is an agent with authority over the person, group, or thing being evaluated in the relevant context.'
           ,10,1,'evalCat:Authority'
           ,'https://credreg.net/ctdlasn/vocabs/evalCat/Authority'
		   ,NULL,GETDATE(),0,0)
GO
INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId] ,[Title] ,[Description]
           ,[SortOrder] ,[IsActive]
           ,[SchemaName] ,[SchemaUrl] ,[ParentSchemaName]
           ,[Created] ,[Totals] ,[IsSubType1])
     VALUES
           (102 ,'Automated'
           ,'Evaluator is an automated agent or process.'
           ,10,1,'evalCat:Automated'
           ,'https://credreg.net/ctdlasn/vocabs/evalCat/Automated'
		   ,NULL,GETDATE(),0,0)
GO
INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId] ,[Title] ,[Description]
           ,[SortOrder] ,[IsActive]
           ,[SchemaName] ,[SchemaUrl] ,[ParentSchemaName]
           ,[Created] ,[Totals] ,[IsSubType1])
     VALUES
           (102 ,'External'
           ,'Evaluator is an agent who is outside the context of the person, group, or thing being evaluated.'
           ,10,1,'evalCat:External'
           ,'https://credreg.net/ctdlasn/vocabs/evalCat/External'
		   ,NULL,GETDATE(),0,0)
GO
INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId] ,[Title] ,[Description]
           ,[SortOrder] ,[IsActive]
           ,[SchemaName] ,[SchemaUrl] ,[ParentSchemaName]
           ,[Created] ,[Totals] ,[IsSubType1])
     VALUES
            (102 ,'Peer'
           ,'Evaluator is one or more peers of the person, group, or thing being evaluated'
           ,10,1,'evalCat:Peer'
           ,'https://credreg.net/ctdlasn/vocabs/evalCat/Peer'
		   ,NULL,GETDATE(),0,0)
GO
INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId] ,[Title] ,[Description]
           ,[SortOrder] ,[IsActive]
           ,[SchemaName] ,[SchemaUrl] ,[ParentSchemaName]
           ,[Created] ,[Totals] ,[IsSubType1])
     VALUES
           (102 ,'Self'
           ,'Evaluator is the person or group being evaluated.'
           ,10,1,'evalCat:Self'
           ,'https://credreg.net/ctdlasn/vocabs/evalCat/Self'
		   ,NULL,GETDATE(),0,0)
GO
