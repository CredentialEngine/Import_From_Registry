
--	Entity.DurationProfile update DurationSummary for proper range
--watch where weeks and hours are included
UPDATE [dbo].[Entity.DurationProfile]
   SET [DurationSummary] = convert(varchar,FromWeeks) + ' - ' + convert(varchar,ToWeeks )+ ' Weeks'
--	select *, convert(varchar,FromWeeks) + ' - ' + convert(varchar,ToWeeks )+ ' Weeks' as d2 from [Entity.DurationProfile]
 WHERE [TypeId] = 2
 and FromWeeks> 0 and ToWeeks > 0
 and FromHours = 0 and ToHours = 0
GO

--note sometimes there is a range say in months and hours!
UPDATE [dbo].[Entity.DurationProfile]
   SET [DurationSummary] = convert(varchar,FromHours) + ' - ' + convert(varchar,ToHours )+ ' Hours'
--	select *, convert(varchar,FromHours) + ' - ' + convert(varchar,ToHours )+ ' Hours' as d2 from [Entity.DurationProfile]
 WHERE [TypeId] = 2
 and FromHours> 0 and ToHours > 0
  and FromMonths = 0 and  ToMonths = 0
 and FromMinutes = 0 and  ToMinutes = 0
GO


--note sometimes there is a range say in months and hours!
UPDATE [dbo].[Entity.DurationProfile]
   SET [DurationSummary] = convert(varchar,FromMonths) + ' - ' + convert(varchar,ToMonths )+ ' Months'
--	select *, convert(varchar,FromMonths) + ' - ' + convert(varchar,ToMonths )+ ' Months' as d2 from [Entity.DurationProfile]
 WHERE [TypeId] = 2
 and FromMonths> 0 and ToMonths > 0
  and FromYears = 0 and  ToYears = 0
   and FromHours = 0 and ToHours = 0
GO


--years, with no months
UPDATE [dbo].[Entity.DurationProfile]
   SET [DurationSummary] = convert(varchar,FromYears) + ' - ' + convert(varchar,ToYears )+ ' Years'
--	select *, convert(varchar,FromYears) + ' - ' + convert(varchar,ToYears )+ ' Years' as d2 from [Entity.DurationProfile]
 WHERE [TypeId] = 2
 and FromYears > 0 and ToYears > 0
    and FromMonths = 0 and  ToMonths = 0
   and FromHours = 0 and ToHours = 0
GO


