

--************************************************************************************
--		TODO THIS MAY BE OBSOLETE WITH THE ADDITION OF Codes.CredentialingActionType
--************************************************************************************
--WHEN DECIDED, do the following deletes
--24-02-06 - now removing


DELETE FROM [dbo].[Codes.PropertyValue]
  where CategoryId = 26
GO

DELETE FROM [dbo].[Codes.PropertyCategory]
  where Id = 26
GO


--	23-11-08 Codes.PropertyCategory add Credentialing Action Type
--UPDATE [dbo].[Codes.PropertyCategory]
--   SET [Title] = 'Learning Opportunity Subclass'
--      ,[Description] = 'Learning Opportunity Sub-Types'
--      ,[IsActive] = 1
--      ,[CodeName] = 'loppType'
--      ,[PropertyTableName] = 'Codes.PropertyValue'

--  where Id = 3
--GO


--UPDATE [dbo].[Codes.PropertyCategory]
--   SET [Title] = 'Credentialing Action Type'
--      ,[Description] = 'Types of credentialing actions'
--      ,[IsActive] = 1
--      ,[CodeName] = 'credentialingActionType'
--      ,[PropertyTableName] = 'Codes.PropertyValue'
--	  ,Created = '2023-10-23 11:30'
--  where Id = 26
--GO


/*

INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId] ,[Title] ,[Description] ,[SortOrder] ,[IsActive]
           ,[SchemaName] ,[SchemaUrl] ,[ParentSchemaName] ,[Created] ,[Totals] ,[IsSubType1])
     VALUES
           (26 ,'Accredit Action'
           ,'Action by an independent, neutral, and authoritative agent that certifies an entity as meeting a prescribed set of standards.'
           ,25 ,1 ,'ceterms:AccreditAction'
           ,'https://credreg.net/ctdl/terms/AccreditAction'
           ,NULL ,GETDATE() ,0 ,0
		   )
GO

INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId] ,[Title] ,[Description] ,[SortOrder] ,[IsActive]
           ,[SchemaName] ,[SchemaUrl] ,[ParentSchemaName] ,[Created] ,[Totals] ,[IsSubType1])
     VALUES
           (26 ,'Advanced Standing Action'
           ,'Claim by an agent asserting that the object credential of the action provides advanced standing for a credential under the asserting agent''s authority.'
           ,25 ,1 ,'ceterms:AdvancedStandingAction'
           ,'https://credreg.net/ctdl/terms/AdvancedStandingAction'
           ,NULL ,GETDATE() ,0 ,0
		   )
GO

INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId] ,[Title] ,[Description] ,[SortOrder] ,[IsActive]
           ,[SchemaName] ,[SchemaUrl] ,[ParentSchemaName] ,[Created] ,[Totals] ,[IsSubType1])
     VALUES
           (26 ,'Approve Action'
           ,'Action by an independent, neutral, and authoritative agent that pronounces a favorable judgment of a credential.'
           ,25 ,1 ,'ceterms:ApproveAction'
           ,'https://credreg.net/ctdl/terms/ApproveAction'
           ,NULL ,GETDATE() ,0 ,0
		   )
GO

INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId] ,[Title] ,[Description] ,[SortOrder] ,[IsActive]
           ,[SchemaName] ,[SchemaUrl] ,[ParentSchemaName] ,[Created] ,[Totals] ,[IsSubType1])
     VALUES
           (26 ,'Credentialing Action'
           ,'Action taken by an agent affecting the status of an object entity.'
           ,25 ,1 ,'ceterms:CredentialingAction'
           ,'https://credreg.net/ctdl/terms/CredentialingAction'
           ,NULL ,GETDATE() ,0 ,0
		   )
GO

INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId] ,[Title] ,[Description] ,[SortOrder] ,[IsActive]
           ,[SchemaName] ,[SchemaUrl] ,[ParentSchemaName] ,[Created] ,[Totals] ,[IsSubType1])
     VALUES
           (26 ,'Offer Action'
           ,'Action by an authoritative agent offering access to a entity such as a credential, learning opportunity or assessment.'
           ,25 ,1 ,'ceterms:OfferAction'
           ,'https://credreg.net/ctdl/terms/OfferAction'
           ,NULL ,GETDATE() ,0 ,0
		   )
GO

INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId] ,[Title] ,[Description] ,[SortOrder] ,[IsActive]
           ,[SchemaName] ,[SchemaUrl] ,[ParentSchemaName] ,[Created] ,[Totals] ,[IsSubType1])
     VALUES
           (26 ,'Recognize Action'
           ,'Action by an independent, neutral, and authoritative agent acknowledging the validity of a resource.'
           ,25 ,1 ,'ceterms:RecognizeAction'
           ,'https://credreg.net/ctdl/terms/RecognizeAction'
           ,NULL ,GETDATE() ,0 ,0
		   )
GO

INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId] ,[Title] ,[Description] ,[SortOrder] ,[IsActive]
           ,[SchemaName] ,[SchemaUrl] ,[ParentSchemaName] ,[Created] ,[Totals] ,[IsSubType1])
     VALUES
           (26 ,'Regulate Action'
           ,'Action by an independent, neutral, and authoritative agent enforcing the legal requirements of a resource.'
           ,25 ,1 ,'ceterms:RegulateAction'
           ,'https://credreg.net/ctdl/terms/RegulateAction'
           ,NULL ,GETDATE() ,0 ,0
		   )
GO

INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId] ,[Title] ,[Description] ,[SortOrder] ,[IsActive]
           ,[SchemaName] ,[SchemaUrl] ,[ParentSchemaName] ,[Created] ,[Totals] ,[IsSubType1])
     VALUES
           (26 ,'Renew Action'
           ,'Action by an agent renewing an existing credential assertion.'
           ,25 ,1 ,'ceterms:RenewAction'
           ,'https://credreg.net/ctdl/terms/RenewAction'
           ,NULL ,GETDATE() ,0 ,0
		   )
GO


INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId] ,[Title] ,[Description] ,[SortOrder] ,[IsActive]
           ,[SchemaName] ,[SchemaUrl] ,[ParentSchemaName] ,[Created] ,[Totals] ,[IsSubType1])
     VALUES
           (26 ,'Revoke Action'
           ,'Action by an agent removing an awarded credential (credential assertion) from the credential holder based on violations or failure of the holder to renew.'
           ,25 ,1 ,'ceterms:RevokeAction'
           ,'https://credreg.net/ctdl/terms/RevokeAction'
           ,NULL ,GETDATE() ,0 ,0
		   )
GO

INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId] ,[Title] ,[Description] ,[SortOrder] ,[IsActive]
           ,[SchemaName] ,[SchemaUrl] ,[ParentSchemaName] ,[Created] ,[Totals] ,[IsSubType1])
     VALUES
           (26 ,'Rights Action'
           ,'Action asserting legal rights by an agent to possess, defend, transfer, license, and grant conditional access to a credential, learning opportunity, or assessment.'
           ,25 ,1 ,'ceterms:RightsAction'
           ,'https://credreg.net/ctdl/terms/RightsAction'
           ,NULL ,GETDATE() ,0 ,0
		   )
GO

INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId] ,[Title] ,[Description] ,[SortOrder] ,[IsActive]
           ,[SchemaName] ,[SchemaUrl] ,[ParentSchemaName] ,[Created] ,[Totals] ,[IsSubType1])
     VALUES
           (26 ,':Workforce Demand Action'
           ,'Action taken by an agent asserting that the resource being described has a workforce demand level worthy of note.'
           ,25 ,1 ,'ceterms::WorkforceDemandAction'
           ,'https://credreg.net/ctdl/terms/:WorkforceDemandAction'
           ,NULL ,GETDATE() ,0 ,0
		   )
GO

UPDATE [dbo].[Codes.PropertyValue]
   SET [Title] = 'Workforce Demand Action',  SchemaName='ceterms:WorkforceDemandAction'
  where SchemaName='ceterms::WorkforceDemandAction'
GO

INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId] ,[Title] ,[Description] ,[SortOrder] ,[IsActive]
           ,[SchemaName] ,[SchemaUrl] ,[ParentSchemaName] ,[Created] ,[Totals] ,[IsSubType1])
     VALUES
           (26 ,'Registration Action'
           ,'Action by an independent, neutral, and authoritative agent that registers a resource that has been vetted, approved, and validated to meet specific criteria.'
           ,25 ,1 ,'ceterms:RegistrationAction'
           ,'https://credreg.net/ctdl/terms/RegistrationAction'
           ,NULL ,GETDATE() ,0 ,0
		   )
GO

*/
