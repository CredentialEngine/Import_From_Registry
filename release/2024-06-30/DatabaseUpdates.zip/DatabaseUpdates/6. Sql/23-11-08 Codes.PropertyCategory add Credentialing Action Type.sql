

--************************************************************************************
--		TODO THIS MAY BE OBSOLETE WITH THE ADDITION OF Codes.CredentialingActionType
--************************************************************************************
--WHEN DECIDED, do the following deletes
--24-02-06 - now removing


DELETE FROM [dbo].[Codes.PropertyValue]
  where CategoryId = 26
GO

DELETE FROM [dbo].[Codes.PropertyCategory]
  where Id = 26
GO

