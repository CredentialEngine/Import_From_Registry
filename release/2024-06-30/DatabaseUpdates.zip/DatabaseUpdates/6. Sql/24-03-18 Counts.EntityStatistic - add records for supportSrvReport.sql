
-- 24-03-18 Counts.EntityStatistic - add records for supportSrvReport

/*
-- add property category. stop don't really need this any more, just make nullable (already is)
--	retain entityTypeId - although it also may not be necessary 
INSERT INTO [dbo].[Codes.PropertyCategory]
           ([Id]
           ,[Title]
           ,[Description]
           ,[SortOrder]
           ,[IsActive]
           ,[SchemaName]
           ,[SchemaUrl]
           ,[Created]
           ,[CodeName]
           ,[InterfaceType]
           ,[PropertyTableName])
     VALUES
           (104
           ,'Support Service Report Item'
           ,'List of Support Service related report items'
           ,10 ,1 ,'SupportServiceReport' ,NULL ,Getdate() ,'SupportServiceReports' ,NULL ,NULL )
GO
*/
-- ==== ADD value to EntityStatistic
--NOTE: review whether we can change the Id to be an Identity. 

INSERT INTO [dbo].[Counts.EntityStatistic]
           ([Id]
           ,[EntityTypeId] ,[CategoryId] ,[Title] ,[Description]
           ,[SortOrder] ,[IsActive] ,[SchemaName] ,[Totals] ,[Created])
     VALUES
           (180 
		   ,38 ,NULL ,'Is Available Online'
           ,'A Support service has the property: IsAvailableOnline.'
           ,25 ,1 ,'supportSrvReport:AvailableOnline' ,0 ,GETDATE())
GO
INSERT INTO [dbo].[Counts.EntityStatistic]
           ([Id]
           ,[EntityTypeId] ,[CategoryId] ,[Title] ,[Description]
           ,[SortOrder] ,[IsActive] ,[SchemaName] ,[Totals] ,[Created])
     VALUES
           (181
		   ,38 ,NULL ,'Has Cost Profile'
           ,'A Support service has the property: CostProfile.'
           ,25 ,1 ,'supportSrvReport:HasCostProfile' ,0 ,GETDATE())
GO
INSERT INTO [dbo].[Counts.EntityStatistic]
           ([Id]
           ,[EntityTypeId] ,[CategoryId] ,[Title] ,[Description]
           ,[SortOrder] ,[IsActive] ,[SchemaName] ,[Totals] ,[Created])
     VALUES
           (182 
		   ,38 ,NULL ,'References Common Conditions'
           ,'A Support service has the property: hasCommonConditions.'
           ,25 ,1 ,'supportSrvReport:ReferencesCommonConditions' ,0 ,GETDATE())
GO
--

INSERT INTO [dbo].[Counts.EntityStatistic]
           ([Id]
           ,[EntityTypeId] ,[CategoryId] ,[Title] ,[Description]
           ,[SortOrder] ,[IsActive] ,[SchemaName] ,[Totals] ,[Created])
     VALUES
           (183
		   ,38 ,NULL ,'References Common Costs'
           ,'A Support service has the property: ReferencesCommonCosts.'
           ,25 ,1 ,'supportSrvReport:ReferencesCommonCosts' ,0 ,GETDATE())
GO
INSERT INTO [dbo].[Counts.EntityStatistic]
           ([Id]
           ,[EntityTypeId] ,[CategoryId] ,[Title] ,[Description]
           ,[SortOrder] ,[IsActive] ,[SchemaName] ,[Totals] ,[Created])
     VALUES
           (184 
		   ,38 ,NULL ,'Has Financial Aid'
           ,'A Support service has the property: FinancialAid.'
           ,25 ,1 ,'supportSrvReport:FinancialAid' ,0 ,GETDATE())
GO
--

INSERT INTO [dbo].[Counts.EntityStatistic]
           ([Id]
           ,[EntityTypeId] ,[CategoryId] ,[Title] ,[Description]
           ,[SortOrder] ,[IsActive] ,[SchemaName] ,[Totals] ,[Created])
     VALUES
           (185
		   ,38 ,NULL ,'Has Occupations'
           ,'A Support service has the property: HasOccupations.'
           ,25 ,1 ,'supportSrvReport:HasOccupations' ,0 ,GETDATE())
GO
INSERT INTO [dbo].[Counts.EntityStatistic]
           ([Id]
           ,[EntityTypeId] ,[CategoryId] ,[Title] ,[Description]
           ,[SortOrder] ,[IsActive] ,[SchemaName] ,[Totals] ,[Created])
     VALUES
           (186
		   ,38 ,NULL ,'Has Address(es)'
           ,'A Support service has the property: Addresses.'
           ,25 ,1 ,'supportSrvReport:HasAddresses' ,0 ,GETDATE())
GO