
-- 24-04-18 add entity.agentrelationship owned for competency frameworks

INSERT INTO [dbo].[Entity.AgentRelationship]
           ([EntityId]
           ,[RelationshipTypeId]
           ,[AgentUid]
           ,[Created]
           ,[LastUpdated]
           ,[RowId]
           ,[IsInverseRole])


SELECT e.Id, 6, org.RowId, a.Created, a.LastUpdated, newID(), 1

--,a.[Id]
--      ,a.[Name]
--      ,a.[EntityStateId]
--      ,a.[CTID]
--      ,a.[OrganizationCTID], org.Name as orgName
--	        ,a.[Created]
--      ,a.[LastUpdated]
--      ,a.[SourceUrl]
--      ,a.[ExistsInRegistry]
--      ,a.[CredentialRegistryId]
--     ,a.[FrameworkUri]
--      ,a.[RowId]
--      ,a.[Description]
--      ,a.[CompetencyFrameworkGraph]
--      ,a.[CompetenciesStore]
--      ,a.[TotalCompetencies]
--      ,a.[CompetencyFrameworkHierarchy]
--	select count(*) as ttl
  FROM [dbo].[CompetencyFramework] a
  inner join Organization org on a.OrganizationCTID = org.CTID		--1113
  inner join entity e on a.RowId = e.EntityUid						--1363
  Left join [Entity.AgentRelationship] ear on e.id = ear.EntityId
  where a.[EntityStateId] > 2	--1729
  and ear.Id is null 
 -- and org.id is null 
  --and e.id is null
  order by a.id desc 
