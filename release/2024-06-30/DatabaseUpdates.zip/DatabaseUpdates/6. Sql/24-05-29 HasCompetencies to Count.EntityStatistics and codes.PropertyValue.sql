

INSERT INTO [dbo].[Codes.PropertyValue]
    ([CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [Created], [Totals], [IsSubType1])
VALUES
    (58, 'Has Competencies', '', 10, 32, 'jobReport:HasCompetencies', GETDATE(), 0, 0),
    (58, 'Has Competencies', '', 10, 33, 'taskReport:HasCompetencies', GETDATE(), 0, 0),
    (58, 'Has Competencies', '', 10, 34, 'workroleReport:HasCompetencies', GETDATE(), 0, 0),
    (58, 'Has Competencies', '', 10, 35, 'occupationReport:HasCompetencies', GETDATE(), 0, 0);



--
INSERT INTO [dbo].[Counts.EntityStatistic]
    ([Id], [EntityTypeId], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [Totals], [Created])
VALUES
    (190, 32, 58, 'Has Competencies', '', 25, 1, 'jobReport:HasCompetencies', 1, GETDATE()),
    (191, 33, 59, 'Has Competencies', '', 25, 1, 'taskReport:HasCompetencies', 1, GETDATE()),
    (192, 34, 60, 'Has Competencies', '', 25, 1, 'workroleReport:HasCompetencies', 1, GETDATE()),
	(193, 35, 60, 'Has Competencies', '', 25, 1, 'occupationReport:HasCompetencies', 1, GETDATE());



