
/*
TBD

*/
--

INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId]           ,[Title]           ,[Description]
           ,[SortOrder]           ,[IsActive]
           ,[SchemaName]           
           ,[Created]           ,[Totals]           ,[IsSubType1])
     VALUES
           (102
           ,'Authority'
           ,'Evaluator is an agent with authority over the person, group, or thing being evaluated in the relevant context.'
           ,10,1
           ,'evalCat:Authority'
           ,GETDATE(), 0, 0)
GO
INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId]           ,[Title]           ,[Description]
           ,[SortOrder]           ,[IsActive]
           ,[SchemaName]           
           ,[Created]           ,[Totals]           ,[IsSubType1])
     VALUES
           (102
           ,'Automated'
           ,'Evaluator is an automated agent or process.'
           ,10,1
           ,'evalCat:Automated'
           ,GETDATE(), 0, 0)
GO
INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId]           ,[Title]           ,[Description]
           ,[SortOrder]           ,[IsActive]
           ,[SchemaName]           
           ,[Created]           ,[Totals]           ,[IsSubType1])
     VALUES
           (102
           ,'External'
           ,'Evaluator is an agent who is outside the context of the person, group, or thing being evaluated.'
           ,10,1
           ,'evalCat:External'
           ,GETDATE(), 0, 0)
GO
--==== 
--
INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId]           ,[Title]           ,[Description]
           ,[SortOrder]           ,[IsActive]
           ,[SchemaName]           
           ,[Created]           ,[Totals]           ,[IsSubType1])
     VALUES
           (102
           ,'Peer'
           ,'Evaluator is one or more peers of the person, group, or thing being evaluated'
           ,10,1
           ,'evalCat:Peer'
           ,GETDATE(), 0, 0)
GO
INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId]           ,[Title]           ,[Description]
           ,[SortOrder]           ,[IsActive]
           ,[SchemaName]           
           ,[Created]           ,[Totals]           ,[IsSubType1])
     VALUES
           (102
           ,'Self'
           ,'Evaluator is the person or group being evaluated.'
           ,10,1
           ,'evalCat:Self'
           ,GETDATE(), 0, 0)
GO
