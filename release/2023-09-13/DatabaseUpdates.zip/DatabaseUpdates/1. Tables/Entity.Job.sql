use credFinder
go
--USE [sandbox_credFinder]
--GO

/****** Object:  Table [dbo].[Entity.Job]    Script Date: 6/5/2023 8:29:47 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
--Drop TABLE [dbo].[Entity.Job]
--go

CREATE TABLE [dbo].[Entity.Job](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[EntityId] [int] NOT NULL,
	[JobId] [int] NOT NULL,
	[Created] [datetime] NULL,
	[RelationshipTypeId] [int] NOT NULL,
 CONSTRAINT [PK_Entity.Job] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Entity.Job] ADD  CONSTRAINT [DF_Entity.Job_RelationshipTypeId]  DEFAULT ((1)) FOR [RelationshipTypeId]
GO

ALTER TABLE [dbo].[Entity.Job]  WITH CHECK ADD  CONSTRAINT [FK_Entity.Job_Entity] FOREIGN KEY([EntityId])
REFERENCES [dbo].[Entity] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Entity.Job] CHECK CONSTRAINT [FK_Entity.Job_Entity]
GO

ALTER TABLE [dbo].[Entity.Job]  WITH CHECK ADD  CONSTRAINT [FK_Entity.Job_Job] FOREIGN KEY([JobId])
REFERENCES [dbo].[JobProfile] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Entity.Job] CHECK CONSTRAINT [FK_Entity.Job_Job]
GO


