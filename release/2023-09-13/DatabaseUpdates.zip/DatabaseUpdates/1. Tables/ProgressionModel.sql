USE [sandbox_credFinder]
GO

/****** Object:  Table [dbo].[ProgressionModel]    Script Date: 7/17/2023 4:25:42 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ProgressionModel](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[RowId] [uniqueidentifier] NOT NULL,
	[OrganizationId] [int] NOT NULL,
	[EntityStateId] [int] NOT NULL,
	[Name] [nvarchar](400) NOT NULL,
	[Description] [nvarchar](max) NULL,
	[CTID] [varchar](50) NULL,
	[Source] [varchar](500) NULL,
	[CredentialRegistryId] [varchar](50) NULL,
	[PublicationStatusType] [varchar](100) NULL,
	[ProgressionLevels] [varchar](max) NULL,
	[Created] [datetime] NOT NULL,
	[LastUpdated] [datetime] NOT NULL,
 CONSTRAINT [PK_ProgressionModel] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON ) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[ProgressionModel] ADD  CONSTRAINT [DF_ProgressionModel_RowId]  DEFAULT (newid()) FOR [RowId]
GO

ALTER TABLE [dbo].[ProgressionModel] ADD  CONSTRAINT [DF_ProgressionModel_EntityStateId]  DEFAULT ((1)) FOR [EntityStateId]
GO

ALTER TABLE [dbo].[ProgressionModel] ADD  CONSTRAINT [DF_ProgressionModel_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[ProgressionModel] ADD  CONSTRAINT [DF_ProgressionModel_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO

ALTER TABLE [dbo].[ProgressionModel]  WITH CHECK ADD  CONSTRAINT [FK_ProgressionModel_Organization] FOREIGN KEY([OrganizationId])
REFERENCES [dbo].[Organization] ([Id])
GO

ALTER TABLE [dbo].[ProgressionModel] CHECK CONSTRAINT [FK_ProgressionModel_Organization]
GO

