USE [credFinder]
GO

use sandbox_credFinder
go

use credFinder_prod
go
use credFinder_github
go

--use staging_credFinder
--go
use ctdleditor 
go
use sandbox_ctdlEditor
go
--use ctdlEditor_prod
--go


/****** Object:  Table [dbo].[Codes.ChildRelationshipType]    Script Date: 9/27/2022 12:30:28 PM ******/

/*
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Codes.ChildRelationshipType]
(
	[Id] [int] NOT NULL,
	[Title] [varchar](200) NOT NULL,
	[InverseTitle] [varchar](200) NOT NULL,
	[Description] [varchar](2000) NULL,
	[SortOrder] [int] NULL,
	[IsActive] [bit] NULL,
	[SchemaName] [varchar](100) NULL,
	[Created] [datetime] NULL,

 CONSTRAINT [PK_Codes.ChildRelationshipType] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Codes.ChildRelationshipType] ADD  CONSTRAINT [DF_Codes.ChildRelationshipType_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO

ALTER TABLE [dbo].[Codes.ChildRelationshipType] ADD  CONSTRAINT [DF_Codes.ChildRelationshipType_Created]  DEFAULT (getdate()) FOR [Created]
GO
*/

-- add data


INSERT INTO [dbo].[Codes.ChildRelationshipType]
           ([Id]           ,[Title]           ,[InverseTitle]  ,[SchemaName]  
           ,[Description]           ,[SortOrder]           ,[IsActive]                  ,[Created])
     VALUES
           (1 ,'Has Part' ,'Is Part Of' ,'ceterms:hasPart' ,'The related resource is part of the parent resource.'
           ,25,1,getdate() )
GO

INSERT INTO [dbo].[Codes.ChildRelationshipType]
           ([Id]           ,[Title]           ,[InverseTitle]  ,[SchemaName]  
           ,[Description]           ,[SortOrder]           ,[IsActive]                  ,[Created])
     VALUES
           (2 ,'Is Part Of' ,'Has Part' ,'ceterms:isPartPart' ,'The related resource has the parent resource as a part.'
           ,25,1,getdate() )
GO


INSERT INTO [dbo].[Codes.ChildRelationshipType]
           ([Id]           ,[Title]           ,[InverseTitle]  ,[SchemaName]  
           ,[Description]           ,[SortOrder]           ,[IsActive]                  ,[Created])
     VALUES
           (3 ,'Is ETPL Resource  ??IN USE??' ,'On ETPL List?' ,'etplResource' ,'The related resource is on the ETPL list for the parent resource. '
           ,25,1,getdate() )
GO


INSERT INTO [dbo].[Codes.ChildRelationshipType]
           ([Id]           ,[Title]           ,[InverseTitle]  ,[SchemaName]  
           ,[Description]           ,[SortOrder]           ,[IsActive]                  ,[Created])
     VALUES
           (4 ,'Has Target Resource' ,'Is Target Resource' ,'targetResource' ,'The related resource is a target resource of the parent resource.'
           ,25,1,getdate() )
GO

INSERT INTO [dbo].[Codes.ChildRelationshipType]
           ([Id]           ,[Title]           ,[InverseTitle]  ,[SchemaName]  
           ,[Description]           ,[SortOrder]           ,[IsActive]                  ,[Created])
     VALUES
           (5 ,'Has Prerequisite' ,'Is Prerequisite of Resource' ,'targetResource' ,'The related resource is a target resource of the parent resource.'
           ,25,1,getdate() )
GO

-- add 
/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Codes.ChildRelationshipType] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Entity.Assessment] ADD CONSTRAINT
	[FK_Entity.Assessment_ChildRelationshipType] FOREIGN KEY
	(
	RelationshipTypeId
	) REFERENCES dbo.[Codes.ChildRelationshipType]
	(
	Id
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.[Entity.Assessment] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
go

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Codes.ChildRelationshipType] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Entity.Credential] ADD CONSTRAINT
	[FK_Entity.Credential_ChildRelationshipType] FOREIGN KEY
	(
	RelationshipTypeId
	) REFERENCES dbo.[Codes.ChildRelationshipType]
	(
	Id
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.[Entity.Credential] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
go


/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/

BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Codes.ChildRelationshipType] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Entity.LearningOpportunity] ADD CONSTRAINT
	[FK_Entity.Lopp_ChildRelationshipType] FOREIGN KEY
	(
	RelationshipTypeId
	) REFERENCES dbo.[Codes.ChildRelationshipType]
	(
	Id
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.[Entity.LearningOpportunity] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT