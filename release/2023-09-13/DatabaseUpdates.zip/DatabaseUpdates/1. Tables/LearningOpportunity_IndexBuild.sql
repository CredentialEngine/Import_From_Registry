USE [sandbox_credFinder]
GO

/****** Object:  Table [dbo].[LearningOpportunity_IndexBuild]    Script Date: 4/1/2023 2:06:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[LearningOpportunity_IndexBuild](
	[RowNumber] [int] NOT NULL,
	[LearningEntityTypeId] [int] NOT NULL,
	[id] [int] NOT NULL,
	[Name] [varchar](900) NOT NULL,
	[Description] [varchar](max) NOT NULL,
	[OrgId] [int] NOT NULL,
	[Organization] [varchar](500) NOT NULL,
	[OwningOrganizationCtid] [varchar](50) NOT NULL,
	[SubjectWebpage] [varchar](600) NOT NULL,
	[DateEffective] [datetime] NULL,
	[IdentificationCode] [varchar](50) NOT NULL,
	[availableOnlineAt] [varchar](600) NULL,
	[AvailabilityListing] [varchar](600) NULL,
	[Created] [datetime] NULL,
	[LastUpdated] [datetime] NULL,
	[EntityLastUpdated] [datetime] NULL,
	[RowId] [uniqueidentifier] NOT NULL,
	[EntityStateId] [int] NULL,
	[LifeCycleStatusType] [varchar](200) NULL,
	[LifeCycleStatusTypeId] [int] NOT NULL,
	[ConnectionsList] [nvarchar](max) NOT NULL,
	[CredentialsList] [nvarchar](max) NOT NULL,
	[IsNonCredit] [bit] NULL,
	[RequiresCount] [int] NOT NULL,
	[RecommendsCount] [int] NOT NULL,
	[isRequiredForCount] [int] NOT NULL,
	[IsRecommendedForCount] [int] NOT NULL,
	[IsAdvancedStandingForCount] [int] NOT NULL,
	[AdvancedStandingFromCount] [int] NOT NULL,
	[isPreparationForCount] [int] NOT NULL,
	[PreparationFromCount] [int] NOT NULL,
	[NumberOfCostProfileItems] [int] NOT NULL,
	[CostProfilesCount] [int] NOT NULL,
	[ConditionProfilesCount] [int] NOT NULL,
	[TotalCostCount] [int] NOT NULL,
	[CommonCostsCount] [int] NOT NULL,
	[CommonConditionsCount] [int] NOT NULL,
	[FinancialAidCount] [int] NOT NULL,
	[ProcessProfilesCount] [int] NOT NULL,
	[AggregateDataProfileCount] [int] NOT NULL,
	[DataSetProfileCount] [int] NOT NULL,
	[HasTransferValueProfileCount] [int] NOT NULL,
	[HasCIPCount] [int] NOT NULL,
	[HasDurationCount] [int] NOT NULL,
	[LoppConnections] [nvarchar](max) NULL,
	[CompetenciesCount] [int] NOT NULL,
	[CTID] [varchar](50) NOT NULL,
	[CredentialRegistryId] [nvarchar](100) NULL,
	[TextValues] [nvarchar](max) NULL,
	[TeachesCompetencies] [nvarchar](max) NULL,
	[RequiresCompetencies] [nvarchar](max) NULL,
	[AssessesCompetencies] [nvarchar](max) NULL,
	[SubjectAreas] [nvarchar](max) NULL,
	[Classifications] [nvarchar](max) NULL,
	[Frameworks] [nvarchar](max) NULL,
	[LoppProperties] [nvarchar](max) NULL,
	[Languages] [nvarchar](max) NOT NULL,
	[ResourceForWidget] [nvarchar](max) NULL,
	[TransferValueReference] [nvarchar](max) NULL,
	[CollectionMembers] [nvarchar](max) NULL,
	[Org_QAAgentAndRoles] [nvarchar](max) NOT NULL,
	[AgentRelationships] [varchar](1) NOT NULL,
	[QualityAssurances] [varchar](1) NOT NULL,
	[AgentRelationshipsForEntity] [nvarchar](max) NULL,
	[ThirdPartyQualityAssuranceReceived] [nvarchar](max) NULL,
	[Addresses] [nvarchar](max) NULL,
	[OrgAddresses] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


