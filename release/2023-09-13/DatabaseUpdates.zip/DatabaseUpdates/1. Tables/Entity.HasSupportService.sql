use credFinder
go

USE [sandbox_credFinder]
GO



/****** Object:  Table [dbo].[Entity.HasSupportService]    Script Date: 5/12/2023 2:16:15 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Entity.HasSupportService](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[EntityId] [int] NOT NULL,
	[SupportServiceId] [int] NOT NULL,
	[Created] [datetime] NULL,
 CONSTRAINT [PK_Entity.HasSupportService] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Entity.HasSupportService] ADD  CONSTRAINT [DF_Entity.HasSupportService_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Entity.HasSupportService]  WITH CHECK ADD  CONSTRAINT [FK_Entity.HasSupportService_Entity] FOREIGN KEY([EntityId])
REFERENCES [dbo].[Entity] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Entity.HasSupportService] CHECK CONSTRAINT [FK_Entity.HasSupportService_Entity]
GO

ALTER TABLE [dbo].[Entity.HasSupportService]  WITH CHECK ADD  CONSTRAINT [FK_EntityHasSupportService_SupportService] FOREIGN KEY([SupportServiceId])
REFERENCES [dbo].[SupportService] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Entity.HasSupportService] CHECK CONSTRAINT [FK_EntityHasSupportService_SupportService]
GO

