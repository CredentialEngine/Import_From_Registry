USE [credFinder]
GO

/****** Object:  Table [dbo].[Codes.EntityPartsRelationship]    Script Date: 9/10/2023 7:12:36 PM ******/
SET ANSI_NULLS ON
GO
--
SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Codes.EntityPartsRelationship](
	[Id] [int] NOT NULL,
	[Title] [varchar](100) NOT NULL,
	[Description] [varchar](500) NULL,
	[SchemaTag] [varchar](200) NULL,
	[Created] [datetime] NULL,
	[IsActive] [bit] NULL,
	--could be many others, so skipping for now
	--[IsAssessmentRelationship] [bit] NULL,
	--[IsCredentialRelationship] [bit] NULL,
	--[IsLearningOppRelationship] [bit] NULL,

	[Totals] [int] NULL,

 CONSTRAINT [PK_Code.EntityPartsRelationship] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Codes.EntityPartsRelationship] ADD  CONSTRAINT [DF_Codes_EntityPartsRelationship_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Codes.EntityPartsRelationship] ADD  CONSTRAINT [DF_Codes_EntityPartsRelationship_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO

USE [credFinder]
GO

INSERT INTO [dbo].[Codes.EntityPartsRelationship]
           ([Id],[Title],[Description],[SchemaTag],[Created],[IsActive],[Totals])
     VALUES
           (1,'Has Part'
           ,'Also, can be IsTarget - TODO - get context'
           ,'hasPart',getdate() ,1 ,0)
GO


INSERT INTO [dbo].[Codes.EntityPartsRelationship]
           ([Id],[Title],[Description],[SchemaTag],[Created],[IsActive],[Totals])
     VALUES
           (2,'Is Part Of'
           ,'Entity is part of the referenced entity'
           ,'isPartOf',getdate() ,1 ,0)
GO


INSERT INTO [dbo].[Codes.EntityPartsRelationship]
           ([Id],[Title],[Description],[SchemaTag],[Created],[IsActive],[Totals])
     VALUES
           (3,'IsETPLResource '
           ,'This was proposed and not implemented yet as may all be done via collections'
           ,'isETPLResource ',getdate() ,1 ,0)
GO



INSERT INTO [dbo].[Codes.EntityPartsRelationship]
           ([Id],[Title],[Description],[SchemaTag],[Created],[IsActive],[Totals])
     VALUES
           (4,'Has Target Resource'
           ,'TBD on definition'
           ,'hasTargetResource',getdate() ,1 ,0)
GO


INSERT INTO [dbo].[Codes.EntityPartsRelationship]
           ([Id],[Title],[Description],[SchemaTag],[Created],[IsActive],[Totals])
     VALUES
           (5,'Has Prerequisite'
           ,'Learning resource has a prerequisite course'
           ,'hasPrequisite',getdate() ,1 ,0)
GO


INSERT INTO [dbo].[Codes.EntityPartsRelationship]
           ([Id],[Title],[Description],[SchemaTag],[Created],[IsActive],[Totals])
     VALUES
           (6,'TARGET_LOPP'
           ,'TBD'
           ,'targetLopp',getdate() ,1 ,0)
GO

