USE [sandbox_credFinder]
GO

ALTER TABLE [dbo].[Collection.CollectionMember] DROP CONSTRAINT [FK_Collection.CollectionMember_Collection]
GO

ALTER TABLE [dbo].[Collection.CollectionMember] DROP CONSTRAINT [DF_Collection.CollectionMember_RowId]
GO

ALTER TABLE [dbo].[Collection.CollectionMember] DROP CONSTRAINT [DF_Collection.CollectionMember_LastUpdated]
GO

ALTER TABLE [dbo].[Collection.CollectionMember] DROP CONSTRAINT [DF_Collection.CollectionMember_Created]
GO

/****** Object:  Table [dbo].[Collection.CollectionMember]    Script Date: 9/13/2022 4:21:42 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Collection.CollectionMember]') AND type in (N'U'))
DROP TABLE [dbo].[Collection.CollectionMember]
GO

/****** Object:  Table [dbo].[Collection.CollectionMember]    Script Date: 9/13/2022 4:21:42 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Collection.CollectionMember](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[CollectionId] [int] NOT NULL,
	[ProxyFor] [varchar](50) NOT NULL,
	[Name] [varchar](500) NULL,
	[Description] [nvarchar](max) NULL,
	[StartDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
	[EntityTypeId] [int] NULL,
	[Created] [datetime] NULL,
	[LastUpdated] [datetime] NULL,
	[RowId] [uniqueidentifier] NOT NULL,
 CONSTRAINT [PK_Collection.CollectionMember] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[Collection.CollectionMember] ADD  CONSTRAINT [DF_Collection.CollectionMember_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Collection.CollectionMember] ADD  CONSTRAINT [DF_Collection.CollectionMember_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO

ALTER TABLE [dbo].[Collection.CollectionMember] ADD  CONSTRAINT [DF_Collection.CollectionMember_RowId]  DEFAULT (newid()) FOR [RowId]
GO

ALTER TABLE [dbo].[Collection.CollectionMember]  WITH CHECK ADD  CONSTRAINT [FK_Collection.CollectionMember_Collection] FOREIGN KEY([CollectionId])
REFERENCES [dbo].[Collection] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Collection.CollectionMember] CHECK CONSTRAINT [FK_Collection.CollectionMember_Collection]
GO


