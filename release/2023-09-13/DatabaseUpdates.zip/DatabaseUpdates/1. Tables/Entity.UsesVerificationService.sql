
use credFinder
go

use sandbox_credFinder
go


/****** Object:  Table [dbo].[Entity.HasVerificationService]    Script Date: 3/23/2023 1:05:49 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Entity.HasVerificationService]') AND type in (N'U'))
DROP TABLE [dbo].[Entity.HasVerificationService]
GO



--ALTER TABLE [dbo].[Entity.UsesVerificationService] DROP CONSTRAINT [FK_Entity.UsesVerificationService_VSP]
--GO

--ALTER TABLE [dbo].[Entity.UsesVerificationService] DROP CONSTRAINT [FK_Entity.UsesVerificationService_Entity]
--GO

--ALTER TABLE [dbo].[Entity.UsesVerificationService] DROP CONSTRAINT [DF_Entity.UsesVerificationService_Created]
--GO

--/****** Object:  Table [dbo].[Entity.UsesVerificationService]    Script Date: 3/23/2023 11:46:35 AM ******/
--IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Entity.UsesVerificationService]') AND type in (N'U'))
--DROP TABLE [dbo].[Entity.UsesVerificationService]
--GO

/****** Object:  Table [dbo].[Entity.UsesVerificationService]    Script Date: 3/23/2023 11:46:35 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Entity.UsesVerificationService](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[EntityId] [int] NOT NULL,
	[VerificationServiceId] [int] NOT NULL,
	[Created] [datetime] NULL,

 CONSTRAINT [PK_Entity.UsesVerificationService] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Entity.UsesVerificationService] ADD  CONSTRAINT [DF_Entity.UsesVerificationService_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Entity.UsesVerificationService]  WITH CHECK ADD  CONSTRAINT [FK_Entity.UsesVerificationService_Entity] FOREIGN KEY([EntityId])
REFERENCES [dbo].[Entity] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Entity.UsesVerificationService] CHECK CONSTRAINT [FK_Entity.UsesVerificationService_Entity]
GO

ALTER TABLE [dbo].[Entity.UsesVerificationService]  WITH CHECK ADD  CONSTRAINT [FK_Entity.UsesVerificationService_VSP] FOREIGN KEY([VerificationServiceId])
REFERENCES [dbo].[VerificationServiceProfile] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Entity.UsesVerificationService] CHECK CONSTRAINT [FK_Entity.UsesVerificationService_VSP]
GO

-- =====================================================================
--	populate Entity.UsesVerificationService
-- =====================================================================

INSERT INTO [dbo].[Entity.UsesVerificationService]
           ([EntityId]
           ,[VerificationServiceId]
           ,[Created])



SELECT credEntity.Id, a.[Id] as vspId, c.Created
      --,a.[RowId]
      --,a.[CTID]
    --  ,a.[Description]

  FROM [dbo].[VerificationServiceProfile] a
  inner join entity b on a.rowId = b.EntityUid
  inner join [Entity.Credential] c on b.Id = c.EntityId
  inner join credential d on c.CredentialId = d.Id 
  inner join Entity credEntity on d.RowId = credEntity.EntityUid
  order by a.id, d.id 
GO

