USE [sandbox_credFinder]
GO
--use credfinder
--go

--ALTER TABLE [dbo].[SupportService] DROP CONSTRAINT [DF_SupportService_LastUpdated]
--GO

--ALTER TABLE [dbo].[SupportService] DROP CONSTRAINT [DF_SupportService_Created]
--GO

--ALTER TABLE [dbo].[SupportService] DROP CONSTRAINT [DF_SupportService_DateEffective1]
--GO

--ALTER TABLE [dbo].[SupportService] DROP CONSTRAINT [DF_SupportService_Created1]
--GO

--ALTER TABLE [dbo].[SupportService] DROP CONSTRAINT [DF_SupportService_EntityStateId]
--GO

--ALTER TABLE [dbo].[SupportService] DROP CONSTRAINT [DF_SupportService_RowId]
--GO

--/****** Object:  Table [dbo].[SupportService]    Script Date: 5/12/2023 11:08:40 AM ******/
--IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SupportService]') AND type in (N'U'))
--DROP TABLE [dbo].[SupportService]
--GO

/****** Object:  Table [dbo].[SupportService]    Script Date: 5/12/2023 11:08:40 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SupportService](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[RowId] [uniqueidentifier] NOT NULL,
	[CTID] [varchar](50) NOT NULL,
	[EntityStateId] [int] NOT NULL,
	[Name] [nvarchar](600) NULL,
	[Description] [nvarchar](max) NOT NULL,
	[PrimaryAgentUid] [uniqueidentifier] NOT NULL,
	[SubjectWebpage] [nvarchar](600) NULL,
	[AvailableOnlineAt] [nvarchar](max) NULL,
	[AvailabilityListing] [nvarchar](max) NULL,
	[AlternateName] [nvarchar](max) NULL,
	[DateEffective] [datetime] NULL,
	[ExpirationDate] [datetime] NULL,
	[Identifier] [nvarchar](max) NULL,
	[LifeCycleStatusTypeId] [int] NULL,
	[Created] [datetime] NOT NULL,
	[LastUpdated] [datetime] NOT NULL,
	[Keyword] [nvarchar](max) NULL,
 CONSTRAINT [PK_SupportService] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [IX_SupportService_CTID] UNIQUE NONCLUSTERED 
(
	[CTID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [IX_SupportService_RowId] UNIQUE NONCLUSTERED 
(
	[RowId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[SupportService] ADD  CONSTRAINT [DF_SupportService_RowId]  DEFAULT (newid()) FOR [RowId]
GO

ALTER TABLE [dbo].[SupportService] ADD  CONSTRAINT [DF_SupportService_EntityStateId]  DEFAULT ((1)) FOR [EntityStateId]
GO

ALTER TABLE [dbo].[SupportService] ADD  CONSTRAINT [DF_SupportService_Created1]  DEFAULT (getdate()) FOR [DateEffective]
GO

ALTER TABLE [dbo].[SupportService] ADD  CONSTRAINT [DF_SupportService_DateEffective1]  DEFAULT (getdate()) FOR [ExpirationDate]
GO

ALTER TABLE [dbo].[SupportService] ADD  CONSTRAINT [DF_SupportService_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[SupportService] ADD  CONSTRAINT [DF_SupportService_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO


