USE [sandbox_credFinder]
GO

/****** Object:  Table [dbo].[ProgressionModel.ProgressionLevel]    Script Date: 7/17/2023 5:35:23 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ProgressionModel.ProgressionLevel](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[RowId] [uniqueidentifier] NOT NULL,
	[ProgressionModelId] [int] NOT NULL,
	[PrefLabel] [nvarchar](400) NOT NULL,
	[Definition] [nvarchar](max) NOT NULL,
	[CTID] [varchar](50) NULL,
	[IsTopConcept] [bit] NULL,
	[Notation] [nvarchar](100) NULL,
	[Note] [nvarchar](max) NULL,
	[PrecededBy] [varchar](50) NULL,
	[Precedes] [varchar](50) NULL,
	[Broader] [int] NULL,
	[Created] [datetime] NOT NULL,
	[LastUpdated] [datetime] NOT NULL,
	[Properties] [nvarchar](max) NULL,
 CONSTRAINT [PK_ProgressionModel.ProgressionLevel] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON ) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[ProgressionModel.ProgressionLevel] ADD  CONSTRAINT [DF_ProgressionModel.ProgressionLevel_RowId]  DEFAULT (newid()) FOR [RowId]
GO

ALTER TABLE [dbo].[ProgressionModel.ProgressionLevel] ADD  CONSTRAINT [DF_ProgressionModel.ProgressionLevel_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[ProgressionModel.ProgressionLevel] ADD  CONSTRAINT [DF_ProgressionModel.ProgressionLevel_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO

ALTER TABLE [dbo].[ProgressionModel.ProgressionLevel]  WITH CHECK ADD  CONSTRAINT [FK_ProgressionModel.ProgressionLevel_ProgressionModel] FOREIGN KEY([ProgressionModelId])
REFERENCES [dbo].[ProgressionModel] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[ProgressionModel.ProgressionLevel] CHECK CONSTRAINT [FK_ProgressionModel.ProgressionLevel_ProgressionModel]
GO


