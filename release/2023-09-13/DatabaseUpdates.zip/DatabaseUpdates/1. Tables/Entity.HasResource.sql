USE [sandbox_credFinder]
GO

use credFinder
go

/****** Object:  Table [dbo].[Entity.HasResource]    Script Date: 6/23/2023 2:18:33 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Entity.HasResource](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[EntityId] [int] NOT NULL,
	[EntityTypeId] [int] NULL,
	[ResourceId] [int] NULL,
	[Created] [datetime] NULL,
 CONSTRAINT [PK_Entity.HasResource] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Entity.HasResource] ADD  CONSTRAINT [DF_Entity.HasResource_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Entity.HasResource]  WITH CHECK ADD  CONSTRAINT [FK_Entity.HasResource_Entity] FOREIGN KEY([EntityId])
REFERENCES [dbo].[Entity] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Entity.HasResource] CHECK CONSTRAINT [FK_Entity.HasResource_Entity]
GO

ALTER TABLE [dbo].[Entity.HasResource]  WITH CHECK ADD  CONSTRAINT [FK_Entity.HasResource_Entity_Cache] FOREIGN KEY([EntityTypeId], [ResourceId])
REFERENCES [dbo].[Entity_Cache] ([EntityTypeId], [BaseId])
GO

ALTER TABLE [dbo].[Entity.HasResource] CHECK CONSTRAINT [FK_Entity.HasResource_Entity_Cache]
GO


