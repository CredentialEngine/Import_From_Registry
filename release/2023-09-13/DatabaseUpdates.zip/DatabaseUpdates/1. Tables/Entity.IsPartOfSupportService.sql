use credFinder
go

USE [sandbox_credFinder]
GO



/****** Object:  Table [dbo].[Entity.IsPartOfSupportService]    Script Date: 6/14/2023 10:54:02 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Entity.IsPartOfSupportService](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[EntityId] [int] NOT NULL,
	[SupportServiceId] [int] NOT NULL,
	[Created] [datetime] NULL,
 CONSTRAINT [PK_Entity.IsPartOfSupportService] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Entity.IsPartOfSupportService] ADD  CONSTRAINT [DF_Entity.IsPartOfSupportService_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Entity.IsPartOfSupportService]  WITH CHECK ADD  CONSTRAINT [FK_Entity.IsPartOfSupportService_Entity] FOREIGN KEY([EntityId])
REFERENCES [dbo].[Entity] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Entity.IsPartOfSupportService] CHECK CONSTRAINT [FK_Entity.IsPartOfSupportService_Entity]
GO

ALTER TABLE [dbo].[Entity.IsPartOfSupportService]  WITH CHECK ADD  CONSTRAINT [FK_EntityIsPartOfSupportService_SupportService] FOREIGN KEY([SupportServiceId])
REFERENCES [dbo].[SupportService] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Entity.IsPartOfSupportService] CHECK CONSTRAINT [FK_EntityIsPartOfSupportService_SupportService]
GO


