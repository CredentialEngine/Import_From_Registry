use credFinder
go
USE [sandbox_credFinder]
GO

/****** Object:  Table [dbo].[Entity.Occupation]    Script Date: 6/5/2023 8:29:47 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
--Drop TABLE [dbo].[Entity.Occupation]
--go

CREATE TABLE [dbo].[Entity.Occupation](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[EntityId] [int] NOT NULL,
	[OccupationId] [int] NOT NULL,
	[Created] [datetime] NULL,
	[RelationshipTypeId] [int] NOT NULL,
 CONSTRAINT [PK_Entity.Occupation] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Entity.Occupation] ADD  CONSTRAINT [DF_Entity.Occupation_RelationshipTypeId]  DEFAULT ((1)) FOR [RelationshipTypeId]
GO

ALTER TABLE [dbo].[Entity.Occupation]  WITH CHECK ADD  CONSTRAINT [FK_Entity.Occupation_Entity] FOREIGN KEY([EntityId])
REFERENCES [dbo].[Entity] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Entity.Occupation] CHECK CONSTRAINT [FK_Entity.Occupation_Entity]
GO

ALTER TABLE [dbo].[Entity.Occupation]  WITH CHECK ADD  CONSTRAINT [FK_Entity.Occupation_Occupation] FOREIGN KEY([OccupationId])
REFERENCES [dbo].[OccupationProfile] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Entity.Occupation] CHECK CONSTRAINT [FK_Entity.Occupation_Occupation]
GO


