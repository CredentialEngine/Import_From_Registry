USE [sandbox_credFinder]
GO

ALTER TABLE [dbo].[ScheduledOffering] DROP CONSTRAINT [DF_ScheduledOffering_LastUpdated]
GO

ALTER TABLE [dbo].[ScheduledOffering] DROP CONSTRAINT [DF_ScheduledOffering_Created]
GO

ALTER TABLE [dbo].[ScheduledOffering] DROP CONSTRAINT [DF_ScheduledOffering_EntityStateId]
GO

ALTER TABLE [dbo].[ScheduledOffering] DROP CONSTRAINT [DF_ScheduledOffering_RowId]
GO

/****** Object:  Table [dbo].[ScheduledOffering]    Script Date: 3/9/2023 3:49:53 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ScheduledOffering]') AND type in (N'U'))
DROP TABLE [dbo].[ScheduledOffering]
GO

/****** Object:  Table [dbo].[ScheduledOffering]    Script Date: 3/9/2023 3:49:53 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ScheduledOffering](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[RowId] [uniqueidentifier] NOT NULL,
	[CTID] [varchar](50) NOT NULL,
	[EntityStateId] [int] NOT NULL,
	[Name] [nvarchar](600) NOT NULL,
	[Description] [nvarchar](max) NULL,
	[SubjectWebpage] [varchar](600) NULL,
	[DeliveryTypeDescription] [nvarchar](max) NULL,
	[AvailableOnlineAt] [varchar](max) NULL,
	[AvailabilityListing] [varchar](max) NULL,
	[AlternateName] [varchar](max) NULL,
	[Created] [datetime] NOT NULL,
	[LastUpdated] [datetime] NOT NULL,
 CONSTRAINT [PK_ScheduledOffering] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[ScheduledOffering] ADD  CONSTRAINT [DF_ScheduledOffering_RowId]  DEFAULT (newid()) FOR [RowId]
GO

ALTER TABLE [dbo].[ScheduledOffering] ADD  CONSTRAINT [DF_ScheduledOffering_EntityStateId]  DEFAULT ((1)) FOR [EntityStateId]
GO

ALTER TABLE [dbo].[ScheduledOffering] ADD  CONSTRAINT [DF_ScheduledOffering_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[ScheduledOffering] ADD  CONSTRAINT [DF_ScheduledOffering_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO


