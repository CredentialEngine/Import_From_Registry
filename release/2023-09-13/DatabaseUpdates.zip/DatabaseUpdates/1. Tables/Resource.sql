use credFinder
go

USE sandbox_credFinder
GO

/****** Object:  Table [dbo].[Resource]    Script Date: 2/19/2023 1:08:39 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
Questions
- should there be a separate table or just add a new prop somewhere?
- adding a new property to every top level table would be a pain
- could be overkill including the CR graph - means would have to download everything to get it
	- could run the download project to get a starter list
	- currently only have one CredentialRegistryDownload db (not one per env)


====================================================



====================================================
Add indices for
- CTDLType
- CTID
- RowId - if a FK to the credential, etc. 
- [PrimaryOrganizationCTID]

The resource table will contain all top level objects. 
So how is this different from entity_cache?
- Entity_cache was considered, but the latter can be rebuilt, and can't easily add the finder detail 
	- especially where updated from a proc/sql
- Or, maybe review the entity_cache usage 
	- Could have a process like PendingIndex to indentify records needing to rebuild ResourceDetail 
	


*/
CREATE TABLE [dbo].[Resource](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	--TBD should this be the actual credential, etc. rowId? Would ease getting related data from the entity. Although the CTID can be used to get via entity_cache
	[RowId] [uniqueidentifier] NOT NULL,
	--might be useful to just have credential, organization, lopp. Not clear how much filtering would be needed.
	[TopLevelType] [varchar](100) NOT NULL,
	--with namespace removed??
	[CTDLType] [varchar](100) NOT NULL,
	[CTID] [varchar](50) NOT NULL,
	[Name] [nvarchar](800) NOT NULL,
	[Description] [nvarchar](max) NULL,
	--TBD do we need this?
	[SubjectWebpage] [varchar](600) NULL,			
	[PrimaryOrganizationCTID] [varchar](50) NULL,
	--would publisher be useful?
	[Created] [datetime] NULL,
	[LastUpdated] [datetime] NULL,
	[DownloadDate] [datetime] NULL,
	--TBD - don't really care yet, but good to have, except need to handle multiple
	[InLanguageId] [int] NULL,			
	[CredentialRegistryGraph] [nvarchar](max) NULL,
	--this would be detail page ready, but primarily for elastic and then exports
	[CredentialFinderObject] [nvarchar](max) NULL,
 CONSTRAINT [PK_Resource] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[Resource] ADD  CONSTRAINT [DF_Resource_RowId]  DEFAULT (newid()) FOR [RowId]
GO

ALTER TABLE [dbo].[Resource] ADD  CONSTRAINT [DF_Resource_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Resource] ADD  CONSTRAINT [DF_Resource_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO

ALTER TABLE [dbo].[Resource] ADD  CONSTRAINT [DF_Resource_LastUpdated1]  DEFAULT (getdate()) FOR [DownloadDate]
GO


