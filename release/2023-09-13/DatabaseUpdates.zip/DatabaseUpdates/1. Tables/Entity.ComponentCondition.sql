USE [sandbox_credFinder]
GO
use credFinder
go
/****** Object:  Table [dbo].[Entity.ComponentCondition]    Script Date: 10/20/2022 9:47:40 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Entity.ComponentCondition](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[RowId] [uniqueidentifier] NOT NULL,
	[EntityId] [int] NOT NULL,
	[Name] [nvarchar](500) NULL,
	[Description] [varchar](max) NULL,
	[RequiredNumber] [int] NULL,
	[HasConstraint] [varchar](max) NULL,
	[LogicalOperator] [varchar](200) NULL,
	[PathwayCTID] [varchar](50) NULL,
	[Created] [datetime] NULL,
	[LastUpdated] [datetime] NULL,
	[SourceRowId] [uniqueidentifier] NOT NULL,
	[ConditionProperties] [nvarchar](max) NULL,
 CONSTRAINT [PK_Entity.ComponentCondition] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[Entity.ComponentCondition] ADD  CONSTRAINT [DF_Entity.ComponentCondition_RowId]  DEFAULT (newid()) FOR [RowId]
GO

ALTER TABLE [dbo].[Entity.ComponentCondition] ADD  CONSTRAINT [DF_Entity.ComponentCondition_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Entity.ComponentCondition] ADD  CONSTRAINT [DF_Entity.ComponentCondition_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO

ALTER TABLE [dbo].[Entity.ComponentCondition]  WITH CHECK ADD  CONSTRAINT [FK_Entity.ComponentCondition_Entity] FOREIGN KEY([EntityId])
REFERENCES [dbo].[Entity] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Entity.ComponentCondition] CHECK CONSTRAINT [FK_Entity.ComponentCondition_Entity]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [dbo].[trgEntityComponentConditionAfterInsert] ON  [dbo].[Entity.ComponentCondition]
FOR INSERT
AS  
    INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
					 ,EntityBaseId, EntityBaseName)
    SELECT RowId,25, getdate(), Id, Name
    FROM inserted;
GO

ALTER TABLE [dbo].[Entity.ComponentCondition] ENABLE TRIGGER [trgEntityComponentConditionAfterInsert]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [dbo].[trgEntityComponentConditionAfterDelete]
ON [dbo].[Entity.ComponentCondition]
   AFTER DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
		DELETE a	
			FROM [dbo].[Entity] a
			inner join Deleted d on a.EntityUid = d.RowId

END
GO

ALTER TABLE [dbo].[Entity.ComponentCondition] ENABLE TRIGGER trgEntityComponentConditionAfterDelete
GO

