USE [credFinder]
GO

/****** Object:  Table [dbo].[Counts.TransferIntermediary_Property]    Script Date: 10/8/2022 8:23:15 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Counts.TransferIntermediary_Property](
	[Id] [int] NOT NULL,
	[Property] [nvarchar](128) NOT NULL,
	[Label] [varchar](100) NULL,
	[Policy] [varchar](50) NULL,
	[PropertyGroup] [varchar](50) NULL,
	[Total] [int] NOT NULL,
	[PercentOfOverallTotal] [decimal](5, 2) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Counts.TransferIntermediary_Property] ADD  CONSTRAINT [DF_Counts.TransferIntermediary_Property_PercentOfTotal]  DEFAULT ((0.00)) FOR [PercentOfOverallTotal]
GO


