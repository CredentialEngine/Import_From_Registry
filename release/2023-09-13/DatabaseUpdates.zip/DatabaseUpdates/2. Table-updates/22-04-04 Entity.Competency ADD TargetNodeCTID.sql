/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/

use credfinder
go

--use sandbox_credFinder
--go

--use staging_credFinder
--go
--use snhu_credFinder
--go
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Entity.Competency] ADD
	TargetNodeCTID varchar(50) NULL
GO
ALTER TABLE dbo.[Entity.Competency] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
