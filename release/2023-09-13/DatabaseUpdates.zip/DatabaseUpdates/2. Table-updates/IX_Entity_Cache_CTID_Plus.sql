/*
Missing Index Details from PathwayComponentSummary.sql - MPARSONS-CE2.sandbox_credFinder (AzureAD\MichaelParsons (57))
The Query Processor estimates that implementing the following index could improve the query cost by 92.6971%.
*/

/**/
USE [sandbox_credFinder]
GO
CREATE NONCLUSTERED INDEX [IX_Entity_Cache_CTID_Plus]
ON [dbo].[Entity_Cache] ([CTID])
INCLUDE ([EntityType],[Name],[Description])
WHERE ([CTID] IS NOT NULL AND [CTID]<>'')
GO

