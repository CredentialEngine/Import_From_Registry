USE [sandbox_credFinder]
GO
CREATE NONCLUSTERED INDEX [IX_Entity_EntityTypeId_LastUpdated]
ON [dbo].[Entity] ([EntityTypeId])
INCLUDE ([Id],[EntityUid],[LastUpdated])
GO