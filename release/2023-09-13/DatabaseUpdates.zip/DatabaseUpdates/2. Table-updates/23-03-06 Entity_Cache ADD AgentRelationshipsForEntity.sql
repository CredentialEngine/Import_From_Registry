use credfinder 
go
use sandbox_credFinder
go


--propotype 
--23-03-06 Entity_Cache ADD AgentRelationshipsForEntity

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.Entity_Cache ADD
	AgentRelationshipsForEntity nvarchar(MAX) NULL
GO
ALTER TABLE dbo.Entity_Cache SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
go

--populate
--need to define where to update this. Probably after most imports. 
--	MAYBE where Entity.AgentRelationship.LastUpdated > ?????

--	Entity_Cache populate - AgentRelationshipsForEntity 

UPDATE [dbo].[Entity_Cache]
   SET [AgentRelationshipsForEntity] = creds.AgentRelationshipsForEntity
-- select ec.ctid, ec.baseId,ec.Name,creds.LastUpdated,  creds.AgentRelationshipsForEntity 
   from entity_cache ec 
   --inner join credential c on ec.CTID = c.CTID 
   inner join ( 
   select Id, entityStateId, ctid, LastUpdated 
   	 ,(SELECT DISTINCT ear.AgentRelativeId As OrgId, ear.AgentName, ear.AgentUrl, ear.EntityStateId, ear.RoleIds as RelationshipTypeIds,  ear.Roles as Relationships, ear.AgentContextRoles FROM [dbo].[Entity.AgentRelationshipIdCSV] ear
			WHERE ear.EntityTypeId= 1 AND ear.EntityBaseId = base.Id 
			FOR XML RAW, ROOT('AgentRelationshipsForEntity')) AgentRelationshipsForEntity
   from credential base 
   ) creds on ec.CTID = creds.CTID

 WHERE creds.EntityStateId = 3
 and ec.EntityStateId = 3
 and ec.[AgentRelationshipsForEntity] is null 
 --and creds.LastUpdated > '2023-01-01'
GO


UPDATE [dbo].[Entity_Cache]
   SET [AgentRelationshipsForEntity] = creds.AgentRelationshipsForEntity
-- select ec.EntityTypeId, ec.ctid, ec.baseId,ec.Name,creds.LastUpdated,  creds.AgentRelationshipsForEntity 
   from entity_cache ec 
   inner join ( 
   select Id, entityStateId, ctid, LastUpdated 
   	 ,(SELECT DISTINCT ear.AgentRelativeId As OrgId, ear.AgentName, ear.AgentUrl, ear.EntityStateId, ear.RoleIds as RelationshipTypeIds,  ear.Roles as Relationships, ear.AgentContextRoles FROM [dbo].[Entity.AgentRelationshipIdCSV] ear
			WHERE ear.EntityTypeId= 7 AND ear.EntityBaseId = base.Id 
			FOR XML RAW, ROOT('AgentRelationshipsForEntity')) AgentRelationshipsForEntity
   from LearningOpportunity base 
   ) creds on ec.CTID = creds.CTID

 WHERE creds.EntityStateId = 3
 and ec.EntityStateId = 3
 and ec.[AgentRelationshipsForEntity] is null 
 --and creds.LastUpdated > '2023-01-01'
GO
