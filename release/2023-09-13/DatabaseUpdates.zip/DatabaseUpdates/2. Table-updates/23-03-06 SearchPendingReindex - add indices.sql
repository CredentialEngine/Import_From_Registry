USE [sandbox_credFinder]
GO
--	23-03-06 SearchPendingReindex - add indices
CREATE NONCLUSTERED INDEX [IX_SearchPendingReindex_EntityTypeId_StatusId]
ON [dbo].[SearchPendingReindex] ([EntityTypeId],[StatusId])
INCLUDE ([RecordId])
GO
CREATE NONCLUSTERED INDEX [IX_SearchPendingReindex_EntityTypeId_RecordId_StatusId]
ON [dbo].[SearchPendingReindex] ([EntityTypeId],[RecordId],[StatusId])

GO