
use credFinder
go
use sandbox_credFinder
go

--USE [staging_credFinder]
--GO

-- 23-01-17 Entity.Property add missing define of FK to Codes.PropertyValue.Id

BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Codes.PropertyValue] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Entity.Property] ADD CONSTRAINT
	[FK_Entity.Property_Codes.PropertyValue] FOREIGN KEY
	(
	PropertyValueId
	) REFERENCES dbo.[Codes.PropertyValue]
	(
	Id
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
ALTER TABLE dbo.[Entity.Property] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT