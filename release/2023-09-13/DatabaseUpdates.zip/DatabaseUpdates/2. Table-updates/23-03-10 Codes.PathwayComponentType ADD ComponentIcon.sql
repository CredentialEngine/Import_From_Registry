use credFinder
go

--use sandbox_credFinder
--go

--23-03-10 Codes.PathwayComponentType ADD ComponentIcon
--		then populate


BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Codes.PathwayComponentType] ADD
	ComponentIcon varchar(500) NULL
GO
ALTER TABLE dbo.[Codes.PathwayComponentType] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO
/* 
first add entry for Component Condition
*/


INSERT INTO [dbo].[Codes.PathwayComponentType]
           ([Id]
           ,[Title]
           ,[Description]
           ,[IsActive]
           ,[SchemaName]
           ,[Created]
           ,[Totals])
     VALUES
           (11
           ,'Component Condition'
           ,'Resource that describes what must be done to complete a PathwayComponent, or part thereof, as determined by the issuer of the Pathway.'
           ,1
           ,'ceterms:ComponentCondition'
           ,getdate()	
           ,0)
GO


--assessment
UPDATE [dbo].[Codes.PathwayComponentType]
  -- SET [ComponentIcon] = 'https://fontawesome.com/icons/memo-circle-check?s=light&f=classic'
    SET [ComponentIcon] = 'fa-light fa-memo-circle-check'

 WHERE Id = 1
GO
--basic
--https://fontawesome.com/icons/cube?s=light&f=classic
UPDATE [dbo].[Codes.PathwayComponentType]
   SET [ComponentIcon] = 'fa-light fa-cube'
 WHERE Id = 2
GO

--Cocurricular Component
--https://fontawesome.com/icons/atom-simple?s=light&f=classic
UPDATE [dbo].[Codes.PathwayComponentType]
   SET [ComponentIcon] = 'fa-light fa-atom-simple'
 WHERE Id = 3
GO
--Competency Component
--https://fontawesome.com/icons/gear?s=light&f=classic
UPDATE [dbo].[Codes.PathwayComponentType]
    SET [ComponentIcon] = '"fa-light fa-gear'

 WHERE Id = 4
GO

--Course Component
--https://fontawesome.com/icons/cubes?s=light&f=classic
UPDATE [dbo].[Codes.PathwayComponentType]
   SET [ComponentIcon] = 'fa-light fa-cubes'
 WHERE Id = 5
GO


--=================================

--Credential Component
--https://fontawesome.com/icons/star-sharp?s=light&f=classic
UPDATE [dbo].[Codes.PathwayComponentType]
    SET [ComponentIcon] = 'fa-light fa-star-sharp'

 WHERE Id = 6
GO
--Extracurricular Component
--https://fontawesome.com/icons/solar-system?s=light&f=classic
UPDATE [dbo].[Codes.PathwayComponentType]
   SET [ComponentIcon] = 'fa-light fa-solar-system'
 WHERE Id = 7
GO

--Job Component			??????????????????
--using selection for now
--https://fontawesome.com/icons/hand-pointer?s=light&f=classic
--<i class="fa-duotone fa-user-helmet-safety"></i>
UPDATE [dbo].[Codes.PathwayComponentType]
   SET [ComponentIcon] = 'fa-light fa-dolly'
 WHERE Id = 8
GO
--Work Experience Component
--https://fontawesome.com/icons/id-badge?s=light&f=classic
UPDATE [dbo].[Codes.PathwayComponentType]
    SET [ComponentIcon] = '"fa-light fa-id-badge'

 WHERE Id = 9
GO
--Selection Component			??????????????????
--https://fontawesome.com/icons/hand-pointer?s=light&f=classic
UPDATE [dbo].[Codes.PathwayComponentType]
   SET [ComponentIcon] = 'fa-light fa-hand-pointer'
 WHERE Id = 10
GO
--=================================
UPDATE [dbo].[Codes.PathwayComponentType]
   --SET [ComponentIcon] = 'https://fontawesome.com/icons/sitemap?s=light&f=classic'
   SET [ComponentIcon] = 'fa-light sitemap'
 WHERE Id = 11
GO

/*
*/
