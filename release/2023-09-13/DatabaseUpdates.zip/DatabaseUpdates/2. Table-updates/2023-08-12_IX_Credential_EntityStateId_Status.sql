/*
Missing Index Details from CodeTables_UpdateTotals.sql - MPARSONS-CE2.credFinder (AzureAD\MichaelParsons (65))
The Query Processor estimates that implementing the following index could improve the query cost by 98.6749%.
*/

/**/
USE [credFinder]
GO
CREATE NONCLUSTERED INDEX [IX_Credential_EntityStateId_Status]
ON [dbo].[Credential] ([EntityStateId])
INCLUDE ([CredentialStatusTypeId])
GO

