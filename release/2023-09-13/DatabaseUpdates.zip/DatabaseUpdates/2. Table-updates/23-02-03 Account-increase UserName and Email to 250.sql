
--	23-02-03 Account-increase UserName and Email to 250

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_Password
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_IsActive
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_Created
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_LastUpdated
GO
ALTER TABLE dbo.Account
	DROP CONSTRAINT DF_Account_RowId
GO
CREATE TABLE dbo.Tmp_Account
	(
	Id int NOT NULL IDENTITY (1, 1),
	UserName varchar(250) NOT NULL,
	Password varchar(50) NULL,
	FirstName varchar(50) NOT NULL,
	LastName varchar(50) NOT NULL,
	Email varchar(250) NOT NULL,
	IsActive bit NULL,
	Created datetime NOT NULL,
	LastUpdated datetime NOT NULL,
	LastUpdatedById int NULL,
	RowId uniqueidentifier NOT NULL,
	AspNetId nvarchar(128) NULL,
	CEAccountIdentifier varchar(50) NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_Account SET (LOCK_ESCALATION = TABLE)
GO
GRANT SELECT ON dbo.Tmp_Account TO public  AS dbo
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_Password DEFAULT (newid()) FOR Password
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_IsActive DEFAULT ((1)) FOR IsActive
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_Created DEFAULT (getdate()) FOR Created
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_LastUpdated DEFAULT (getdate()) FOR LastUpdated
GO
ALTER TABLE dbo.Tmp_Account ADD CONSTRAINT
	DF_Account_RowId DEFAULT (newid()) FOR RowId
GO
SET IDENTITY_INSERT dbo.Tmp_Account ON
GO
IF EXISTS(SELECT * FROM dbo.Account)
	 EXEC('INSERT INTO dbo.Tmp_Account (Id, UserName, Password, FirstName, LastName, Email, IsActive, Created, LastUpdated, LastUpdatedById, RowId, AspNetId, CEAccountIdentifier)
		SELECT Id, UserName, Password, FirstName, LastName, Email, IsActive, Created, LastUpdated, LastUpdatedById, RowId, AspNetId, CEAccountIdentifier FROM dbo.Account WITH (HOLDLOCK TABLOCKX)')
GO
SET IDENTITY_INSERT dbo.Tmp_Account OFF
GO
DROP TABLE dbo.Account
GO
EXECUTE sp_rename N'dbo.Tmp_Account', N'Account', 'OBJECT' 
GO
ALTER TABLE dbo.Account ADD CONSTRAINT
	PK_Account PRIMARY KEY CLUSTERED 
	(
	Id
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
COMMIT