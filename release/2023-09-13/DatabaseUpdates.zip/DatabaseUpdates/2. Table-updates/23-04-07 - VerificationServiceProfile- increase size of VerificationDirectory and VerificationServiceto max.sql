use credfinder
go


--23-04-07 - VerificationServiceProfile- increase size of VerificationDirectory and VerificationServiceto max

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.VerificationServiceProfile
	DROP CONSTRAINT FK_VerificationServiceProfile_Organization
GO
ALTER TABLE dbo.Organization SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.VerificationServiceProfile
	DROP CONSTRAINT DF_VerificationServiceProfile_RowId
GO
ALTER TABLE dbo.VerificationServiceProfile
	DROP CONSTRAINT DF_VerificationServiceProfile_Created
GO
ALTER TABLE dbo.VerificationServiceProfile
	DROP CONSTRAINT DF_VerificationServiceProfile_LastUpdated
GO
CREATE TABLE dbo.Tmp_VerificationServiceProfile
	(
	Id int NOT NULL IDENTITY (1, 1),
	RowId uniqueidentifier NOT NULL,
	CTID varchar(50) NULL,
	Description varchar(MAX) NULL,
	DateEffective datetime NULL,
	HolderMustAuthorize bit NULL,
	SubjectWebpage varchar(500) NULL,
	VerificationDirectory varchar(MAX) NULL,
	VerificationMethodDescription varchar(MAX) NULL,
	VerificationService varchar(MAX) NULL,
	OfferedBy uniqueidentifier NULL,
	Created datetime NOT NULL,
	LastUpdated datetime NOT NULL
	)  ON [PRIMARY]
	 TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_VerificationServiceProfile SET (LOCK_ESCALATION = TABLE)
GO
ALTER TABLE dbo.Tmp_VerificationServiceProfile ADD CONSTRAINT
	DF_VerificationServiceProfile_RowId DEFAULT (newid()) FOR RowId
GO
ALTER TABLE dbo.Tmp_VerificationServiceProfile ADD CONSTRAINT
	DF_VerificationServiceProfile_Created DEFAULT (getdate()) FOR Created
GO
ALTER TABLE dbo.Tmp_VerificationServiceProfile ADD CONSTRAINT
	DF_VerificationServiceProfile_LastUpdated DEFAULT (getdate()) FOR LastUpdated
GO
SET IDENTITY_INSERT dbo.Tmp_VerificationServiceProfile ON
GO
IF EXISTS(SELECT * FROM dbo.VerificationServiceProfile)
	 EXEC('INSERT INTO dbo.Tmp_VerificationServiceProfile (Id, RowId, CTID, Description, DateEffective, HolderMustAuthorize, SubjectWebpage, VerificationDirectory, VerificationMethodDescription, VerificationService, OfferedBy, Created, LastUpdated)
		SELECT Id, RowId, CTID, Description, DateEffective, HolderMustAuthorize, SubjectWebpage, CONVERT(varchar(MAX), VerificationDirectory), VerificationMethodDescription, CONVERT(varchar(MAX), VerificationService), OfferedBy, Created, LastUpdated FROM dbo.VerificationServiceProfile WITH (HOLDLOCK TABLOCKX)')
GO
SET IDENTITY_INSERT dbo.Tmp_VerificationServiceProfile OFF
GO
ALTER TABLE dbo.[Entity.UsesVerificationService]
	DROP CONSTRAINT [FK_Entity.UsesVerificationService_VSP]
GO
DROP TABLE dbo.VerificationServiceProfile
GO
EXECUTE sp_rename N'dbo.Tmp_VerificationServiceProfile', N'VerificationServiceProfile', 'OBJECT' 
GO
ALTER TABLE dbo.VerificationServiceProfile ADD CONSTRAINT
	PK_VerificationServiceProfile PRIMARY KEY CLUSTERED 
	(
	Id
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
ALTER TABLE dbo.VerificationServiceProfile ADD CONSTRAINT
	FK_VerificationServiceProfile_Organization FOREIGN KEY
	(
	OfferedBy
	) REFERENCES dbo.Organization
	(
	RowId
	) ON UPDATE  NO ACTION 
	 ON DELETE  NO ACTION 
	
GO
Create TRIGGER [dbo].[trgVerificationServiceProfileAfterDelete] ON  dbo.VerificationServiceProfile
FOR DELETE
AS  
BEGIN
     -- delete the entity
		DELETE a	
			FROM [dbo].[Entity] a
			inner join Deleted d on a.EntityUid = d.RowId

END
GO
--VerificationServiceProfile =============================================
Create TRIGGER [dbo].[trgVerificationServiceProfileAfterInsert] ON  dbo.VerificationServiceProfile
FOR INSERT
AS  
    INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
					 ,EntityBaseId, EntityBaseName)
    SELECT RowId,41, getdate(), Id, 'VerificationProfile'
    FROM inserted;
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Entity.UsesVerificationService] ADD CONSTRAINT
	[FK_Entity.UsesVerificationService_VSP] FOREIGN KEY
	(
	VerificationServiceId
	) REFERENCES dbo.VerificationServiceProfile
	(
	Id
	) ON UPDATE  CASCADE 
	 ON DELETE  CASCADE 
	
GO
ALTER TABLE dbo.[Entity.UsesVerificationService] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT