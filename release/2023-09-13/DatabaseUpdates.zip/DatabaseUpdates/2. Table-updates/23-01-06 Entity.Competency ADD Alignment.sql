use credfinder
go
use sandbox_credfinder
go

--	23-01-06 Entity.Competency] ADD Alignment

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Entity.Competency] ADD
	Alignment varchar(50) NULL
GO
ALTER TABLE dbo.[Entity.Competency] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
go

-- conversion

UPDATE [dbo].[Entity.Competency]
   SET [Alignment] = 'Assesses'
--	select b.EntityTypeId, b.EntityBaseId, a.TargetNodeName
from [dbo].[Entity.Competency] a
inner join entity b on a.EntityId = b.Id
 WHERE b.EntityTypeId = 3
GO


UPDATE [dbo].[Entity.Competency]
   SET [Alignment] = 'Requires'
--	select b.EntityTypeId, b.EntityBaseId, a.TargetNodeName
from [dbo].[Entity.Competency] a
inner join entity b on a.EntityId = b.Id
 WHERE b.EntityTypeId = 4
GO



UPDATE [dbo].[Entity.Competency]
   SET [Alignment] = 'Teaches'
--	select b.EntityTypeId, b.EntityBaseId, a.TargetNodeName
from [dbo].[Entity.Competency] a
inner join entity b on a.EntityId = b.Id
 WHERE b.EntityTypeId in ( 7,36,37)
GO



