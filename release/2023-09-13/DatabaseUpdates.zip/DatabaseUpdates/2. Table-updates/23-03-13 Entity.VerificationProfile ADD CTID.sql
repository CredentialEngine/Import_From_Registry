use credFinder
go

--use sandbox_credFinder
--go

--		23-03-13 Entity.VerificationProfile ADD CTID

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Entity.VerificationProfile] ADD
	CTID varchar(50) NULL
GO

ALTER TABLE dbo.[Entity.VerificationProfile] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO

update [Entity.VerificationProfile]
Set CTID = 'ce-' + convert(varchar(50),RowId )

