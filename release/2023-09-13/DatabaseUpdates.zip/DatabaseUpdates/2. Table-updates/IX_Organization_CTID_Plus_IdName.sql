/*
Missing Index Details from LearningOpportunity.ElasticSearch.sql - CREDENGINEMPARS.credFinder (AzureAD\mparsons-ce (77))
The Query Processor estimates that implementing the following index could improve the query cost by 15.9932%.
*/

/**/
USE [credFinder]
GO
use sandbox_credfinder
go


CREATE NONCLUSTERED INDEX [IX_Organization_CTID_Plus_IdName]
ON [dbo].[Organization] ([CTID])
INCLUDE ([Id],[Name])
GO

