use credfinder
go
use sandbox_credfinder
go

--		23-03-10 Codes.PathwayComponentType ADD ComponentClassTypeId

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Codes.PathwayComponentType] ADD
	ComponentClassTypeId int NOT NULL CONSTRAINT [DF_Codes.PathwayComponentType_ComponentClassTypeId] DEFAULT 1
GO
ALTER TABLE dbo.[Codes.PathwayComponentType] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
go

UPDATE [dbo].[Codes.PathwayComponentType]
   SET [ComponentClassTypeId] = 2
 WHERE Id=11
GO

UPDATE [dbo].[Codes.PathwayComponentType]
   SET IsActive = 0
 WHERE Id=10
GO
