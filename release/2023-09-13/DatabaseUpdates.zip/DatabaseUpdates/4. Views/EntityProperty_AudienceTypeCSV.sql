use credFinder
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




/*

SELECT top (500)
[EntityId]
      ,[Properties]
  FROM [dbo].[EntityProperty_AudienceTypeCSV]
GO


*/
/*
modifications

*/
ALTER VIEW [dbo].[EntityProperty_AudienceTypeCSV]
AS
SELECT     distinct
base.EntityId, 
base.EntityTypeId,
    CASE
          WHEN Properties IS NULL THEN ''
          WHEN len(Properties) = 0 THEN ''
          ELSE left(Properties,len(Properties)-1)
    END AS Properties
FROM [dbo].EntityProperty_Summary base

CROSS APPLY (
    SELECT convert(varchar,cp.PropertyValueId)  + '~' + cp.Property + '| '
    FROM dbo.EntityProperty_Summary cp 
 
    WHERE cp.CategoryId = 14
	and base.EntityId = cp.EntityId
	Order by cp.PropertyValueId
    FOR XML Path('') ) D (Properties)
where Properties is not null

GO
grant select on [EntityProperty_AudienceTypeCSV] to public
go


