USE [credFinder]
GO

use sandbox_credFinder
go

/****** Object:  View [dbo].[Reports_ReferencesPublisher]    Script Date: 8/4/2023 1:30:43 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*
This will be an expensive query. 
- what is the purpose?
consider an alternative
*/
CREATE View [dbo].[Reports_ReferencesPublisher]
as 

  SELECT   
	[EntityType] 
	,EntityTypeId
	,[BaseId] as Id   
	,[Name]
	,[Description]
	,URL
	,[LastUpdated]
	,'Publisher' as Source
  FROM ctdlEditor.[dbo].[Entity_Cache]
  where [EntityStateId]= 2
  and EntityTypeId in (1,2,3,7)
GO

