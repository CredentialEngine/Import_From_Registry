use credfinder
go

--use credfinder_prod
--go
--use sandbox_credFinder
--go


--use staging_credFinder
--go
--use snhu_credFinder
--go
--use credFinder_github
--go
/*

SELECT [Publisher],[PublisherCTID]	,[Organization]	,[OrganizationCTID]	,count(*) as Total FROM [dbo].[ResourceCurrency_Summary]  Where LastUpdated < '2021-01-01' group by   [Publisher]	,[PublisherCTID]	,[Organization]	,[OrganizationCTID]
  order by Publisher, Organization

  go
SELECT [Publisher],[PublisherCTID]	,[Organization]	,[OrganizationCTID], EntityType	,count(*) as Total FROM [dbo].[ResourceCurrency_Summary]  Where LastUpdated < '2021-01-01' group by   [Publisher]	,[PublisherCTID]	,[Organization]	,[OrganizationCTID], EntityType
  order by Publisher, Organization,EntityType

  go

  --just data owner
  SELECT [Organization]	,[OrganizationCTID], EntityType	,count(*) as Total FROM [dbo].[ResourceCurrency_Summary]  
  Where LastUpdated < '2021-01-01' 
  and [PublisherCTID] =[OrganizationCTID]
  group by   [Organization]	,[OrganizationCTID], EntityType
  order by Organization,EntityType

    --just TPP
  SELECT [Publisher],[PublisherCTID], EntityType	,count(*) as Total FROM [dbo].[ResourceCurrency_Summary]  
  Where LastUpdated < '2021-01-01' 
  and [PublisherCTID] <> [OrganizationCTID]
  group by   [Publisher],[PublisherCTID], EntityType
  order by 1,EntityType

  go

USE [sandbox_credFinder]
GO
INSERT INTO [dbo].[Work.Query]
           ([ReportType]
           ,[Publisher]
           ,[PublisherCTID]
           ,[Organization]
           ,[OrganizationCTID]
           ,[EntityType]
           ,[Category]
           ,[Name]
           ,[CTID]
           ,[Description]
          ,[DateCreated]
           ,[LastUpdated]
		   ,[Variable1]
           ,[Variable2]
           ,[Variable3]
         --  ,[IsProcessed]
		   )


SELECT 'CurrencyReport 18 months'
	,[Publisher]
	,[PublisherCTID]
	,[Organization]
	,[OrganizationCTID]
	-- ,[OwningOrgId]
	--  ,[EntityTypeId]
	,[EntityType]
	,[CTDLType]
	--    ,[BaseId]
	,[Name]
	,[CTID]
	,[Description]
		,[Created]
	,[LastUpdated]

	,Status		as Variable1

	,[PublishMethodURI] as Variable2

	  ,[SubjectWebpage] 
	--  ,[ImageUrl]
	-- ,[CacheDate]
  FROM [dbo].[ResourceCurrency_Summary]

  Where
-- EntityTypeId = 1  and 
LastUpdated < '2021-01-01'
  order by Publisher, Organization,[EntityTypeId], Name
GO

select * from ResourceCurrency_Summary
where organization = 'Placeholder until full document is downloaded'
or   publisher = 'Placeholder until full document is downloaded'

*/

/*
ResourceCurrency_Summary view for use by currency reporting
Notes
- this is fairly slow
- also may want to avoid the join to the Accounts table to get the publisher
Options
- daily generation of a reports table
- generate a table for unique publisher - data owners (as main reason for slowness)

Status ********************
- have to consider the credential and lifecycle status. That is either exclude deprecated, etc or make configurable

Modifications
22-05-01 - add use of View [Accounts.OrganizationSummary] instead CE_Accounts.dbo.Organization
23-03-02 - need a means to exclude resources that have a non-active life cycle. 
			- could add a simple IsActive property?
		 - Also may want a means to exclude some entity types, like concept schemes, frameworks, etc. 
*/
--drop View Entity_CacheSummary 
--go

Alter View ResourceCurrency_Summary 
as 

SELECT  
	case when f.Name is not null then f.Name else 'Missing - get from accounts' end as Publisher,
	case when f.Name is not null then f.CTID else '' end as PublisherCTID

	,b.Name as Organization
	,b.CTID as OrganizationCTID
	,a.[OwningOrgId]
	,a.[EntityTypeId]
	,a.[EntityType]
	,et.SchemaName as CTDLType
	--  ,a.[EntityUid]
     
	--      ,a.[EntityStateId]
	,a.[BaseId]
	,a.[Name]
	,a.[LastUpdated]
	,a.[Description]
	,a.[CTID]
	
	,a.[Created]
	,'Active' As Status
	,a.[SubjectWebpage]
	,a.[ImageUrl]
      
	,a.[CacheDate]  
	,case When latestImport.PublishMethodURI='publishMethod:ManualEntry' then 1 else 0 end as IsInPublisher
    --  ,case when IsNUll(ec.CTID,'') <> '' then 1 else 0 end as ExistsInPublisher
--		select count(*)
  FROM [dbo].[Entity_Cache] a
  left join (
			Select EntityCtid, PublisherCTID, DataOwnerCTID, a.EntityName, Max(PublishMethodURI) as PublishMethodURI
		from [Import.PendingRequest] a
		--actually only target the publish values
		where PublishMethodURI = 'publishMethod:ManualEntry' OR PublishMethodURI = 'publishMethod:RegistryAssistant'
		group by EntityCtid, PublisherCTID, DataOwnerCTID, a.EntityName
) latestImport on a.CTID = latestImport.EntityCtid 
left join [Codes.EntityTypes] et on a.EntityTypeId = et.id 

inner join Organization b on a.OwningOrgId = b.id
inner join [Accounts.OrganizationSummary] f on latestImport.PublisherCTID = f.CTID

-- this is a risk, as TPP may not have been published. Or
	--left join dbo.Organization f on latestImport.PublisherCTID = f.CTID

	--  *** production ***
	--inner join CE_Accounts.dbo.Organization f on latestImport.PublisherCTID = f.CTID
	--left join ctdlEditor.dbo.Credential ec on a.CTID = ec.CTID

	--  *** sandbox ***
	--inner join sandbox_CE_Accounts.dbo.Organization f on latestImport.PublisherCTID = f.CTID
	--left join to publisher DB to allow determining if exists in publisher. This could slow the queries. However this is only run to populate the reports nightly so small risk
	--left join sandbox_ctdlEditor.dbo.Credential ec on a.CTID = ec.CTID

where a.EntityTypeId in (1,2,3,7,8,10)
AND a.EntityStateId = 3
and b.EntityStateId = 3
--23-07-05 mp - should remove this for now, as not being set 
And IsNull(a.IsActive,1) = 1

  go

  grant select on ResourceCurrency_Summary to public
  go

