USE [credFinder]
GO

--use sandbox_credFinder 
--go

--use staging_credFinder
--go

--use credfinder_prod
--go

/****** Object:  View [dbo].[TransferValue_PropertyTotals]    Script Date: 5/31/2020 9:35:03 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
ceasn:derivedFrom
ceterms:ctid
ceterms:description
ceterms:developmentProcess
ceterms:endDate
ceterms:identifier
ceterms:name
ceterms:ownedBy
ceterms:startDate
ceterms:subjectWebpage
ceterms:transferValue
ceterms:transferValueFor
ceterms:transferValueFrom

USE [sandbox_credFinder]
GO

SELECT [Total]
      ,[Name]
      ,[Description]
      ,[SubjectWebpage]
      ,[CTID]
      ,[DerivedFrom]
      ,[EndDate]
      ,[Identifier]
      ,[StartDate]
      ,[TransferValue]
      ,[TransferValueFrom]
      ,[TransferValueFor]
      ,[OwnedBy]
      ,[DevelopmentProcess]
  FROM [dbo].[TransferValue_PropertyTotals]

GO




*/
Alter VIEW [dbo].[TransferValue_PropertyTotals]
AS

select 

		sum(case when Len(IsNull(a.Name, '')) > 0 then 1 else 0 end) as Total
		, sum(case when Len(IsNull(a.Name, '')) > 0 then 1 else 0 end) as Name
		, sum(case when Len(IsNull(a.Description, '')) > 0 then 1 else 0 end) as Description
		, sum(case when Len(IsNull(a.SubjectWebpage, '')) > 0 then 1 else 0 end) as SubjectWebpage
		, sum(case when Len(IsNull(a.CTID, '')) > 0 then 1 else 0 end) as CTID
		, sum(case when Len(IsNull(a.LifeCycleStatusType, '')) > 0 then 1 else 0 end) as LifeCycleStatusType

		,sum(case when IsNull(derivedFrom.EntityBaseId,0) > 0 then 1 else 0 end)		DerivedFrom
		, sum(case when Len(IsNull(a.EndDate, '')) > 0 then 1 else 0 end) as EndDate
		, sum(case when Len(IsNull(a.IdentifierJson, '')) > 0 then 1 else 0 end) as Identifier
		, sum(case when Len(IsNull(a.StartDate, '')) > 0 then 1 else 0 end) as StartDate
		, sum(case when Len(IsNull(a.TransferValueJson, '')) > 0 then 1 else 0 end) as TransferValue
		, sum(case when Len(IsNull(a.TransferValueFromJson, '')) > 0 then 1 else 0 end) as TransferValueFrom
		, sum(case when Len(IsNull(a.TransferValueForJson, '')) > 0 then 1 else 0 end) as TransferValueFor
		-- BYs
		,sum(case when IsNull(ownedBy.RelationshipTypeId,0) > 0 then 1 else 0 end)		OwnedBy

		---- from/for types?
		--,sum(case when IsNull(asmtComponent.ComponentTypeId,0) > 0 then 1 else 0 end) AssessmentComponents
		--,sum(case when IsNull(basicComponent.ComponentTypeId,0) > 0 then 1 else 0 end) BasicComponents

		-- Process Profiles --------------------------------------------------------------
		,sum(case when IsNull(devProfile.EntityBaseId,0)	> 0 then 1 else 0 end) DevelopmentProcess

	-- ========================================================
	--select count(*)
  from TransferValueProfile a
  inner join entity b on a.RowId = b.EntityUid

  --combine owns/offers =========================================================
   left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  RelationshipTypeId  FROM dbo.[Entity.AgentRelationship] inner join entity on EntityId = entity.Id where entity.EntityTypeId=26 and RelationshipTypeId=6
  ) ownedBy on a.Id = ownedBy.EntityBaseId

-- 
   left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.TransferValueProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=26 
  ) derivedFrom on a.Id = derivedFrom.EntityBaseId
 
-- Process profiles---------------------------------------------------------------------
  --2-dev
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ProcessProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=26 and a.ProcessTypeId=2 
  ) devProfile on a.Id = devProfile.EntityBaseId
 
--======================
where a.EntityStateId = 3 
GO

