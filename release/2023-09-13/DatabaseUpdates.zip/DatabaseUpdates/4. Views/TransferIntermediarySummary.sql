USE [credFinder]
GO
--use credfinder_prod
--go

--USE staging_credFinder
--GO

use sandbox_credFinder
go


/****** Object:  View [dbo].[TransferIntermediarySummary]    Script Date: 7/29/2020 11:13:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*
USE [credFinder]
GO
USE [sandbox_credFinder]
GO

SELECT [Id]
      ,[RowId]
      ,[EntityStateId]
      ,[Name]
      ,[Description]
      ,[SubjectWebpage]
      ,[CTID]
      ,[OwningAgentUid]
      ,[OrganizationCTID]
      ,[OrganizationId]
      ,[OrganizationName]
      ,[HasTransferValueProfiles]
      ,[CredentialRegistryId]
      ,[CodedNotation]
      ,[CreditValueJson]
      ,[IntermediaryForJson]
      ,[Subject]
      ,[Created]
      ,[LastUpdated]
  FROM [dbo].[TransferIntermediarySummary]

GO



GO


*/
/*
TransferIntermediarySummary
Notes
- 
Mods
22-01-27 mparsons - added
22-02-12 mparsons - added TVP totals

*/
Alter VIEW [dbo].[TransferIntermediarySummary]
AS


SELECT 
	a.[Id]
	,a.[RowId]
	,e.Id as EntityId
	,a.[EntityStateId]
	,a.[Name]
	,a.[Description]
	,a.[SubjectWebpage]
	,a.[CTID]
	--
	,a.[OwningAgentUid]
	,isnull(b.ctid,'')  as OrganizationCTID
	,b.Id as OrganizationId
	,b.Name as OrganizationName
	--
	,IsNull(tvp.total,0) as HasTransferValueProfiles
	--TBD
	,a.[CredentialRegistryId]
	,a.[CodedNotation]
	,a.[CreditValueJson]
	,a.[IntermediaryForJson]
	,a.[Subject]
	,a.[Created]
	,a.[LastUpdated]
	--

	
--
  FROM [dbo].[TransferIntermediary] a

INNER JOIN dbo.Entity AS e ON a.RowId = e.EntityUid 
LEFT  JOIN dbo.Organization AS b ON a.OwningAgentUid = b.RowId


--================================
Left Join (
	SELECT [TransferIntermediaryId] ,Count(*)  as total
  FROM [dbo].[TransferIntermediary.TransferValue]
  group by [TransferIntermediaryId]
	) tvp on a.Id = tvp.[TransferIntermediaryId]
--


GO

grant select on [TransferIntermediarySummary] to public
go


