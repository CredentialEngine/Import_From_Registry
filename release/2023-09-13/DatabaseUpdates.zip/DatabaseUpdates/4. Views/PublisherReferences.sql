USE [sandbox_credFinder]
GO

/****** Object:  View [dbo].[Reports_References]    Script Date: 12/16/2022 4:51:41 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




Create View [dbo].[Reports_ReferencesPublisher]
as 
select distinct
    c.BaseId as Id,
	c.Name,
	c.Description,
	c.LastUpdated,
	c.Url,
	c.EntityType,
	c.EntityTypeId
	from [sandbox_ctdlEditor].[dbo].[Entity_Cache] as C Where C.CTID='' and EntityStateId=2
GO


