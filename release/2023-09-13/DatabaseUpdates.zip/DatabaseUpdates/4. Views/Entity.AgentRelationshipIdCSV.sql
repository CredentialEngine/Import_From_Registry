use credFinder
GO

use sandbox_credFinder
go
/****** Object:  View [dbo].[Entity.AgentRelationshipIdCSV]    Script Date: 8/27/2017 10:41:34 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*

use credFinder
GO
distinct
USE [credFinder]
GO

SELECT [EntityId]
      ,[EntityUid]
      ,[EntityBaseId]
      ,[EntityBaseName]
      ,[EntityType]
      ,[EntityTypeId]
      ,[AgentRelativeId]
      ,[AgentUid]
      ,[AgentName]
      ,[IsInverseRole]
      ,[RoleIds]
      ,[Roles], AgentContextRoles
      ,[AgentDescription]
      ,[AgentUrl]
      ,[AgentImageUrl]
  FROM [dbo].[Entity.AgentRelationshipIdCSV]
where entitytypeid = 7
and EntityBaseId= 14856
 
 
order by EntityId,AgentName


SELECT DISTINCT ear.AgentRelativeId As OrgId, ear.AgentName, ear.AgentUrl, ear.EntityStateId, ear.RoleIds as RelationshipTypeIds,  ear.Roles as Relationships, ear.AgentContextRoles FROM [dbo].[Entity.AgentRelationshipIdCSV] ear
			WHERE ear.EntityTypeId = 7 AND ear.EntityBaseId = 14856
			FOR XML RAW, ROOT('AgentRelationshipsForEntity')
			) 
*/

/* ==========================================================================
Description:  Output three CSV properties for Agent to entity relationships
What is the real objective for this? If from the org context, will list all of the org relationships.
	If from the cred context, we want to list the orgs with relationships to the resource

  ------------------------------------------------------
Modifications
23-02-23 mparsons - This can be costly. Reviewing to determine if at least one can be removed
			- AgentContextRoles is not being used in elasticManager

*/
Alter VIEW [dbo].[Entity.AgentRelationshipIdCSV]
AS
--
SELECT     distinct
		--base.Id			as EntityAgentRelationshipId,
		--base.RowId	as EntityAgentRelationshipRowId,
		Isnull(es.Id, -1) as EntityId, 
		es.EntityUid, 
		es.EntityBaseId, 
		es.EntityBaseName, 
		c.Title As EntityType, 
		es.EntityTypeId,
		Isnull(agent.Id, -1) As AgentRelativeId, 
		base.AgentUid, 
		agent.Name as AgentName, 
		base.IsInverseRole, --TODO dump this
		--agent.Description As AgentDescription,
		'' as AgentDescription,
		agent.SubjectWebpage As AgentUrl,
		agent.ImageURL as AgentImageUrl,
		agent.EntityStateId,

		CASE
			WHEN RoleIds IS NULL THEN ''
			WHEN len(RoleIds) = 0 THEN ''
			ELSE left(RoleIds,len(RoleIds)-1)
			END AS RoleIds,
		CASE
			WHEN ByRoles IS NULL THEN ''
			WHEN len(ByRoles) = 0 THEN ''
			ELSE left(ByRoles,len(ByRoles)-1)
			END AS Roles,
		--'' Roles,
		--CASE
		--	WHEN AgentContextRoles IS NULL THEN ''
		--	WHEN len(AgentContextRoles) = 0 THEN ''
		--	ELSE left(AgentContextRoles,len(AgentContextRoles)-1)
		--END AS AgentContextRoles
		'' AgentContextRoles

FROM [dbo].[Entity.AgentRelationship] base
inner join Entity es on base.EntityId = es.Id
Inner Join [Codes.EntityTypes] c on es.EntityTypeId = c.Id
inner join Organization agent on base.AgentUid = agent.RowId

CROSS APPLY (
    SELECT convert(varchar,ear.RelationshipTypeId)  + ', '
    FROM dbo.[Entity.AgentRelationship] ear 
		inner join [Codes.CredentialAgentRelationship] car on ear.RelationshipTypeId = car.Id
    WHERE car.IsActive = 1 
		and base.EntityId = ear.EntityId
		and base.AgentUid = ear.AgentUid

    FOR XML Path('') 
) D (RoleIds)

CROSS APPLY (
    SELECT car2.Title  + ', ' 

    FROM dbo.[Entity.AgentRelationship] ear2 
		inner join [Codes.CredentialAgentRelationship] car2 on ear2.RelationshipTypeId = car2.Id
    WHERE car2.IsActive = 1 
		and base.EntityId = ear2.EntityId
		and base.AgentUid = ear2.AgentUid

    FOR XML Path('') 
) E (ByRoles)

--CROSS APPLY (
--    SELECT car2.ReverseRelation  + ', '

--    FROM dbo.[Entity.AgentRelationship] ear2 
--		inner join [Codes.CredentialAgentRelationship] car2 on ear2.RelationshipTypeId = car2.Id
--    WHERE car2.IsActive = 1 
--		and base.EntityId = ear2.EntityId
--		and base.AgentUid = ear2.AgentUid

--    FOR XML Path('') 
--) F (AgentContextRoles)

where agent.EntityStateId > 1
AND RoleIds is not null


order by AgentRelativeId, es.entityBaseId

go
grant select on [Entity.AgentRelationshipIdCSV] to public

GO


