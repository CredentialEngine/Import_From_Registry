USE [credFinder]
GO

--use sandbox_credFinder 
--go

--use staging_credFinder
--go


/****** Object:  View [dbo].[TransferIntermediary_PropertyTotals]    Script Date: 5/31/2020 9:35:03 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*

USE [credFinder]
GO

SELECT [Total]
      ,[Name]
      ,[Description]
      ,[SubjectWebpage]
      ,[CTID]
      ,[HasAlternateNames]
      ,[CodedNotation]
      ,[CreditValue]
      ,[IntermediaryFor]
      ,[HasSubjects]
      ,[OwnedBy]
      ,[HasRequires]
  FROM [dbo].[TransferIntermediary_PropertyTotals]

GO



*/
Alter  VIEW [dbo].[TransferIntermediary_PropertyTotals]
AS

select 

		sum(case when Len(IsNull(a.Name, '')) > 0			then 1 else 0 end) as Total
		, sum(case when Len(IsNull(a.Name, '')) > 0			then 1 else 0 end) as Name
		, sum(case when Len(IsNull(a.Description, '')) > 0	then 1 else 0 end) as Description
		, sum(case when Len(IsNull(a.SubjectWebpage, '')) > 0 then 1 else 0 end) as SubjectWebpage
		, sum(case when Len(IsNull(a.CTID, '')) > 0			then 1 else 0 end) as CTID
		, sum(case when IsNull(alternateNames.EntityBaseId,0) > 0 then 1 else 0 end) HasAlternateNames
		, sum(case when Len(IsNull(a.CodedNotation, '')) > 0 then 1 else 0 end) as CodedNotation
		, sum(case when Len(IsNull(a.CreditValueJson, '')) > 0 then 1 else 0 end) as CreditValue
		, sum(case when Len(IsNull(a.IntermediaryForJson, '')) > 0 then 1 else 0 end) as IntermediaryFor
		--, sum(case when IsNull(subjects.EntityBaseId,0) > 0 then 1 else 0 end) HasSubjects
		, sum(case when Len(IsNull(a.Subject, '')) > 0 then 1 else 0 end) as HasSubjects

		-- BYs
		,sum(case when IsNull(ownedBy.RelationshipTypeId,0) > 0 then 1 else 0 end)		OwnedBy

		-- Requires  --------------------------------------------------------------
	,sum(case when IsNull(requires.EntityBaseId,0) > 0 then 1 else 0 end) HasRequires

	-- ========================================================
	--select count(*)
  from TransferIntermediary a
  inner join entity b on a.RowId = b.EntityUid

  --combine owns/offers =========================================================
   left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  RelationshipTypeId  FROM dbo.[Entity.AgentRelationship] inner join entity on EntityId = entity.Id where entity.EntityTypeId=28 and RelationshipTypeId=6
  ) ownedBy on a.Id = ownedBy.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.Reference] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=28 and [CategoryId] = 38
	  and Len(IsNull(a.TextValue,'')) > 0
  ) alternateNames on a.Id = alternateNames.EntityBaseId 
  -- **WHOA, seem to be storing these on the table
  -- left join (
	 -- SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.Reference] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=28 and [CategoryId] = 34
	 -- and Len(IsNull(a.TextValue,'')) > 0
  --) subjects on a.Id = subjects.EntityBaseId
-- condition profiles---------------------------------------------------------------------
  --requires
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ConditionProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=28 and a.ConnectionTypeId=1 and isnull(ConditionSubTypeId, 0) = 1 
  ) requires on a.Id = requires.EntityBaseId

--======================
where a.EntityStateId = 3 
GO

