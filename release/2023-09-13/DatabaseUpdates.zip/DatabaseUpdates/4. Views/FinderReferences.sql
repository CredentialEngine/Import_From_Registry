USE [sandbox_credFinder]
GO

/****** Object:  View [dbo].[Reports_ReferencesFinder]    Script Date: 12/16/2022 5:26:15 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





Create View [dbo].[Reports_ReferencesFinder]
as 
select distinct
    c.BaseId as Id,
	c.Name,
	c.Description,
	c.LastUpdated,
	c.SubjectWebpage,
	c.EntityType,
	c.EntityTypeId
	from [dbo].[Entity_Cache] as C where c.CTID='' and EntityStateId=2
GO


