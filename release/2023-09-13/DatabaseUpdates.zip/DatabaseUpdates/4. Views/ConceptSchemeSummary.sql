USE credFinder
GO

USE [sandbox_credFinder]
GO


--USE [staging_credFinder]
--GO



/****** Object:  View [dbo].[ConceptSchemeSummary]    Script Date: 8/24/2020 2:51:11 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*

USE [sandbox_credFinder]
GO

SELECT [Id]
      ,[EntityStateId]
      ,[Name]
      ,[CTID]
      ,[Description]
      ,[EntityId]
      ,[EntityLastUpdated]
      ,[OrgId]
      ,[OrganizationId]
      ,[OrganizationName]
      ,[OrganizationCTID]
      ,[OwningAgentUid]
      ,[Source]
      ,[PublicationStatusType]
      ,[IsProgressionModel]
      ,[CredentialRegistryId]
      ,[Created]
      ,[LastUpdated]
      ,[RowId]
  FROM [dbo].[ConceptSchemeSummary]

GO




========================================================
20-08-23 mparsons - added 

*/
Alter VIEW [dbo].[ConceptSchemeSummary]
AS

SELECT base.[Id]
	,base.EntityStateId
	,base.EntityTypeId
	,base.[Name]
	,isnull(base.CTID,'') As CTID 
	,base.[Description]
	,e.id as EntityId
	,e.LastUpdated as EntityLastUpdated
	,base.OrgId
	--owning org
	,owningOrg.Id as OrganizationId --used in publisher filters
	,owningOrg.Name as OrganizationName
	,owningOrg.ctid as OrganizationCTID
	,owningOrg.RowId as OwningAgentUid
	--

	,base.Source
	,base.PublicationStatusType
	,base.IsProgressionModel
	,isnull(base.CredentialRegistryId,'') As CredentialRegistryId	

	,base.[Created]
	,base.[LastUpdated]
	,base.RowId
	--=====================================
	
  FROM [dbo].ConceptScheme base
  inner join Entity e on base.RowId = e.EntityUid
-- join for owner
	Left join Organization owningOrg on base.OrgId = owningOrg.Id

where base.EntityStateId=3

GO
grant select on [ConceptSchemeSummary] to public
go
