use credFinder
GO

/****** Object:  View [dbo].[CostProfileSummary]    Script Date: 9/28/2016 12:36:27 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*


SELECT top (1000)
	cp.[ParentEntityId], ec.EntityType, ec.Name
   --   ,cp.[ParentEntityUid]
      ,cp.[ParentEntityTypeId]
      ,cp.[EntityCostProfileId]
      ,cp.[ProfileName]
      ,cp.[DetailsUrl]
      ,cp.[CurrencyCode]
      ,cp.[Currency]
      ,cp.[CostTypeId]
      ,cp.[CostType]
      ,cp.[Price]
  FROM [dbo].[CostProfileSummary] cp
  inner join entity_cache ec on cp.parentEntityId = ec.Id
WHERE ec.EntityStateId = 3
and cp.ParentEntityTypeId= 1

Order by cp.[ParentEntityId], cp.[EntityCostProfileId] ,cp.[CostType]
  
GO

*/
/*
list cost profile plus profile item by parent entity
*/
Alter VIEW [dbo].[CostProfileSummary]
AS
SELECT        
	ParentEntity.Id AS ParentEntityId, 
	ParentEntity.EntityUid AS ParentEntityUid, 
	ParentEntity.EntityTypeId AS ParentEntityTypeId, 
	ParentEntity.EntityBaseId,
	a.Id AS EntityCostProfileId, 
	a.ProfileName, 
	a.Description,
	a.DetailsUrl, 
	d.AlphabeticCode AS CurrencyCode, 
	d.Currency, 
	--c.Title AS CostType, 
	b.CostTypeId, 
	c.Title AS CostType,

	b.Price

FROM dbo.[Entity.CostProfile] a 
Left JOIN dbo.[Entity.CostProfileItem] b ON a.Id = b.CostProfileId 
INNER JOIN dbo.Entity AS ParentEntity	ON a.EntityId = ParentEntity.Id 
Left JOIN dbo.[Codes.PropertyValue] c	ON b.CostTypeId = c.Id 
LEFT OUTER JOIN dbo.[Codes.Currency] d	ON a.CurrencyTypeId = d.NumericCode

GO
grant select on [CostProfileSummary] to public
go

