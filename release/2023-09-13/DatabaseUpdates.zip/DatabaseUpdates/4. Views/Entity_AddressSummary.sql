use credFinder
GO

use sandbox_credFinder
go

/****** Object:  View [dbo].[Entity_AddressSummary]    Script Date: 8/16/2017 9:52:23 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
use credFinder
GO

SELECT top (500)
	ec.EntityType as ParentEntityType  
	,a.[EntityTypeId] 
	,a.[EntityId] as ParentEntityId
	,ec.Name as ParentName, ec.CTID as parentCTID

      ,a.[EntityBaseId] as ParentFinderId
   --   ,a.[EntityBaseName]
   ,a.AddressName, a.Description
      ,a.[Address1]
      ,a.[City]
      ,a.[Region]
      ,a.[PostalCode]
      ,a.[Country]
      ,a.[Latitude]
      ,a.[Longitude]

  FROM [dbo].[Entity_AddressSummary] a
  inner join entity_cache ec on a.EntityId = ec.Id
WHERE ec.EntityStateId = 3
and a.EntityTypeId= 1




*/
Alter VIEW [dbo].[Entity_AddressSummary]
AS
SELECT        
	b.EntityId, a.EntityUid,
	a.EntityTypeId, 
	a.EntityBaseId, 
	a.EntityBaseName, 
	b.Id as EntityAddressId,
	b.Name As AddressName,
	b.Description ,
	b.Address1, 
	b.Address2, 
	b.City, 
	b.Region, 
	b.PostalCode, 
	b.Country, 
	b.Latitude, b.Longitude 
	--c.CommonName As Country, 
	--c.FormalName
	,b.Created,
	b.[IdentifierJson]
FROM dbo.Entity a
INNER JOIN dbo.[Entity.Address] b				ON a.Id = b.EntityId 
--LEFT OUTER JOIN CE_ExternalData.dbo.[Codes.Countries] c ON b.CountryId = c.Id


GO


