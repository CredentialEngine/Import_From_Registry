USE [credFinder]
GO
use sandbox_credFinder
go


/****** Object:  View [dbo].[Reports_ReferencesFinder]    Script Date: 8/4/2023 1:29:59 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
This will be an expensive query. 
- what is the purpose?
consider an alternative
*/
CREATE View [dbo].[Reports_ReferencesFinder]
as 
SELECT  
 
	[EntityType] 
	,EntityTypeId
	,[BaseId] as Id   
	,[Name]
	,[Description]
	,[SubjectWebpage]
	,[LastUpdated]
	,'Finder' as Source
  FROM [dbo].[Entity_Cache]
  where [EntityStateId]= 2
  and EntityTypeId in (1,2,3,7)

 -- UNION
 -- SELECT  
 
	--[EntityType] as ReferenceType
	--,[BaseId] as Id   
	--,[Name]
	--,[Description]
	--,URL as [SubjectWebpage]
	--,[LastUpdated]
	--,'Finder' as Source
 -- FROM [ctdlEditor].[dbo].[Entity_Cache]
 -- where [EntityStateId]= 2
 -- and EntityTypeId in (1,2,3,7)
GO

