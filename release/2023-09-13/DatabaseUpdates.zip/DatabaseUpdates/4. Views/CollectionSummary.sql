
Use credFinder
go

use sandbox_credFinder
go


Alter View CollectionSummary
AS
SELECT  a.[Id]
	--need EntityId as a unique Id for a common elastic index
	,e.Id as EntityId
	,a.[Name]
	,a.[Description]
	,a.[EntityStateId]
	,a.[CTID]
	--
	,a.[OwningAgentUid]
	,isnull(b.ctid,'')  as OrganizationCTID
	,b.Id as OrganizationId
	,b.Name as OrganizationName
	,b.EntityStateId as OrganizationEntityStateId
	,case when IsNull(a.LifeCycleStatusTypeId,0) > 0 then a.LifeCycleStatusTypeId
	else 2648 end As LifeCycleStatusTypeId --default to production value for now

	,case when IsNull(a.LifeCycleStatusTypeId,0) > 0 then cpv.Title
	else 'Active' end As LifeCycleStatusType --
	--
	,a.[SubjectWebpage]
	,a.[CodedNotation]
	,a.[License]
	,a.[DateEffective]
	,a.[ExpirationDate]
	,a.[CredentialRegistryId]
	,a.[Created]
	,a.[LastUpdated]
	,a.[RowId]
	,a.[CollectionGraph]

  FROM [dbo].[Collection] a
  Inner join Entity e on a.rowId = e.EntityUid
  LEFT  JOIN dbo.Organization AS b ON a.OwningAgentUid = b.RowId
  left join [codes.PropertyValue] cpv on a.LifeCycleStatusTypeId = cpv.Id

--
GO

grant select on CollectionSummary to public
go

