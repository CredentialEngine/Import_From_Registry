use credFinder
GO
use sandbox_credFinder
go

/****** Object:  View [dbo].[Entity_QARolesCSV]    Script Date: 9/20/2017 5:52:33 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




/*

1~Owning Org is Accredited~144~Retail Management Certificate~Organization| 10~Owning Org is Recognized~144~Retail Management Certificate~Organization| 2~Owning Org is Approved~144~Retail Management Certificate~Organization

USE [credFinder_ProdSync]
GO

USE [sandbox_credFinder]
GO

SELECT top 1000
	[EntityTypeId]
      ,[BaseId]
      ,[Id]
      ,[OwningOrgId]
      ,[Org_QAAgentAndRoles]
  FROM [dbo].[Entity_QARolesCSV]
where entitytypeid = 7

order by entityTypeId, BaseId, OwningOrgId



*/
/*
Description - List CSV list of QA roles on the owning org for an entity.
May not need OrgQARoles

23-02-20 mp - this is only used by the views: learning opp summary and asmt summary. check procs
			- check what credentials do
Modifications

*/
Alter  VIEW [dbo].[Entity_QARolesCSV]
AS
SELECT     distinct
base.EntityTypeId,
base.BaseId, 
base.Id,
base.OwningOrgId,

		--CASE
  --        WHEN OrgQARoles IS NULL THEN ''
  --        WHEN len(OrgQARoles) = 0 THEN ''
  --        ELSE left(OrgQARoles,len(OrgQARoles)-1)
  --  END AS OrgQARoles,
		--'Not applicable' AS OrgRoles,
		CASE
          WHEN Org_QAAgentAndRoles IS NULL THEN ''
          WHEN len(Org_QAAgentAndRoles) = 0 THEN ''
          ELSE left(Org_QAAgentAndRoles,len(Org_QAAgentAndRoles)-1)
    END AS Org_QAAgentAndRoles
-- select *    
From
	dbo.Entity_Summary base


--this is count of QA roles on the owning org
--CROSS APPLY (
--    SELECT convert(varchar, a.RelationshipTypeId) 
--		+ '~' + replace(a.[SourceToAgentRelationship], ' By','')  
--		+ '~' + convert(varchar, RolesCount) + '~Organization| '
--		From dbo.[Organization_QARolesTotals] a
--		inner join Entity_Summary b on a.OrganizationId = b.OwningOrgId 
--					--AND b.RelationshipTypeId in (5, 6)
--    WHERE base.BaseId = b.BaseId
--	AND base.EntityTypeId = b.EntityTypeId

--    FOR XML Path('') 
--) E (OrgQARoles)

--this is to QA on the owning org
CROSS APPLY (
    SELECT distinct convert(varchar, b.RelationshipTypeId) 
				+ '~Owning Org is ' + replace(code.Title, ' By','')   
				+ '~' + convert(varchar, c.Id) 
				+ '~' +  c.Name + '~' + c.SubjectWebpage  + '~' + convert(varchar, c.EntityStateId )
				+ '~Organization| '
		FROM Organization org
		Inner join Entity				e on org.RowId = e.EntityUid
		inner join [dbo].[Entity.AgentRelationship] b on e.id = b.EntityId
		inner join [Codes.CredentialAgentRelationship] code on b.RelationshipTypeId = code.id and code.IsActive = 1 and code.IsQARole = 1
		Inner join Organization c on b.AgentUid = c.RowId  --org performing QA
					
    WHERE base.OwningOrgId = org.Id
		and org.EntityStateId > 1
		and c.EntityStateId > 1
    FOR XML Path('') 
) E2 (Org_QAAgentAndRoles)


where Org_QAAgentAndRoles is not null 
go
grant select on [Entity_QARolesCSV] to public


GO

