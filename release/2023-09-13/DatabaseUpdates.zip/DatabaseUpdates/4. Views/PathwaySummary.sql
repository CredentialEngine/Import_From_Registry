USE [credFinder]
GO

use sandbox_credFinder
go

--use staging_credFinder
--go


--use snhu_credFinder
--go


/****** Object:  View [dbo].[PathwaySummary]    Script Date: 12/16/2020 1:11:13 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*
USE [credFinder]
GO

SELECT [Id]
      ,[RowId]
      ,[CTID]
      ,[Description]
      ,[EntityStateId]
      ,[SubjectWebpage]
      ,[OwningAgentUid]
      ,[OrganizationId]
      ,[OrganizationName]
      ,[OrganizationCTID]
      ,[CredentialRegistryId]
      ,[EntityLastUpdated]
      ,[Created]
      ,[LastUpdated]
	  ,ResourceDetail
  FROM [dbo].[PathwaySummary]
order by lastupdated desc 
GO




*/
Alter VIEW [dbo].[PathwaySummary]
AS

SELECT a.[Id]
	,a.[RowId]
	,a.[CTID]
	,a.[Name]
	,a.[Description]
	,a.[EntityStateId]
	,a.[SubjectWebpage]
	,a.[OwningAgentUid]
	,b.Id as OrganizationId
	,b.Name      as OrganizationName
	,b.CTID as OrganizationCTID
	,a.[CredentialRegistryId]
	,a.hasProgressionModel
	,a.Properties
	,ec.LastUpdated as EntityLastUpdated
	,a.[Created]	,a.[LastUpdated]
	,ec.ResourceDetail
	  --

  FROM [dbo].[Pathway] a
Left join dbo.Organization b on a.OwningAgentUid = b.RowId
INNER JOIN dbo.Entity_Cache AS ec ON a.RowId = ec.EntityUid
--Left Join EntityProperty_Summary	statusProperty on a.RowId = statusProperty.EntityUid and statusProperty.CategoryId = 84


GO
grant select on [PathwaySummary] to public
go

