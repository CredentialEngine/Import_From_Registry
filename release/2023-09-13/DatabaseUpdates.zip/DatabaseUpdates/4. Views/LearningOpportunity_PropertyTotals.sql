USE [credFinder]
GO

use sandbox_credFinder 
go

--use staging_credFinder
--go


/****** Object:  View [dbo].[LearningOpportunity_PropertyTotals]    Script Date: 5/31/2020 9:40:24 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- group 2
/*
Add
Learning Method Description
Assessment Method Description
Coded Notation
VersionIdentifier


HasPart
IsPartOf
OfferedIN

Modifications
22-01-11 mparsons - add LifeCycleStatusType
22-10-08 mparsons - add alternameName
*/
ALTER VIEW [dbo].[LearningOpportunity_PropertyTotals]
AS
select 

	sum(case when Len(IsNull(a.Name, '')) > 0 then 1 else 0 end) as Total
	, sum(case when Len(IsNull(a.Name, '')) > 0 then 1 else 0 end) as Name
	, sum(case when Len(IsNull(a.Description, '')) > 0 then 1 else 0 end) as Description
	, sum(case when Len(IsNull(a.SubjectWebpage, '')) > 0 then 1 else 0 end) as SubjectWebpage
	, sum(case when Len(IsNull(a.CTID, '')) > 0 then 1 else 0 end) as CTID
	 , sum(case when Len(IsNull(a.LifeCycleStatusType, '')) > 0 then 1 else 0 end) as LifeCycleStatusType

	,sum(case when Len(IsNull(a.AvailabilityListing,'')) > 0 then 1 else 0 end) HasAvailabilityListing
	,sum(case when Len(IsNull(a.availableOnlineAt,'')) > 0 then 1 else 0 end) HasAvailableOnlineAt
	,sum(case when IsNull(a.DateEffective,'') > '1900-01-01 00:00:00.000' then 1 else 0 end) HasDateEffective
	,sum(case when Len(IsNull(a.IdentificationCode,'')) > 0 then 1 else 0 end) HasCodedNotation
	,sum(case when Len(IsNull(a.SCED,'')) > 0 then 1 else 0 end) HasSCED

	,sum(case when Len(IsNull(tbl.DeliveryTypeDescription,'')) > 0 then 1 else 0 end) HasDeliveryTypeDescription	
	,sum(case when Len(IsNull(tbl.LearningMethodDescription,'')) > 0 then 1 else 0 end) HasLearningMethodDescription
	,sum(case when Len(IsNull(tbl.AssessmentMethodDescription,'')) > 0 then 1 else 0 end) HasAssessmentMethodDescription

	,sum(case when Len(tbl.CreditUnitTypeId) > 0 then 1 else 0 end) HasCreditUnitType	
	,sum(case when Len(tbl.CreditUnitValue) > 0 then 1 else 0 end) HasCreditUnitValue	
	,sum(case when Len(tbl.CreditUnitMaxValue) > 0 then 1 else 0 end) HasCreditUnitMaxValue	
	,sum(case when Len(IsNull(tbl.CreditUnitTypeDescription,'')) > 0 then 1 else 0 end) HasCreditUnitTypeDescription	
	--
	,sum(case when IsNull(cip.CategoryId,0) > 0 then 1 else 0 end) HasInstructionalPgms		--##
	,sum(case when IsNull(occ.CategoryId,0) > 0 then 1 else 0 end) HasOccupations			--##
	,sum(case when IsNull(ind.CategoryId,0) > 0 then 1 else 0 end) HasIndustries			--##
	--
	,sum(case when IsNull(audienceLevelType.CategoryId,0) > 0 then 1 else 0 end) HasAudienceLevelType
	,sum(case when IsNull(audience.CategoryId,0) > 0 then 1 else 0 end) HasAudience
	,sum(case when IsNull(delType.CategoryId,0) > 0 then 1 else 0 end) HasDeliveryMethodType
	,sum(case when IsNull(learningMethod.CategoryId,0) > 0 then 1 else 0 end) HasLearningMethodType
	--
	,sum(case when IsNull(Competencies.EntityBaseId,0) > 0 then 1 else 0 end) HasCompetencies
	,sum(case when IsNull(Address.EntityBaseId,0) > 0 then 1 else 0 end) HasAddress
	,sum(case when IsNull(Costs.EntityBaseId,0) > 0 then 1 else 0 end) HasCosts
	,sum(case when IsNull(Duration.EntityBaseId,0) > 0 then 1 else 0 end) HasDuration
	,sum(case when IsNull(jurisdictions.EntityBaseId,0) > 0 then 1 else 0 end) HasJurisdictions
	,sum(case when IsNull(identifiers.EntityBaseId,0) > 0 then 1 else 0 end) HasIdentifier
	,sum(case when IsNull(videntifiers.EntityBaseId,0) > 0 then 1 else 0 end) HasVersionIdentifier
	--
	,sum(case when IsNull(commonCosts.EntityBaseId,0) > 0 then 1 else 0 end) HasCommonCosts
	,sum(case when IsNull(commonConditions.EntityBaseId,0) > 0 then 1 else 0 end) HasCommonConditions
	--
		,sum(case when IsNull(HasPart.EntityBaseId,0) > 0 then 1 else 0 end) HasPart
	--conditions
		--
	,sum(case when IsNull(requires.EntityBaseId,0) > 0 then 1 else 0 end) HasRequires
	,sum(case when IsNull(recommends.EntityBaseId,0) > 0 then 1 else 0 end) HasRecommends
	,sum(case when IsNull(coreq.EntityBaseId,0) > 0 then 1 else 0 end) HasCorequisites
	,sum(case when IsNull(entryLvl.EntityBaseId,0) > 0 then 1 else 0 end) HasEntryConditions

	--connections
	--,sum(case when IsNull(RequiresCount,0) > 0 then 1 else 0 end) HasRequires
	--,sum(case when IsNull(RecommendsCount,0) > 0 then 1 else 0 end) HasRecommends
	,sum(case when IsNull(isRequiredForCount,0) > 0 then 1 else 0 end) HasIsRequiredFor
	,sum(case when IsNull(IsRecommendedForCount,0) > 0 then 1 else 0 end) HasRecommendedFor
	,sum(case when IsNull(IsAdvancedStandingForCount,0) > 0 then 1 else 0 end) HasIsAdvancedStandingFor
	,sum(case when IsNull(AdvancedStandingFromCount,0) > 0 then 1 else 0 end) HasAdvancedStandingFrom
	,sum(case when IsNull(isPreparationForCount,0) > 0 then 1 else 0 end) HasIsPreparationFor
	,sum(case when IsNull(PreparationFromCount,0) > 0 then 1 else 0 end) HasPreparationFrom
	-- BYs
	,sum(case when IsNull(ownedBy.RelationshipTypeId,0) > 0 then 1 else 0 end) HasOwnedBy
	,sum(case when IsNull(offeredBy.RelationshipTypeId,0) > 0 then 1 else 0 end) HasOfferedBy
	,sum(case when IsNull(accreditedBy.RelationshipTypeId,0) > 0 then 1 else 0 end) HasAccreditedBy
	,sum(case when IsNull(approvedBy.RelationshipTypeId,0) > 0 then 1 else 0 end) HasApprovedBy
	,sum(case when IsNull(recognizedBy.RelationshipTypeId,0) > 0 then 1 else 0 end) HasRecognizedBy
	,sum(case when IsNull(RegulatedBy.RelationshipTypeId,0) > 0 then 1 else 0 end) HasRegulatedBy

	,sum(case when IsNull(finAssistance.EntityBaseId,0) > 0 then 1 else 0 end) HasFinancialAssistance
	,sum(case when IsNull(languages.EntityBaseId,0) > 0 then 1 else 0 end) HasLanguages
	,sum(case when IsNull(subjects.EntityBaseId,0) > 0 then 1 else 0 end) HasSubjects
	,sum(case when IsNull(keywords.EntityBaseId,0) > 0 then 1 else 0 end) HasKeywords
	,sum(case when IsNull(alternateNames.EntityBaseId,0) > 0 then 1 else 0 end) HasAlternateNames
	--INs --------------------------------------------------------------
	,sum(case when IsNull(accreditedIN.[AssertedInTypeId],0) > 0	then 1 else 0 end) HasAccreditedIn
	,sum(case when IsNull(approvedIN.[AssertedInTypeId],0) > 0		then 1 else 0 end) HasApprovedIN
	,sum(case when IsNull(offeredIN.[AssertedInTypeId],0) > 0		then 1 else 0 end) HasOfferedIN
	,sum(case when IsNull(recognizedIN.[AssertedInTypeId],0) > 0	then 1 else 0 end) HasRecognizedIN
	,sum(case when IsNull(RegulatedIN.[AssertedInTypeId],0) > 0		then 1 else 0 end) HasRegulatedIN

	-- Process Profiles --------------------------------------------------------------
	--,sum(case when IsNull(adminProfile.EntityBaseId,0) > 0 then 1 else 0 end) HasAdminProcessProfile
	--,sum(case when IsNull(appealProfile.EntityBaseId,0) > 0 then 1 else 0 end) HasAppealProcessProfile
	--,sum(case when IsNull(complaintProfile.EntityBaseId,0) > 0 then 1 else 0 end) HasComplaintProcessProfile
	----,sum(case when IsNull(criteriaProfile.EntityBaseId,0) > 0 then 1 else 0 end) HasCriteriaProcessProfile
	--,sum(case when IsNull(devProfile.EntityBaseId,0) > 0 then 1 else 0 end) HasDevProcessProfile
	--,sum(case when IsNull(mtceProfile.EntityBaseId,0) > 0 then 1 else 0 end) HasMtceProcessProfile
	--,sum(case when IsNull(reviewProfile.EntityBaseId,0) > 0 then 1 else 0 end) HasReviewProcessProfile
	--,sum(case when IsNull(revokeProfile.EntityBaseId,0) > 0 then 1 else 0 end) HasRevokeProcessProfile

  from LearningOpportunity_Summary a
  inner join LearningOpportunity tbl on a.Id = tbl.Id
  inner join entity b on a.RowId = b.EntityUid
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  RelationshipTypeId  FROM [dbo].[Entity.AgentRelationship] inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and RelationshipTypeId=6
  ) ownedBy on a.Id = ownedBy.EntityBaseId

  -- BYs---------------------------------------------------------------------
  left join (
	  SELECT distinct Entity.EntityBaseId,  EntityId,  RelationshipTypeId  FROM [dbo].[Entity.AgentRelationship] inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and RelationshipTypeId=1
  ) accreditedBy on a.Id = accreditedBy.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  RelationshipTypeId  FROM [dbo].[Entity.AgentRelationship] inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and RelationshipTypeId=2
  ) approvedBy on a.Id = approvedBy.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  RelationshipTypeId  FROM [dbo].[Entity.AgentRelationship] inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and RelationshipTypeId=7
  ) offeredBy on a.Id = offeredBy.EntityBaseId

  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  RelationshipTypeId  FROM [dbo].[Entity.AgentRelationship] inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and RelationshipTypeId=10
  ) recognizedBy on a.Id = recognizedBy.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  RelationshipTypeId  FROM [dbo].[Entity.AgentRelationship] inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and RelationshipTypeId=12
  ) RegulatedBy on a.Id = RegulatedBy.EntityBaseId
  -- address---------------------------------------------------------------------
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.Address] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7
  ) Address on a.Id = Address.EntityBaseId
  ---------------------------------------------------------------------
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.CostProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7
  ) Costs on a.Id = Costs.EntityBaseId
  ---------------------------------------------------------------------
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.DurationProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7
  ) Duration on a.Id = Duration.EntityBaseId
  -------------------------------------
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.IdentifierValue] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7  and a.[IdentityValueTypeId] = 2
  ) identifiers on a.Id = identifiers.EntityBaseId
    left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.IdentifierValue] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and a.[IdentityValueTypeId] = 1
  ) videntifiers on a.Id = videntifiers.EntityBaseId
    -- hasPart---------------------------------------------------------------------
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.Credential] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7
  ) HasPart on a.Id = HasPart.EntityBaseId
  --manifests---------------------------------------------------------------------
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.CostManifest] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7
  ) commonCosts on a.Id = commonCosts.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.CommonCondition] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7
  ) commonConditions on a.Id = commonConditions.EntityBaseId
-----------------------------------------------------------------------
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.FinancialAssistanceProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7
  ) finAssistance on a.Id = finAssistance.EntityBaseId
-----------------------------------------------------------------------
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.Competency] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7
  ) Competencies on a.Id = Competencies.EntityBaseId
  -----------------------------------------------------------------------
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.JurisdictionProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7
  ) jurisdictions on a.Id = jurisdictions.EntityBaseId
  -- frameworks -------------------------------------------------------------------
left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM [dbo].[Entity_ReferenceFramework_Summary]
	  where [EntityTypeId]= 7 and [CategoryId] = 23
  ) cip on a.Id = cip.EntityBaseId
  left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM [dbo].[Entity_ReferenceFramework_Summary]
	  where [EntityTypeId]= 7 and [CategoryId] = 11
  ) occ on a.Id = occ.EntityBaseId
  left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM [dbo].[Entity_ReferenceFramework_Summary]
	  where [EntityTypeId]= 7 and [CategoryId] = 10
  ) ind on a.Id = ind.EntityBaseId
  --properties---------------------------------------------------------------------
    left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM [dbo].[EntityProperty_Summary]  where [EntityTypeId]= 7 and [CategoryId] = 4
  ) audienceLevelType on a.Id = audienceLevelType.EntityBaseId
    left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM [dbo].[EntityProperty_Summary]  where [EntityTypeId]= 7 and [CategoryId] = 14
  ) audience on a.Id = audience.EntityBaseId
    left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM [dbo].[EntityProperty_Summary]  where [EntityTypeId]= 7 and [CategoryId] = 21
  ) delType on a.Id = delType.EntityBaseId
    left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM [dbo].[EntityProperty_Summary]  where [EntityTypeId]= 7 and [CategoryId] = 53
  ) learningMethod on a.Id = learningMethod.EntityBaseId

  --INs ---------------------------------------------------------------------
   left join (
	  SELECT distinct Entity.EntityBaseId,  EntityId,  [AssertedInTypeId]  FROM [dbo].[Entity.JurisdictionProfile] inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and  JProfilePurposeId = 3 and [AssertedInTypeId] = 1
  ) accreditedIN on a.Id = accreditedIN.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  [AssertedInTypeId]  FROM [dbo].[Entity.JurisdictionProfile] inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and  JProfilePurposeId = 3 and [AssertedInTypeId] = 2
  ) approvedIN on a.Id = approvedIN.EntityBaseId
    --
    left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  [AssertedInTypeId]  FROM [dbo].[Entity.JurisdictionProfile] inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and  JProfilePurposeId = 3 and [AssertedInTypeId] = 7
  ) offeredIN on a.Id = offeredIN.EntityBaseId
  --
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  [AssertedInTypeId]  FROM [dbo].[Entity.JurisdictionProfile] inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and  JProfilePurposeId = 3 and [AssertedInTypeId] = 10
  ) recognizedIN on a.Id = recognizedIN.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  [AssertedInTypeId]  FROM [dbo].[Entity.JurisdictionProfile] inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and  JProfilePurposeId = 3 and [AssertedInTypeId] = 12
  ) RegulatedIN on a.Id = RegulatedIN.EntityBaseId

-- condition profiles---------------------------------------------------------------------
  --requires
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ConditionProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and a.ConnectionTypeId=1 and isnull(ConditionSubTypeId, 0) = 1 
  ) requires on a.Id = requires.EntityBaseId
  --recommends
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ConditionProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and a.ConnectionTypeId=2 and isnull(ConditionSubTypeId, 0) = 1
  ) recommends on a.Id = recommends.EntityBaseId
  --co-requisite
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ConditionProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and a.ConnectionTypeId=10
  ) coreq on a.Id = coreq.EntityBaseId
-- entry condition
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ConditionProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and a.ConnectionTypeId=11
  ) entryLvl on a.Id = entryLvl.EntityBaseId
  --[Entity.Reference]---------------------------------------------------------------------
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.Reference] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and [CategoryId] = 65
  ) languages on a.Id = languages.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.Reference] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and [CategoryId] = 34
	  and Len(IsNull(a.TextValue,'')) > 0
  ) subjects on a.Id = subjects.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.Reference] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and [CategoryId] = 35
	  and Len(IsNull(a.TextValue,'')) > 0
  ) keywords on a.Id = keywords.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.Reference] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and [CategoryId] = 38
	  and Len(IsNull(a.TextValue,'')) > 0
  ) alternateNames on a.Id = alternateNames.EntityBaseId 
-- Process profiles---------------------------------------------------------------------
--  --1-admin
--  left join (
--	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ProcessProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and a.ProcessTypeId=1 
--  ) adminProfile on a.Id = requires.EntityBaseId
--  --2
--  left join (
--	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ProcessProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and a.ProcessTypeId=2 
--  ) devProfile on a.Id = requires.EntityBaseId
--  --3
--  left join (
--	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ProcessProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and a.ProcessTypeId=3 
--  ) mtceProfile on a.Id = requires.EntityBaseId
----4
--  left join (
--	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ProcessProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and a.ProcessTypeId=4
--  ) appealProfile on a.Id = requires.EntityBaseId
--  --5
--  left join (
--	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ProcessProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and a.ProcessTypeId=5
--  ) complaintProfile on a.Id = requires.EntityBaseId
-- --6 CRITERIA- obsolete
--  --left join (
--	 -- SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ProcessProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and a.ProcessTypeId=6 
--  --) criteriaProfile on a.Id = requires.EntityBaseId
----7
--  left join (
--	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ProcessProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and a.ProcessTypeId=7
--  ) reviewProfile on a.Id = requires.EntityBaseId
--  --8
--  left join (
--	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ProcessProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=7 and a.ProcessTypeId=8
--  ) revokeProfile on a.Id = requires.EntityBaseId

where a.EntityStateId = 3
GO

