use credFinder
GO


--USE staging_credFinder
--GO

use sandbox_credFinder
go

/****** Object:  View [dbo].[Assessment_Competency_Summary]    Script Date: 10/6/2017 4:29:36 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*

use credFinder
GO

SELECT [Id]
      ,[EntityId]
      ,[EntityUid]
      ,[Assessment]
      ,[AssessmentId]
      ,[FrameworkName]
      ,[EntityCompetencyId]
      ,[Competency]
      ,[TargetNodeDescription]
      ,[TargetNode]
      ,[CodedNotation]
      ,[ParentAssessmentId]
      ,[ParentAssessment]
	  ,CompetencyCreated
  FROM [dbo].[Assessment_Competency_Summary]
	where AssessmentId= 12
order by EntityCompetencyId



 ( base.Id in (
 SELECT LearningOpportunityId FROM [dbo].Assessment_Competency_Summary  where AlignmentType = 'assesses' AND ( ([Name] like '%design%' OR [Description] like '%design%') ) 
 
 ) )

*/

/*
Assessment_Competency_Summary
Modifications
21-05-02 mparsons - stop using: EntityCompetencyFramework_Items_Summary
					- too many joins result

*/
Alter VIEW [dbo].[Assessment_Competency_Summary]
AS

SELECT DISTINCT
	---a.EntityCompetencyFrameworkItemId as Id,
	IsNUll(b.Id,0) AS  Id,
	a.[EntityId], e.EntityUid,
	asmt.Name as Assessment, 
	asmt.Id as AssessmentId
	,a.[FrameworkName]
	--,a.EntityCompetencyId
	,a.Id AS EntityCompetencyId
	,a.TargetNodeName AS Competency
	,a.TargetNodeName AS Name 
	--,a.Competency
	--,a.Competency As Name
	,a.TargetNodeDescription
	,a.TargetNodeDescription as Description
	,TargetNode
	,[CodedNotation]
	,b.[ExistsInRegistry]
	,parentAsmt.Id as ParentAssessmentId
	,parentAsmt.Name as ParentAssessment
	--,'Assesses' as [AlignmentType]
	,a.Alignment as AlignmentType
	,a.Created  as CompetencyCreated

  --FROM [dbo].[EntityCompetencyFramework_Items_Summary] a
  --inner join Entity e					on a.EntityId = e.Id
	FROM       dbo.[Entity.Competency] a
	LEFT JOIN dbo.CompetencyFramework b ON a.CompetencyFrameworkId = b.id
	inner join Entity e					on a.EntityId = e.Id
	inner join Assessment asmt	on e.EntityUid = asmt.RowId

  --get related Entity.Assessment
  -- WHOA why would there always be an Entity.Assessment? Changed to a left join to evaluate
  Left join [Entity.Assessment] relatedEntityAsmt	on asmt.Id = relatedEntityAsmt.AssessmentId
  --get parent (most likely comp is at a embedded Lopp level)
  left join Entity entityAsmtEntity					on relatedEntityAsmt.EntityId = entityAsmtEntity.Id
  left join Assessment parentAsmt					on entityAsmtEntity.EntityUid = parentAsmt.RowId

  --not sure if should limit alignment type here?
  where e.EntityTypeId = 3
  --AND a.[AlignmentType] = 'assesses' 
  /*
     entity.Competency
		 Assessment
    		entity.Assessment
    			entity (parent LO)
					Assessment (rowId)

	*/

GO


