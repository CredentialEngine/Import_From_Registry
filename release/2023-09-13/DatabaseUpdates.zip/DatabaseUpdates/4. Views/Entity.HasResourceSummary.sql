use credFinder
go

USE [sandbox_credFinder]
GO
--use staging_credFinder
--go

/*
USE [sandbox_credFinder]
GO

SELECT [Id]
      ,[EntityId]
      ,[EntityTypeId]
      ,[ResourceId], RelationshipTypeId
      ,[Created]
      ,[EntityType]
      ,[Name]
      ,[Description]
      ,[CTID]
      ,[SubjectWebpage]
      ,[OwningOrgId], Organization
      ,[PublishedByOrgId]
  FROM [dbo].[Entity.HasResourceSummary]

GO



*/
Alter VIEW [Entity.HasResourceSummary] 
AS
SELECT a.[Id]
      ,a.[EntityId]
      ,a.[EntityTypeId]
      ,a.[ResourceId]
	  ,a.RelationshipTypeId
      ,a.[Created]
	  ,b.EntityType, b.Name, b.Description, b.CTID, b.SubjectWebpage
	  ,b.EntityStateId
	  ,b.[OwningOrgId], Isnull(c.name,'') As Organization 
	  ,b.[PublishedByOrgId]
  FROM [dbo].[Entity.HasResource] a 
  inner join Entity_Cache b on a.EntityTypeId = b.EntityTypeId and a.ResourceId = b.BaseId
  Left Join Organization c on b.OwningOrgId = c.Id 
  where b.EntityStateId > 1


GO
grant select on [Entity.HasResourceSummary] to public 
go


