use credFinder
GO

use sandbox_credfinder
go

/****** Object:  View [dbo].[Credential_ConditionProfile]    Script Date: 8/22/2017 5:26:56 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
USE [credFinder]
GO

SELECT DISTINCT
	 [CredentialId]
     -- ,[CredentialRowId]
      ,[parentEntityId]
      ,a.[Name] As Credential
      ,a.[EntityId]
     -- ,[EntityTypeId]
    --  ,[EntityUid]
      ,[EntityConditionProfileId]
      --,[ConnectionTypeId]
      --,[ConditionSubTypeId]
      --,[ConnectionType]
      ,[ConnectionTypeSchemaName]
      --,a.[RowId]
	  ,ConditionDescription
      ,[HasTargetCredential]
      ,[HasTargetAssessment]
	  ,ISNULL(asmt.Id, 0) AS AssessmentId
	  ,asmt.Name as Assessment, asmt.SubjectWebpage as AssessmentSubjectWebpage

      ,[HasLearningOpportunity]
	  ,ISNULL(lo.Id, 0) AS LearningOpportunityId
	  ,lo.Name as LearningOpportunity, lo.SubjectWebpage as LearningOpportunitySubjectWebpage
  FROM [dbo].[Credential_ConditionProfile] a

	inner join [Credential_BasicSummary] c on a.CredentialId = c.Id
	Inner Join [Indiana.OrganizationSummary] d on c.OwningAgentUid = d.RowId
	Left JOIN dbo.[Entity.LearningOpportunity] elo ON a.EntityId = elo.EntityId 
	Left join LearningOpportunity lo on elo.LearningOpportunityId = lo.Id and lo.EntityStateId > 1

	Left JOIN dbo.[Entity.Assessment] ea ON a.EntityId = ea.EntityId 
	Left join Assessment asmt on ea.AssessmentId = asmt.Id and asmt.EntityStateId > 1
where 
	ConnectionTypeId= 1 and ConditionSubTypeId = 1 -- requires only


*/
/*
NOTE: should this be excluding connection profiles????
	Cannot at this time, as used in the view Credential_PartsSummary

Entity.ConditionProfile a
	Entity condProfEntity	on a.RowId = condProfEntity.EntityUid (entity for condition, not parent)
	Entity credEntity		on a.EntityId  = credEntity.Id
	credential c			on c.RowId = credEntity.EntityUid

*/
Alter VIEW [dbo].[Credential_ConditionProfile]
AS
SELECT        
	c.Id AS CredentialId
	, c.RowId as CredentialRowId
	, a.EntityId as parentEntityId
	, c.Name
	, condProfEntity.Id As EntityId		-- entityId for the Entity for the ConditionProfile
	, condProfEntity.EntityTypeId		--?? always cond profile
	, credEntity.EntityUid					--mixing Entity references!!!
	, a.Id AS EntityConditionProfileId
	, a.ConnectionTypeId
	, isnull(a.ConditionSubTypeId,1) as ConditionSubTypeId
	, a.Description as ConditionDescription
	, cpv.Title as ConnectionType
	, cpv.SchemaName as ConnectionTypeSchemaName

	--temp for testing
	--, ec.CredentialId as TargetCredential
	, a.RowId		--Can use to join Entity.Assessment and Entity.LearningOpportunity 
							--RowId = Entity.EntitUid and Entity.Id = child.EntityId
	-- AS EntityConditionProfileRowId
	,case when exists (select a.credentialId from [Entity.Credential] a 
		inner join Credential b on a.CredentialId = b.Id and b.EntityStateId > 1 
		where a.EntityId = condProfEntity.id) then 1			else 0 end As HasTargetCredential
	,case when exists (select AssessmentId from [Entity.Assessment] a
		inner join Assessment b on a.AssessmentId = b.Id and b.EntityStateId > 1 
		where a.EntityId = condProfEntity.id) then 1			else 0 end As HasTargetAssessment
	,case when exists (select LearningOpportunityId from [Entity.LearningOpportunity] a
		inner join LearningOpportunity b on a.LearningOpportunityId = b.Id and b.EntityStateId > 1 
		where a.EntityId = condProfEntity.id) then 1			else 0 end As HasLearningOpportunity


FROM            
		dbo.[Entity.ConditionProfile] a
INNER JOIN dbo.Entity credEntity			ON a.EntityId = credEntity.Id				--entity of parent/credential
INNER JOIN dbo.Credential c					ON credEntity.EntityUid = c.RowId

Inner Join [Codes.PropertyValue] cpv	on a.ConnectionTypeId = cpv.Id
INNER JOIN dbo.Entity condProfEntity	ON a.RowId = condProfEntity.EntityUid		--entity for cond profile
--temp for testing:
--Left Join [Entity.Credential] ec on condProfEntity.Id = ec.EntityId

where c.EntityStateId > 1

GO
grant select on [Credential_ConditionProfile] to public
go

