USE [sandbox_credFinder]
GO

/****** 
NOTE NEED TO CHG THE ENV FOR BOTH DATABASES FOR EACH OF STAGING, SANDBOX, AND PROD

******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
This will be an expensive query. 
- what is the purpose?
consider an alternative
SELECT  
 
	[EntityType] as ReferenceType
	,[BaseId] as Id   
	,[Name]
	,[Description]
	,[SubjectWebpage]
	,[LastUpdated]
	,'Finder' as Source
  FROM [sandbox_credFinder].[dbo].[Entity_Cache]
  where [EntityStateId]= 2
  and EntityTypeId in (1,2,3,7)

  UNION
  SELECT  
 
	[EntityType] as ReferenceType
	,[BaseId] as Id   
	,[Name]
	,[Description]
	,URL as [SubjectWebpage]
	,[LastUpdated]
	,'Finder' as Source
  FROM [sandbox_ctdlEditor].[dbo].[Entity_Cache]
  where [EntityStateId]= 2
  and EntityTypeId in (1,2,3,7)

*/
CREATE View [dbo].[Reports_References]
as 
select distinct
   'Organization' as ReferenceType,
    c.Id,
	c.Name,
	c.Description,
	c.LastUpdated,
	c.SubjectWebpage,
	'Finder' as Source
	from [dbo].[Organization_Summary] as C where C.CTID=''

	Union 
	select distinct
	'Credential' as ReferenceType,
    c.Id,
	c.Name,
	c.Description,
	c.LastUpdated,
	c.SubjectWebpage,
	'Finder' as Source
	from [dbo].[Credential_Summary] as C where C.CTID=''

	Union 
	select distinct
	'Assessment' as ReferenceType,
    c.Id,
	c.Name,
	c.Description,
	c.LastUpdated,
	c.SubjectWebpage,
	'Finder' as Source
	from [dbo].[Assessment_Summary] as C where C.CTID=''

	Union 
	select distinct
	'LearningOpportunity' as ReferenceType,
    c.Id,
	c.Name,
	c.Description,
	c.LastUpdated,
	c.SubjectWebpage,
	'Finder' as Source
	from [dbo].LearningOpportunity_Summary as C where C.CTID=''

	union
	-----------------------Publisher references------------------------------------------------------------
	select distinct
   'Organization' as ReferenceType,
    c.Id,
	c.Name,
	c.Description,
	c.LastUpdated,
	'',
	'Publisher' as Source
	from [sandbox_ctdlEditor].[dbo].[Organization_Summary] as C where c.CTID='' --update to ctdleditor for production
	--from [ctdlEditor].[dbo].[Organization_Summary] as C where c.CTID=''

	Union 
	select distinct
	'Credential' as ReferenceType,
    c.Id,
	c.Name,
	c.Description,
	c.LastUpdated,
	'',
	'Publisher' as Source
	from [sandbox_ctdlEditor].[dbo].[Credential_Summary] as C where c.CTID=''

	--from [ctdlEditor].[dbo].[[Credential_Summary]] as C where c.CTID=''
	Union 
	select distinct
	'Assessment' as ReferenceType,
    c.Id,
	c.Name,
	c.Description,
	c.LastUpdated,
	'',
	'Publisher' as Source
	from [sandbox_ctdlEditor].[dbo].[Assessment_Summary] as C where c.CTID=''
	--from [ctdlEditor].[dbo].[[Assessment_Summary]] as C where c.CTID=''

	Union 
	select distinct
	'LearningOpportunity' as ReferenceType,
    c.Id,
	c.Name,
	c.Description,
	c.LastUpdated,
	'',
	'Publisher' as Source
	from [sandbox_ctdlEditor].[dbo].[LearningOpportunity_Summary] as C where c.CTID=''
	--from [ctdlEditor].[dbo].[[LearningOpportunity_Summary]] as C where c.CTID=''
GO


