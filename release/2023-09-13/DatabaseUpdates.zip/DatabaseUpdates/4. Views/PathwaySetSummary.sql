USE [credFinder]
GO

--use credfinder_prod
--go

--USE staging_credFinder
--GO

use sandbox_credFinder
go

/****** Object:  View [dbo].[PathwaySetSummary]    Script Date: 9/8/2020 2:15:42 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
USE [credFinder]
GO

SELECT [Id]
      ,[RowId]
      ,[CTID]
      ,[Name]
	  ,HasPathwaysCount
      ,[Description]
      ,[EntityStateId]
      ,[SubjectWebpage]
      ,[OwningAgentUid]
      ,[OrganizationId]
      ,[OrganizationName]
      ,[OrganizationCTID]
      ,[CredentialRegistryId]
      ,[EntityLastUpdated]
      ,[Created]
      ,[LastUpdated]
	  ,HasPathways, HasPathways2
  FROM [dbo].[PathwaySetSummary]

GO




*/
Alter VIEW [dbo].[PathwaySetSummary]
AS

SELECT a.[Id]
      ,a.[RowId]
      ,a.[CTID]
      ,a.[Name]
      ,a.[Description]
      ,a.[EntityStateId]
      ,a.[SubjectWebpage]
      ,a.[OwningAgentUid]
	  ,b.Id as OrganizationId
	  ,b.Name      as OrganizationName
	  ,b.CTID as OrganizationCTID
	  ,a.[CredentialRegistryId]
	  ,c.LastUpdated as EntityLastUpdated
      ,a.[Created]
      ,a.[LastUpdated]
	  --
	  ,pathways.cnt as HasPathwaysCount
	  --
	  	,(SELECT DISTINCT a.PathwayId, b.Name as Pathway
		FROM [dbo].[Entity.HasPathway] a Inner Join Pathway b on a.PathwayId = b.Id
		WHERE c.EntityTypeId= 23 AND a.EntityId = c.Id
		FOR XML RAW, ROOT('HasPathways')) HasPathways
	, IsNull(STUFF(
		(	
		SELECT '|' + convert(varchar,a.PathwayId)+'~'+b.Name AS [text()] 
		FROM [dbo].[Entity.HasPathway] a Inner Join Pathway b on a.PathwayId = b.Id
		WHERE c.EntityTypeId= 23 AND a.EntityId = c.Id
		FOR XML Path('')
		), 1,1,''
	),'') as HasPathways2
  FROM [dbo].[PathwaySet] a
Inner join dbo.Organization b on a.OwningAgentUid = b.RowId
INNER JOIN dbo.Entity AS c ON a.RowId = c.EntityUid

left Join (
	Select b.EntityUid, count(*) as cnt 
	from dbo.[Entity.HasPathway] a 
	inner join Entity b on a.EntityId = b.Id 
	group by b.EntityUid) as pathways on a.RowId = pathways.EntityUid

GO
grant select on [PathwaySetSummary] to public
go
/*
<HasPathways><row PathwayId="186" Pathway="UpSkill! SA Pathway- Skillbooster"/><row PathwayId="187" Pathway="UpSkill! SA Pathway- Certificate +"/></HasPathways>

187~UpSkill! SA Pathway- Certificate +|186~UpSkill! SA Pathway- Skillbooster

*/
