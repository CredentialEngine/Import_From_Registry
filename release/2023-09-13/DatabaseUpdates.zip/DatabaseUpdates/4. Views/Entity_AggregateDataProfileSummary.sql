use credFinder
go

use sandbox_credFinder
go

/****** Object:  View [dbo].[Entity_AggregateDataProfileSummary]    Script Date: 2/12/2023 12:21:54 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
USE [credFinder_prod]
GO

SELECT [EntityTypeId]
      ,[EntityBaseId]
      ,[EntityBaseName]
      ,[Name]
      ,[Description]
      ,[PostReceiptMonths]
      ,[NumberAwarded]
      ,[dspEntityStateId]
      ,[dspCTID]
      ,[dspName]
      ,[dspDescription]
      ,[DataProviderUID]
  FROM [dbo].[Entity_AggregateDataProfileSummary]
  where EntityTypeId= 7 and EntityBaseId=9062
GO

just for adhoc queries

*/
Alter VIEW [dbo].[Entity_AggregateDataProfileSummary]
AS
SELECT        e.EntityTypeId, e.EntityBaseId, e.EntityBaseName
, eadp.Name, eadp.Description, eadp.PostReceiptMonths, eadp.NumberAwarded
, dsp.EntityStateId as dspEntityStateId
, dsp.CTID	as dspCTID
, dsp.Name AS dspName
, dsp.Description AS dspDescription
, dsp.DataProviderUID
FROM            dbo.Entity AS e 
INNER JOIN dbo.[Entity.AggregateDataProfile] AS eadp ON e.Id = eadp.EntityId 
INNER JOIN dbo.Entity AS adpEntity ON eadp.EntityId = adpEntity.Id 

LEFT JOIN dbo.[Entity.DataSetProfile] AS edsp ON adpEntity.Id = edsp.EntityId 
LEFT OUTER JOIN dbo.DataSetProfile AS dsp	ON edsp.DataSetProfileId = dsp.Id
--these won't happen because the adp is deleted on each import.
--Left JOIN dbo.Entity AS dspEntity			ON dsp.RowId = dspEntity.EntityUId 
--Left Join dbo.[Entity.learningOpportunity] elo on dspEntity.Id = elo.Id

--where e.EntityTypeId = 7
--AND e.EntityBaseId=elo.LearningOpportunityId
GO


