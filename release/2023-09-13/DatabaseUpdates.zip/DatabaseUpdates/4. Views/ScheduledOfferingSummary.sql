USE [credFinder]
GO
--use credfinder_prod
--go

--USE staging_credFinder
--GO

use sandbox_credFinder
go


/****** Object:  View [dbo].[ScheduledOfferingSummary]    Script Date: 7/29/2020 11:13:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*
USE [credFinder]
GO
USE [sandbox_credFinder]
GO

SELECT [Id]
      ,[RowId]
      ,[EntityStateId]
      ,[Name]
      ,[Description]
      ,[SubjectWebpage]
      ,[CTID]
      ,[OwningAgentUid]
      ,[OrganizationCTID]
      ,[OrganizationId]
      ,[OrganizationName]
      ,[HasTransferValueProfiles]
      ,[CredentialRegistryId]
      ,[CodedNotation]
      ,[CreditValueJson]
      ,[IntermediaryForJson]
      ,[Subject]
      ,[Created]
      ,[LastUpdated]
  FROM [dbo].[ScheduledOfferingSummary]

GO



GO


*/
/*
ScheduledOfferingSummary
Notes
- 
Mods
23-04-05 mparsons - new


*/
Alter VIEW [dbo].[ScheduledOfferingSummary]
AS


SELECT  a.[Id]
		,e.Id as EntityId
		,a.[RowId]
		,a.[CTID]
		,a.[EntityStateId]
		,a.[Name]
		,a.[Description]
		,a.[OfferedBy]
		,a.[SubjectWebpage]
		,a.[DeliveryTypeDescription]
		,a.[AvailableOnlineAt]
		,a.[AvailabilityListing]
		,a.[AlternateName]
		,a.[Created]
		,a.[LastUpdated]

		,isnull(b.ctid,'')  as OrganizationCTID
		,b.Id as OrganizationId
		,b.Name as OrganizationName
	--
		,IsNull(aggregateDataProfile.Nbr,0) As AggregateDataProfileCount
--
  FROM [dbo].[ScheduledOffering] a

INNER JOIN dbo.Entity AS e ON a.RowId = e.EntityUid 
LEFT  JOIN dbo.Organization AS b ON a.[OfferedBy] = b.RowId

--=========
left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.AggregateDataProfile] a Inner join Entity b ON a.EntityId = b.Id Where b.EntityTypeId = 15  Group By b.EntityBaseId
		) aggregateDataProfile	on a.Id = aggregateDataProfile.EntityBaseId 

GO

grant select on [ScheduledOfferingSummary] to public
go


