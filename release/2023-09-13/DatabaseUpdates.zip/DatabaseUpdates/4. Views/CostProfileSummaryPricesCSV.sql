use credFinder
GO

/****** Object:  View [dbo].[CostProfileSummaryPricesCSV]    Script Date: 9/28/2016 12:36:27 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
USE [credFinder]
GO

SELECT top (500)
cp.[ParentEntityId], ec.EntityType as ParentEntityType,  
	cp.[EntityBaseId] as ParentFinderId
	,ec.Name as ParentName, ec.CTID as parentCTID
     -- ,cp.[ParentEntityUid]
   --   ,cp.[ParentEntityTypeId]
     
      ,cp.[EntityCostProfileId]
      ,cp.[ProfileName] as CostProfileName
      ,cp.[Description]
      ,cp.[DetailsUrl] as CostDetails
      ,cp.[CurrencyCode]
      ,cp.[Currency]
      ,cp.[CostsList]
	  ,cp.LastUpdated as costProfileLastUpdated
  FROM [dbo].[CostProfileSummaryPricesCSV] cp
  inner join entity_cache ec on cp.parentEntityId = ec.Id
WHERE ec.EntityStateId = 3
and cp.ParentEntityTypeId= 1

GO


*/
/*
list cost profile detail and CSV of prices
*/
Alter VIEW [dbo].[CostProfileSummaryPricesCSV]
AS

SELECT        
	ParentEntity.Id AS ParentEntityId, 
	ParentEntity.EntityUid AS ParentEntityUid, 
	ParentEntity.EntityTypeId AS ParentEntityTypeId, 
	ParentEntity.EntityBaseId,
	ecp.Id AS EntityCostProfileId, 
	ecp.ProfileName, 
	ecp.Description,
	ecp.DetailsUrl, 
	d.AlphabeticCode AS CurrencyCode, 
	d.Currency, 
	CASE
          WHEN CostsList IS NULL THEN ''
          WHEN len(CostsList) = 0 THEN ''
          ELSE left(CostsList,len(CostsList)-1)
    END AS CostsList
	,ecp.LastUpdated

FROM dbo.[Entity.CostProfile] ecp 
INNER JOIN dbo.Entity AS ParentEntity	ON ecp.EntityId = ParentEntity.Id 
LEFT OUTER JOIN dbo.[Codes.Currency] d	ON ecp.CurrencyTypeId = d.NumericCode
-- 21-12-17 mp - this should probably use the schema or have an alternative with the schema for export/external use
CROSS APPLY (
    SELECT convert(varchar(50),replace(c.SchemaName,'costType:','') )  + '~' + convert(varchar,cp.Price) + '| '
    FROM dbo.[Entity.CostProfileItem] cp 
	Inner JOIN dbo.[Codes.PropertyValue] c	ON cp.CostTypeId = c.Id 
    WHERE ecp.Id = cp.CostProfileId
	Order by c.Title
    FOR XML Path('') ) E (CostsList)

GO
grant select on [CostProfileSummaryPricesCSV] to public
go

