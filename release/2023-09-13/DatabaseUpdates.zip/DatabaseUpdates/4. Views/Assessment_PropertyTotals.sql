use credFinder
go

use sandbox_credFinder 
go

--use staging_credFinder
--go

/*
INSERT INTO [dbo].[Counts.Assessment_Property]
           ([Id]           ,[Property]           ,[Label]           ,[Policy]           ,[PropertyGroup]           ,[Total])
     VALUES
           (99, 'AssessmentExample','AssessmentExample','Recommended','URL',0)
GO


--generate totals for columns with data

USE [credFinder]
GO

SELECT [Total]
      ,[Name]
      ,[Description]
      ,[SubjectWebpage]
      ,[CTID]
      ,[LifeCycleStatusType]
      ,[HasAvailabilityListing]
      ,[HasAvailableOnlineAt]
      ,[HasDateEffective]
      ,[HasDeliveryTypeDescription]
      ,[HasAssessmentExample]
      ,[HasAssessmentExampleDescription]
      ,[HasAssessmentMethodDescription]
      ,[HasLearningMethodDescription]
      ,[HasCodedNotation]
      ,[HasGroupEvaluation]
      ,[HasGroupParticipation]
      ,[IsProctored]
      ,[HasAssessmentOutput]
      ,[HasExternalResearch]
      ,[HasProcessStandards]
      ,[HasProcessStandardsDescription]
      ,[HasScoringMethodDescription]
      ,[HasScoringMethodExample]
      ,[HasScoringMethodExampleDescription]
      ,[HasVersionIdentifier]
      ,[HasCreditUnitType]
      ,[HasCreditUnitValue]
      ,[HasCreditUnitMaxValue]
      ,[HasCreditUnitTypeDescription]
      ,[HasOwnedBy]
      ,[HasOfferedBy]
      ,[HasAccreditedBy]
      ,[HasApprovedBy]
      ,[HasRecognizedBy]
      ,[HasRegulatedBy]
      ,[HasInstructionalPgms]
      ,[HasOccupations]
      ,[HasIndustries]
      ,[HasAudienceLevelType]
      ,[HasAudience]
      ,[HasDeliveryMethodType]
      ,[hasAssessmentMethodType]
      ,[hasAssessmentUseType]
      ,[HasScoringMethodType]
      ,[HasCompetencies]
      ,[HasAddress]
      ,[HasCosts]
      ,[HasDuration]
      ,[HasJurisdictions]
      ,[HasCommonCosts]
      ,[HasCommonConditions]
      ,[HasRequires]
      ,[HasRecommends]
      ,[HasCorequisites]
      ,[HasEntryConditions]
      ,[HasIsRequiredFor]
      ,[HasRecommendedFor]
      ,[HasIsAdvancedStandingFor]
      ,[HasAdvancedStandingFrom]
      ,[HasIsPreparationFor]
      ,[HasPreparationFrom]
      ,[HasFinancialAssistance]
      ,[HasLanguages]
      ,[HasSubjects]
      ,[HasKeywords]
      ,[HasAccreditedIn]
      ,[HasApprovedIN]
      ,[HasOfferedIN]
      ,[HasRecognizedIN]
      ,[HasRegulatedIN]
      ,[HasAdminProcessProfile]
      ,[HasDevProcessProfile]
      ,[HasMtceProcessProfile]
  FROM [dbo].[Assessment_PropertyTotals]

GO



Updates
- change to use actual property names
- add inLanguage
- determine sort order - can be done in the counts table

Add:
HasAssessmentMethodDescription
HasAssessmentMethodType
HasAssessmentUseType
HasScoringMethodType
HasLearningMethodDescription
CodedNotation
hasGroupEvaluation
hasGroupParticipation
isProctored

Alt handling
HasCreditValue

Modifications
22-01-11 mparsons - add LifeCycleStatusType
22-10-08 mparsons - add alternameName
*/
Alter VIEW [dbo].[Assessment_PropertyTotals]
AS

select 

	sum(case when Len(IsNull(a.Name, '')) > 0 then 1 else 0 end) as Total
	, sum(case when Len(IsNull(a.Name, '')) > 0 then 1 else 0 end) as Name
	, sum(case when Len(IsNull(a.Description, '')) > 0 then 1 else 0 end) as Description
	, sum(case when Len(IsNull(a.SubjectWebpage, '')) > 0 then 1 else 0 end) as SubjectWebpage
	, sum(case when Len(IsNull(a.CTID, '')) > 0 then 1 else 0 end) as CTID
	 , sum(case when Len(IsNull(a.LifeCycleStatusType, '')) > 0 then 1 else 0 end) as LifeCycleStatusType
	 --
	,sum(case when Len(IsNull(a.AvailabilityListing,'')) > 0 then 1 else 0 end) HasAvailabilityListing
	,sum(case when Len(IsNull(a.availableOnlineAt,'')) > 0 then 1 else 0 end) HasAvailableOnlineAt
	,sum(case when IsNull(a.DateEffective,'') > '1900-01-01 00:00:00.000' then 1 else 0 end) HasDateEffective

	,sum(case when Len(IsNull(tbl.DeliveryTypeDescription,'')) > 0 then 1 else 0 end) HasDeliveryTypeDescription		--##

	,sum(case when Len(IsNull(tbl.AssessmentExampleUrl,'')) > 0 then 1 else 0 end) HasAssessmentExample	
	,sum(case when Len(IsNull(tbl.AssessmentExampleDescription,'')) > 0 then 1 else 0 end) HasAssessmentExampleDescription		
	,sum(case when Len(IsNull(tbl.AssessmentMethodDescription,'')) > 0 then 1 else 0 end) HasAssessmentMethodDescription		
	,sum(case when Len(IsNull(tbl.LearningMethodDescription,'')) > 0 then 1 else 0 end) HasLearningMethodDescription	
	,sum(case when Len(IsNull(tbl.IdentificationCode,'')) > 0 then 1 else 0 end) HasCodedNotation
	,sum(case when IsNull(tbl.HasGroupEvaluation,0) = 1 then 1 else 0 end) HasGroupEvaluation
	,sum(case when IsNull(tbl.HasGroupParticipation,0) = 1 then 1 else 0 end) HasGroupParticipation
	,sum(case when IsNull(tbl.IsProctored,0) = 1 then 1 else 0 end) IsProctored
		--
	,sum(case when Len(IsNull(tbl.AssessmentOutput,'')) > 0 then 1 else 0 end) HasAssessmentOutput --##
	,sum(case when Len(IsNull(tbl.ExternalResearch,'')) > 0 then 1 else 0 end) HasExternalResearch		--##
	,sum(case when Len(IsNull(tbl.ProcessStandards,'')) > 0 then 1 else 0 end) HasProcessStandards --##

	,sum(case when Len(IsNull(tbl.ProcessStandardsDescription,'')) > 0 then 1 else 0 end) HasProcessStandardsDescription		--##
	,sum(case when Len(IsNull(tbl.ScoringMethodDescription,'')) > 0 then 1 else 0 end) HasScoringMethodDescription --##
	,sum(case when Len(IsNull(tbl.ScoringMethodExample,'')) > 0 then 1 else 0 end) HasScoringMethodExample
	,sum(case when Len(IsNull(tbl.ScoringMethodExampleDescription,'')) > 0 then 1 else 0 end) HasScoringMethodExampleDescription
	,sum(case when Len(IsNull(tbl.VersionIdentifier,'')) > 0 then 1 else 0 end) HasVersionIdentifier
	--
	,sum(case when Len(tbl.CreditUnitTypeId) > 0 then 1 else 0 end) HasCreditUnitType	
	,sum(case when Len(tbl.CreditUnitValue) > 0 then 1 else 0 end) HasCreditUnitValue	
	,sum(case when Len(tbl.CreditUnitMaxValue) > 0 then 1 else 0 end) HasCreditUnitMaxValue	
	,sum(case when Len(IsNull(tbl.CreditUnitTypeDescription,'')) > 0 then 1 else 0 end) HasCreditUnitTypeDescription  
	--
		-- BYs
	,sum(case when IsNull(ownedBy.RelationshipTypeId,0) > 0 then 1 else 0 end) HasOwnedBy
	,sum(case when IsNull(offeredBy.RelationshipTypeId,0) > 0 then 1 else 0 end) HasOfferedBy
	,sum(case when IsNull(accreditedBy.RelationshipTypeId,0) > 0 then 1 else 0 end) HasAccreditedBy
	,sum(case when IsNull(approvedBy.RelationshipTypeId,0) > 0 then 1 else 0 end) HasApprovedBy
	,sum(case when IsNull(recognizedBy.RelationshipTypeId,0) > 0 then 1 else 0 end) HasRecognizedBy
	,sum(case when IsNull(RegulatedBy.RelationshipTypeId,0) > 0 then 1 else 0 end) HasRegulatedBy
	--
	,sum(case when IsNull(cip.CategoryId,0) > 0 then 1 else 0 end) HasInstructionalPgms		--##
	,sum(case when IsNull(occ.CategoryId,0) > 0 then 1 else 0 end) HasOccupations			--##
	,sum(case when IsNull(ind.CategoryId,0) > 0 then 1 else 0 end) HasIndustries			--##
	-- PROPERTIES
	,sum(case when IsNull(audienceLevelType.CategoryId,0) > 0 then 1 else 0 end) HasAudienceLevelType
	,sum(case when IsNull(audience.CategoryId,0) > 0 then 1 else 0 end) HasAudience
	,sum(case when IsNull(delType.CategoryId,0) > 0 then 1 else 0 end) HasDeliveryMethodType

	,sum(case when IsNull(asmtMethodType.CategoryId,0) > 0 then 1 else 0 end) hasAssessmentMethodType
	,sum(case when IsNull(asmtUseType.CategoryId,0) > 0 then 1 else 0 end) hasAssessmentUseType
	,sum(case when IsNull(scoringMethodType.CategoryId,0) > 0 then 1 else 0 end) HasScoringMethodType
	--
	,sum(case when IsNull(Competencies.EntityBaseId,0) > 0 then 1 else 0 end) HasCompetencies
	,sum(case when IsNull(address.EntityBaseId,0) > 0 then 1 else 0 end) HasAddress
	,sum(case when IsNull(Costs.EntityBaseId,0) > 0 then 1 else 0 end) HasCosts
	,sum(case when IsNull(Duration.EntityBaseId,0) > 0 then 1 else 0 end) HasDuration
	,sum(case when IsNull(jurisdictions.EntityBaseId,0) > 0 then 1 else 0 end) HasJurisdictions
	--
	,sum(case when IsNull(commonCosts.EntityBaseId,0) > 0 then 1 else 0 end) HasCommonCosts
	,sum(case when IsNull(commonConditions.EntityBaseId,0) > 0 then 1 else 0 end) HasCommonConditions
	--conditions
		--
	,sum(case when IsNull(requires.EntityBaseId,0) > 0 then 1 else 0 end) HasRequires
	,sum(case when IsNull(recommends.EntityBaseId,0) > 0 then 1 else 0 end) HasRecommends
	,sum(case when IsNull(coreq.EntityBaseId,0) > 0 then 1 else 0 end) HasCorequisites
	,sum(case when IsNull(entryLvl.EntityBaseId,0) > 0 then 1 else 0 end) HasEntryConditions

	--connections
	--,sum(case when IsNull(RequiresCount,0) > 0 then 1 else 0 end) HasRequires
	--,sum(case when IsNull(RecommendsCount,0) > 0 then 1 else 0 end) HasRecommends
	,sum(case when IsNull(isRequiredForCount,0) > 0 then 1 else 0 end) HasIsRequiredFor
	,sum(case when IsNull(IsRecommendedForCount,0) > 0 then 1 else 0 end) HasRecommendedFor
	,sum(case when IsNull(IsAdvancedStandingForCount,0) > 0 then 1 else 0 end) HasIsAdvancedStandingFor
	,sum(case when IsNull(AdvancedStandingFromCount,0) > 0 then 1 else 0 end) HasAdvancedStandingFrom
	,sum(case when IsNull(isPreparationForCount,0) > 0 then 1 else 0 end) HasIsPreparationFor
	,sum(case when IsNull(PreparationFromCount,0) > 0 then 1 else 0 end) HasPreparationFrom


	,sum(case when IsNull(finAssistance.EntityBaseId,0) > 0 then 1 else 0 end) HasFinancialAssistance
	,sum(case when IsNull(languages.EntityBaseId,0) > 0 then 1 else 0 end) HasLanguages
	,sum(case when IsNull(subjects.EntityBaseId,0) > 0 then 1 else 0 end) HasSubjects
	,sum(case when IsNull(keywords.EntityBaseId,0) > 0 then 1 else 0 end) HasKeywords
	,sum(case when IsNull(alternateNames.EntityBaseId,0) > 0 then 1 else 0 end) HasAlternateNames
	--INs
	,sum(case when IsNull(accreditedIN.[AssertedInTypeId],0) > 0 then 1 else 0 end) HasAccreditedIn
	,sum(case when IsNull(approvedIN.[AssertedInTypeId],0) > 0 then 1 else 0 end) HasApprovedIN
	,sum(case when IsNull(offeredIN.[AssertedInTypeId],0) > 0 then 1 else 0 end) HasOfferedIN
	,sum(case when IsNull(recognizedIN.[AssertedInTypeId],0) > 0 then 1 else 0 end) HasRecognizedIN
	,sum(case when IsNull(RegulatedIN.[AssertedInTypeId],0) > 0 then 1 else 0 end) HasRegulatedIN

	-- Process Profiles --------------------------------------------------------------
	,sum(case when IsNull(adminProfile.EntityBaseId,0) > 0 then 1 else 0 end) HasAdminProcessProfile
	--,sum(case when IsNull(appealProfile.EntityBaseId,0) > 0 then 1 else 0 end) HasAppealProcessProfile
	--,sum(case when IsNull(complaintProfile.EntityBaseId,0) > 0 then 1 else 0 end) HasComplaintProcessProfile
	--,sum(case when IsNull(criteriaProfile.EntityBaseId,0) > 0 then 1 else 0 end) HasCriteriaProcessProfile
	,sum(case when IsNull(devProfile.EntityBaseId,0) > 0 then 1 else 0 end) HasDevProcessProfile
	,sum(case when IsNull(mtceProfile.EntityBaseId,0) > 0 then 1 else 0 end) HasMtceProcessProfile
	--,sum(case when IsNull(reviewProfile.EntityBaseId,0) > 0 then 1 else 0 end) HasReviewProcessProfile
	--,sum(case when IsNull(revokeProfile.EntityBaseId,0) > 0 then 1 else 0 end) HasRevokeProcessProfile

	--select count(*)
  from Assessment_Summary a
  inner join Assessment tbl on a.Id = tbl.Id
  inner join entity b on a.RowId = b.EntityUid
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  RelationshipTypeId  FROM dbo.[Entity.AgentRelationship] inner join entity on EntityId = entity.Id where entity.EntityTypeId=3 and RelationshipTypeId=6
  ) ownedBy on a.Id = ownedBy.EntityBaseId

  -- BYs
  left join (
	  SELECT distinct Entity.EntityBaseId,  EntityId,  RelationshipTypeId  FROM dbo.[Entity.AgentRelationship] inner join entity on EntityId = entity.Id where entity.EntityTypeId=3 and RelationshipTypeId=1
  ) accreditedBy on a.Id = accreditedBy.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  RelationshipTypeId  FROM dbo.[Entity.AgentRelationship] inner join entity on EntityId = entity.Id where entity.EntityTypeId=3 and RelationshipTypeId=2
  ) approvedBy on a.Id = approvedBy.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  RelationshipTypeId  FROM dbo.[Entity.AgentRelationship] inner join entity on EntityId = entity.Id where entity.EntityTypeId=3 and RelationshipTypeId=7
  ) offeredBy on a.Id = offeredBy.EntityBaseId

  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  RelationshipTypeId  FROM dbo.[Entity.AgentRelationship] inner join entity on EntityId = entity.Id where entity.EntityTypeId=3 and RelationshipTypeId=10
  ) recognizedBy on a.Id = recognizedBy.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  RelationshipTypeId  FROM dbo.[Entity.AgentRelationship] inner join entity on EntityId = entity.Id where entity.EntityTypeId=3 and RelationshipTypeId=12
  ) RegulatedBy on a.Id = RegulatedBy.EntityBaseId
-- frameworks -------------------------------------------------------------------
left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM dbo.[Entity_ReferenceFramework_Summary]
	  where EntityTypeId=3 and [CategoryId] = 23
  ) cip on a.Id = cip.EntityBaseId
  left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM dbo.[Entity_ReferenceFramework_Summary]
	  where EntityTypeId=3 and [CategoryId] = 11
  ) occ on a.Id = occ.EntityBaseId
  left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM dbo.[Entity_ReferenceFramework_Summary]
	  where EntityTypeId=3 and [CategoryId] = 10
  ) ind on a.Id = ind.EntityBaseId

  --properties
    left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM dbo.[EntityProperty_Summary]  where EntityTypeId=3 and [CategoryId] = 4
  ) audienceLevelType on a.Id = audienceLevelType.EntityBaseId
    left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM dbo.[EntityProperty_Summary]  where EntityTypeId=3 and [CategoryId] = 14
  ) audience on a.Id = audience.EntityBaseId
    left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM dbo.[EntityProperty_Summary]  where EntityTypeId=3 and [CategoryId] = 21
  ) delType on a.Id = delType.EntityBaseId

    left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM dbo.[EntityProperty_Summary]  where EntityTypeId=3 and [CategoryId] = 56
  ) asmtMethodType on a.Id = asmtMethodType.EntityBaseId
    left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM dbo.[EntityProperty_Summary]  where EntityTypeId=3 and [CategoryId] = 37
  ) asmtUseType on a.Id = asmtUseType.EntityBaseId
    left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM dbo.[EntityProperty_Summary]  where EntityTypeId=3 and [CategoryId] = 54
  ) scoringMethodType on a.Id = scoringMethodType.EntityBaseId
  -- ==========================================
--
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.Competency] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=3
  ) Competencies on a.Id = Competencies.EntityBaseId
  -- address
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.Address] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=3
  ) address on a.Id = address.EntityBaseId

  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.CostProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=3
  ) Costs on a.Id = Costs.EntityBaseId

  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.DurationProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=3
  ) Duration on a.Id = Duration.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.JurisdictionProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=3
  ) jurisdictions on a.Id = jurisdictions.EntityBaseId
  --manifests
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.CostManifest] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=3
  ) commonCosts on a.Id = commonCosts.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.CommonCondition] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=3
  ) commonConditions on a.Id = commonConditions.EntityBaseId
--
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.FinancialAssistanceProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=3
  ) finAssistance on a.Id = finAssistance.EntityBaseId

  -----------------------------------------------------------------------


  --INs
   left join (
	  SELECT distinct Entity.EntityBaseId,  EntityId,  [AssertedInTypeId]  FROM dbo.[Entity.JurisdictionProfile] inner join entity on EntityId = entity.Id where entity.EntityTypeId=3 and  JProfilePurposeId = 3 and [AssertedInTypeId] = 1
  ) accreditedIN on a.Id = accreditedIN.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  [AssertedInTypeId]  FROM dbo.[Entity.JurisdictionProfile] inner join entity on EntityId = entity.Id where entity.EntityTypeId=3 and  JProfilePurposeId = 3 and [AssertedInTypeId] = 2
  ) approvedIN on a.Id = approvedIN.EntityBaseId
    --
    left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  [AssertedInTypeId]  FROM [dbo].[Entity.JurisdictionProfile] inner join entity on EntityId = entity.Id where entity.EntityTypeId=3 and  JProfilePurposeId = 3 and [AssertedInTypeId] = 7
  ) offeredIN on a.Id = offeredIN.EntityBaseId
  --
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  [AssertedInTypeId]  FROM dbo.[Entity.JurisdictionProfile] inner join entity on EntityId = entity.Id where entity.EntityTypeId=3 and  JProfilePurposeId = 3 and [AssertedInTypeId] = 10
  ) recognizedIN on a.Id = recognizedIN.EntityBaseId
  --
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  [AssertedInTypeId]  FROM dbo.[Entity.JurisdictionProfile] inner join entity on EntityId = entity.Id where entity.EntityTypeId=3 and  JProfilePurposeId = 3 and [AssertedInTypeId] = 12
  ) RegulatedIN on a.Id = RegulatedIN.EntityBaseId

-- condition profiles
  --requires
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ConditionProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=3 and a.ConnectionTypeId=1 and isnull(ConditionSubTypeId, 0) = 1 
  ) requires on a.Id = requires.EntityBaseId
  --recommends
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ConditionProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=3 and a.ConnectionTypeId=2 and isnull(ConditionSubTypeId, 0) = 1
  ) recommends on a.Id = recommends.EntityBaseId
  --co-requisite
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ConditionProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=3 and a.ConnectionTypeId=10
  ) coreq on a.Id = coreq.EntityBaseId
-- entry condition
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ConditionProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=3 and a.ConnectionTypeId=11
  ) entryLvl on a.Id = entryLvl.EntityBaseId
  --[Entity.Reference]
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.Reference] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=3 and [CategoryId] = 65
  ) languages on a.Id = languages.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.Reference] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=3 and [CategoryId] = 34
	  and Len(IsNull(a.TextValue,'')) > 0
  ) subjects on a.Id = subjects.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.Reference] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=3 and [CategoryId] = 35
	  and Len(IsNull(a.TextValue,'')) > 0
  ) keywords on a.Id = keywords.EntityBaseId
   left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.Reference] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=3 and [CategoryId] = 38
	  and Len(IsNull(a.TextValue,'')) > 0
  ) alternateNames on a.Id = alternateNames.EntityBaseId 
-- Process profiles---------------------------------------------------------------------
  --1-admin
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ProcessProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=3 and a.ProcessTypeId=1 
  ) adminProfile on a.Id = adminProfile.EntityBaseId
  --2
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ProcessProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=3 and a.ProcessTypeId=2 
  ) devProfile on a.Id = devProfile.EntityBaseId
  --3
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.ProcessProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=3 and a.ProcessTypeId=3 
  ) mtceProfile on a.Id = mtceProfile.EntityBaseId


where a.EntityStateId = 3
go
grant select on [Assessment_PropertyTotals] to public
go

/*
SELECT distinct [EntityId],[CategoryId]
      --,[SortOrder]
      ,[Category]

  FROM dbo.[EntityProperty_Summary]
  where [EntityTypeId] = 3
  go
  SELECT distinct [CategoryId]
      --,[SortOrder]
      ,[Category]

  FROM dbo.[EntityProperty_Summary]
  where [EntityTypeId] = 3

  */