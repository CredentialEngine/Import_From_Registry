USE [credFinder]
GO
--use credfinder_prod
--go

--USE staging_credFinder
--GO

use sandbox_credFinder
go


/****** Object:  View [dbo].[JobProfileSummary]    Script Date: 7/29/2020 11:13:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*
USE [credFinder]
GO
USE [sandbox_credFinder]
GO

SELECT base.[Id]
      ,base.[RowId]
      ,base.[EntityId]
      ,base.[Name]
      ,base.[Description]
      ,base.[EntityStateId]
      ,base.[CTID]
      ,base.[PrimaryAgentUid]
      ,base.[PrimaryOrganizationId]
      ,base.[PrimaryOrganizationName]
      ,base.[PrimaryOrganizationCtid]
      ,base.[SubjectWebpage]
      ,base.[AbilityEmbodied]
      ,base.[Classification]
      ,base.[CodedNotation]
      ,base.[Comment]
      ,base.[Identifier]
      ,base.[KnowledgeEmbodied]
      ,base.[SkillEmbodied]
      ,base.[SameAs]
      ,base.[VersionIdentifier]
      ,base.[JsonProperties]
      ,base.[Created]
      ,base.[LastUpdated]
  FROM [dbo].[JobProfileSummary] a

GO



*/
/*
JobProfileSummary
Notes
- 
Mods
22-11-08 mparsons - new

*/
Alter VIEW [dbo].[JobProfileSummary]
AS
 
SELECT base.[Id]
	,base.[RowId]
	,b.Id as EntityId
	,base.[Name]
	,base.[Description]
	,base.[EntityStateId]
	,base.[CTID]
	,base.[PrimaryAgentUid]
	,isnull(primaryOrg.Id,0)	as PrimaryOrganizationId
	,isnull(primaryOrg.Name,'') as PrimaryOrganizationName
	,isnull(primaryOrg.CTID,'') as PrimaryOrganizationCtid
	,base.[SubjectWebpage]
	,base.[AbilityEmbodied]
	,base.[Classification]
	,base.[CodedNotation]
	,base.[Comment]
	,base.[Identifier]
	,base.[KnowledgeEmbodied]
	,base.[SkillEmbodied]
	,base.[SameAs]
	,base.[VersionIdentifier]
	,base.[JsonProperties]
	,base.[Created]
	,base.[LastUpdated]

--
  FROM [dbo].[JobProfile] a

INNER JOIN dbo.Entity AS b ON base.RowId = b.EntityUid 
-- join for primary
	Left join Organization primaryOrg on base.[PrimaryAgentUid] = primaryOrg.RowId and primaryOrg.EntityStateId > 1

GO

grant select on [JobProfileSummary] to public
go


