USE [credFinder]
GO
--use credfinder_prod
--go

--USE staging_credFinder
--GO

use sandbox_credFinder
go


/****** Object:  View [dbo].[OccupationProfileSummary]    Script Date: 7/29/2020 11:13:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*
USE [credFinder]
GO
USE [sandbox_credFinder]
GO

SELECT a.[Id]
      ,a.[RowId]
      ,a.[Name]
      ,a.[Description]
      ,a.[EntityStateId]
      ,a.[CTID]
	        ,a.[PrimaryAgentUid]
      ,a.[PrimaryOrganizationId]
      ,a.[PrimaryOrganizationName]
      ,a.[PrimaryOrganizationCtid]
      ,a.[SubjectWebpage]
      ,a.[AbilityEmbodied]
      ,a.[Classification]
      ,a.[CodedNotation]
      ,a.[Comment]
      ,a.[Identifier]
      ,a.[KnowledgeEmbodied]
      ,a.[SkillEmbodied]
      ,a.[SameAs]
      ,a.[VersionIdentifier]
      ,a.[JsonProperties]
      ,a.[Created]
      ,a.[LastUpdated]
  FROM [dbo].[OccupationProfileSummary] a

*/
/*
OccupationProfileSummary
Notes
- 
Mods
22-11-08 mparsons - new

*/
Alter VIEW [dbo].[OccupationProfileSummary]
AS
 
SELECT a.[Id]
		,a.[RowId]
		,b.Id as EntityId
		,a.[Name]
		,a.[Description]
		,a.[EntityStateId]
		,a.[CTID]
		,a.[PrimaryAgentUid]
		,isnull(primaryOrg.Id,0)	as PrimaryOrganizationId
		,isnull(primaryOrg.Name,'') as PrimaryOrganizationName
		,isnull(primaryOrg.CTID,'') as PrimaryOrganizationCtid

		,a.[SubjectWebpage]
		,a.[AbilityEmbodied]
		,a.[Classification]
		,a.[CodedNotation]
		,a.[Comment]
		,a.[Identifier]
		,a.[KnowledgeEmbodied]
		,a.[SkillEmbodied]
		,a.[SameAs]
		,a.[VersionIdentifier]
		,a.[JsonProperties]
		,a.[Created]
		,a.[LastUpdated]

--
  FROM [dbo].[OccupationProfile] a

INNER JOIN dbo.Entity AS b ON a.RowId = b.EntityUid 
-- join for primary
	Left join Organization primaryOrg on a.[PrimaryAgentUid] = primaryOrg.RowId and primaryOrg.EntityStateId > 1



GO

grant select on [OccupationProfileSummary] to public
go


