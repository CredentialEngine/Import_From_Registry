use credFinder
GO
--use credfinder_freshStart
--go
--use staging_credFinder
--go
use sandbox_credFinder
go

--use credfinder_prod
--go

--use snhu_credFinder
--go

--use credFinder_github
--go

/****** Object:  View [dbo].[Credential_Summary]    Script Date: 8/16/2017 9:32:00 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
use credFinder
GO
drop table Credential_Summary_Cache
go


SELECT [Id]
    -- ,count(*) As Nbr
from Credential_Summary
group by Id having count(*) > 1


truncate table Credential_Summary_Cache
go
insert Credential_Summary_Cache
--2 secs
set statistics IO On
set statistics IO Off
use credFinder
GO


SELECT top 500
base.[Id]
      ,base.[EntityId]
      ,base.[EntityUid]
      ,base.[RowId]
      ,base.[Name]
      ,base.[EntityStateId]
      ,base.[OwningAgentUid]
      ,base.[OrgEntityStateId]
      ,base.[OwningOrganizationId]
      --,base.[OwningOrganization]
      --,base.[CredentialTypeId]
      --,base.[CredentialType]
      --,base.[CredentialTypeSchema]
      --,base.[AlternateName]
      --,base.[Description]
      --,base.[SubjectWebpage]
      --,base.[CTID]
      --,base.[CredentialRegistryId]
      --,base.[cerEnvelopeUrl]
      --,base.[Version]
      --,base.[LatestVersionUrl]
      --,base.[ReplacesVersionUrl]
      --,base.[PreviousVersion]
      --,base.[DateEffective]
      --,base.[availableOnlineAt]
      --,base.[AvailabilityListing]
      --,base.[CredentialId]
      --,base.[Created]
      --,base.[LastUpdated]
      --,base.[IsAQACredential]
      --,base.[HasQualityAssurance]
      --,base.[OwningOrgs]
      --,base.[LearningOppsCompetenciesCount]
      --,base.[AssessmentsCompetenciesCount]
      --,base.[QARolesCount]
      --,base.[QARolesList]
      --,base.[QAOrgRolesList]
      --,base.[AgentAndRoles]
      --,base.[HasPartList]
      --,base.[IsPartOfList]
      --,base.[HasPartCount]
      --,base.[IsPartOfCount]
      --,base.[RequiresCount]
      --,base.[RecommendsCount]
      --,base.[isRequiredForCount]
      --,base.[IsRecommendedForCount]
      --,base.[IsAdvancedStandingForCount]
      --,base.[AdvancedStandingFromCount]
      --,base.[isPreparationForCount]
      --,base.[isPreparationFromCount]
      --,base.[entryConditionCount]
      --,base.[corequisiteConditionCount]
	,ea.Nbr as AvailableAddresses
	, (SELECT b.RowId, b.Id, b.EntityId, base.EntityUid, base.EntityTypeId, base.EntityBaseId, base.EntityBaseName, b.Id AS EntityAddressId, b.Name, b.IsPrimaryAddress, b.Address1, b.Address2, b.City, b.Region, b.PostOfficeBoxNumber, b.PostalCode, b.Country, b.Latitude, b.Longitude, b.Created, b.LastUpdated FROM dbo.Entity AS a INNER JOIN dbo.[Entity.Address] AS b ON base.Id = b.EntityId where base.[EntityUid] = base.[RowId] 
		FOR XML RAW, ROOT('Addresses')) Addresses

		-- addresses for owning org - will only be used if there is no address for the credential
	, (SELECT b.RowId, b.Id, b.EntityId, base.EntityUid, base.EntityTypeId, base.EntityBaseId, base.EntityBaseName, b.Id AS EntityAddressId, b.Name, b.IsPrimaryAddress, b.Address1, b.Address2, b.City, b.Region, b.PostOfficeBoxNumber, b.PostalCode, b.Country, b.Latitude, b.Longitude, b.Created, b.LastUpdated FROM dbo.Entity AS a INNER JOIN dbo.[Entity.Address] AS b ON base.Id = b.EntityId where base.[EntityUid] = base.OwningAgentUid 
		FOR XML RAW, ROOT('OrgAddresses')) OrgAddresses

  FROM [dbo].[Credential_Summary] base
--where base.OwningOrganization like 'Placeholder%'

	Inner join Entity e on base.Id = e.EntityBaseId and e.EntityTypeId = 1

	left Join (select EntityId, count(*) as nbr from [Entity.Address] group by EntityId ) ea on base.EntityId = ea.EntityId
	
	left join Credential_ConditionProfilesCSV connectionsCsv on base.id = connectionsCsv.CredentialId

	-- ========== check for a verifiable badge claim ========== 
	Left Join (SELECT c.CredentialId, count(*) as Total
		FROM [Entity.VerificationProfile] a
		inner join entity vpEntity							on base.RowId = vpEntity.EntityUid
		inner join  [dbo].[Entity.Credential] c on vpEntity.Id = c.EntityId
		inner join  [dbo].[Entity.Property] ep  on vpEntity.Id = ep.EntityId
		inner join [Codes.PropertyValue] b			on ep.PropertyValueId = b.Id
		where 	b.SchemaName = 'claimType:BadgeClaim'
		group by c.CredentialId

	) badgeClaims on base.Id = badgeClaims.CredentialId

	left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.CostProfile] a Inner join Entity b ON base.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId
	) costProfiles	on base.Id = costProfiles.EntityBaseId  


-- ========== total cost items - just for credential, no child items ========== 


-- ========== total cost items - just for credential, AND child items ========== 

	left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.CommonCost] a Inner join Entity b ON base.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId
		) CommonCost	on base.Id = CommonCost.EntityBaseId     
	left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.CommonCondition] a Inner join Entity b ON base.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId
		) CommonCondition	on base.Id = CommonCondition.EntityBaseId     
	--left join (
	--	Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.FinancialAlignmentProfile] a Inner join Entity b ON base.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId 
	--	) FinancialAid	on base.Id = FinancialAid.EntityBaseId 
	left join (
	Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.FinancialAssistanceProfile] a Inner join Entity b ON base.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId 
	) FinancialAid	on base.Id = FinancialAid.EntityBaseId  
		--renewals ----------------------------
	left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.ConditionProfile] a 
			Inner join Entity b ON base.EntityId = b.Id 
			inner Join Credential c on b.EntityUid = c.RowId
		where c.EntityStateId = 3
	  and base.ConnectionTypeId = 5 and isnull(base.ConditionSubTypeId,0) = 1
		Group By b.EntityBaseId 
		) Renewals	on base.Id = Renewals.EntityBaseId 
	--embedded ----------------------------
	left join (
	Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.Credential] a Inner join Entity b ON base.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId 
	) EmbeddedCredentials	on base.Id = EmbeddedCredentials.EntityBaseId 

	--targets
	left join (
		SELECT parentId as EntityBaseId, Sum(HasTargetAssessment) As HasTargetAssessments, Sum(HasTargetCredential) As HasTargetCredentials, Sum(HasLearningOpportunity) as HasLearningOpportunities FROM [dbo].[Entity_ConditionProfileTargetsSummary] where ParentEntityTypeId = 1 and ConnectionTypeId = 1 and (HasTargetAssessment > 0 OR HasTargetCredential > 0 OR HasLearningOpportunity > 0) group by parentId
		) reqTargets	on base.Id = reqTargets.EntityBaseId 

	left join (
		SELECT parentId as EntityBaseId, Sum(HasTargetAssessment) As HasTargetAssessments, Sum(HasTargetCredential) As HasTargetCredentials, Sum(HasLearningOpportunity) as HasLearningOpportunities FROM [dbo].[Entity_ConditionProfileTargetsSummary] where ParentEntityTypeId = 1 and ConnectionTypeId = 2 and (HasTargetAssessment > 0 OR HasTargetCredential > 0 OR HasLearningOpportunity > 0) group by parentId
		) recommendedTargets	on base.Id = recommendedTargets.EntityBaseId 
	left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.ProcessProfile] a Inner join Entity b ON base.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId
		) processProfiles	on base.Id = processProfiles.EntityBaseId     
	left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.RevocationProfile] a Inner join Entity b ON base.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId
		) revocationProfiles	on base.Id = revocationProfiles.EntityBaseId   
	left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.ReferenceFramework] a Inner join Entity b ON base.EntityId = b.Id Where b.EntityTypeId = 1 and CategoryId = 11 Group By b.EntityBaseId 
		) HasOccupations	on base.Id = HasOccupations.EntityBaseId   
	left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.ReferenceFramework] a Inner join Entity b ON base.EntityId = b.Id Where b.EntityTypeId = 1 and CategoryId = 10 Group By b.EntityBaseId 
		) HasIndustries	on base.Id = HasIndustries.EntityBaseId 
	
	--left join (
	--	Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.ReferenceFramework] a Inner join Entity b ON base.EntityId = b.Id Where b.EntityTypeId = 1 and CategoryId = 23 Group By b.EntityBaseId 
	--	) CIPCounts on base.Id = CIPCounts.EntityBaseId 
--SLOWish
	left Join ( 
		SELECT     distinct base.Id, 
		CASE WHEN Languages IS NULL THEN ''           WHEN len(Languages) = 0 THEN ''          ELSE left(Languages,len(Languages)-1)     END AS Languages
		From dbo.credential base
		CROSS APPLY ( SELECT base.TextValue + '| '
			FROM [dbo].[Entity.Reference] a inner join [Entity] b on base.EntityId = b.Id 
			where b.EntityTypeId= 1 AND base.CategoryId = 65
			and base.Id = b.EntityBaseId FOR XML Path('')  ) D (Languages)
		where Languages is not null
	) Languages on base.Id = Languages.Id

	left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.ConditionProfile] a Inner join Entity b ON base.EntityId = b.Id Where b.EntityTypeId = 1 Group By b.EntityBaseId 
		) HasConditionProfile	on base.Id = HasConditionProfile.EntityBaseId 
	 left join (
		Select b.EntityBaseId, COUNT(*)  As Nbr from [Entity.DurationProfile] a Inner join Entity b ON base.EntityId = b.Id Where b.EntityTypeId = 1  Group By b.EntityBaseId 
		) HasDuration	on base.Id = HasDuration.EntityBaseId  
-- =======================================================
	left join (SELECT [ParentEntityUid] ,sum([AverageMinutes]) as [AverageMinutes] 
	  FROM [dbo].[Entity_Duration_EntityAverage] group by [ParentEntityUid]
	  )  duration on base.EntityUid = duration.ParentEntityUid 





	where id in (79, 1042)
  where organizationName like '%train%' or owingOrganization like 'train%'
   or organizationName is null
order by Id

select *
from   [dbo].[Credential_Summary] base
where base.CredentialType = 'License'

*/

/*
Summary view for credentials
NOTE: ONLY USED FOR SEARCH

ALSO note that uses [Credential.SummaryCache]

-- =========================================================
16-10-27 mparsons - changed to use a join of credential and Credential.SummaryCache.
									- the latter is regulary populated, but will always have the base data available
17-10-10 mparsons - added owningOrganization and OwningOrganizationId to Credential.SummaryCache, and using here 
22-04-26 mparsons - added languages here - need to remove from the proc!
22-11-17 mparsons - need to remove use of Credential.SummaryCache - may be a challenge
*/
Alter VIEW [dbo].[Credential_Summary]
AS

SELECT  Distinct    
-- === IDs ===
	base.Id, 
	e.Id as EntityId,
	base.RowId as EntityUid,
	base.RowId,
	isnull(base.CTID,'') As CTID, 
	-- common data not sync'd to Credential.SummaryCache
	base.Name, 
	base.EntityStateId,
	--
	base.CredentialTypeId,
	--friendly label for a credential type
	isnull(credTypeProperty.Title,'') As CredentialType,
	-- ctdl schema name
	isnull(credTypeProperty.SchemaName,'') As CredentialTypeSchema,
	--added virtual property, as the name can change and don't want buried in code. Added here for consistency, though will always be zero based on the where clause
	case when isnull(credTypeProperty.SchemaName,'') = 'qualityAssuranceCredential' then 1 else 0 end As IsAQACredential,
	-- new
	base.CredentialStatusTypeId,
	credStatus.Title as CredentialStatus,
	--retain temporarily
	base.CredentialStatusTypeId as CredentialStatusId,
	--
	--isnull(statusProperty.Property,'') As CredentialStatus,
	--isnull(statusProperty.PropertyValueId,'') As CredentialStatusId,
	-- ==== owning org =================================
	base.OwningAgentUid,
	owningOrg.EntityStateId as OrgEntityStateId,
	isnull(owningOrg.Id,0) as OwningOrganizationId,
	isnull(owningOrg.Name,'') as OwningOrganization,
	isnull(owningOrg.CTID,'') as OwningOrganizationCTID,
	-- =====================================

	--or
	--0	isnull(parts.IsAQACredential, 0) As IsAQACredential, 

	isnull(base.AlternateName,'') As AlternateName, 
	isnull(base.Description,'') As [Description], 
	Isnull(base.ImageUrl,'') as ImageUrl,
	isnull(base.SubjectWebpage,'') As SubjectWebpage, 
	--21-12-17 changed to use DateEffective. Retail alias for a bit
	base.EffectiveDate as DateEffective, 
	--base.EffectiveDate, 
	base.ExpirationDate,

	isnull(base.CredentialRegistryId,'') As CredentialRegistryId, 
	case when len(isnull(base.CredentialRegistryId,'')) = 36 then
	'<a href="https://credentialengineregistry.org/ce-registry/envelopes/' + base.CredentialRegistryId + '" target="_blank">cerEnvelope</a>'
	else '' End As cerEnvelopeUrl,

	isnull(base.Version,'') As Version, 
	isnull(base.LatestVersionUrl,'') As LatestVersionUrl, 

	isnull(base.ReplacesVersionUrl,'') As ReplacesVersionUrl, 
	isnull(base.ReplacesVersionUrl,'') As PreviousVersion, 


	isnull(base.availableOnlineAt,'') As availableOnlineAt, 
	isnull(base.AvailabilityListing,'') As AvailabilityListing, 
	base.CredentialId,
	base.Created, 
	--isnull(base.CreatedById,0) as CreatedById,		
	base.LastUpdated, 
	e.LastUpdated as EntityLastUpdated,
	parts.LastSyncDate,
	--json stuff in progress
	base.JsonProperties,

	--==== external data =========================
	isnull(Languages.Languages,'') As Languages,	
	isnull(parts.HasQualityAssurance, 0) As HasQualityAssurance, 

	--empty stuff needed by search proc
	--this is an old view, needs to be scrubbed.
	'' As OwningOrgs, 
	'' as OfferingOrgs,
	0 as totalCost,
	0 as NumberOfCostProfileItems,
	'' As NaicsList,
	'' As LevelsList,
	'' As OccupationsList,
	'' as SubjectsList,

	'' as ConnectionsList,
	'' as CredentialsList,
	'' as badgeClaimsCount,
	'' as AvailableAddresses,


	-- === content from Credential.SummaryCache==================
		--isnull(parts.CredentialType,'') As CredentialType, 
	--isnull(parts.CredentialTypeSchema,'') As CredentialTypeSchema, 
	--isnull(parts.CredentialTypeId,0) As CredentialTypeId, 
	isnull(parts.LearningOppsCompetenciesCount,0) As LearningOppsCompetenciesCount, 
	isnull(parts.AssessmentsCompetenciesCount,0) As AssessmentsCompetenciesCount, 
	isnull(parts.RequiresCompetenciesCount,0) As RequiresCompetenciesCount, 
	isnull(parts.QARolesCount,0) As QARolesCount 
	,parts.QARolesList
	,parts.AgentAndRoles
	,parts.QAOrgRolesList
	,parts.QAAgentAndRoles
	
	,parts.HasPartList
	,parts.IsPartOfList

	,isnull(parts.HasPartCount,0) As HasPartCount, 
	isnull(parts.IsPartOfCount,0) As IsPartOfCount, 
	isnull(parts.RequiresCount,0) As RequiresCount, 
	isnull(parts.RecommendsCount,0) As RecommendsCount, 
	isnull(parts.RequiredForCount,0) As isRequiredForCount, 
	isnull(parts.IsRecommendedForCount,0) As IsRecommendedForCount, 
	isnull(parts.IsAdvancedStandingForCount,0) As IsAdvancedStandingForCount, 
	isnull(parts.AdvancedStandingFromCount,0) As AdvancedStandingFromCount, 
	isnull(parts.PreparationForCount,0) As isPreparationForCount, 
	isnull(parts.PreparationFromCount,0) As isPreparationFromCount,
	isnull(parts.EntryConditionCount,0) As entryConditionCount  ,
	isnull(parts.CorequisiteConditionCount,0) As corequisiteConditionCount 	
	--

FROM dbo.Credential base 
Inner Join Entity								e	on base.RowId = e.EntityUid
left join [Codes.PropertyValue] credTypeProperty	on base.CredentialTypeId = credTypeProperty.Id 
Left join [Credential.SummaryCache]			parts	on base.Id = parts.CredentialId
Left Join Organization					owningOrg	on base.OwningAgentUid = owningOrg.RowId and owningOrg.EntityStateId > 1
Left Join [Codes.PropertyValue] credStatus			on base.CredentialStatusTypeId = credStatus.Id

--Left Join EntityProperty_Summary statusProperty on base.RowId = statusProperty.EntityUid and statusProperty.CategoryId = 39

--AND isnull(credTypeProperty.SchemaName,'') <> 'ceterms:QualityAssuranceCredential'
	left Join ( 
		SELECT     distinct base.Id, 
		CASE WHEN Languages IS NULL THEN ''           WHEN len(Languages) = 0 THEN ''          ELSE left(Languages,len(Languages)-1)     END AS Languages
		From dbo.credential base
		CROSS APPLY ( SELECT base.Title + '| ' + base.TextValue + '| '
			FROM [dbo].[Entity.Reference] a inner join [Entity] b on base.EntityId = b.Id 
			where b.EntityTypeId= 1 AND base.CategoryId = 65
			and base.Id = b.EntityBaseId FOR XML Path('')  ) D (Languages)
		where Languages is not null
	) Languages on base.Id = Languages.Id

where base.EntityStateId >= 2
--order by 1


GO
grant select on Credential_Summary to public
go


