USE [credFinder]
GO

--use sandbox_credFinder 
--go

--use staging_credFinder
--go

--use credfinder_prod
--go

/****** Object:  View [dbo].[SupportService_PropertyTotals]    Script Date: 5/31/2020 9:35:03 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
ceterms:accommodationType
ceterms:alternateName
ceterms:availabilityListing
ceterms:availableAt
ceterms:availableOnlineAt
ceterms:commonConditions
ceterms:commonCosts
ceterms:ctid
ceterms:dateEffective
ceterms:deliveryType
ceterms:description
ceterms:estimatedCost
ceterms:expirationDate
ceterms:financialAssistance
ceterms:hasSupportService
ceterms:identifier
ceterms:inLanguage
ceterms:keyword
ceterms:lifeCycleStatusType
ceterms:name
ceterms:occupationType
ceterms:offeredBy
ceterms:offeredIn
ceterms:ownedBy
ceterms:subjectWebpage
ceterms:supportServiceCondition
ceterms:supportServiceFor
ceterms:supportServiceType
USE [credFinder]
GO

SELECT [Total]
      ,[Name]
      ,[Description]
      ,[SubjectWebpage]
      ,[CTID]
      ,[LifeCycleStatusType]
      ,[DateEffective]
      ,[AvailableOnlineAt]
      ,[AvailableAt]
      ,[ExpirationDate]
      ,[AvailabilityListing]
      ,[AlternateName]
      ,[Identifier]
      ,[Keyword]
      ,[OwnedBy]
      ,[OfferedBy]
      ,[OfferedIN]
      ,[HasAccommodationType]
      ,[HasSupportServiceType]
      ,[HasDeliveryMethodType]
      ,[HasCommonCosts]
      ,[HasCommonConditions]
      ,[EstimatedCost]
      ,[HasFinancialAssistance]
      ,[HasLanguages]
      ,[HasOccupations]
      ,[SupportServiceCondition]
      ,[SupportServiceFor]
  FROM [dbo].[SupportService_PropertyTotals]

GO




Modifications
23-07-21 mparsons - new

*/
Alter VIEW [dbo].[SupportService_PropertyTotals]
AS

select 

		sum(case when Len(IsNull(a.Name, '')) > 0 then 1 else 0 end) as Total
		, sum(case when Len(IsNull(a.Name, '')) > 0 then 1 else 0 end) as Name
		, sum(case when Len(IsNull(a.Description, '')) > 0 then 1 else 0 end) as Description
		, sum(case when Len(IsNull(a.SubjectWebpage, '')) > 0 then 1 else 0 end) as SubjectWebpage
		, sum(case when Len(IsNull(a.CTID, '')) > 0 then 1 else 0 end) as CTID

		,sum(case when Len(IsNull(a.LifeCycleStatusTypeId, '')) > 0 then 1 else 0 end) as LifeCycleStatusType

		, sum(case when Len(IsNull(a.DateEffective, '')) > 0 then 1 else 0 end) as DateEffective
		, sum(case when Len(IsNull(a.AvailableOnlineAt, '')) > 0 then 1 else 0 end) as AvailableOnlineAt
		--ceterms:availableAt
		, sum(case when IsNull(address.EntityBaseId,0) > 0 then 1 else 0 end) AvailableAt
		, sum(case when Len(IsNull(a.ExpirationDate, '')) > 0 then 1 else 0 end) as ExpirationDate
		, sum(case when Len(IsNull(a.AvailabilityListing, '')) > 0 then 1 else 0 end) as AvailabilityListing
		, sum(case when Len(IsNull(a.AlternateName, '')) > 0 then 1 else 0 end) as AlternateName
		, sum(case when Len(IsNull(a.Identifier, '')) > 0 then 1 else 0 end) as Identifier
		, sum(case when Len(IsNull(a.Keyword, '')) > 0 then 1 else 0 end) as Keyword
		-- BYs
		,sum(case when IsNull(ownedBy.RelationshipTypeId,0) > 0 then 1 else 0 end)		OwnedBy
		,sum(case when IsNull(offeredBy.RelationshipTypeId,0) > 0 then 1 else 0 end)	OfferedBy
		,sum(case when IsNull(offeredIN.[AssertedInTypeId],0) > 0 then 1 else 0 end)	OfferedIN
		-- PROPERTIES
		,sum(case when IsNull(accommodationType.CategoryId,0) > 0 then 1 else 0 end) HasAccommodationType
		,sum(case when IsNull(supportServiceType.CategoryId,0) > 0 then 1 else 0 end) HasSupportServiceType
		,sum(case when IsNull(delType.CategoryId,0) > 0 then 1 else 0 end) HasDeliveryMethodType
		--
		,sum(case when IsNull(commonCosts.EntityBaseId,0) > 0 then 1 else 0 end) HasCommonCosts
		,sum(case when IsNull(commonConditions.EntityBaseId,0) > 0 then 1 else 0 end) HasCommonConditions
		--
		,sum(case when IsNull(Costs.EntityBaseId,0) > 0 then 1 else 0 end) EstimatedCost

		--
		,sum(case when IsNull(finAssistance.EntityBaseId,0) > 0 then 1 else 0 end) HasFinancialAssistance

		--ceterms:hasSupportService
		--ceterms:inLanguage
		,sum(case when IsNull(languages.EntityBaseId,0) > 0 then 1 else 0 end) HasLanguages
		--
		,sum(case when IsNull(occ.CategoryId,0) > 0 then 1 else 0 end) HasOccupations			--##

		--ceterms:supportServiceCondition
		,sum(case when IsNull(a.SupportServiceConditionCount,0) > 0 then 1 else 0 end) SupportServiceCondition
			--
		--ceterms:supportServiceFor - NOT likely? or just a count of hasSupportService
		,sum(case when IsNull(supportServiceFor.Nbr,0) > 0 then 1 else 0 end) SupportServiceFor
	-- ========================================================
	--select count(*)
  from [SupportServiceSummary] a
  inner join entity b on a.RowId = b.EntityUid

  --combine owns/offers =========================================================
   left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  RelationshipTypeId  FROM dbo.[Entity.AgentRelationship] inner join entity on EntityId = entity.Id where entity.EntityTypeId=38 and RelationshipTypeId=6
  ) ownedBy on a.Id = ownedBy.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  RelationshipTypeId  FROM dbo.[Entity.AgentRelationship] inner join entity on EntityId = entity.Id where entity.EntityTypeId=38 and RelationshipTypeId=7
  ) offeredBy on a.Id = offeredBy.EntityBaseId
	--
left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId,  [AssertedInTypeId]  FROM [dbo].[Entity.JurisdictionProfile] inner join entity on EntityId = entity.Id where entity.EntityTypeId=38 and  JProfilePurposeId = 3 and [AssertedInTypeId] = 7
  ) offeredIN on a.Id = offeredIN.EntityBaseId


  --properties
    left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM dbo.[EntityProperty_Summary]  where EntityTypeId=38 and [CategoryId] = 100
  ) accommodationType on a.Id = accommodationType.EntityBaseId
    left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM dbo.[EntityProperty_Summary]  where EntityTypeId=38 and [CategoryId] = 101
  ) supportServiceType on a.Id = supportServiceType.EntityBaseId
    left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM dbo.[EntityProperty_Summary]  where EntityTypeId=38 and [CategoryId] = 21
  ) delType on a.Id = delType.EntityBaseId
-- 
  left join (
	  SELECT distinct  EntityBaseId,  [CategoryId]  FROM dbo.[Entity_ReferenceFramework_Summary]
	  where EntityTypeId=38 and [CategoryId] = 11
  ) occ on a.Id = occ.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.CostProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=38
  ) Costs on a.Id = Costs.EntityBaseId
   --manifests
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.CostManifest] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=38
  ) commonCosts on a.Id = commonCosts.EntityBaseId
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.CommonCondition] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=38
  ) commonConditions on a.Id = commonConditions.EntityBaseId
  --
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.FinancialAssistanceProfile] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=38
  ) finAssistance on a.Id = finAssistance.EntityBaseId
  --[Entity.Reference]
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.Reference] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=38 and [CategoryId] = 65
  ) languages on a.Id = languages.EntityBaseId
  -- address
  left join (
	  SELECT distinct  Entity.EntityBaseId,  EntityId  FROM [Entity.Address] a inner join entity on EntityId = entity.Id where entity.EntityTypeId=38
  ) address on a.Id = address.EntityBaseId
--supportServiceFor
  	left join (
		Select b.EntityBaseId, Count(*) As Nbr from [Entity.HasSupportService] a
		inner join Entity b on a.EntityId = b.Id
		where b.EntityTypeId= 38 
		group by b.EntityBaseId
	) supportServiceFor on a.Id = supportServiceFor.EntityBaseId
--======================
where a.EntityStateId = 3 
GO

