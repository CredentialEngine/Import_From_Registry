use credFinder
GO

use sandbox_credFinder
go
/****** Object:  View [dbo].[ConditionProfile_LearningOpp_Competencies_Summary]    Script Date: 10/6/2017 4:15:30 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*


SELECT [CredentialId]
      ,[ConnectionTypeId]
      ,[RowId]
      ,[learningOppNode]
      ,[LearningOpportunityId]
      ,[LearningOpportunity]
      ,[Competency]
      ,[Description]
      ,[AlignmentType]
      ,[AlignmentTypeId]
  FROM [dbo].[ConditionProfile_LearningOpp_Competencies_Summary]
GO


select * from credential_summary base
where 
( base.Id in (SELECT CredentialId FROM [dbo].[ConditionProfile_LearningOpp_Competencies_Summary]  where AlignmentType = 'teaches' AND ({0}) ) )
*/

/*

Modifications
17-10-10 mparsons - commented out ConnectionTypeId and RowId (of condition profile) to avoid duplicates where same lopp is referrenced in multiple conditions
*/
Alter VIEW [dbo].[ConditionProfile_LearningOpp_Competencies_Summary]
AS
--do we want to limit this to a particulr connection type - probably just requirements
--for now seems unlikely to have learning opps in other condtions

SELECT DISTINCT 
	base.CredentialId, 
	--base.ConnectionTypeId, 
	--base.RowId, 
	'level1' as learningOppNode,
	competencies.LearningOpportunityId, 
	competencies.[LearningOpportunity],
	competencies.Id As CompetencyFrameworkItemId,
	competencies.Competency, 
	competencies.TargetNodeDescription,
	competencies.CompetencyCreated

FROM            
--dbo.[Credential.ConnectionProfile] 
	dbo.Credential_ConditionProfile AS base  
	--ON conditionEntity.EntityUid = condProf.EntityConditionProfileRowId
--INNER JOIN dbo.Entity AS e ON base.RowId = e.EntityUid --entity for cond profile
--Inner Join Credential c on base.CredentialId = c.Id and c.StatusId <= 2
INNER JOIN dbo.[Entity.LearningOpportunity] AS eLopp ON base.EntityId = eLopp.EntityId 
INNER JOIN dbo.LearningOpportunity_Competency_Summary AS competencies ON eLopp.LearningOpportunityId = competencies.LearningOpportunityId

-- from parts
UNION
SELECT DISTINCT 
	base.CredentialId, 
	--base.ConnectionTypeId, 
	--base.RowId, 
	'level2' as learningOppNode,
	competencies.LearningOpportunityId, 
	competencies.[LearningOpportunity_Part],
	competencies.EntityCompetencyFrameworkItemId As CompetencyFrameworkItemId,
	competencies.Competency, 
	competencies.TargetNodeDescription,
	competencies.CompetencyCreated

FROM  
dbo.Credential_ConditionProfile AS base           
--dbo.[Credential.ConnectionProfile] AS base 
--INNER JOIN dbo.Entity AS e ON base.RowId = e.EntityUid 
--Inner Join Credential c on base.CredentialId = c.Id and c.StatusId <= 2
INNER JOIN dbo.[Entity.LearningOpportunity] AS eLopp ON base.EntityId = eLopp.EntityId 
INNER JOIN dbo.[LearningOpportunity_Parts_Competencies_Summary] AS competencies ON eLopp.LearningOpportunityId = competencies.LearningOpportunityId

-- from parts - parts
UNION
SELECT DISTINCT 
	base.CredentialId, 
	--base.ConnectionTypeId, 
	--base.RowId, 
	'level3' as learningOppNode,
	competencies.LearningOpportunityId, 
	competencies.[LearningOpportunity_Part],
	competencies.EntityCompetencyFrameworkItemId As CompetencyFrameworkItemId,
	competencies.Competency, 
	competencies.TargetNodeDescription,
	competencies.CompetencyCreated

FROM            
dbo.Credential_ConditionProfile AS base           
--dbo.[Credential.ConnectionProfile] AS base 
--INNER JOIN dbo.Entity AS e ON base.RowId = e.EntityUid 
--Inner Join Credential c on base.CredentialId = c.Id and c.StatusId <= 2
INNER JOIN dbo.[Entity.LearningOpportunity] AS eLopp ON base.EntityId = eLopp.EntityId 

INNER JOIN dbo.[LearningOpportunity_Parts_Summary] AS lparts ON eLopp.LearningOpportunityId = lparts.LearningOpportunityId

INNER JOIN dbo.[LearningOpportunity_Parts_Competencies_Summary] AS competencies ON lparts.LearningOpportunity_PartId = competencies.LearningOpportunityId


GO
