use credFinder
go

USE [sandbox_credFinder]
GO

/****** Object:  Trigger [dbo].[trgSupportServiceBeforeDelete]    Script Date: 6/23/2023 10:00:02 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Description:	
--	Deletes are typically triggered from entity frameworks code. 
--	Tables like Entity are not removed via Referencial Integrity. 
--	The latter will be deleted, and then the SupportService
-- =============================================


Alter TRIGGER [dbo].[trgSupportServiceBeforeDelete]
ON [dbo].[SupportService]
INSTEAD OF DELETE
AS
BEGIN
 BEGIN TRY
     -- Some code you want to do before delete
		DELETE a	
			FROM [dbo].[Entity] a
			inner join Deleted d on a.EntityUid = d.RowId

		 -- do the delete
     DELETE SupportService
     FROM DELETED D
     INNER JOIN dbo.SupportService T ON T.Id = D.Id
    END TRY
    BEGIN CATCH
        DECLARE @ErrorMsg VARCHAR(MAX), @ErrorNumber INT, @ErrorProc sysname, @ErrorLine INT 

        SELECT @ErrorMsg = ERROR_MESSAGE(), @ErrorNumber = ERROR_NUMBER(), @ErrorProc = ERROR_PROCEDURE(), @ErrorLine = ERROR_LINE();
        --RollBack Tran;

        --INSERT INTO ErrorLog (ErrorMsg,  ErrorNumber,  ErrorProc,  ErrorLine)
        --VALUES               (@ErrorMsg, @ErrorNumber, @ErrorProc, @ErrorLine)

		INSERT INTO [dbo].[MessageLog]
           ([Created] ,[Application] ,[Activity] ,[MessageType] ,[Message] 
			,[Description]
           --,[ActionByUserId] ,[ActivityObjectId] ,[RelatedUrl] 
		   )
     VALUES
           (getdate(), 'CredentialFinder','trgSupportServiceBeforeDelete','Error', @ErrorProc
           ,@ErrorMsg
           --,<ActionByUserId, int,>
           --,<ActivityObjectId, varchar(50),>
           )
    END CATCH

END
GO

ALTER TABLE [dbo].[SupportService] ENABLE TRIGGER [trgSupportServiceBeforeDelete]
GO


