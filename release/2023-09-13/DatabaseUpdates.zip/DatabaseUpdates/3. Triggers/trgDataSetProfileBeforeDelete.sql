use credFinder
go

--USE [sandbox_credFinder]
--GO

/****** Object:  Trigger [dbo].[trgDataSetProfileBeforeDelete]    Script Date: 6/23/2023 10:00:02 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Description:	
--	Deletes are typically triggered from entity frameworks code. 
--	Tables like Entity are not removed via Referencial Integrity. 
--	The latter will be deleted, and then the DataSetProfile
-- =============================================


CREATE TRIGGER [dbo].[trgDataSetProfileBeforeDelete]
ON [dbo].[DataSetProfile]
INSTEAD OF DELETE
AS
BEGIN

     -- Some code you want to do before delete
		DELETE a	
			FROM [dbo].[Entity] a
			inner join Deleted d on a.EntityUid = d.RowId

		 -- do the delete
     DELETE DataSetProfile
     FROM DELETED D
     INNER JOIN dbo.DataSetProfile T ON T.Id = D.Id
END
GO

ALTER TABLE [dbo].[DataSetProfile] ENABLE TRIGGER [trgDataSetProfileBeforeDelete]
GO


