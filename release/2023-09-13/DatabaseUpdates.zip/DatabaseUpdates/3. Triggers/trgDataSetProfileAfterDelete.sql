USE [sandbox_credFinder]
GO
--use credFinder
--go

--use staging_credFinder
--go

/****** Object:  Trigger [dbo].[trgDataSetProfileAfterDelete]    Script Date: 4/21/2023 4:04:02 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER TRIGGER [dbo].[trgDataSetProfileAfterDelete]
ON [dbo].[DataSetProfile]
   AFTER DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
		DELETE a	
			FROM [dbo].[Entity] a
			inner join Deleted d on a.EntityUid = d.RowId

		DELETE a	
			FROM [dbo].[Entity_Cache] a
			inner join Deleted d on a.EntityUid = d.RowId

END
