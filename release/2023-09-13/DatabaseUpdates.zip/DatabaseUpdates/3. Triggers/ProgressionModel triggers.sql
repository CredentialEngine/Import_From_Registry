--USE credFinder
--GO

use sandbox_credFinder
go

--use staging_credFinder
--go

--	ProgressionModel triggers

/****** Object:  Trigger [dbo].[trgProgressionModelAfterInsert]    Script Date: 5/7/2020 5:07:06 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Create TRIGGER [dbo].[trgProgressionModelAfterInsert] ON  [dbo].[ProgressionModel]
FOR INSERT
AS  
    INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
					 ,EntityBaseId, EntityBaseName)
    SELECT RowId, 12, getdate(), Id, Name
    FROM inserted;

--Update ProgressionModel 
--		set StatusId = 1
--		from ProgressionModel a 
--		inner join inserted b on a.Id = b.Id
GO

ALTER TABLE [dbo].[ProgressionModel] ENABLE TRIGGER [trgProgressionModelAfterInsert]
GO


--INSERT INTO [dbo].[Entity]
--           ([EntityUid]
--           ,[EntityTypeId]
--           ,[Created]
--           ,[EntityBaseId]
--           ,[EntityBaseName]
--           ,[LastUpdated])

--SELECT [RowId], 11, [LastUpdated], id, Name,[LastUpdated]
--  FROM [dbo].[ProgressionModel]

--GO




/****** Object:  Trigger [dbo].[trgProgressionModelAfterUpdate]    Script Date: 5/7/2020 5:07:17 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Keep the Entity.EntityBaseName in sync with actual name
-- Mods
--20-07-28 mp - not using this trigger.

-- =============================================
--CREATE TRIGGER [dbo].[trgProgressionModelAfterUpdate] ON  [dbo].[ProgressionModel]
--   AFTER UPDATE
--AS 
--BEGIN
--	-- SET NOCOUNT ON added to prevent extra result sets from
--	-- interfering with SELECT statements.
--	SET NOCOUNT ON;


----  print convert(varchar(26), @Lastdate, 121)
----  if @lastdate is null OR ( DATEADD(s, 2, @Lastdate) < getdate() ) begin
--	--then do updated
--	UPDATE [dbo].[Entity]
--		SET	[EntityBaseName] = b.Name
--		--, LastUpdated = getdate()
--		 from [Entity] a
--		 inner join inserted b on a.EntityUid = b.RowId
--	--	end

--END
--GO

--ALTER TABLE [dbo].[ProgressionModel] ENABLE TRIGGER [trgProgressionModelAfterUpdate]
--GO


/****** Object:  Trigger [dbo].[trgProgressionModelBeforeDelete]    Script Date: 5/7/2020 5:07:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Create date: 2020-05-06
-- Description:	Delete the related Entity before deleting actual record
-- =============================================

CREATE TRIGGER [dbo].[trgProgressionModelBeforeDelete]
ON [dbo].[ProgressionModel]
INSTEAD OF DELETE
AS
BEGIN

     -- Some code you want to do before delete
		DELETE a	
			FROM [dbo].[Entity] a
			inner join Deleted d on a.EntityUid = d.RowId


		 -- do the delete
     DELETE ProgressionModel
     FROM DELETED D
     INNER JOIN dbo.ProgressionModel T ON T.Id = D.Id
END
GO

ALTER TABLE [dbo].[ProgressionModel] ENABLE TRIGGER [trgProgressionModelBeforeDelete]
GO




