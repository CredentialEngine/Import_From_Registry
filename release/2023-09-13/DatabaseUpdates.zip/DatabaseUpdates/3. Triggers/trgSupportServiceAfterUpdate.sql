USE [sandbox_credFinder]
GO

/****** Object:  Trigger [dbo].[trgSupportServiceAfterUpdate]    Script Date: 5/3/2023 12:00:03 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* =============================================
23-05-02 mparsons - new
-- =============================================
*/
Create TRIGGER [dbo].[trgSupportServiceAfterUpdate] ON  [dbo].[SupportService]
   AFTER UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	UPDATE [dbo].[Entity]
		SET	[EntityBaseName] = IsNull(b.Name,'SupportService')
		 from [Entity] a
		 inner join inserted b on a.EntityUid = b.RowId
	
/* 
	could also update entity.cache (esp for top level resources)

UPDATE [dbo].[Entity_Cache]
   SET [Name] = b.Name
      ,[Description] = b.Description
      ,[LastUpdated] = b.LastUpdated
      ,[CacheDate] = getdate()
      ,[Url] = b.SubjectWebpage
      ,[IsPublished] = case when b.LastPublished is not null then 'yes' else 'no' end
      ,[HasApproval] =case when b.LastApproved is not null then 'yes' else 'no' end
	  --not likely to chg??
      ,[EntityStateId] = b.EntityStateId
from [Entity_Cache] a
		 inner join inserted b on a.EntityUid = b.RowId

	*/
END
GO

ALTER TABLE [dbo].[SupportService] ENABLE TRIGGER [trgSupportServiceAfterUpdate]
GO


