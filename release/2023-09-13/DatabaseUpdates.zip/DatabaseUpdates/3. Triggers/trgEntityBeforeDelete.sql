use credFinder
go

USE [sandbox_credFinder]
GO
--use staging_credFinder
--go

/****** Object:  Trigger [dbo].[trgEntityBeforeDelete]   Script Date: 6/23/2023 10:02:55 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Create date: 23-06-24
-- Description:	
--	Need to delete the Entity_cache related to an Entity 
--	Tables like Entity_cache are not removed via Referencial Integrity. 
-- 23-06-26 - seems to be causing a problem - removing

-- =============================================


Alter TRIGGER [dbo].[trgEntityBeforeDelete]
ON [dbo].Entity
INSTEAD OF DELETE
AS
BEGIN

     -- Remove related entity_cache
		DELETE a	
			FROM [dbo].[Entity_Cache] a
			inner join Deleted d on a.EntityUid = d.EntityUid

		 -- do the delete
     DELETE Entity
     FROM DELETED D
     INNER JOIN dbo.Entity T ON T.Id = D.Id
END
