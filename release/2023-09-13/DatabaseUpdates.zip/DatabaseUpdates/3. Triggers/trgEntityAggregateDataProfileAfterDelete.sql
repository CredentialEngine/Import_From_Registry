USE [credFinder]
GO

use sandbox_credFinder
go
use credFinder_prod
go

--use staging_credFinder
--go

--use snhu_credFinder
--go

/****** Object:  Trigger [dbo].[trgEntity.AggregateDataProfileAfterDelete]    Script Date: 3/3/2021 3:28:34 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
trgEntity.AggregateDataProfileAfterDelete
Delete any DataSetProfiles associated with an e.adp after delete of the latter

Modifications
23-02-10 Do we really want to take the hit of deleting the dsp on each update. 
		For the ProPath scenario, we would delete the e.ADP and related Dsp, then add the e.ADP and likely create a new pending DSP (assuming the likely import order
		Could just do a virtual delete
*/
ALTER TRIGGER [dbo].[trgEntity.AggregateDataProfileAfterDelete]
ON [dbo].[Entity.AggregateDataProfile]
   AFTER DELETE
AS 
BEGIN
	
BEGIN TRY 
		  BEGIN TRANSACTION
 
			-- SET NOCOUNT ON added to prevent extra result sets from
			-- interfering with SELECT statements.
			--DELETE a	
			----	select d.CTID, d.description as HoldersProfile, a.CTID as dspCTID, a.name as dspName
			--	FROM [dbo].[DataSetProfile] a
			--	inner join [dbo].[Entity.DataSetProfile] b on a.Id = b.DataSetProfileId
			--	inner join [dbo].[Entity] c on b.EntityId = c.id	
			--	--23-02-09 mparsons - we get here after delete of Entity.ADP, so this inner join would never work
			--	--inner join [dbo].[Entity.AggregateDataProfile] d on c.EntityUid =d.RowId
			--	--inner join Deleted e on d.RowId = e.RowId
			--	-- instead:
			--	inner join Deleted e on c.EntityUid = e.RowId
		-- ================ OR =====================
		--SIGH this assumes the dsp will published right after the resource. 
		---		will most likely be true
			Update [DataSetProfile]	
			set EntityStateId=0
			--	select d.CTID, d.description as HoldersProfile, a.CTID as dspCTID, a.name as dspName
				FROM [dbo].[DataSetProfile] a
				inner join [dbo].[Entity.DataSetProfile] b on a.Id = b.DataSetProfileId
				inner join [dbo].[Entity] c on b.EntityId = c.id	
				--23-02-09 mparsons - we get here after delete of Entity.ADP, so this inner join would never work
				--inner join [dbo].[Entity.AggregateDataProfile] d on c.EntityUid =d.RowId
				--inner join Deleted e on d.RowId = e.RowId
				-- instead:
				inner join Deleted e on c.EntityUid = e.RowId


	--now delete entity
		DELETE a	
			FROM [dbo].[Entity] a
			inner join Deleted d on a.EntityUid = d.RowId
		  IF @@TRANCOUNT > 0
			 COMMIT
 
	   END TRY
	   BEGIN CATCH 

		  IF @@TRANCOUNT > 0
			 ROLLBACK
 
		  SELECT ERROR_NUMBER() AS ErrorNumber
		  SELECT ERROR_MESSAGE() AS ErrorMessage
 
   END CATCH
END
GO


