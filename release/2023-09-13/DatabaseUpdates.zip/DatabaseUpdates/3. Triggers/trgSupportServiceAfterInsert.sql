USE [sandbox_credFinder]
GO

/****** Object:  Trigger [dbo].[trgSupportServiceAfterInsert]    Script Date: 5/3/2023 11:59:57 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
Modifcations
23-05-02 mparsons - new
*/

Create TRIGGER [dbo].[trgSupportServiceAfterInsert] ON  [dbo].[SupportService]
FOR INSERT
AS  
    INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
		   ,EntityBaseId, EntityBaseName)
    SELECT RowId, 38, getdate(), Id, IsNull(Name,'SupportService')  as Name
    FROM inserted;
GO

ALTER TABLE [dbo].[SupportService] ENABLE TRIGGER [trgSupportServiceAfterInsert]
GO


