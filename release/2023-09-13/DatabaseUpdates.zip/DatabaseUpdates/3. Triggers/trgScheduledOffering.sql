USE credFinder
GO

--use sandbox_credfinder
--go



SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
Modifcations
22-09-29 mparsons - new
*/

Create TRIGGER [dbo].[trgScheduledOfferingAfterInsert] ON  [dbo].[ScheduledOffering]
FOR INSERT
AS  
    INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
		   ,EntityBaseId, EntityBaseName)
    SELECT RowId, 15, getdate(), Id, Name
    FROM inserted;

	
GO

/* =============================================
-- Create date: 2022-09-29
-- 22-09-29 mparsons - duh moment: could be updating entity.cache from this trigger??
						TBD
-- =============================================
*/
Create TRIGGER [dbo].[trgScheduledOfferingAfterUpdate] ON  [dbo].[ScheduledOffering]
   AFTER UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	UPDATE [dbo].[Entity]
		SET	[EntityBaseName] = b.Name
		 from [Entity] a
		 inner join inserted b on a.EntityUid = b.RowId
	
/* 
	could also update entity.cache (esp for top level resources)

UPDATE [dbo].[Entity_Cache]
   SET [Name] = b.Name
      ,[Description] = b.Description
      ,[LastUpdated] = b.LastUpdated
      ,[CacheDate] = getdate()
      ,[Url] = b.SubjectWebpage
      ,[IsPublished] = case when b.LastPublished is not null then 'yes' else 'no' end
      ,[HasApproval] =case when b.LastApproved is not null then 'yes' else 'no' end
	  --not likely to chg??
      ,[EntityStateId] = b.EntityStateId
from [Entity_Cache] a
		 inner join inserted b on a.EntityUid = b.RowId

	*/
END


