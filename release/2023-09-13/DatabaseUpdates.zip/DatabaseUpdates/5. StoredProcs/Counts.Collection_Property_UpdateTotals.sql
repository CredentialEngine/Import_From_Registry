USE [credFinder]
GO

use sandbox_credFinder 
go

--use staging_credFinder
--go

/****** Object:  StoredProcedure [dbo].[Counts.Collection_Property_UpdateTotals]    Script Date: 5/31/2020 9:35:55 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


--use credfinder_prod
--go

/****** 
	Populate the Collection properties totals table. 
	The first three steps are to initially generate the counts table. Additional properties can be added manaually as needed. 
	1. Use the following to generate the columns into _Dictionary (or create a customized version for this process)
		aspGenerateColumnDef @TableFilter = 'Collection_Property%', @TypeFilter='view'

	2. Then generate a counts table
		truncate if needed
		truncate table [dbo].[Counts.Collection_Property]

		SELECT [col_id] As Id, colName as Property, 0 as Total
		  into [credFinder].[dbo].[Counts.Collection_Property]
		FROM [credFinder].[dbo].[_Dictionary]
		where tableName = 'Collection_PropertyTotals'
		OR - if already exists
		INSERT INTO [dbo].[Counts.Collection_Property]
           ([Id]           ,[Property]           ,[Total])
    	SELECT [col_id] As Id, colName as Property, 0 as Total
		FROM [credFinder].[dbo].[_Dictionary]
		where tableName = 'Collection_PropertyTotals'


	3. Next generate the Update statements 
		- use the select sql below
	4. Execute the update statements

******/

/*
SELECT TOP (1000) Id
      ,Property
      ,[Total]

	  --,'UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.' + [Property] + ' from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = ''' + [Property] + '''  ' as updateLine
	  
	  FROM [credFinder].[dbo].[Counts.Collection_Property]
	  --order by Property
  go

  */

/*
--reset
UPDATE [dbo].[Counts.Collection_Property]
   SET [Total] = 0
go
*/
--UPDATE [dbo].[Counts.Collection_Property] 
--   SET [Total] = b.Name
--from [Counts.Collection_Property] a
----inner join 
--cross join Collection_PropertyTotals b
-- WHERE a.Property = 'Name'
--GO


/*
USE [credFinder]
GO

DROP PROCEDURE [dbo].[Counts.Collection_Property_UpdateTotals]
GO



exec [Counts.Collection_Property_UpdateTotals]
go

SELECT * FROM [credFinder].[dbo].[Counts.Collection_Property]
order by 1



Add:

Alt handling
HasCreditValue

Modifications
22-01-11 mparsons - add LifeCycleStatusType
*/
Create PROCEDURE [dbo].[Counts.Collection_Property_UpdateTotals] 
AS
BEGIN
declare @OverallTotal decimal(9,2)
--reset first
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = 0
--

UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.Total from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'Total' 
select @OverallTotal= Total from [Counts.Collection_Property] where Property='Total'
print 'over all total: ' + convert(varchar,@OverallTotal)
--=======================
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.Name from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'Name'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.Description from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'Description'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.SubjectWebpage from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'SubjectWebpage'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.CTID from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'CTID' 
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.LifeCycleStatusType from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'LifeCycleStatusType' 
--========
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasAvailabilityListing from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasAvailabilityListing'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasAvailableOnlineAt from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasAvailableOnlineAt'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasDateEffective from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasDateEffective'  
--
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasDeliveryTypeDescription from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasDeliveryTypeDescription'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasCollectionExampleDescription from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasCollectionExampleDescription'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasCollectionMethodDescription from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasCollectionMethodDescription'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasLearningMethodDescription from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasLearningMethodDescription'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasCollectionOutput from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasCollectionOutput'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasCodedNotation from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'CodedNotation'  

UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasGroupEvaluation from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasGroupEvaluation'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasGroupParticipation from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasGroupParticipation'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.IsProctored from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'IsProctored'  

--
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasExternalResearch from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasExternalResearch'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasProcessStandards from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasProcessStandards'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasProcessStandardsDescription from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasProcessStandardsDescription'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasScoringMethodDescription from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasScoringMethodDescription'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasScoringMethodExample from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasScoringMethodExample'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasScoringMethodExampleDescription from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasScoringMethodExampleDescription'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasVersionIdentifier from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasVersionIdentifier'  

UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasCreditUnitType from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasCreditUnitType'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasCreditUnitValue from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasCreditUnitValue'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasCreditUnitMaxValue from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasCreditUnitMaxValue'  

UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasCreditUnitTypeDescription from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasCreditUnitTypeDescription'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasInstructionalPgms from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasInstructionalPgms'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasOccupations from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasOccupations'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasIndustries from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasIndustries'  
-- ================
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasAudienceLevelType from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasAudienceLevelType'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasAudience from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasAudience'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasDeliveryMethodType from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasDeliveryMethodType'  

UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.hasCollectionMethodType from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'hasCollectionMethodType'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.hasCollectionUseType from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'hasCollectionUseType'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasScoringMethodType from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasScoringMethodType'  
-- =================
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasCompetencies from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasCompetencies'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasAddress from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasAddress'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasCosts from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasCosts'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasDuration from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasDuration'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasJurisdictions from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasJurisdictions'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasCommonCosts from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasCommonCosts'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasCommonConditions from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasCommonConditions'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasRequires from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasRequires'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasRecommends from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasRecommends'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasCorequisites from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasCorequisites'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasEntryConditions from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasEntryConditions'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasIsRequiredFor from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasIsRequiredFor'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasRecommendedFor from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasRecommendedFor'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasIsAdvancedStandingFor from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasIsAdvancedStandingFor'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasAdvancedStandingFrom from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasAdvancedStandingFrom'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasIsPreparationFor from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasIsPreparationFor'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasPreparationFrom from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasPreparationFrom'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasOwnedBy from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasOwnedBy'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasOfferedBy from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasOfferedBy'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasAccreditedBy from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasAccreditedBy'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasApprovedBy from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasApprovedBy'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasRecognizedBy from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasRecognizedBy'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasRegulatedBy from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasRegulatedBy'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasFinancialAssistance from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasFinancialAssistance'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasLanguages from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasLanguages'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasSubjects from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasSubjects'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasKeywords from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasKeywords'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasAccreditedIn from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasAccreditedIn'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasApprovedIN from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasApprovedIN'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasOfferedIN from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasOfferedIN'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasRecognizedIN from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasRecognizedIN'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasRegulatedIN from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasRegulatedIN'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasAdminProcessProfile from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasAdminProcessProfile'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasDevProcessProfile from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasDevProcessProfile'  
UPDATE [dbo].[Counts.Collection_Property]  SET [Total] = b.HasMtceProcessProfile from [Counts.Collection_Property] a cross join Collection_PropertyTotals b  WHERE a.[Property] = 'HasMtceProcessProfile'  
--
UPDATE [dbo].[Counts.Collection_Property]  SET PercentOfOverallTotal = (Total * 100) / @OverallTotal

-- overall data points
declare @TotalDatapoints int
 Select @TotalDatapoints=Sum([Total])  FROM [dbo].[Counts.Collection_Property]  
 where property <> 'Total' AND property <> 'Overall Data Points'
print '@TotalDatapoints: ' + convert(varchar, @TotalDatapoints)

UPDATE [dbo].[Counts.Collection_Property]  SET  Total =  @TotalDatapoints where property = 'Overall Data Points'


END
GO

grant execute on [Counts.Collection_Property_UpdateTotals] to public
go
/*

INSERT INTO [dbo].[Counts.Collection_Property]
           ([Id]
           ,[Property]
           ,[Label]
           ,[Policy]
           ,[PropertyGroup]
           ,[Total]
           ,[PercentOfOverallTotal])
     VALUES
           (2
           ,'Overall Data Points'
           ,'Overall Data Points'
           ,'1. Required'
           ,''
           ,0
           ,0)
GO

*/