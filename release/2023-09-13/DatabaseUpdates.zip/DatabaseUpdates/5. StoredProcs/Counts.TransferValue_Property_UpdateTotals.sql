use credfinder
go

--use sandbox_credFinder 
--go

--use staging_credFinder
--go

--use credfinder_prod
--go

/****** 
	Populate the TransferValue properties totals table. 
	FIRST CREATE THE VIEW: [TransferValue_PropertyTotals]
	
	See Counts.TransferIntermediary_Property for the latest approach

******/

/*
SELECT TOP (1000) Id
      ,Property
      ,[Total]

	  ,'UPDATE [dbo].[Counts.TransferValue_Property]  SET [Total] = b.' + [Property] + ' from [Counts.TransferValue_Property] a cross join TransferValue_PropertyTotals b  WHERE a.[Property] = ''' + [Property] + '''  ' as updateLine
	  
	  FROM [dbo].[Counts.TransferValue_Property]
	  order by 1
  go

  */

/*
--reset
UPDATE [dbo].[Counts.TransferValue_Property]
   SET [Total] = 0
go
*/
--UPDATE [dbo].[Counts.TransferValue_Property] 
--   SET [Total] = b.Name
--from [Counts.TransferValue_Property] a
----inner join 
--cross join TransferValue_PropertyTotals b
-- WHERE a.Property = 'Name'
--GO


/*
USE [credFinder]
GO

DROP PROCEDURE [dbo].[Counts.TransferValue_PropertyTransferValue_Property_UpdateTotals]
GO



exec [Counts.TransferValue_Property_UpdateTotals]
go

select * FROM [dbo].[Counts.TransferValue_Property]
order by id

Modifications
22-01-11 mparsons - add LifeCycleStatusType
*/
Alter PROCEDURE [Counts.TransferValue_Property_UpdateTotals] 
AS
BEGIN
declare @OverallTotal decimal(9,2)
--reset first
UPDATE [dbo].[Counts.TransferValue_Property]  SET [Total] = 0
--
 
UPDATE [dbo].[Counts.TransferValue_Property]  SET [Total] = b.Total from [Counts.TransferValue_Property] a cross join TransferValue_PropertyTotals b  WHERE a.[Property] = 'Total'  
--
select @OverallTotal= Total from [Counts.TransferValue_Property] where Property='Total'
print 'over all total: ' + convert(varchar,@OverallTotal)
--============

UPDATE [dbo].[Counts.TransferValue_Property]  SET [Total] = b.Name from [Counts.TransferValue_Property] a cross join TransferValue_PropertyTotals b  WHERE a.[Property] = 'Name'  
UPDATE [dbo].[Counts.TransferValue_Property]  SET [Total] = b.Description from [Counts.TransferValue_Property] a cross join TransferValue_PropertyTotals b  WHERE a.[Property] = 'Description'  
UPDATE [dbo].[Counts.TransferValue_Property]  SET [Total] = b.SubjectWebpage from [Counts.TransferValue_Property] a cross join TransferValue_PropertyTotals b  WHERE a.[Property] = 'SubjectWebpage'  
UPDATE [dbo].[Counts.TransferValue_Property]  SET [Total] = b.CTID from [Counts.TransferValue_Property] a cross join TransferValue_PropertyTotals b  WHERE a.[Property] = 'CTID'  
UPDATE [dbo].[Counts.TransferValue_Property]  SET [Total] = b.LifeCycleStatusType from [Counts.TransferValue_Property] a cross join TransferValue_PropertyTotals b  WHERE a.[Property] = 'LifeCycleStatusType' 
--========
UPDATE [dbo].[Counts.TransferValue_Property]  SET [Total] = b.DerivedFrom from [Counts.TransferValue_Property] a cross join TransferValue_PropertyTotals b  WHERE a.[Property] = 'DerivedFrom'  
UPDATE [dbo].[Counts.TransferValue_Property]  SET [Total] = b.EndDate from [Counts.TransferValue_Property] a cross join TransferValue_PropertyTotals b  WHERE a.[Property] = 'EndDate'  
UPDATE [dbo].[Counts.TransferValue_Property]  SET [Total] = b.Identifier from [Counts.TransferValue_Property] a cross join TransferValue_PropertyTotals b  WHERE a.[Property] = 'Identifier'  
UPDATE [dbo].[Counts.TransferValue_Property]  SET [Total] = b.StartDate from [Counts.TransferValue_Property] a cross join TransferValue_PropertyTotals b  WHERE a.[Property] = 'StartDate'  
UPDATE [dbo].[Counts.TransferValue_Property]  SET [Total] = b.TransferValue from [Counts.TransferValue_Property] a cross join TransferValue_PropertyTotals b  WHERE a.[Property] = 'TransferValue'  
UPDATE [dbo].[Counts.TransferValue_Property]  SET [Total] = b.TransferValueFrom from [Counts.TransferValue_Property] a cross join TransferValue_PropertyTotals b  WHERE a.[Property] = 'TransferValueFrom'  
UPDATE [dbo].[Counts.TransferValue_Property]  SET [Total] = b.TransferValueFor from [Counts.TransferValue_Property] a cross join TransferValue_PropertyTotals b  WHERE a.[Property] = 'TransferValueFor'  
UPDATE [dbo].[Counts.TransferValue_Property]  SET [Total] = b.OwnedBy from [Counts.TransferValue_Property] a cross join TransferValue_PropertyTotals b  WHERE a.[Property] = 'OwnedBy'  
UPDATE [dbo].[Counts.TransferValue_Property]  SET [Total] = b.DevelopmentProcess from [Counts.TransferValue_Property] a cross join TransferValue_PropertyTotals b  WHERE a.[Property] = 'DevelopmentProcess'  

--
UPDATE [dbo].[Counts.TransferValue_Property]  SET PercentOfOverallTotal = (Total * 100) / @OverallTotal

-- overall data points
declare @TotalDatapoints int
 Select @TotalDatapoints=Sum([Total])  FROM [dbo].[Counts.TransferValue_Property]  
 where property <> 'Total' AND property <> 'Overall Data Points'
print '@TotalDatapoints: ' + convert(varchar, @TotalDatapoints)

UPDATE [dbo].[Counts.TransferValue_Property]  SET  Total =  @TotalDatapoints where property = 'Overall Data Points'


END
GO
grant execute on [Counts.TransferValue_Property_UpdateTotals] to public
go

/*

INSERT INTO [dbo].[Counts.TransferValue_Property]
           ([Id]
           ,[Property]
           ,[Label]
           ,[Policy]
           ,[PropertyGroup]
           ,[Total]
           ,[PercentOfOverallTotal])
     VALUES
           (2
           ,'Overall Data Points'
           ,'Overall Data Points'
           ,'1. Required'
           ,''
           ,0
           ,0)
GO

*/