use credfinder
go

use sandbox_credFinder 
go

--use staging_credFinder
--go



/****** 
	Populate the SupportService properties totals table. 
	FIRST CREATE THE VIEW: [SupportService_PropertyTotals]
	
	See Counts.SupportService_Property for the latest approach
	FIRST CREATE THE VIEW: [SupportService_PropertyTotals]
	The first three steps are to initially generate the counts table. Additional properties can be added manaually as needed. 
	1. Use the following to generate the columns into _Dictionary (or create a customized version for this process)
		aspGenerateColumnDef @TableFilter = 'SupportService_Property%', @TypeFilter='view'

	2. Then generate a counts table
	===> preference is to use the create statement for any existing counts table, then use the insert *************************************
		drop/truncate if needed
		drop table [dbo].[Counts.SupportService_Property]

		SELECT [col_id] As Id, colName as Property, colName as Label, '1. Required' As Policy, '' as PropertyGroup, 0 as Total, 0 as PercentOfOverallTotal
		 into [dbo].[Counts.SupportService_Property]
		FROM [dbo].[_Dictionary]
		where tableName = 'SupportService_PropertyTotals'
		order by 1
		=======================================
		OR - if already exists (actually easier to just drop it, unless adding a few new ones)
		USE [credFinder]
		GO

		INSERT INTO [dbo].[Counts.SupportService_Property]
				   ([Id]
				   ,[Property]
				   ,[Label]
				   ,[Policy]
				   ,[PropertyGroup]
				   ,[Total]
				   ,[PercentOfOverallTotal])

    			SELECT [col_id] As Id, colName as Property, colName as Label, '1. Required' As Policy, '' as PropertyGroup, 0 as Total, 0 as PercentOfOverallTotal
				FROM [dbo].[_Dictionary]
				where tableName = 'SupportService_PropertyTotals'
				order by 1

			***EDIT THE COLUMN SIZE AS NEEDED - SEE BELOW ***
			USE [credFinder]
GO

		
			SET ANSI_NULLS ON
			GO

			SET QUOTED_IDENTIFIER ON
			GO

			CREATE TABLE [dbo].[Counts.SupportService_Property](
				[Id] [int] NOT NULL,
				[Property] [varchar](100) NOT NULL,
				[Label] [varchar](100) NOT NULL,
				[Policy] [varchar](100) NOT NULL,
				[PropertyGroup] [varchar](100) NOT NULL,
				[Total] [int] NOT NULL,
				[PercentOfOverallTotal] [decimal](5, 2) NOT NULL,
			 CONSTRAINT [PK_Counts.SupportService_Property] PRIMARY KEY CLUSTERED 
			(
				[Id] ASC
			)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
			) ON [PRIMARY]
			GO



			Now add the extra property: Overall Data Points
			- this could be added as a 'fake' property in the view like 'Total'

			Update the Policy contents

			3. Next generate the Update statements for the stored proc 
				- use the select sql below
				SELECT TOP (1000) Id
				  ,Property
				  ,[Total]

				  ,'UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = b.' + [Property] + ' from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = ''' + [Property] + '''  ' as updateLine
	  
				  FROM [dbo].[Counts.SupportService_Property]
				  order by 1
			  go
			4. Execute the update statements

	aspGenerateColumnDef @TableFilter = 'SupportService_PropertyTotal%', @TypeFilter='view'

	SELECT [col_id] As Id, colName as Property, colName as Label, '1. Required' As Policy, '' as PropertyGroup, 0 as Total, 0 as PercentOfOverallTotal
		 into [dbo].[Counts.SupportService_Property]
		FROM [dbo].[_Dictionary]
		where tableName = 'SupportService_PropertyTotals'
		order by 1

		
INSERT INTO [dbo].[Counts.SupportService_Property_UpdateTotals]
           ([Id]
           ,[Property]
           ,[Label]
           ,[Policy]
           ,[PropertyGroup]
           ,[Total]
           ,[PercentOfOverallTotal])

    	SELECT [col_id] As Id, colName as Property, colName as Label, '1. Required' As Policy, '' as PropertyGroup, 0 as Total, 0 as PercentOfOverallTotal
		FROM [dbo].[_Dictionary]
		where tableName = 'SupportService_PropertyTotals'
		order by 1

	3. Next generate the Update statements for the stored proc
		- use the select sql below
		SELECT TOP (1000) Id
				  ,Property
				  ,[Total]

				  ,'UPDATE [dbo].[Counts.TransferIntermediary_Property]  SET [Total] = b.' + [Property] + ' from [Counts.TransferIntermediary_Property] a cross join TransferIntermediary_PropertyTotals b  WHERE a.[Property] = ''' + [Property] + '''  ' as updateLine
	  
				  FROM [dbo].[Counts.TransferIntermediary_Property]
				  order by 1
	4. Execute the update statements

	/*


  */
******/

/*
SELECT TOP (1000) Id
      ,Property
      ,[Total]

	  ,'UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = b.' + [Property] + ' from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = ''' + [Property] + '''  ' as updateLine
	  
	  FROM [dbo].[Counts.SupportService_Property]
	  order by 1
  go

  */

/*
--reset
UPDATE [dbo].[Counts.SupportService_Property]
   SET [Total] = 0
go
*/
--UPDATE [dbo].[Counts.SupportService_Property] 
--   SET [Total] = b.Name
--from [Counts.SupportService_Property] a
----inner join 
--cross join SupportService_PropertyTotals b
-- WHERE a.Property = 'Name'
--GO


/*
USE [credFinder]
GO

DROP PROCEDURE [dbo].[Counts.SupportService_PropertySupportService_Property_UpdateTotals]
GO



exec [Counts.SupportService_Property_UpdateTotals]
go

select * FROM [dbo].[Counts.SupportService_Property]
order by id

Modifications
23-07-21 mparsons - new
*/
Create PROCEDURE [Counts.SupportService_Property_UpdateTotals] 
AS
BEGIN
declare @OverallTotal decimal(9,2)
--reset first
UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = 0
--
 
UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = IsNull(b.Total,0) from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = 'Total'  
--
select @OverallTotal= Total from [Counts.SupportService_Property] where Property='Total'
print 'over all total: ' + convert(varchar,@OverallTotal)
--============
 
UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = b.Name from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = 'Name'  
UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = b.Description from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = 'Description'  
UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = b.SubjectWebpage from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = 'SubjectWebpage'  
UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = b.CTID from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = 'CTID'  
UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = b.LifeCycleStatusType from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = 'LifeCycleStatusType'  
UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = b.DateEffective from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = 'DateEffective'  
UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = b.AvailableOnlineAt from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = 'AvailableOnlineAt'  
UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = b.AvailableAt from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = 'AvailableAt'  
UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = b.ExpirationDate from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = 'ExpirationDate'  
UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = b.AvailabilityListing from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = 'AvailabilityListing'  
UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = b.AlternateName from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = 'AlternateName'  
UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = b.Identifier from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = 'Identifier'  
UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = b.Keyword from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = 'Keyword'  
UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = b.OwnedBy from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = 'OwnedBy'  
UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = b.OfferedBy from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = 'OfferedBy'  
UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = b.OfferedIN from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = 'OfferedIN'  
UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = b.HasAccommodationType from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = 'HasAccommodationType'  
UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = b.HasSupportServiceType from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = 'HasSupportServiceType'  
UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = b.HasDeliveryMethodType from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = 'HasDeliveryMethodType'  
UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = b.HasCommonCosts from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = 'HasCommonCosts'  
UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = b.HasCommonConditions from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = 'HasCommonConditions'  
UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = b.EstimatedCost from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = 'EstimatedCost'  
UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = b.HasFinancialAssistance from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = 'HasFinancialAssistance'  
UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = b.HasLanguages from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = 'HasLanguages'  
UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = b.HasOccupations from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = 'HasOccupations'  
UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = b.SupportServiceCondition from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = 'SupportServiceCondition'  
UPDATE [dbo].[Counts.SupportService_Property]  SET [Total] = b.SupportServiceFor from [Counts.SupportService_Property] a cross join SupportService_PropertyTotals b  WHERE a.[Property] = 'SupportServiceFor'  

-- ============================== totals =========================================
UPDATE [dbo].[Counts.SupportService_Property]  SET PercentOfOverallTotal = (Total * 100) / @OverallTotal

-- overall data points
declare @TotalDatapoints int
 Select @TotalDatapoints=Sum([Total])  FROM [dbo].[Counts.SupportService_Property]  
 where property <> 'Total' AND property <> 'Overall Data Points'
print '@TotalDatapoints: ' + convert(varchar, @TotalDatapoints)

UPDATE [dbo].[Counts.SupportService_Property]  SET  Total =  @TotalDatapoints where property = 'Overall Data Points'


END
GO
grant execute on [Counts.SupportService_Property_UpdateTotals] to public
go

/*

INSERT INTO [dbo].[Counts.SupportService_Property]
           ([Id]
           ,[Property]
           ,[Label]
           ,[Policy]
           ,[PropertyGroup]
           ,[Total]
           ,[PercentOfOverallTotal])
     VALUES
           (2
           ,'Overall Data Points'
           ,'Overall Data Points'
           ,'1. Required'
           ,''
           ,0
           ,0)
GO

*/