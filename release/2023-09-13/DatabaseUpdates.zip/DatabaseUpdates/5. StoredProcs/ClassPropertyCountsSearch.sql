USE credFinder
GO
use sandbox_credFinder
go

--use staging_credFinder
--go
/****** Object:  StoredProcedure [dbo].[PropertyCountsSearch]    Script Date: 4/6/2020 5:33:16 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



/*

truncate table [Counts.Credential_Property]

--=====================================================

DECLARE @RC int,@SortOrder varchar(100),@Filter varchar(5000), @ClassType	varchar(100)
DECLARE @StartPageIndex int, @PageSize int, @TotalRows int,@CurrentUserId	int
--
set @SortOrder = ''
set @ClassType	= 'organization'
--set @ClassType	= 'assessment'
set @ClassType	= 'Pathway'
--set @Filter = '   (Policy=''required'' ) '
-- blind search 
set @Filter = ''

set @StartPageIndex = 1
set @PageSize = 200
--set statistics time on       
EXECUTE @RC = [ClassPropertyCountsSearch] @ClassType,	@Filter,@SortOrder  ,@StartPageIndex  ,@PageSize, @TotalRows OUTPUT

select 'total rows = ' + convert(varchar,@TotalRows)

--set statistics time off       


*/


/* =============================================
Description:      search for property counts tables
Options:

  @StartPageIndex - starting page number. If interface is at 20 when next
page is requested, this would be set to 21?
  @PageSize - number of records on a page
  @TotalRows OUTPUT - total available rows. Used by interface to build a
custom pager
  ------------------------------------------------------
Modifications
20-06-21 mparsons - new

*/

Alter PROCEDURE [dbo].[ClassPropertyCountsSearch]
		@ClassType			varchar(100)
		,@Filter           varchar(5000)
		,@SortOrder       varchar(100)
		,@StartPageIndex  int
		,@PageSize        int
		,@TotalRows       int OUTPUT

As

SET NOCOUNT ON;
-- paging
DECLARE
      @first_id               int
      ,@startRow        int
      ,@debugLevel      int
      ,@SQL             varchar(5000)
      ,@OrderBy         varchar(100)
	  ,@TableName		varchar(100)

if @ClassType = 'credential'				set @TableName = '[Counts.Credential_Property]'
else if @ClassType = 'organization'			set @TableName = '[Counts.Organization_Property]'
else if @ClassType = 'assessment' OR @ClassType = 'assessmentprofile' set @TableName = '[Counts.Assessment_Property]'
else if @ClassType = 'learningOpportunity'	set @TableName = '[Counts.learningOpportunity_Property]'
else if @ClassType = 'lopp'					set @TableName = '[Counts.learningOpportunity_Property]'
else if @ClassType = 'CostManifest'			set @TableName = '[Counts.CostManifest_Property]'
else if @ClassType = 'ConditionManifest'	set @TableName = '[Counts.ConditionManifest_Property]'
else if @ClassType = 'Pathway'				set @TableName = '[Counts.Pathway_Property]'
else if @ClassType = 'TransferValue'		set @TableName = '[Counts.TransferValue_Property]'
else if @ClassType = 'TransferIntermediary'	set @TableName = '[Counts.TransferIntermediary_Property]'
else if @ClassType = 'competencyframework'	set @TableName = '[Counts.CompetencyFramework_Property]'
else if @ClassType = 'Collection'			set @TableName = '[Counts.Collection_Property]'
else if @ClassType = 'SupportService'		set @TableName = '[Counts.SupportService_Property]'
else begin
set @TableName = '[Counts.Credential_Property]'
	end
-- =================================

--set @CurrentUserId = 24
Set @debugLevel = 4

if len(@SortOrder) > 0
      set @OrderBy = ' Order by ' + @SortOrder
else
      set @OrderBy = ' Order by base.Id '

--===================================================
-- Calculate the range
--===================================================
SET @StartPageIndex =  (@StartPageIndex - 1)  * @PageSize
IF @StartPageIndex < 1        SET @StartPageIndex = 1

-- =================================
--CREATE TABLE #tempWorkTable(
--      RowNumber         int PRIMARY KEY IDENTITY(1,1) NOT NULL,
--      Id int,
--      OrganizationName             varchar(max)
--)



CREATE TABLE #tempWorkTable(
	RowNumber         int PRIMARY KEY IDENTITY(1,1) NOT NULL,
	[Id] [int] NOT NULL,
	[Property] [nvarchar](128) NOT NULL,
	[Label] [varchar](100) ,
	[Policy] [varchar](50) ,
	[PropertyGroup] [varchar](50) ,
	[Total] [int] ,
	[PercentOfOverallTotal] decimal(5,2)
) 
-- =================================


-- =============
  if len(@Filter) > 0 begin
     if charindex( 'where', @Filter ) = 0 OR charindex( 'where',  @Filter ) > 10
        set @Filter =     ' where ' + @Filter
     end

  print '@Filter len: '  +  convert(varchar,len(@Filter))
  set @SQL = 'SELECT [Id]      ,[Property]      ,[Label]      ,[Policy]      ,[PropertyGroup]      ,[Total], [PercentOfOverallTotal]   FROM  ' + @TableName + ' base   '
        + @Filter
        
  if charindex( 'order by', lower(@Filter) ) = 0
    set @SQL = @SQL + ' ' + @OrderBy

  print '@SQL len: '  +  convert(varchar,len(@SQL))
  print @SQL


INSERT INTO #tempWorkTable
           ([Id]
           ,[Property]
           ,[Label]
           ,[Policy]
           ,[PropertyGroup]
           ,[Total], [PercentOfOverallTotal]
		   )
  exec (@SQL)



  --print 'rows: ' + convert(varchar, @@ROWCOUNT)
  SELECT @TotalRows = @@ROWCOUNT
-- =================================

print 'added to temp table: ' + convert(varchar,@TotalRows)
if @debugLevel > 7 begin
  select * from #tempWorkTable
  end

-- Calculate the range
--===================================================
PRINT '@StartPageIndex = ' + convert(varchar,@StartPageIndex)

SET ROWCOUNT @StartPageIndex
SELECT @first_id = @StartPageIndex
PRINT '@first_id = ' + convert(varchar,@first_id)

if @first_id = 1 set @first_id = 0
--set max to return
SET ROWCOUNT @PageSize

-- ================================= 
SELECT        
	RowNumber, 
	[Id]      ,[Property]      ,[Label]      ,[Policy]      ,[PropertyGroup]      
	,[Total]   
	,[PercentOfOverallTotal]

From #tempWorkTable work
	

WHERE RowNumber > @first_id
order by RowNumber 

GO

grant execute on [ClassPropertyCountsSearch] to public
go