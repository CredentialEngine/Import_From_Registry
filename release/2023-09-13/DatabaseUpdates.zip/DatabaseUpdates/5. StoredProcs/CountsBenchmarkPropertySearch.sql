USE credFinder
GO
use sandbox_credFinder
go

	--*****NOT USED YET????? SEE: [ClassPropertyCountsSearch]

--use staging_credFinder
--go
/****** Object:  StoredProcedure [dbo].[PropertyCountsSearch]    Script Date: 4/6/2020 5:33:16 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



/*

truncate table [Counts.Credential_Property]

--=====================================================

DECLARE @RC int,@SortOrder varchar(100),@Filter varchar(5000), @ClassType	varchar(100)
DECLARE @StartPageIndex int, @PageSize int, @TotalRows int,@CurrentUserId	int
--
set @SortOrder = ''
set @ClassType	= 'organization'
set @ClassType	= 'assessment'
set @ClassType	= 'pathway'

set @Filter = '   (BenchmarkClass=''Credential'') '

--set @Filter = '   (Policy=''required'' ) '

-- blind search 
set @Filter = ''

set @StartPageIndex = 1
set @PageSize = 200
--set statistics time on       
EXECUTE @RC = [CountsBenchmarkProperty] @ClassType,	@Filter,@SortOrder  ,@StartPageIndex  ,@PageSize, @TotalRows OUTPUT

select 'total rows = ' + convert(varchar,@TotalRows)

--set statistics time off       


*/


/* =============================================
			NOT USED YET????? SEE: [ClassPropertyCountsSearch]
Description:    search for benchmark property counts tables
				This proc would be used with Counts.BenchmarkProperty
Options:

  @StartPageIndex - starting page number. If interface is at 20 when next
page is requested, this would be set to 21?
  @PageSize - number of records on a page
  @TotalRows OUTPUT - total available rows. Used by interface to build a
custom pager
  ------------------------------------------------------
Modifications
20-07-07 mparsons - new

*/

Create PROCEDURE [dbo].[CountsBenchmarkProperty]
		@ClassType			varchar(100)
		,@Filter           varchar(5000)
		,@SortOrder       varchar(100)
		,@StartPageIndex  int
		,@PageSize        int
		,@TotalRows       int OUTPUT

As

SET NOCOUNT ON;
-- paging
DECLARE
      @first_id               int
      ,@startRow        int
      ,@debugLevel      int
      ,@SQL             varchar(5000)
      ,@OrderBy         varchar(100)
	  ,@TableName		varchar(100)

if @ClassType = 'credential' set @TableName = '[Counts.Credential_Property]'
else if @ClassType = 'organization' set @TableName = '[Counts.Organization_Property]'
else if @ClassType = 'assessment' set @TableName = '[Counts.Assessment_Property]'
else if @ClassType = 'learningOpportunity' set @TableName = '[Counts.learningOpportunity_Property]'
else if @ClassType = 'lopp' set @TableName = '[Counts.learningOpportunity_Property]'
else if @ClassType = 'costManifest' set @TableName = '[Counts.costManifest_Property]'
else if @ClassType = 'ConditionManifest' set @TableName = '[Counts.ConditionManifest_Property]'
else if @ClassType = 'Pathway' set @TableName = '[Counts.Pathway_Property]'
else if @ClassType = 'TransferValue' set @TableName = '[Counts.TransferValue_Property]'
else begin
set @TableName = '[Counts.Credential_Property]'
	end
-- =================================

--set @CurrentUserId = 24
Set @debugLevel = 4

if len(@SortOrder) > 0
      set @OrderBy = ' Order by BenchmarkClass, ' + @SortOrder
else
      set @OrderBy = ' Order by BenchmarkClass,  base.DefaultOrder '

--===================================================
-- Calculate the range
--===================================================
SET @StartPageIndex =  (@StartPageIndex - 1)  * @PageSize
IF @StartPageIndex < 1        SET @StartPageIndex = 1

-- =================================
--CREATE TABLE #tempWorkTable(
--      RowNumber         int PRIMARY KEY IDENTITY(1,1) NOT NULL,
--      Id int,
--      OrganizationName             varchar(max)
--)



CREATE TABLE #tempWorkTable(
	RowNumber         int PRIMARY KEY IDENTITY(1,1) NOT NULL,
	BenchmarkClass varchar(100) NOT NULL,
	DefaultOrder [int] NOT NULL,
	[Property] [nvarchar](128) NOT NULL,
	[Label] [varchar](100) ,
	[Policy] [varchar](50) ,
	[PropertyGroup] [varchar](50) ,
	[Total] [int], 
	PercentOfOverallTotal decimal(5,2)
) 
-- =================================


-- =============
  if len(@Filter) > 0 begin
     if charindex( 'where', @Filter ) = 0 OR charindex( 'where',  @Filter ) > 10
        set @Filter =     ' where ' + @Filter
     end

  print '@Filter len: '  +  convert(varchar,len(@Filter))
  set @SQL = 'SELECT BenchmarkClass, [DefaultOrder]      ,[Property]      ,[Label]      ,[Policy]      ,[PropertyGroup]      ,[Total], PercentOfOverallTotal   FROM  [Counts.BenchmarkProperty] base   '
        + @Filter
        
  if charindex( 'order by', lower(@Filter) ) = 0
    set @SQL = @SQL + ' ' + @OrderBy

  print '@SQL len: '  +  convert(varchar,len(@SQL))
  print @SQL


INSERT INTO #tempWorkTable
           (BenchmarkClass
		   ,DefaultOrder
           ,[Property]
           ,[Label]
           ,[Policy]
           ,[PropertyGroup]
           ,[Total]
		   ,PercentOfOverallTotal)
  exec (@SQL)



  --print 'rows: ' + convert(varchar, @@ROWCOUNT)
  SELECT @TotalRows = @@ROWCOUNT
-- =================================

print 'added to temp table: ' + convert(varchar,@TotalRows)
if @debugLevel > 7 begin
  select * from #tempWorkTable
  end

-- Calculate the range
--===================================================
PRINT '@StartPageIndex = ' + convert(varchar,@StartPageIndex)

SET ROWCOUNT @StartPageIndex
SELECT @first_id = @StartPageIndex
PRINT '@first_id = ' + convert(varchar,@first_id)

if @first_id = 1 set @first_id = 0
--set max to return
SET ROWCOUNT @PageSize

-- ================================= 
SELECT        
	RowNumber, 
	BenchmarkClass
	,DefaultOrder      
	,[Property]      
	,[Label]      
	,[Policy]      
	,[PropertyGroup]      
	,[Total]
	--could calculate here if zero? - don't have overall total though
	,PercentOfOverallTotal   

From #tempWorkTable work
	

WHERE RowNumber > @first_id
order by RowNumber 

GO

grant execute on [CountsBenchmarkProperty] to public
go