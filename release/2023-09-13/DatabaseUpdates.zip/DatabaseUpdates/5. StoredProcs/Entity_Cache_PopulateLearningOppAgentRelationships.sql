use credFinder
go

--use sandbox_credfinder	
--go

/*
USE [credFinder]
GO

SSELECT TOP (1000) a.[Id]
           ,a.[EntityTypeId]      ,a.[EntityType]      ,a.[EntityUid]
      ,a.[EntityStateId]
      ,a.[CTID]
    --  ,a.[parentEntityId]      ,a.[parentEntityUid]      ,a.[parentEntityType]      ,a.[parentEntityTypeId]
      ,a.[BaseId]
      ,a.[Name]
  --    ,a.[Description]
 
   --   ,a.[SubjectWebpage]
      ,a.[OwningOrgId], b.Name as Org   ,a.[AgentRelationshipsForEntity]
    --  ,a.[ImageUrl]
      ,a.[Created]
      ,a.[LastUpdated]
      ,a.[CacheDate]
      ,a.[PublishedByOrgId]
      ,a.[ResourceDetail]
     
      ,a.[IsActive]
--	select count(*)
  FROM [credFinder].[dbo].[Entity_Cache] a
  left join Organization b on a.[OwningOrgId] = b.Id
  where a.entitytypeid  in (7,36,37)
  --where entitytypeid =7
  and a.entitystateid = 3
  --and [BaseId] = 14856
  and [AgentRelationshipsForEntity] is NOT null
 -- and CHARINDEX(a.[AgentRelationshipsForEntity], convert(varchar(5),a.OwningOrgId), 1 ) > 0
 and convert(varchar(10),a.CacheDate ,120) = '2023-05-17'
  order by a.LastUpdated desc

  --NOT null: 9882
  --NULL: 4161
    --where entitytypeid not in (7,36,37)
  where entitytypeid =7
  and entitystateid = 3
  --and [BaseId] = 14856
  and [AgentRelationshipsForEntity] is NOT null

  order by LastUpdated --desc
GO



select ec.ctid, ec.baseId,ec.Name,resource.LastUpdated,  resource.AgentRelationshipsForEntity 
   from entity_cache ec 
   --inner join LearningOpp c on ec.CTID = c.CTID 
   inner join ( 
   select Id, entityStateId, ctid, LastUpdated 
   	 ,(SELECT DISTINCT ear.AgentRelativeId As OrgId, ear.AgentName, ear.AgentUrl, ear.EntityStateId, ear.RoleIds as RelationshipTypeIds,  ear.Roles as Relationships, ear.AgentContextRoles FROM [dbo].[Entity.AgentRelationshipIdCSV] ear
			WHERE ear.EntityTypeId= 1 AND ear.EntityBaseId = base.Id 
			FOR XML RAW, ROOT('AgentRelationshipsForEntity')) AgentRelationshipsForEntity
   from LearningOpp base 
   ) resource on ec.CTID = resource.CTID

 WHERE resource.EntityStateId = 3
 and ec.EntityStateId = 3
 AND ec.CTID = 'ce-6efdcdfd-923d-433f-a674-f06d7cccca01'
 and ec.[AgentRelationshipsForEntity] is null 
 --and resource.LastUpdated > '2023-01-01'
GO
Select * from entity_cache ec 
where ec.CTID = 'ce-a87a9fa0-e03e-4642-9296-d17a5000c927'	
or ec.AgentRelationshipsForEntity is not null 


[Entity_Cache_PopulateLearningOppAgentRelationships] 'ce-6efdcdfd-923d-433f-a674-f06d7cccca01'

*/
/*
Entity_Cache_PopulateLearningOppAgentRelationships
Due to the atrocious performance deriving AgentRelationshipsForEntity in procs, changing approach to populate separately. 
We need a means to check if it works, and notify if not

*/
Alter Procedure [dbo].Entity_Cache_PopulateLearningOppAgentRelationships
	@ResourceCTID	varchar(50)
AS
-- =================================
if IsNull(@ResourceCTID,'') = '' begin

	print 'Entity_Cache_PopulateLearningOppAgentRelationships - Invalid request, missing CTID' 
	end
else
	 BEGIN TRY  
	
		UPDATE [dbo].[Entity_Cache]
		   SET [AgentRelationshipsForEntity] = resource.AgentRelationshipsForEntity
		-- select ec.ctid, ec.baseId,ec.Name,resource.LastUpdated,  resource.AgentRelationshipsForEntity 
		   from entity_cache ec 
		   --do the lopp join just to be sure??
		   inner join LearningOpportunity c on ec.CTID = c.CTID 
		   inner join 
		   ( 
			   select Id, entityStateId, ctid, LastUpdated 
   				 ,(SELECT DISTINCT ear.AgentRelativeId As OrgId, ear.AgentName, ear.AgentUrl, ear.EntityStateId, ear.RoleIds as RelationshipTypeIds,  ear.Roles as Relationships, ear.AgentContextRoles FROM [dbo].[Entity.AgentRelationshipIdCSV] ear
						WHERE ear.EntityTypeId= 7 AND ear.EntityBaseId = base.Id 
						FOR XML RAW, ROOT('AgentRelationshipsForEntity')
					) AgentRelationshipsForEntity
			   from LearningOpportunity base 
		   ) resource on ec.CTID = resource.CTID

		 WHERE resource.EntityStateId = 3
		 and ec.EntityStateId = 3
		 --and ec.[AgentRelationshipsForEntity] is null 
		 and resource.CTID = @ResourceCTID
		 --now check. Or return the result, and have the caller check?


END TRY  
BEGIN CATCH  
     print 'Errors encountered in Entity_Cache_PopulateLearningOppAgentRelationships ' 
	   --SELECT
    --ERROR_NUMBER() AS ErrorNumber,
    --ERROR_STATE() AS ErrorState,
    --ERROR_SEVERITY() AS ErrorSeverity,
    --ERROR_PROCEDURE() AS ErrorProcedure,
    --ERROR_LINE() AS ErrorLine,
    --ERROR_MESSAGE() AS ErrorMessage;

INSERT INTO [dbo].[MessageLog]
           ([Created],[Application],[Activity]
           ,[MessageType],[Message],[Description]
           ,[ActionByUserId],[ActivityObjectId]
           ,[RelatedUrl],[SessionId],[IPAddress],[Tags])
     VALUES
           (getdate(), 'LearningOppFinder'
           ,'LearningOpp'
           ,'Error'
           ,ERROR_MESSAGE()
           ,'Errors encountered in Entity_Cache_PopulateLearningOppAgentRelationships for ' + @ResourceCTID 
           ,0
           ,@ResourceCTID
           ,NULL,NULL,NULL,NULL)

END CATCH 

go
grant execute on Entity_Cache_PopulateLearningOppAgentRelationships to public
go

