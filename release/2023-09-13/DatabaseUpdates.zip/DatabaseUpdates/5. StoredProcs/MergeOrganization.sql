
  USE [credFinder]
GO

/*
 MergeOrganization oldRowId, NewRowId
 go
 */
 Create  Procedure [dbo].MergeOrganization
 @DuplicateRowId varchar(50),  @TargetRowId varchar(50)
AS
--TODO 
-- should we record stuff to be changed to allow reverting?

Declare 
@TargetOrgId int, @TargetOrgName varchar(500)
,@DuplicateOrgId int, @DuplicateOrgName varchar(500)
,@DebugLevel int
set @DebugLevel= 10
--
Select @DuplicateOrgId=  Id, @DuplicateOrgName=Name 
from Organization where RowId = @DuplicateRowId
print 'Duplicate organization: ' + @DuplicateOrgName + ' ( ' + convert(varchar,@DuplicateOrgId) + ' ) '
--
Select @TargetOrgId=  Id, @TargetOrgName=Name 
from Organization where RowId = @TargetRowId
print 'Target organization: ' + @TargetOrgName + ' ( ' + convert(varchar,@TargetOrgId) + ' ) '


if @DebugLevel > 8 begin
	print 'skipping updates '
	end
else begin
	-- do the merge 
	--NOTE: there could be a case where there were multiple duplicates and a second update could result in a duplicate EntityId + AgentUID combination
	UPDATE [dbo].[Entity.AgentRelationship]
	   SET [AgentUid] =  @TargetRowId 
	from [Entity.AgentRelationship] 
	 WHERE agentuid = @DuplicateRowId

	-- add old to be deleted from elastic index
	INSERT INTO [dbo].[SearchPendingReindex]
			   ([EntityTypeId]
			   ,[RecordId]
			   ,[StatusId]
			   ,[IsUpdateOrDeleteTypeId]
			   ,[Created]
			   ,[LastUpdated])
	Select 2, Id, 1, 2, GETDATE(), GETDATE()
	from Organization where RowId = @DuplicateRowId

	-- add target to be updated in elastic index (if not already has pending reindex)
	INSERT INTO [dbo].[SearchPendingReindex]
			   ([EntityTypeId]
			   ,[RecordId]
			   ,[StatusId]
			   ,[IsUpdateOrDeleteTypeId]
			   ,[Created]
			   ,[LastUpdated])
	Select 2, a.Id, 1, 1, GETDATE(), GETDATE()
	from Organization a
	left join [SearchPendingReindex] b on a.Id = b.RecordId and b.EntityTypeId=2 and [StatusId]=1
	where b.Id is null 
	AND a.RowId = @TargetRowId



	-- set old to deleted
	-- mark somehow to allow recovery?
	Update Organization 
		Set EntityStateId = 0,
			LastUpdated = GETDATE()
	where RowId = @DuplicateRowId

	--Add activity for reference
	INSERT INTO [dbo].[ActivityLog]
			   ([CreatedDate]
			   ,[ActivityType]
			   ,[Activity]
			   ,[Event]
			   ,[Comment]
			   ,[ActivityObjectId]
				)
		 VALUES
			   (getdate(), 'Organization', 'Manage', 'Merge Duplicate'
			   ,'Merged relationshiops for duplicate a Organization into Organization: "' + @TargetOrgName+ '"'
			   ,@TargetOrgId

			   )
	end

GO

