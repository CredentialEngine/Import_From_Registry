use credFinder
go

use sandbox_credfinder	
go

--use staging_credFinder
--go

/*
select ec.ctid, ec.baseId,ec.Name,resource.LastUpdated,  resource.AgentRelationshipsForEntity 
   from entity_cache ec 
   --inner join credential c on ec.CTID = c.CTID 
   inner join ( 
   select Id, entityStateId, ctid, LastUpdated 
   	 ,(SELECT DISTINCT ear.AgentRelativeId As OrgId, ear.AgentName, ear.AgentUrl, ear.EntityStateId, ear.RoleIds as RelationshipTypeIds,  ear.Roles as Relationships, ear.AgentContextRoles FROM [dbo].[Entity.AgentRelationshipIdCSV] ear
			WHERE ear.EntityTypeId= 1 AND ear.EntityBaseId = base.Id 
			FOR XML RAW, ROOT('AgentRelationshipsForEntity')) AgentRelationshipsForEntity
   from credential base 
   ) resource on ec.CTID = resource.CTID

 WHERE resource.EntityStateId = 3
 and ec.EntityStateId = 3
 AND ec.CTID = 'ce-6efdcdfd-923d-433f-a674-f06d7cccca01'
 and ec.[AgentRelationshipsForEntity] is null 
 --and resource.LastUpdated > '2023-01-01'
GO
Select * from entity_cache ec 
where ec.CTID = 'ce-6efdcdfd-923d-433f-a674-f06d7cccca01'
or ec.AgentRelationshipsForEntity is not null 


[Entity_Cache_PopulateCredentialAgentRelationships] 'ce-6efdcdfd-923d-433f-a674-f06d7cccca01'

*/
/*
Entity_Cache_PopulateCredentialAgentRelationships
Due to the atrocious performance deriving AgentRelationshipsForEntity in procs, changing approach to populate separately. 
We need a means to check if it works, and notify if not

*/
Alter Procedure [dbo].Entity_Cache_PopulateCredentialAgentRelationships
	@ResourceCTID	varchar(50)
AS
-- =================================
if IsNull(@ResourceCTID,'') = '' begin

	print 'Entity_Cache_PopulateCredentialAgentRelationships - Invalid request, missing CTID' 
	end
else
	 BEGIN TRY  
	
		UPDATE [dbo].[Entity_Cache]
		   SET [AgentRelationshipsForEntity] = resource.AgentRelationshipsForEntity
		-- select ec.ctid, ec.baseId,ec.Name,resource.LastUpdated,  resource.AgentRelationshipsForEntity 
		   from entity_cache ec 
		   inner join 
		   ( 
			   select Id, entityStateId, ctid, LastUpdated 
   				 ,(SELECT DISTINCT ear.AgentRelativeId As OrgId, ear.AgentName, ear.AgentUrl, ear.EntityStateId, ear.RoleIds as RelationshipTypeIds,  ear.Roles as Relationships, ear.AgentContextRoles FROM [dbo].[Entity.AgentRelationshipIdCSV] ear
						WHERE ear.EntityTypeId= 1 AND ear.EntityBaseId = base.Id 
						FOR XML RAW, ROOT('AgentRelationshipsForEntity')
					) AgentRelationshipsForEntity
			   from credential base 
		   ) resource on ec.CTID = resource.CTID

		 WHERE resource.EntityStateId = 3
		 and ec.EntityStateId = 3
		 --and ec.[AgentRelationshipsForEntity] is null 
		 and resource.CTID = @ResourceCTID
		 --now check. Or return the result, and have the caller check?


END TRY  
BEGIN CATCH  
     print 'Errors encountered in Entity_Cache_PopulateCredentialAgentRelationships ' 
	   --SELECT
    --ERROR_NUMBER() AS ErrorNumber,
    --ERROR_STATE() AS ErrorState,
    --ERROR_SEVERITY() AS ErrorSeverity,
    --ERROR_PROCEDURE() AS ErrorProcedure,
    --ERROR_LINE() AS ErrorLine,
    --ERROR_MESSAGE() AS ErrorMessage;

INSERT INTO [dbo].[MessageLog]
           ([Created],[Application],[Activity]
           ,[MessageType],[Message],[Description]
           ,[ActionByUserId],[ActivityObjectId]
           ,[RelatedUrl],[SessionId],[IPAddress],[Tags])
     VALUES
           (getdate(), 'CredentialFinder'
           ,'Credential'
           ,'Error'
           ,ERROR_MESSAGE()
           ,'Errors encountered in Entity_Cache_PopulateCredentialAgentRelationships for ' + @ResourceCTID 
           ,0
           ,@ResourceCTID
           ,NULL,NULL,NULL,NULL)

END CATCH 

go
grant execute on Entity_Cache_PopulateCredentialAgentRelationships to public
go

