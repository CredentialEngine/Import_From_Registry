USE [credFinder]
GO

--use credFinder_freshStart
--go

--use credfinder_prod
--go

--USE staging_credFinder
--GO

--use sandbox_credFinder
--go

/****** Object:  StoredProcedure [dbo].[PathwaySet.ElasticSearch]    Script Date: 4/20/2018 11:40:06 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
USE [credFinder]
GO

SELECT TOP (1000) [Id]
      ,[RowId]
      ,[EntityStateId]
      ,[Name]
      ,[Description]
      ,[SubjectWebpage]
      ,[CTID]
      ,[OwningAgentUid]
      ,[CredentialRegistryId]
      ,[StartDate]
      ,[EndDate]
      ,[Created]
      ,[LastUpdated]
      ,[CodedNotation]
      ,[IdentifierJson]
      ,[PathwayJson]
      ,[PathwayFromJson]
      ,[PathwayForJson]
  FROM [credFinder].[dbo].[PathwaySet]



--=====================================================

DECLARE @RC int,@SortOrder varchar(100),@Filter varchar(5000)
DECLARE @StartPageIndex int, @PageSize int, @TotalRows int
--

set @SortOrder = ''
set @SortOrder = 'base.Name'

--set @Filter = ' ( base.Id in (SELECT  OrgId FROM [PathwaySet.Member] where UserId = 2) ) '
set @Filter = ' ( base.EntityStateId = 3 ) and [ExistsInRegistry] = 1 '


-- blind search 
set @Filter = ''
set @StartPageIndex = 1
set @PageSize = 55
--set statistics time on       
EXECUTE @RC = [PathwaySet.ElasticSearch]
     @Filter,@SortOrder  ,@StartPageIndex  ,@PageSize,  @TotalRows OUTPUT

select 'total rows = ' + convert(varchar,@TotalRows)

--set statistics time off       


*/


/* =============================================
Description:      PathwaySet search
Options:

  @StartPageIndex - starting page number. If interface is at 20 when next
page is requested, this would be set to 21?
  @PageSize - number of records on a page
  @TotalRows OUTPUT - total available rows. Used by interface to build a
custom pager
  ------------------------------------------------------
Modifications
20-01-14 mparsons - new

*/

Alter PROCEDURE [dbo].[PathwaySet.ElasticSearch] 
		@Filter           varchar(5000)
		,@SortOrder       varchar(100)
		,@StartPageIndex  int
		,@PageSize        int
		,@TotalRows       int OUTPUT

As

SET NOCOUNT ON;
-- paging
DECLARE
      @first_id               int
      ,@startRow        int
      ,@debugLevel      int
      ,@SQL             varchar(5000)
      ,@OrderBy         varchar(100)
	  ,@HasSitePrivileges bit

-- =================================

--set @CurrentUserId = 24
Set @debugLevel = 4
set @HasSitePrivileges= 0

if @SortOrder = 'relevance' set @SortOrder = 'base.Name '
else if @SortOrder = 'alpha' set @SortOrder = 'base.Name '
else if @SortOrder = 'newest' set @SortOrder = 'base.lastUpdated Desc '
else set @SortOrder = 'base.Name '

if len(@SortOrder) > 0 
      set @OrderBy = ' Order by ' + @SortOrder
else
      set @OrderBy = ' Order by base.Name '

--===================================================
-- Calculate the range
--===================================================
SET @StartPageIndex =  (@StartPageIndex - 1)  * @PageSize
IF @StartPageIndex < 1        SET @StartPageIndex = 1

 
-- =================================
CREATE TABLE #tempWorkTable(
      RowNumber         int PRIMARY KEY IDENTITY(1,1) NOT NULL,
      Id int,
      Name             varchar(1000)
)
-- =================================

  if len(@Filter) > 0 begin
     if charindex( 'where', @Filter ) = 0 OR charindex( 'where',  @Filter ) > 10
        set @Filter =     ' where ' + @Filter
     end

  print '@Filter len: '  +  convert(varchar,len(@Filter))
  set @SQL = 'SELECT  base.Id, base.Name from [PathwaySetSummary] base   '
        + @Filter
        
  if charindex( 'order by', lower(@Filter) ) = 0
    set @SQL = @SQL + ' ' + @OrderBy

  print '@SQL len: '  +  convert(varchar,len(@SQL))
  print @SQL

  INSERT INTO #tempWorkTable (Id, Name)
  exec (@SQL)
  --print 'rows: ' + convert(varchar, @@ROWCOUNT)
  SELECT @TotalRows = @@ROWCOUNT
-- =================================

print 'added to temp table: ' + convert(varchar,@TotalRows)
if @debugLevel > 7 begin
  select * from #tempWorkTable
  end

-- Calculate the range
--===================================================
PRINT '@StartPageIndex = ' + convert(varchar,@StartPageIndex)

SET ROWCOUNT @StartPageIndex
--SELECT @first_id = RowNumber FROM #tempWorkTable   ORDER BY RowNumber
SELECT @first_id = @StartPageIndex
PRINT '@first_id = ' + convert(varchar,@first_id)

if @first_id = 1 set @first_id = 0
--set max to return
SET ROWCOUNT @PageSize

-- ================================= 
SELECT        
	RowNumber, 
	base.[Id]
	,base.[RowId]
	,e.Id as EntityId
	,base.[EntityStateId]
	,base.[Name]
	,base.[Description]
	,base.[SubjectWebpage]
	,base.[CTID]
	--
	,base.[OwningAgentUid]
	,base.[OrganizationId]
	,base.[OrganizationName]
	,base.[OrganizationCTID]
	,base.[CredentialRegistryId]
	,e.LastUpdated as EntityLastUpdated
	,base.[Created]
	,base.[LastUpdated]
	,base.HasPathwaysCount
	,base.HasPathways
	--,base.HasPathways2

	--pathways? - json for easy expansion

	--pathways count

	
	--all entity to organization relationships with org information. 
	 ,(SELECT DISTINCT AgentRelativeId As OrgId, AgentName, AgentUrl, EntityStateId, RoleIds as RelationshipTypeIds,  Roles as Relationships, AgentContextRoles FROM [dbo].[Entity.AgentRelationshipIdCSV]
			WHERE EntityTypeId= 23 AND EntityBaseId = base.id 
			FOR XML RAW, ROOT('AgentRelationshipsForEntity')) AgentRelationshipsForEntity
	--now obsolete
	,'' as AgentRelationships
	-- addresses for owning org - will only be used if there is no address for the credential
	, (SELECT b.RowId, b.Id, b.EntityId, a.EntityUid, a.EntityTypeId, a.EntityBaseId, a.EntityBaseName, b.Id AS EntityAddressId, b.Name, b.IsPrimaryAddress, b.Address1, b.Address2, b.City, b.Region, b.SubRegion, b.PostOfficeBoxNumber, b.PostalCode, b.Country, b.Latitude, b.Longitude, b.Created, b.LastUpdated FROM dbo.Entity AS a 
		INNER JOIN dbo.[Entity.Address] AS b ON a.Id = b.EntityId 
		where a.[EntityUid] = base.OwningAgentUid
	FOR XML RAW, ROOT('OrgAddresses')) OrgAddresses

From #tempWorkTable work
Inner join PathwaySetSummary base on work.Id = base.Id
Inner join Entity e on base.RowId = e.EntityUid 
--Left Join Organization c on base.OwningAgentUid = c.RowId



WHERE RowNumber > @first_id
order by RowNumber 
go

grant execute on [PathwaySet.ElasticSearch] to public
go
/*
<HasPathways><row PathwayId="186" Pathway="UpSkill! SA Pathway- Skillbooster"/>
<row PathwayId="187" Pathway="UpSkill! SA Pathway- Certificate +"/></HasPathways>

187~UpSkill! SA Pathway- Certificate +|186~UpSkill! SA Pathway- Skillbooster

select        * from PathwaySetSummary

*/