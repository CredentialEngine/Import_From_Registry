use credfinder
go

use sandbox_credFinder 
go

--use staging_credFinder
--go

--use credfinder_prod
--go

/****** 
	Populate the LearningOpportunity properties totals table. 
	The first three steps are to initially generate the counts table. Additional properties can be added manaually as needed. 
	1. Use the following to generate the columns into _Dictionary (or create a customized version for this process)
		aspGenerateColumnDef @TableFilter = 'LearningOpportunity_Property%', @TypeFilter='view'

	2. Then generate a counts table
		truncate if needed
		truncate table [dbo].[Counts.LearningOpportunity_Property]

		SELECT [col_id] As Id, colName as Property, 0 as Total
		  --into [credFinder].[dbo].[Counts.LearningOpportunity_Property]
		FROM [credFinder].[dbo].[_Dictionary]
		where tableName = 'LearningOpportunity_PropertyTotals'
		order by 1
		OR - if already exists
		INSERT INTO [dbo].[Counts.LearningOpportunity_Property]
           ([Id]           ,[Property]           ,[Total])
    	SELECT [col_id] As Id, colName as Property, 0 as Total
		FROM [credFinder].[dbo].[_Dictionary]
		where tableName = 'LearningOpportunity_PropertyTotals'


	3. Next generate the Update statements 
		- use the select sql below
	4. Execute the update statements

******/

/*
SELECT TOP (1000) Id
      ,Property
      ,[Total]

	  --,'UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.' + [Property] + ' from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = ''' + [Property] + '''  ' as updateLine
	  
	  FROM [credFinder].[dbo].[Counts.LearningOpportunity_Property]
	  order by 1
  go

  */

/*
--reset
UPDATE [dbo].[Counts.LearningOpportunity_Property]
   SET [Total] = 0
go
*/
--UPDATE [dbo].[Counts.LearningOpportunity_Property] 
--   SET [Total] = b.Name
--from [Counts.LearningOpportunity_Property] a
----inner join 
--cross join LearningOpportunity_PropertyTotals b
-- WHERE a.Property = 'Name'
--GO


/*
USE [credFinder]
GO

DROP PROCEDURE [dbo].[Counts.LearningOpportunity_PropertyLearningOpportunity_Property_UpdateTotals]
GO



exec [Counts.LearningOpportunity_Property_UpdateTotals]
go

select * FROM [credFinder].[dbo].[Counts.LearningOpportunity_Property]
order by id

Modifications
22-01-11 mparsons - add LifeCycleStatusType
22-10-08 mparsons - add alternameName
*/
Alter PROCEDURE [Counts.LearningOpportunity_Property_UpdateTotals] 
AS
BEGIN
declare @OverallTotal decimal(9,2)
--reset first
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = 0
--

UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.Total from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'Total' 
select @OverallTotal= Total from [Counts.LearningOpportunity_Property] where Property='Total'
print 'over all total: ' + convert(varchar,@OverallTotal)
--=======================
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.Name from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'Name'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.Description from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'Description'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.SubjectWebpage from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'SubjectWebpage'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.CTID from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'CTID'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.LifeCycleStatusType from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'LifeCycleStatusType' 
--========
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasAvailabilityListing from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasAvailabilityListing'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasAvailableOnlineAt from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasAvailableOnlineAt'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasDateEffective from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasDateEffective'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasCodedNotation from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'CodedNotation'  
--
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasSCED from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'SCED'  
--
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasDeliveryTypeDescription from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasDeliveryTypeDescription'  

UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasCreditUnitType from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasCreditUnitType'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasCreditUnitValue from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasCreditUnitValue'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasCreditUnitMaxValue from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasCreditUnitMaxValue'  

UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasCreditUnitTypeDescription from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasCreditUnitTypeDescription'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasInstructionalPgms from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasInstructionalPgms'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasOccupations from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasOccupations'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasIndustries from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasIndustries'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasAudienceLevelType from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasAudienceLevelType'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasAudience from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasAudience'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasDeliveryMethodType from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasDeliveryMethodType'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasLearningMethodType from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasLearningMethodType'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasCompetencies from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasCompetencies'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasAddress from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasAddress'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasCosts from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasCosts'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasDuration from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasDuration'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasJurisdictions from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasJurisdictions'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasCommonCosts from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasCommonCosts'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasCommonConditions from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasCommonConditions'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasRequires from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasRequires'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasRecommends from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasRecommends'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasCorequisites from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasCorequisites'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasEntryConditions from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasEntryConditions'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasIsRequiredFor from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasIsRequiredFor'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasRecommendedFor from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasRecommendedFor'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasIsAdvancedStandingFor from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasIsAdvancedStandingFor'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasAdvancedStandingFrom from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasAdvancedStandingFrom'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasIsPreparationFor from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasIsPreparationFor'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasPreparationFrom from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasPreparationFrom'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasOwnedBy from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasOwnedBy'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasOfferedBy from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasOfferedBy'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasAccreditedBy from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasAccreditedBy'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasApprovedBy from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasApprovedBy'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasRecognizedBy from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasRecognizedBy'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasRegulatedBy from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasRegulatedBy'  
--==========
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasApprovedIN from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasApprovedIN'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasOfferedIN from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasOfferedIN'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasRecognizedIN from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasRecognizedIN'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasRegulatedIN from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasRegulatedIN'  
--==========
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasFinancialAssistance from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasFinancialAssistance'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasLanguages from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasLanguages'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasSubjects from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasSubjects'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasKeywords from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasKeywords'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasAlternateNames from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasAlternateNames'  
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET [Total] = b.HasAccreditedIn from [Counts.LearningOpportunity_Property] a cross join LearningOpportunity_PropertyTotals b  WHERE a.[Property] = 'HasAccreditedIn'  
--
UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET PercentOfOverallTotal = (Total * 100) / @OverallTotal

-- overall data points
declare @TotalDatapoints int
 Select @TotalDatapoints=Sum([Total])  FROM [dbo].[Counts.LearningOpportunity_Property]  
 where property <> 'Total' AND property <> 'Overall Data Points'
print '@TotalDatapoints: ' + convert(varchar, @TotalDatapoints)

UPDATE [dbo].[Counts.LearningOpportunity_Property]  SET  Total =  @TotalDatapoints where property = 'Overall Data Points'


END
GO

grant execute on [Counts.LearningOpportunity_Property_UpdateTotals] to public
go
/*

INSERT INTO [dbo].[Counts.LearningOpportunity_Property]
           ([Id]
           ,[Property]
           ,[Label]
           ,[Policy]
           ,[PropertyGroup]
           ,[Total]
           ,[PercentOfOverallTotal])
     VALUES
           (2
           ,'Overall Data Points'
           ,'Overall Data Points'
           ,'1. Required'
           ,''
           ,0
           ,0)
GO

*/