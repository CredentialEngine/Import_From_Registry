use credfinder
go

--use sandbox_credFinder 
--go

--use staging_credFinder
--go

--use credfinder_prod
--go

/****** 
	Populate the TransferIntermediary properties totals table. 
	FIRST CREATE THE VIEW: [TransferIntermediary_PropertyTotals]
	The first three steps are to initially generate the counts table. Additional properties can be added manaually as needed. 
	1. Use the following to generate the columns into _Dictionary (or create a customized version for this process)
		aspGenerateColumnDef @TableFilter = 'TransferIntermediary_Property%', @TypeFilter='view'

	2. Then generate a counts table
	===> preference is to use the create statement for any existing counts table, then use the insert *************************************
		drop/truncate if needed
		drop table [dbo].[Counts.TransferIntermediary_Property]

		SELECT [col_id] As Id, colName as Property, colName as Label, '1. Required' As Policy, '' as PropertyGroup, 0 as Total, 0 as PercentOfOverallTotal
		 into [dbo].[Counts.TransferIntermediary_Property]
		FROM [dbo].[_Dictionary]
		where tableName = 'TransferIntermediary_PropertyTotals'
		order by 1
		=======================================
		OR - if already exists (actually easier to just drop it, unless adding a few new ones)
		USE [credFinder]
		GO

		INSERT INTO [dbo].[Counts.TransferIntermediary_Property]
				   ([Id]
				   ,[Property]
				   ,[Label]
				   ,[Policy]
				   ,[PropertyGroup]
				   ,[Total]
				   ,[PercentOfOverallTotal])

    			SELECT [col_id] As Id, colName as Property, colName as Label, '1. Required' As Policy, '' as PropertyGroup, 0 as Total, 0 as PercentOfOverallTotal
				FROM [dbo].[_Dictionary]
				where tableName = 'TransferIntermediary_PropertyTotals'
				order by 1

			***EDIT THE COLUMN SIZE AS NEEDED - SEE BELOW ***
			USE [credFinder]
GO

			/****** Object:  Table [dbo].[Counts.SupportService_Property]    Script Date: 7/21/2023 3:59:53 PM ******/
			SET ANSI_NULLS ON
			GO

			SET QUOTED_IDENTIFIER ON
			GO

			CREATE TABLE [dbo].[Counts.SupportService_Property](
				[Id] [int] NOT NULL,
				[Property] [varchar](100) NOT NULL,
				[Label] [varchar](100) NOT NULL,
				[Policy] [varchar](100) NOT NULL,
				[PropertyGroup] [varchar](100) NOT NULL,
				[Total] [int] NOT NULL,
				[PercentOfOverallTotal] [decimal](5, 2) NOT NULL,
			 CONSTRAINT [PK_Counts.SupportService_Property] PRIMARY KEY CLUSTERED 
			(
				[Id] ASC
			)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
			) ON [PRIMARY]
			GO



			Now add the extra property: Overall Data Points
			- this could be added as a 'fake' property in the view like 'Total'

			3. Next generate the Update statements for the stored proc 
				- use the select sql below
				SELECT TOP (1000) Id
				  ,Property
				  ,[Total]

				  ,'UPDATE [dbo].[Counts.TransferIntermediary_Property]  SET [Total] = b.' + [Property] + ' from [Counts.TransferIntermediary_Property] a cross join TransferIntermediary_PropertyTotals b  WHERE a.[Property] = ''' + [Property] + '''  ' as updateLine
	  
				  FROM [dbo].[Counts.TransferIntermediary_Property]
				  order by 1
			  go
			4. Execute the update statements

******/

/*
--reset
UPDATE [dbo].[Counts.TransferIntermediary_Property]
   SET [Total] = 0
go
*/
--UPDATE [dbo].[Counts.TransferIntermediary_Property] 
--   SET [Total] = b.Name
--from [Counts.TransferIntermediary_Property] a
----inner join 
--cross join TransferIntermediary_PropertyTotals b
-- WHERE a.Property = 'Name'
--GO


/*
USE [credFinder]
GO

DROP PROCEDURE [dbo].[Counts.TransferIntermediary_PropertyTransferIntermediary_Property_UpdateTotals]
GO



exec [Counts.TransferIntermediary_Property_UpdateTotals]
go

select * FROM [dbo].[Counts.TransferIntermediary_Property]
order by id

Modifications
22-10-08 mparsons - added
*/
Create PROCEDURE [Counts.TransferIntermediary_Property_UpdateTotals] 
AS
BEGIN
declare @OverallTotal decimal(9,2)
--reset first
UPDATE [dbo].[Counts.TransferIntermediary_Property]  SET [Total] = 0
--
 
UPDATE [dbo].[Counts.TransferIntermediary_Property]  SET [Total] = b.Total from [Counts.TransferIntermediary_Property] a cross join TransferIntermediary_PropertyTotals b  WHERE a.[Property] = 'Total'  
--
select @OverallTotal= Total from [Counts.TransferIntermediary_Property] where Property='Total'
print 'over all total: ' + convert(varchar,@OverallTotal)
--============

UPDATE [dbo].[Counts.TransferIntermediary_Property]  SET [Total] = b.Name from [Counts.TransferIntermediary_Property] a cross join TransferIntermediary_PropertyTotals b  WHERE a.[Property] = 'Name'  
UPDATE [dbo].[Counts.TransferIntermediary_Property]  SET [Total] = b.Description from [Counts.TransferIntermediary_Property] a cross join TransferIntermediary_PropertyTotals b  WHERE a.[Property] = 'Description'  
UPDATE [dbo].[Counts.TransferIntermediary_Property]  SET [Total] = b.SubjectWebpage from [Counts.TransferIntermediary_Property] a cross join TransferIntermediary_PropertyTotals b  WHERE a.[Property] = 'SubjectWebpage'  
UPDATE [dbo].[Counts.TransferIntermediary_Property]  SET [Total] = b.CTID from [Counts.TransferIntermediary_Property] a cross join TransferIntermediary_PropertyTotals b  WHERE a.[Property] = 'CTID'  

--========
UPDATE [dbo].[Counts.TransferIntermediary_Property]  SET [Total] = b.HasAlternateNames from [Counts.TransferIntermediary_Property] a cross join TransferIntermediary_PropertyTotals b  WHERE a.[Property] = 'HasAlternateNames'  

UPDATE [dbo].[Counts.TransferIntermediary_Property]  SET [Total] = b.CodedNotation from [Counts.TransferIntermediary_Property] a cross join TransferIntermediary_PropertyTotals b  WHERE a.[Property] = 'CodedNotation'  
 
UPDATE [dbo].[Counts.TransferIntermediary_Property]  SET [Total] = b.CreditValue from [Counts.TransferIntermediary_Property] a cross join TransferIntermediary_PropertyTotals b  WHERE a.[Property] = 'CreditValue'  
--all will have IntermediaryFor
UPDATE [dbo].[Counts.TransferIntermediary_Property]  SET [Total] = b.IntermediaryFor from [Counts.TransferIntermediary_Property] a cross join TransferIntermediary_PropertyTotals b  WHERE a.[Property] = 'IntermediaryFor'  

UPDATE [dbo].[Counts.TransferIntermediary_Property]  SET [Total] = b.HasSubjects from [Counts.TransferIntermediary_Property] a cross join TransferIntermediary_PropertyTotals b  WHERE a.[Property] = 'HasSubjects'  
UPDATE [dbo].[Counts.TransferIntermediary_Property]  SET [Total] = b.OwnedBy from [Counts.TransferIntermediary_Property] a cross join TransferIntermediary_PropertyTotals b  WHERE a.[Property] = 'OwnedBy'  
UPDATE [dbo].[Counts.TransferIntermediary_Property]  SET [Total] = b.HasRequires from [Counts.TransferIntermediary_Property] a cross join TransferIntermediary_PropertyTotals b  WHERE a.[Property] = 'HasRequires'  

--
UPDATE [dbo].[Counts.TransferIntermediary_Property]  SET PercentOfOverallTotal = (Total * 100) / @OverallTotal

-- overall data points
declare @TotalDatapoints int
 Select @TotalDatapoints=Sum([Total])  FROM [dbo].[Counts.TransferIntermediary_Property]  
 where property <> 'Total' AND property <> 'Overall Data Points'
print '@TotalDatapoints: ' + convert(varchar, @TotalDatapoints)

UPDATE [dbo].[Counts.TransferIntermediary_Property]  SET  Total =  @TotalDatapoints where property = 'Overall Data Points'


END
GO
grant execute on [Counts.TransferIntermediary_Property_UpdateTotals] to public
go

/*

INSERT INTO [dbo].[Counts.TransferIntermediary_Property]
           ([Id]
           ,[Property]
           ,[Label]
           ,[Policy]
           ,[PropertyGroup]
           ,[Total]
           ,[PercentOfOverallTotal])
     VALUES
           (2
           ,'Overall Data Points'
           ,'Overall Data Points'
           ,'1. Required'
           ,''
           ,0
           ,0)
GO

*/