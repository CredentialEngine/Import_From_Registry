--	remove duplicate Collection.CollectionMember
SELECT 
a.id,
a.[CollectionId]      
	  ,a.[EntityTypeId]
      ,a.[ProxyFor]

  FROM [sandbox_credFinder].[dbo].[Collection.CollectionMember] a
Inner join (
SELECT a.[CollectionId]      
	  ,a.[EntityTypeId]
      ,a.[ProxyFor]
	  ,max(a.id	) as lastId, min(a.id) as firstId
	  ,COUNT(*) as ttl
  FROM [sandbox_credFinder].[dbo].[Collection.CollectionMember] a
 -- where b.BaseId = 45094
 group by 
 a.[CollectionId]      
	  ,a.[EntityTypeId]
      ,a.[ProxyFor]
	  having count(*) > 1
 -- order by 1,2,3
) dups on a.ProxyFor = dups.ProxyFor
where a.Id = dups.lastId

order by 1,2,3
go

delete a
--	select a.*
	 from [dbo].[Collection.CollectionMember] a
inner join (
SELECT a.[CollectionId]      
	  ,a.[EntityTypeId]
      ,a.[ProxyFor]
	  ,max(a.id	) as lastId, min(a.id) as firstId
	  ,COUNT(*) as ttl
  FROM [sandbox_credFinder].[dbo].[Collection.CollectionMember] a
 -- where b.BaseId = 45094
 group by 
 a.[CollectionId]      
	  ,a.[EntityTypeId]
      ,a.[ProxyFor]
	  having count(*) > 1
 -- order by 1,2,3
) dups on a.ProxyFor = dups.ProxyFor
where a.Id = dups.lastId
