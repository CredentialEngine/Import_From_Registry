USE [credFinder]
GO
use sandbox_credFinder
go

-- Codes.EntityTypes-update 17 to be competency

UPDATE [dbo].[Codes.EntityTypes]
   SET [Title] = 'Competency'
      ,[Label] = 'Competency'
      ,[Description] = 'Competency'
      ,[IsActive] = 1
      ,[SchemaName] = 'Competency'
      ,[IsTopLevelEntity] = 1
      ,[Totals] = 0

 WHERE Id=17
GO


