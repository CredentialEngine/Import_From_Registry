/****** Script for SelectTopNRows command from SSMS 
SELECT TOP (1000) [Id]
      ,[Title],[Label]
      ,[Description]
      ,[IsActive]
      ,[SchemaName]
      ,[Created]
      ,[Totals]
      ,[SortOrder]
  FROM [sandbox_credFinder].[dbo].[Codes.EntityTypes]

  go
 ******/

use credFinder
go

--USE [sandbox_credFinder]
--GO


INSERT INTO [dbo].[Codes.EntityTypes]
           ([Id]           ,[Title],[Label]
           ,[Description]
           ,[IsActive]           ,[SchemaName]           ,[Created]
           ,[Totals]           ,[SortOrder])
     VALUES
           (38,'SupportService','Support Service'
           ,'Resources and assistance that help people overcome barriers to succeed in their education and career goals.'
           ,1           ,'ceterms:SupportService'           ,GETDATE()           
		   ,0           ,50)
GO


use ctdlEditor
go
--use sandbox_ctdlEditor
--go

INSERT INTO [dbo].[Codes.EntityType]
           ([Id]           ,[Title]
           ,[Description]
           ,[IsActive]          ,SchemaUrl         ,[Created]           
		   ,[Totals],    [IsTopLevelEntity]     )
     VALUES
           (38,'Support Service'
           ,'Resources and assistance that help people overcome barriers to succeed in their education and career goals.'
           ,1           ,'ceterms:SupportService'           ,GETDATE()     
		   ,0, 1)

