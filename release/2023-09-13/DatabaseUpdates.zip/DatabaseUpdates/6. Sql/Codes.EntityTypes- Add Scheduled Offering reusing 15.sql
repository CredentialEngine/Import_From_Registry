
USE credFinder
GO

--use staging_credFinder
--go

use sandbox_credFinder
go
UPDATE [dbo].[Codes.EntityTypes]
   SET [Title] = 'Scheduled Offering'
      ,[Description] = 'Offering of a Learning Opportunity or Assessment with a schedule associated with a specified location or modality.'
      ,[IsActive] = 1
      ,[SchemaName] ='ceterms:ScheduledOffering'
      ,[Created] = GETDATE()
      ,[IsTopLevelEntity] = 1
      ,[Label] = 'Scheduled Offering'
 WHERE [Id]=15
GO



