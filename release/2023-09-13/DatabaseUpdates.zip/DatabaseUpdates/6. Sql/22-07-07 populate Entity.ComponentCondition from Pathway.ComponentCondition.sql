USE [sandbox_credfinder]
GO

-- 22-07-07 populate Entity.ComponentCondition from Pathway.ComponentCondition

-- ===================================================
--need to chg all EntityTypeId for pathway.ComponentCondtion to a temp diff thing
-- ===================================================

-- ===================================================
-- = create code 70
-- ===================================================


INSERT INTO [dbo].[Codes.EntityTypes]
           ([Id]
           ,[Title]
           ,[Label]
           ,[Description]
           ,[IsActive]
           ,[SchemaName]
           ,[Created]
           ,[Totals]
           ,[SortOrder]
           ,[IsTopLevelEntity])

SELECT 70
	,[Title] + ' copy'
	,[Label]
	,[Description] + ' copy'
	,[IsActive]
	,[SchemaName] + ' copy'
	,[Created]
	,[Totals]
	,[SortOrder]
	,[IsTopLevelEntity]
  FROM [dbo].[Codes.EntityTypes]
  where id = 25
GO
--
-- ===================================================
-- = chg trigger
-- ===================================================

/****** Object:  Trigger [dbo].[trgPathwayComponentConditionAfterInsert]    Script Date: 7/7/2022 6:15:07 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER TRIGGER [dbo].[trgPathwayComponentConditionAfterInsert] ON  [dbo].[Pathway.ComponentCondition]
FOR INSERT
AS  
    INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
					 ,EntityBaseId, EntityBaseName)
    SELECT RowId,70, getdate(), Id, Name
    FROM inserted;
GO

--
-- ===================================================
-- = change EntityTypeId on Entity from 25 to 70
-- ===================================================

UPDATE [dbo].[Entity]
   SET [EntityTypeId] = 70
 WHERE [EntityTypeId]=25
GO

-- ===================================================
-- = now transfer
-- ===================================================
/*
select * from [Entity.ComponentCondition]

select * from entity where entitytypeid = 25

delete  entity where entitytypeid = 25

delete  entity_cache where entitytypeid = 25

truncate table [Entity.ComponentCondition]
*/

INSERT INTO [dbo].[Entity.ComponentCondition]
           ([RowId]
           ,[EntityId]
           ,[Name]
           ,[Description]
           ,[RequiredNumber]
           ,[HasConstraint]
           ,[LogicalOperator]
           ,[PathwayCTID]
           ,[Created]
           ,[LastUpdated]
           ,[SourceRowId]
           ,[ConditionProperties])

SELECT newid() as RowId
--what if we use the same RowId as [Pathway.ComponentCondition]
--or maybe need a temp property to related the old and new?
, c.Id as PathwayComponentEntityId
    --  ,a.[ParentComponentId]
      ,a.[Name]
      ,a.[Description]
      ,a.[RequiredNumber]
	  ,null		as [HasConstraint]
	   ,null		as [LogicalOperator]
      ,a.[PathwayCTID]
      ,a.[Created]
      ,a.[LastUpdated]
	  ,a.RowId
	  ,null		as [ConditionProperties]

  FROM [dbo].[Pathway.ComponentCondition] a
  inner join [PathwayComponent] b  on a.ParentComponentId = b.id 
  inner join entity c on b.RowId = c.EntityUid

GO

--Need to get the targetComponents referenced by a [Pathway.ComponentCondition]
--might have been better to reuse the entity related to [Pathway.ComponentCondition]

INSERT INTO [dbo].[Entity.HasPathwayComponent]
           ([EntityId]
           ,[PathwayComponentId]
           ,[ComponentRelationshipTypeId]
           ,[Created] )

SELECT eccEntity.Id as newEntityid
      --,a.[EntityId] as pccEntityId
      ,a.[PathwayComponentId]
      ,a.[ComponentRelationshipTypeId]
      ,a.[Created]
     
  FROM [dbo].[Entity.HasPathwayComponent] a
  inner join entity b on a.EntityId = b.id 
  inner join [Entity.ComponentCondition] c on b.EntityUid = c.SourceRowId
  inner join entity eccEntity on c.RowId = eccEntity.EntityUid 

GO


-- test results
SELECT a.[Id]
      ,a.[RowId]
      ,a.[EntityId]
      ,a.[Name]
      ,a.[Description]
      ,a.[RequiredNumber]
      ,a.[HasConstraint]
      ,a.[LogicalOperator]
      ,a.[PathwayCTID]
	  ,c.PathwayComponentId
      --,a.[Created]
      --,a.[LastUpdated]
      ,a.[SourceRowId]
  FROM [dbo].[Entity.ComponentCondition] a
  inner join entity b on a.RowId = b.EntityUid
  inner join [Entity.HasPathwayComponent] c on b.Id = c.EntityId

GO



SELECT a.[Id]
      ,a.[EntityId], b.EntityTypeId
      ,a.[PathwayComponentId]
      ,a.[ComponentRelationshipTypeId]
      ,a.[Created]
  FROM [dbo].[Entity.HasPathwayComponent] a
  inner join entity b on a.entityId = b.Id 

GO






