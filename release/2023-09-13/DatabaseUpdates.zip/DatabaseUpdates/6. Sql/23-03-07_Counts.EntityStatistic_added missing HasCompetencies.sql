
USE [credFinder]
GO

--USE [credFinder_prod]
--GO

--use staging_credFinder
--go

--use sandbox_credFinder
--go

INSERT [dbo].[Counts.EntityStatistic] ([Id], [EntityTypeId], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [Totals], [Created]) 
VALUES (160, 3, 60, N'Has Competencies (any type)', NULL, 25, 1, N'asmtReport:HasCompetencies', 0, getdate())
GO

INSERT [dbo].[Counts.EntityStatistic] ([Id], [EntityTypeId], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [Totals], [Created]) 
VALUES (161, 7, 61, N'Has Competencies (any type)', NULL, 25, 1, N'loppReport:HasCompetencies', 0, getdate())
GO




