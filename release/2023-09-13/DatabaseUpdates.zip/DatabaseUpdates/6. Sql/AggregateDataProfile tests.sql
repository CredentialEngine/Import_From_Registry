
SELECT TOP (1000) a.[Id] as eadpId
      ,a.[EntityId]
     -- ,a.[RowId]
     -- ,a.[Name]
      ,a.[Description] as eadpDescription
	  ,d.Name as dspName, d.EntityStateId as dspEntityStateId, d.Description as dspDesc, d.CTID as dspCTID
	  ,d.LastUpdated as dspLastUpdated, d.Created as dspCreated 
	  , e.Name as Organization 
	  ,l.Name as Lopp, l.Id as loppId
      ,a.[Created] as edapCreated     ,a.[LastUpdated] as eadpLastUpdated
  FROM [dbo].[Entity.AggregateDataProfile] a
  inner join Entity loppEntity on a.EntityId = loppEntity.Id 
  Inner join LearningOpportunity l on loppEntity.EntityUid = l.RowId
  inner join Entity b on a.RowId = b.EntityUid
  inner join [Entity.DataSetProfile] c on b.Id = c.EntityId
  inner join DataSetProfile d on c.DataSetProfileId = d.id 
  left join Organization e on d.DataProviderUID = e.RowId

  where l.id = 9062
  order by l.Name
  go

  Select a.Id as dspId, a.CTID
  ,a.EntityStateId
  ,a.Description
  ,a.DataProviderUID, a.Created, a.LastUpdated
  ,c.LearningOpportunityId, d.EntityStateId as loppEntityStateId, d.CTID as loppCTID, d.Name as loppName
  from DataSetProfile a
  inner join Entity b on a.RowId = b.EntityUid
  inner join [Entity.LearningOpportunity] c on b.Id = c.EntityId
  inner join LearningOpportunity d on c.LearningOpportunityId = d.id 
  where 
 -- a.Created < '2023-01-01' and a.LastUpdated > '2023-01-01'
  
  c.LearningOpportunityId = 9062
  go
  /*
  Update DataSetProfile
  set EntityStateId = 3
  where id in (3381)

delete from DataSetProfile
  where entitystateId = 0


  select * from DataSetProfile where ctid = 'ce-acb03025-59a3-4ce6-b52e-29eba4866643'

    select * from DataSetProfile where id > 5735



  select ctid from DataSetProfile 
  group by CTID having count(*) > 1
  */

  SELECT TOP (1000) a.[Id]
      ,a.[EntityId], b.entitytypeId
      ,a.[DataSetProfileId]
	  ,d.entityTypeId as loppEntityTypeId, d.entityBaseId
      ,a.[Created]
  FROM [credFinder_prod].[dbo].[Entity.DataSetProfile] a
  inner join entity b on a.entityid = b.id 
  inner join [Entity.AggregateDataProfile] c on b.entityuid = c.rowid
  inner join entity d on c.entityId = d.Id

  where a.[DataSetProfileId] = 5869

  order by a.id desc 