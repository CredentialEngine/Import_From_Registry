--	reorder credential columns - OPTIONAL

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.Credential
	DROP CONSTRAINT DF_Credential_RowId
GO
ALTER TABLE dbo.Credential
	DROP CONSTRAINT DF_Credential_Created
GO
ALTER TABLE dbo.Credential
	DROP CONSTRAINT DF_Credential_LastUpdated
GO
CREATE TABLE dbo.Tmp_Credential
	(
	Id int NOT NULL IDENTITY (1, 1),
	RowId uniqueidentifier NOT NULL,
	EntityStateId int NULL,
	Name nvarchar(800) NOT NULL,
	Description nvarchar(MAX) NULL,
	CredentialTypeId int NULL,
	CTID varchar(50) NULL,
	SubjectWebpage varchar(500) NULL,
	CredentialStatusTypeId int NOT NULL,
	OwningAgentUid uniqueidentifier NULL,
	ImageUrl varchar(500) NULL,
	Created datetime NULL,
	LastUpdated datetime NULL,
	CredentialRegistryId varchar(100) NULL,
	AlternateName varchar(500) NULL,
	AvailableOnlineAt varchar(500) NULL,
	AvailabilityListing nvarchar(500) NULL,
	EffectiveDate datetime NULL,
	ExpirationDate datetime NULL,
	CredentialId nvarchar(1500) NULL,
	CodedNotation nvarchar(100) NULL,
	ProcessStandards nvarchar(500) NULL,
	ProcessStandardsDescription nvarchar(MAX) NULL,
	CopyrightHolder uniqueidentifier NULL,
	InLanguageId int NULL,
	IsNonCredit bit NULL,
	Version nvarchar(100) NULL,
	LatestVersionUrl varchar(500) NULL,
	ReplacesVersionUrl varchar(500) NULL,
	NextVersion varchar(500) NULL,
	Supersedes varchar(500) NULL,
	SupersededBy varchar(500) NULL,
	ISICV4 varchar(15) NULL,
	JsonProperties nvarchar(MAX) NULL,
	PrimaryOrganizationUid uniqueidentifier NULL
	)  ON [PRIMARY]
	 TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE dbo.Tmp_Credential SET (LOCK_ESCALATION = TABLE)
GO
DECLARE @v sql_variant 
SET @v = N'1-pending;2-Reference;3-Full'
EXECUTE sp_addextendedproperty N'MS_Description', @v, N'SCHEMA', N'dbo', N'TABLE', N'Tmp_Credential', N'COLUMN', N'EntityStateId'
GO
ALTER TABLE dbo.Tmp_Credential ADD CONSTRAINT
	DF_Credential_RowId DEFAULT (newid()) FOR RowId
GO
ALTER TABLE dbo.Tmp_Credential ADD CONSTRAINT
	DF_Credential_Created DEFAULT (getdate()) FOR Created
GO
ALTER TABLE dbo.Tmp_Credential ADD CONSTRAINT
	DF_Credential_LastUpdated DEFAULT (getdate()) FOR LastUpdated
GO
SET IDENTITY_INSERT dbo.Tmp_Credential ON
GO
IF EXISTS(SELECT * FROM dbo.Credential)
	 EXEC('INSERT INTO dbo.Tmp_Credential (Id, RowId, EntityStateId, Name, Description, CredentialTypeId, CTID, SubjectWebpage, CredentialStatusTypeId, OwningAgentUid, ImageUrl, Created, LastUpdated, CredentialRegistryId, AlternateName, AvailableOnlineAt, AvailabilityListing, EffectiveDate, ExpirationDate, CredentialId, CodedNotation, ProcessStandards, ProcessStandardsDescription, CopyrightHolder, InLanguageId, IsNonCredit, Version, LatestVersionUrl, ReplacesVersionUrl, NextVersion, Supersedes, SupersededBy, ISICV4, JsonProperties, PrimaryOrganizationUid)
		SELECT Id, RowId, EntityStateId, Name, Description, CredentialTypeId, CTID, SubjectWebpage, CredentialStatusTypeId, OwningAgentUid, ImageUrl, Created, LastUpdated, CredentialRegistryId, AlternateName, AvailableOnlineAt, AvailabilityListing, EffectiveDate, ExpirationDate, CredentialId, CodedNotation, ProcessStandards, ProcessStandardsDescription, CopyrightHolder, InLanguageId, IsNonCredit, Version, LatestVersionUrl, ReplacesVersionUrl, NextVersion, Supersedes, SupersededBy, ISICV4, JsonProperties, PrimaryOrganizationUid FROM dbo.Credential WITH (HOLDLOCK TABLOCKX)')
GO
SET IDENTITY_INSERT dbo.Tmp_Credential OFF
GO
ALTER TABLE dbo.[Entity.Credential]
	DROP CONSTRAINT [FK_Entity.Credential_Credential]
GO
ALTER TABLE dbo.[Credential.SummaryCache]
	DROP CONSTRAINT [FK_Credential.SummaryCache_Credential1]
GO
DROP TABLE dbo.Credential
GO
EXECUTE sp_rename N'dbo.Tmp_Credential', N'Credential', 'OBJECT' 
GO
ALTER TABLE dbo.Credential ADD CONSTRAINT
	PK_Credential PRIMARY KEY CLUSTERED 
	(
	Id
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
CREATE NONCLUSTERED INDEX IX_Credential_Webpage ON dbo.Credential
	(
	SubjectWebpage
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IX_Credential_OwningAgentUid ON dbo.Credential
	(
	OwningAgentUid
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IX_Credential_EntityStateId ON dbo.Credential
	(
	EntityStateId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IX_Credential_RowIdEntityStateId ON dbo.Credential
	(
	RowId,
	EntityStateId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX IX_Credential_EntityStateId_Many ON dbo.Credential
	(
	EntityStateId
	) INCLUDE (Id, RowId, Name, Description, CredentialTypeId, CredentialRegistryId, AlternateName, CTID, AvailableOnlineAt, AvailabilityListing, OwningAgentUid, Version, SubjectWebpage, LatestVersionUrl, ReplacesVersionUrl, LastUpdated, ImageUrl) 
 WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [IDX_Credential.EntityStateId] ON dbo.Credential
	(
	EntityStateId
	) INCLUDE (Id, RowId, Name, Description, CredentialTypeId, CredentialRegistryId, AlternateName, CTID, AvailableOnlineAt, AvailabilityListing, OwningAgentUid, Version, SubjectWebpage, LatestVersionUrl, ReplacesVersionUrl, ImageUrl, LastUpdated) 
 WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE UNIQUE NONCLUSTERED INDEX IX_Credential_CTID ON dbo.Credential
	(
	CTID
	) WHERE ([CTID] IS NOT NULL)
 WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
CREATE UNIQUE NONCLUSTERED INDEX IX_Credential_RowId ON dbo.Credential
	(
	RowId
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
Create TRIGGER trgCredentialAfterInsert ON   dbo.Credential
FOR INSERT
AS  
Begin
    INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
					 ,EntityBaseId, EntityBaseName)
    SELECT RowId,1, getdate(), Id, Name
    FROM inserted;
End
GO
-- =============================================
-- Create date: 16-09-20
-- Description:	
--	Deletes are typically triggered from entity frameworks code. 
--	Tables like Entity are not removed via Referencial Integrity. 
--	The latter will be deleted, and then the Credential
-- NOTE: currently credentials are virtual deletes for now, so this would normally not be invoked
-- =============================================


Create TRIGGER dbo.[trgCredentialBeforeDelete]
ON dbo.Credential
INSTEAD OF DELETE
AS
BEGIN

     -- Some code you want to do before delete
		DELETE a	
			FROM [dbo].[Entity] a
			inner join Deleted d on a.EntityUid = d.RowId

			--also Jurisdictions
			--added to Entity, now what about GeoCoordinates

		 -- do the delete
     DELETE Credential
     FROM DELETED D
     INNER JOIN dbo.Credential T ON T.Id = D.Id
END
GO
-- =============================================
-- Create date: 2017-03-12
-- Keep the Entity.EntityBaseName in sync with actual name
-- =============================================
Create TRIGGER [dbo].[trgCredentialAfterUpdate] ON  dbo.Credential
   AFTER UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


UPDATE [dbo].[Entity]
    SET	[EntityBaseName] = b.Name,
				LastUpdated = getdate()
	 from [Entity] a
	 inner join inserted b on a.EntityUid = b.RowId

END
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Credential.SummaryCache] ADD CONSTRAINT
	[FK_Credential.SummaryCache_Credential1] FOREIGN KEY
	(
	CredentialId
	) REFERENCES dbo.Credential
	(
	Id
	) ON UPDATE  CASCADE 
	 ON DELETE  CASCADE 
	
GO
ALTER TABLE dbo.[Credential.SummaryCache] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Entity.Credential] ADD CONSTRAINT
	[FK_Entity.Credential_Credential] FOREIGN KEY
	(
	CredentialId
	) REFERENCES dbo.Credential
	(
	Id
	) ON UPDATE  CASCADE 
	 ON DELETE  CASCADE 
	
GO
ALTER TABLE dbo.[Entity.Credential] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT