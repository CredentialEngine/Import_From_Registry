use credfinder
go

--use sandbox_credFinder
--go

/*


- add filter for organization class
*/



INSERT INTO [dbo].[Codes.EntityTypes]
           ([Id],[Title],[Label], [Description],[IsActive],SchemaName,[Created],[Totals],SortOrder,[IsTopLevelEntity])
     VALUES
           (29,'Concept','Concept','Term in a controlled vocabulary.',1,'ceasn:Concept',GETDATE(), 0,25,0)
GO
INSERT INTO [dbo].[Codes.EntityTypes]
           ([Id],[Title],[Label], [Description],[IsActive],SchemaName,[Created],[Totals],SortOrder,[IsTopLevelEntity])
     VALUES
           (30,'ProgressionLevel','Progression Level','Identifiable point along a developmental progression of competence, achievement or temporal position.',1,'asn:ProgressionLevel',GETDATE(), 0,25, 0)
GO