USE [sandbox_credFinder]
GO

--update entity_cache for inactive resources

UPDATE [dbo].[Entity_Cache]
   SET [IsActive] = 0
--	Select a.CTID, b.Name, b.description
from [Entity_Cache] a 
inner join Credential b on a.ctid = b.ctid 
inner join [Codes.PropertyValue] c on b.CredentialStatusTypeId = c.Id
 WHERE c.Title = 'Deprecated'

GO

UPDATE [dbo].[Entity_Cache]
   SET [IsActive] = 0
--	Select a.CTID, b.Name, b.description
from [Entity_Cache] a 
inner join Organization b on a.ctid = b.ctid 
inner join [Codes.PropertyValue] c on b.LifeCycleStatusTypeId = c.Id
 WHERE c.Title = 'Deprecated'

GO

UPDATE [dbo].[Entity_Cache]
   SET [IsActive] = 0
--	Select a.CTID, b.Name, b.description
from [Entity_Cache] a 
inner join LearningOpportunity b on a.ctid = b.ctid 
inner join [Codes.PropertyValue] c on b.LifeCycleStatusTypeId = c.Id
 WHERE c.Title = 'Deprecated'

GO

UPDATE [dbo].[Entity_Cache]
   SET [IsActive] = 0
--	Select a.CTID, b.Name, b.description
from [Entity_Cache] a 
inner join Assessment b on a.ctid = b.ctid 
inner join [Codes.PropertyValue] c on b.LifeCycleStatusTypeId = c.Id
 WHERE c.Title = 'Deprecated'

GO


UPDATE [dbo].[Entity_Cache]
   SET [IsActive] = 0
--	Select a.CTID, b.Name, b.description
from [Entity_Cache] a 
inner join Collection b on a.ctid = b.ctid 
inner join [Codes.PropertyValue] c on b.LifeCycleStatusTypeId = c.Id
 WHERE c.Title = 'Deprecated'

GO