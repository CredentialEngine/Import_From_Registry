/****** Default lifecycleCycleId  ******/
update [dbo].[TransferIntermediary]
set LifecycleStatusTypeId = activeLifeCycle.Id

from (
select b.id from [Codes.PropertyValue] b 
where CategoryId = 84 and title = 'Active'
) activeLifeCycle

