--22-11-10 Counts.EntityStatistic-Add IsPartOfCollection

USE [sandbox_credFinder]
GO

INSERT INTO [dbo].[Counts.EntityStatistic]
           ([Id]
           ,[EntityTypeId]           ,[CategoryId]           ,[Title]           ,[Description]
           ,[SortOrder]           ,[IsActive]           ,[SchemaName]           ,[Totals]           ,[Created])
     VALUES
           (140 ,1 ,58,'Is Part of a Collection'
           ,'Resource is part of one or more collections'
           ,25,1
           ,'credReport:IsPartOfCollection'
           ,0,GETDATE())
GO
INSERT INTO [dbo].[Counts.EntityStatistic]
           ([Id]
           ,[EntityTypeId]           ,[CategoryId]           ,[Title]           ,[Description]
           ,[SortOrder]           ,[IsActive]           ,[SchemaName]           ,[Totals]           ,[Created])
     VALUES
           (141 ,2 ,59,'Is Part of a Collection'
           ,'Resource is part of one or more collections'
           ,25,1
           ,'orgReport:IsPartOfCollection'
           ,0,GETDATE())
GO


INSERT INTO [dbo].[Counts.EntityStatistic]
           ([Id]
           ,[EntityTypeId]           ,[CategoryId]           ,[Title]           ,[Description]
           ,[SortOrder]           ,[IsActive]           ,[SchemaName]           ,[Totals]           ,[Created])
     VALUES
           (142 ,3 ,60,'Is Part of a Collection'
           ,'Resource is part of one or more collections'
           ,25,1
           ,'asmtReport:IsPartOfCollection'
           ,0,GETDATE())
GO


INSERT INTO [dbo].[Counts.EntityStatistic]
           ([Id]
           ,[EntityTypeId]           ,[CategoryId]           ,[Title]           ,[Description]
           ,[SortOrder]           ,[IsActive]           ,[SchemaName]           ,[Totals]           ,[Created])
     VALUES
           (143 ,7 ,61,'Is Part of a Collection'
           ,'Resource is part of one or more collections'
           ,25,1
           ,'loppReport:IsPartOfCollection'
           ,0,GETDATE())
GO

