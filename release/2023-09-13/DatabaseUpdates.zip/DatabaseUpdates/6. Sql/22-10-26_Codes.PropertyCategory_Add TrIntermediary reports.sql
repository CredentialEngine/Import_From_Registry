USE [credFinder]
GO

use sandbox_credFinder
go

--use staging_credFinder
--go


INSERT INTO [dbo].[Codes.PropertyCategory]
           ([Id]
           ,[Title]
           ,[Description]
           ,[SortOrder]
           ,[IsActive]
           ,[SchemaName]
           ,[SchemaUrl]
           ,[Created]
           ,[CodeName]
           ,[InterfaceType]
           ,[PropertyTableName])
     VALUES
           (72
           ,'Transfer Intermediary Report Item'
           ,'List of Transfer Intermediary related report items'
           ,10
           ,1
           ,'TransferIntermediaryReport'
           ,NULL
           ,Getdate()
           ,'TransferIntermediaryReports'
           ,NULL
           ,NULL
		   )
GO

