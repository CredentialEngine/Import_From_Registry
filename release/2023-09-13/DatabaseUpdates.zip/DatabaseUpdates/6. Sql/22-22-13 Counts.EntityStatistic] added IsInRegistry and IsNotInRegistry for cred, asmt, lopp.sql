USE [sandbox_credFinder]
GO

use credFinder
go


-- 22-22-13 Counts.EntityStatistic] added IsInRegistry and IsNotInRegistry for cred, asmt, lopp
INSERT INTO [dbo].[Counts.EntityStatistic]
           ([Id]           ,[EntityTypeId]           ,[CategoryId]           ,[Title]           ,[Description]
           ,[SortOrder]           ,[IsActive]           ,[SchemaName]           ,[Totals]           ,[Created])
     VALUES
           (150, 1, 58,'Is a Registered Credential'
           ,'' ,10 ,1 ,'credReport:IsInRegistry' ,0 ,GETDATE())
GO
-- 
INSERT INTO [dbo].[Counts.EntityStatistic]
           ([Id]           ,[EntityTypeId]           ,[CategoryId]           ,[Title]           ,[Description]
           ,[SortOrder]           ,[IsActive]           ,[SchemaName]           ,[Totals]           ,[Created])
     VALUES
           (151, 1, 58,'Is a Reference Credential'
           ,'' ,12 ,1 ,'credReport:IsNotInRegistry' ,0 ,GETDATE())
GO
-- 
INSERT INTO [dbo].[Counts.EntityStatistic]
           ([Id]           ,[EntityTypeId]           ,[CategoryId]           ,[Title]           ,[Description]
           ,[SortOrder]           ,[IsActive]           ,[SchemaName]           ,[Totals]           ,[Created])
     VALUES
           (152, 3, 60,'Is a Registered Assessment'
           ,'' ,10 ,1 ,'asmtReport:IsInRegistry' ,0 ,GETDATE())
GO
-- 
INSERT INTO [dbo].[Counts.EntityStatistic]
           ([Id]           ,[EntityTypeId]           ,[CategoryId]           ,[Title]           ,[Description]
           ,[SortOrder]           ,[IsActive]           ,[SchemaName]           ,[Totals]           ,[Created])
     VALUES
           (153, 3, 60,'Is a Reference Assessment'
           ,'' ,12 ,1 ,'asmtReport:IsNotInRegistry' ,0 ,GETDATE())
GO
-- 
INSERT INTO [dbo].[Counts.EntityStatistic]
           ([Id]           ,[EntityTypeId]           ,[CategoryId]           ,[Title]           ,[Description]
           ,[SortOrder]           ,[IsActive]           ,[SchemaName]           ,[Totals]           ,[Created])
     VALUES
           (154, 7, 61,'Is a Registered Learning Opportunity'
           ,'' ,10 ,1 ,'loppReport:IsInRegistry' ,0 ,GETDATE())
GO
-- 
INSERT INTO [dbo].[Counts.EntityStatistic]
           ([Id]           ,[EntityTypeId]           ,[CategoryId]           ,[Title]           ,[Description]
           ,[SortOrder]           ,[IsActive]           ,[SchemaName]           ,[Totals]           ,[Created])
     VALUES
           (155, 7, 61,'Is a Reference Learning Opportunity'
           ,'' ,12 ,1 ,'loppReport:IsNotInRegistry' ,0 ,GETDATE())
GO
-- 
