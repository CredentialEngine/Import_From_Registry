USE credfinder
GO
--	23-03-20 VerificationServiceProfile Conversion steps
--	Codes.EntityTypess- Set 41-VerificationServiceProfile to top level and convert data
--	Create a VSP copy for existing e.vs
--	Then can convert existing to 41



use sandbox_credFinder
go

--use staging_credFinder
--go

UPDATE [dbo].[Codes.EntityTypes]
   SET [Title] = 'Verification Service Profile'
   ,Description = 'Entity describing the means by which someone can verify whether a credential has been attained.'
      ,[IsTopLevelEntity] = 1
 WHERE [Id]=41
GO

--=========== create new entityTypeId for Entity.VS

select * from  [Codes.EntityTypes]


INSERT INTO [dbo].[Codes.EntityTypes]
           ([Id]
           ,[Title]
           ,[Label]
           ,[Description]
           ,[IsActive]
           ,[SchemaName]
           ,[Created]
           ,[Totals]
           ,[SortOrder]
           ,[IsTopLevelEntity]
		   )

SELECT 99
      ,[Title] + '-COPY'
	  ,[Label] + '-COPY'
      ,[Description] + '-COPY'
      ,[IsActive]
      ,SchemaName + '-COPY'
      ,getdate() as created
      ,[Totals]
	  ,[SortOrder]
      ,0
	  
  FROM [dbo].[Codes.EntityTypes]
   WHERE [Id]=41
GO

--============================================
-- Change entity.VS entityTypeId to 99


UPDATE [dbo].[Entity]
   SET [EntityTypeId] = 99
		--change date????
    --  ,[LastUpdated] = GETDATE()
 WHERE [EntityTypeId]=41
GO

--============================================
-- Offered by will soon be required, set any records missing it to the owning org.
UPDATE [dbo].[Entity.VerificationProfile]
   SET [OfferedByAgentUid] = b.EntityUid
from [Entity.VerificationProfile] a
inner join entity b on a.entityId = b.Id
 WHERE [OfferedByAgentUid] is null 
GO


--============================================
-- convert entity.VS to VSP

select * from [VerificationServiceProfile]



INSERT INTO [dbo].[VerificationServiceProfile]
           ([RowId]
           ,[CTID]
           ,[Description]
           ,[DateEffective]
           ,[HolderMustAuthorize]
           ,[SubjectWebpage]
           ,[VerificationDirectory]
           ,[VerificationMethodDescription]
           ,[VerificationService]
           ,[OfferedBy]
           ,[Created]
           ,[LastUpdated]
		   )

SELECT       
	newId() as 	[RowId]
	,Lower([CTID]) as CTID
	,[Description]
	,[DateEffective]
	,[HolderMustAuthorize]
	,[SubjectWebpage]

	,[VerificationDirectory]
	,[VerificationMethodDescription]
	,[VerificationService]
	,[OfferedByAgentUid]
	,[Created]
	,[LastUpdated]

  FROM [dbo].[Entity.VerificationProfile]

GO

--========== entity.credential ===================


INSERT INTO [dbo].[Entity.Credential]
           ([EntityId]
           ,[CredentialId]
           ,[Created]
           ,[RelationshipTypeId])

SELECT  vspEntity.Id as vspEntityId
   --  ,a.[EntityId]
      ,a.[CredentialId]
	  ,a.created
      ,a.[RelationshipTypeId]
--,c.CTID, vspEntity.EntityTypeId, vspEntity.EntityBaseId
  FROM [dbo].[Entity.Credential] a
  inner join entity b on a.EntityId = b.Id 
  inner join [Entity.VerificationProfile] c on b.EntityUid = c.RowId
  inner join [VerificationServiceProfile] d on c.CTID = d.CTID
  inner join Entity vspEntity on d.RowId = vspEntity.EntityUid
  where b.EntityTypeId = 99 

GO

select lower(newId())

-- check

SELECT  a.[EntityId]
      ,a.[CredentialId]
      ,a.[Created]
      ,a.[RelationshipTypeId]
--,c.CTID
  FROM [dbo].[Entity.Credential] a
  inner join entity b on a.EntityId = b.Id 
  --inner join [VerificationServiceProfile] d on c.CTID = c.CTID
  --inner join Entity vspEntity on d.RowId = vspEntity.EntityUid
  where b.EntityTypeId = 41

GO


--========== entity.Property ===================

INSERT INTO [dbo].[Entity.Property]
           ([EntityId]
           ,[PropertyValueId]
           ,[Created]
		   )

SELECT  vspEntity.Id as vspEntityId
    -- ,a.[EntityId]
      ,a.[PropertyValueId]
	  ,a.created

--,c.CTID, vspEntity.EntityTypeId, vspEntity.EntityBaseId
  FROM [dbo].[Entity.Property] a
  inner join entity b on a.EntityId = b.Id 
  inner join [Entity.VerificationProfile] c on b.EntityUid = c.RowId
  inner join [VerificationServiceProfile] d on c.CTID = d.CTID
  inner join Entity vspEntity on d.RowId = vspEntity.EntityUid
  where b.EntityTypeId = 99 

GO

-- check

SELECT  a.[EntityId]
 ,a.[PropertyValueId]
	  ,a.created
--,c.CTID
  FROM [dbo].[Entity.Property] a
  inner join entity b on a.EntityId = b.Id 
  --inner join [VerificationServiceProfile] d on c.CTID = c.CTID
  --inner join Entity vspEntity on d.RowId = vspEntity.EntityUid
  where b.EntityTypeId = 41

GO

--========== [dbo].[Entity.JurisdictionProfile]===================
-- experiment with just updating the entity Id


SELECT a.[Id]
      ,a.[EntityId]
      ,a.[Name]
      ,a.[Description]
      ,a.[IsOnlineJurisdiction]
      ,a.[IsGlobalJurisdiction]
      ,a.[JProfilePurposeId]
      ,a.[Created]
      ,a.[LastUpdated]
      ,a.[RowId]
      ,a.[AssertedByAgentUid]
,c.CTID, vspEntity.Id, vspEntity.EntityTypeId, vspEntity.EntityBaseId
  FROM [dbo].[Entity.JurisdictionProfile] a
  inner join entity b on a.EntityId = b.Id 
  inner join [Entity.VerificationProfile] c on b.EntityUid = c.RowId
  inner join [VerificationServiceProfile] d on c.CTID = d.CTID
  inner join Entity vspEntity on d.RowId = vspEntity.EntityUid
  where b.EntityTypeId = 99
  go


UPDATE [dbo].[Entity.JurisdictionProfile]
   SET [EntityId] = vspEntity.Id
from [Entity.JurisdictionProfile] a 

  inner join entity b on a.EntityId = b.Id 
  inner join [Entity.VerificationProfile] c on b.EntityUid = c.RowId
  inner join [VerificationServiceProfile] d on c.CTID = d.CTID
  inner join Entity vspEntity on d.RowId = vspEntity.EntityUid
  where b.EntityTypeId = 99
GO

