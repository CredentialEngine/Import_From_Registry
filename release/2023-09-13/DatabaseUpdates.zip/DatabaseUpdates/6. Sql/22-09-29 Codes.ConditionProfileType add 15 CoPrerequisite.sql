--	22-09-29 Codes.ConditionProfileType add 15 CoPrerequisite
USE credFinder
GO

--use staging_credFinder
--go

use sandbox_credFinder
go


INSERT INTO [dbo].[Codes.ConditionProfileType]
           ([Id]
           ,[CategoryId]
           ,[Title]
           ,[ConditionManifestTitle]
           ,[Description]
           ,[SortOrder]
           ,[IsActive]
           ,[IsCommonCondtionType]           ,[IsLearningOpportunityType]           ,[IsAssessmentType]           ,[IsCredentialsConnectionType]
           ,[SchemaName]
           ,[Created]
           ,[Totals]           ,[CredentialTotals]           ,[AssessmentTotals]           ,[LoppTotals])

SELECT 15
      ,[CategoryId]
      ,'CoPrequisite'
      ,'CoPrequisite'
      ,'Resource that must be completed prior to, or pursued at the same time as, this resource."'
      ,[SortOrder]
      ,[IsActive]
      ,1      ,1      ,1      ,1
      ,'ceterms:coprequisite'
      ,getdate()
      ,0,0,0,0
  FROM [dbo].[Codes.ConditionProfileType]
  where id = 10

GO