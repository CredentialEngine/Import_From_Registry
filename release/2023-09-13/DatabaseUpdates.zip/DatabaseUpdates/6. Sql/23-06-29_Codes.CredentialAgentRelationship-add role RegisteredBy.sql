USE [credFinder]
GO
use sandbox_credFinder
go
--use staging_credFinder
--go

--use credFinder_github
--go


/*

*/

/*
--23-06-29_Codes.CredentialAgentRelationship-add role RegisteredBy
select * from [Codes.CredentialAgentRelationship]

delete FROM            [Codes.CredentialAgentRelationship]
WHERE        (Id IN (14))
go
delete FROM            [Codes.AssertionType]
WHERE        (Id IN (14))
go
*/

INSERT INTO [dbo].[Codes.CredentialAgentRelationship]
           ([Id]
           ,[Title]
           ,[Description]
           ,[SchemaTag]
           ,[ReverseRelation]
           ,[ReverseSchemaTag]
           ,[Created]
           ,[IsActive]
           ,[IsQARole]
           ,[IsOwnerAgentRole]
           ,[IsAgentToAgentRole]
           ,[IsEntityToAgentRole]
           ,[IsAssessmentAgentRole]
           ,[IsLearningOppAgentRole]
           ,[Totals]
           ,[CredentialTotals]
           ,[OrganizationTotals]
           ,[AssessmentTotals]
           ,[LoppTotals]
           ,[QAPerformedTotals])
     VALUES
           (14
           ,'Registered By'
           ,'Entity is Registered By the related Agent'
           ,'ceterms:registeredBy'
           ,'Registered For'
           ,'ceterms:registeredBy'
           ,getdate()
           ,1	--[IsActive]
           ,0	--[IsQARole]
           ,0	--[IsOwnerAgentRole]
           ,0	--[IsAgentToAgentRole]
           ,0	--[[IsEntityToAgentRole]]
           ,0	--[IsAssessmentAgentRole]
           ,1	--[IsLearningOppAgentRole]
           ,0	--[Totals]
           ,0
           ,0
           ,0
           ,0
           ,0
		   )
GO


INSERT INTO [dbo].[Codes.AssertionType]
           ([Id]
           ,[Title]
           ,[Description]
           ,[SchemaTag]
           ,[ReverseRelation]
           ,[ReverseSchemaTag]
           ,[Created]
           ,[IsActive]
           ,[IsQARole]
           ,[IsOwnerAgentRole]
           ,[IsAgentToAgentRole]
           ,[IsEntityToAgentRole]
           ,[IsAssessmentAgentRole]
           ,[IsLearningOppAgentRole]
           ,[Totals])
     VALUES
           (14
           ,'Registered By'
           ,'Entity is Registered By the related Agent'
           ,'ceterms:registeredBy'
           ,'Registered For'
           ,'ceterms:registeredBy'
           ,getdate()
           ,1	--[IsActive]
           ,0	--[IsQARole]
           ,0	--[IsOwnerAgentRole]
           ,0	--[IsAgentToAgentRole]
           ,0	--[[IsEntityToAgentRole]]
           ,0	--[IsAssessmentAgentRole]
           ,1	--[IsLearningOppAgentRole]
           ,0	--[Totals]
		   )
GO


