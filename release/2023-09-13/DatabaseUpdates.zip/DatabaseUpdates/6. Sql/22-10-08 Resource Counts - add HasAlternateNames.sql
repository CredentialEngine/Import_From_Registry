/****** Script for SelectTopNRows command from SSMS  ******/
--SELECT TOP (1000) [Id]
--      ,[Property]
--      ,[Label]
--      ,[Policy]
--      ,[PropertyGroup]
--      ,[Total]
--      ,[PercentOfOverallTotal]
--  FROM [sandbox_credFinder].[dbo].[Counts.Assessment_Property]
--  go
--  USE [credFinder]
--GO
--	22-10-08 Resource Counts - add HasAlternateNames

INSERT INTO [dbo].[Counts.Assessment_Property]
           ([Id]
           ,[Property]
           ,[Label]
           ,[Policy]
           ,[PropertyGroup]
           ,[Total]
           ,[PercentOfOverallTotal])
     VALUES
           (67
           ,'HasAlternateNames'
           ,'Alternate Name'
           ,'3. Optional'
           ,''
           ,0
           ,0.00)
GO


INSERT INTO [dbo].[Counts.LearningOpportunity_Property]
           ([Id]
           ,[Property]
           ,[Label]
           ,[Policy]
           ,[PropertyGroup]
           ,[Total]
           ,[PercentOfOverallTotal])
     VALUES
           (67
           ,'HasAlternateNames'
           ,'Alternate Name'
           ,'3. Optional'
           ,''
           ,0
           ,0.00)
GO

