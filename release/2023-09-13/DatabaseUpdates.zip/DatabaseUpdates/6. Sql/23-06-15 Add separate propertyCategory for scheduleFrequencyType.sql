USE [credFinder]
GO

use sandbox_credFinder
go 

--23-06-15 Add separate propertyCategory for scheduleFrequencyType

USE [ctdlEditor]
GO

use sandbox_ctdlEditor
go

/*
Add: conceptScheme for 
OfferFrequencyType
- adjust schedule frequency

*/
update .[Codes.PropertyCategory]
set Title = 'Schedule Frequency Type'
,[SchemeFor]='ceterms:scheduleFrequencyType'
where id = 94
-- =========================================================
--		 Offer Frequency
--	uses same concepts as scheduleFrequency, but need a separate catgegory for property storage
-- =========================================================
INSERT INTO [dbo].[Codes.PropertyCategory]
           ([Id],[Title] ,[Description]
           ,[SortOrder] ,[IsActive]
           ,[SchemaName] ,[SchemaUrl]
           ,[Created]
           ,[CodeName],[PropertyTableName],[IsConceptScheme],[SchemeFor])
     VALUES
           (96
           ,'Offer Frequency Type'
           ,'Type of frequency at which a resource is offered; select from an existing enumeration of such types.'
           ,10           ,1
           ,'ceterms:ScheduleFrequency' ,'https://credreg.net/ctdl/terms/ScheduleFrequency'
           ,GETDATE()
           ,'offerFrequency'		--??
		   ,'Codes.PropertyValue' ,1
           ,'ceterms:offerFrequencyType'		
			)
GO

--copy the schedule frequency. 
--	TBD - do we need fake change the namespace? there are lookups by schemaname?
--		check code and force use of category as well?


INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId]
           ,[Title]
           ,[Description]
           ,[SortOrder]
           ,[IsActive]
           ,[SchemaName]
           ,[SchemaUrl]
           ,[ParentSchemaName]
           ,[Created]
           ,[Totals]
           ,[IsSubType1])

SELECT 96
      ,[Title]
      ,[Description]
      ,[SortOrder]
      ,[IsActive]
      ,[SchemaName]
      ,[SchemaUrl]
      ,[ParentSchemaName]
      , getdate() as [Created]
      ,0 as [Totals]
      ,[IsSubType1]
  FROM [dbo].[Codes.PropertyValue]
  where categoryId = 94
GO



