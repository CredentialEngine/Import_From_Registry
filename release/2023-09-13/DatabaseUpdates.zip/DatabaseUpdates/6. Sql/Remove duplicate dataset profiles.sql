
use credFinder_prod
go
USE [credFinder]
GO
use sandbox_credFinder
go
--	Remove duplicate dataset profiles
/*
Propath
lopp - agdp - dsp
same lopp, and different dsp for 22-06. 

- get date of last dsp
- delete all except for the latter (virtual)

*/
/*
select top (100) a.id as dspID,  a.EntityStateId, a.ctid, a.description, a.LastUpdated
from [DataSetProfile] a
WHERE        (Description = 'Data Set Profile for credential Basic Nurse Assistant Training Program') AND (EntityStateId = 3)

*/
/*
NO BAD IDEA
--UPDATE [dbo].[DataSetProfile]
--   SET [EntityStateId] = 3
--	, Lastupdated = Created
--where entitystateid = 0
--and LastUpdated > '2023-01-01'

--UPDATE [dbo].[DataSetProfile]
--   SET [EntityStateId] = 3
--	, Lastupdated = Created
--where entitystateid = 3
--and LastUpdated > '2023-01-01'
--go

*/
UPDATE [dbo].[DataSetProfile]
   SET [EntityStateId] = 0
   
	--, Lastupdated = Getdate() --NO - need to be able to reference actual from envelope

--	select top (100) action.[LearningOpportunityId],a.id as dspID,  a.EntityStateId, a.ctid, a.description, a.LastUpdated as dspLastUpdated, org.Name as Organization
from [DataSetProfile] a
  inner join Organization org on a.DataProviderUID = org.RowId
Inner join 
(
--	Select where an lopp has multiple dsps 
SELECT 
--a.[Id]
      a.[LearningOpportunityId]
	    ,l.LastUpdated as loppLastUpdated
	  --,max(e.EntityBaseId) as lastDataSetProfileId
	  --,count(*) as ttl
      ,a.[EntityId]	  , e.EntityTypeId, e.EntityBaseId
	   ,dsp.Description
      ,a.[Created]
   --   ,a.[RelationshipTypeId]
  FROM [dbo].[Entity.LearningOpportunity] a
  inner join LearningOpportunity l on a.LearningOpportunityId = l.Id
  inner join entity e on a.EntityId = e.id 
  inner join DataSetProfile dsp on e.EntityBaseId = dsp.id 

  where e.EntityTypeId = 31
  and dsp.EntityStateId = 3
 --and a.LearningOpportunityId in (6401,6407,6424,6427)
--===== where the dsp.Id is not the last one
  and dsp.id not in (
  --latest dsp 
    SELECT 
  --a.[Id]
     --a.[LearningOpportunityId],
	  --,
	  max(e.EntityBaseId) as lastDataSetProfileId
	  -- ,max(a.max(LastUpdated)) as lastmax(LastUpdated)Date
	-- ,count(*) as ttl
  FROM [dbo].[Entity.LearningOpportunity] a
  inner join entity e on a.EntityId = e.id 
  inner join DataSetProfile dsp on e.EntityBaseId = dsp.id 
  where e.EntityTypeId = 31
	and dsp.EntityStateId = 3
	and a.LearningOpportunityId in (6401,6407,6424,6427)
  group by a.[LearningOpportunityId]  having count(*) > 5
  --order by ttl desc 
  )
 -- order by a.[LearningOpportunityId]   ,e.EntityBaseId desc 


) action on a.Id = action.EntityBaseId
where a.[EntityStateId] = 3
and a.Created > '2022-05-01' and  a.Created < '2023-12-31'

order by  action.[LearningOpportunityId], a.lastUpdated

/*
alternate to clean up dataset profiles directly
see: "duplicate DatasetProfile clean up" for SQL to create table: DatasetProfile_DeleteSubjects

UPDATE [dbo].[DataSetProfile]
   SET [EntityStateId] = 0
    --  ,[LastUpdated] = getdate()
--select a.*
from [DataSetProfile] a
inner join (
SELECT distinct 
 a.[Id], b.minId, b.[maxId]
      ,a.[EntityStateId]
      ,a.[CTID]
      ,a.[Name]
	  , org.Name as Organization
      ,a.[Description]
      ,a.[Created]
      ,a.[LastUpdated]
      ,a.[DataProviderUID]
--	select count(*)
  FROM [dbo].[DataSetProfile] a		--5794
    Left join Organization org on a.DataProviderUID = org.RowId
  inner join [DatasetProfile_DeleteSubjects] b on a.[DataProviderUID] = b.[DataProviderUID] and a.Description = b.description
  where a.EntityStateId = 3
  and a.Created > '2022-06-01' and  a.Created < '2022-07-31'
  and a.Id < b.maxId
  ) candidates on a.Id = candidates.Id
  where a.EntityStateId = 3
  and a.Created > '2022-06-01' and  a.Created < '2022-07-31'
  --and a.Description = 'Data Set Profile for credential Dental Assistant'
order by candidates.Organization, a.Description, a.id 
GO


*/


  /*
SELECT distinct 
 a.[Id], b.minId, b.[maxId]
      ,a.[EntityStateId]
      ,a.[CTID]
      ,a.[Name]
	  , org.Name as Organization
      ,a.[Description]
      ,a.[Created]
      ,a.[LastUpdated]
      ,a.[DataProviderUID]
--	select count(*)
  FROM [dbo].[DataSetProfile] a		--5794
    Left join Organization org on a.DataProviderUID = org.RowId
  inner join [DatasetProfile_DeleteSubjects] b on a.[DataProviderUID] = b.[DataProviderUID] and a.Description = b.description
  where a.Created > '2022-06-01' and  a.Created < '2022-07-31'
 -- and  a.EntityStateId = 3
  and a.id in (5580)
  --and a.Id < b.maxId
order by org.name, a.Description, a.id 
GO

*/