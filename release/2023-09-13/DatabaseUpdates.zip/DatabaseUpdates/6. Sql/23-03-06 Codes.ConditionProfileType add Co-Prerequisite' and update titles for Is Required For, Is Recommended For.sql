use credfinder
go

USE sandbox_credFinder
GO
--	23-03-06 Codes.ConditionProfileType add Co-Prerequisite' and update titles for Is Required For, Is Recommended For


  update [dbo].[Codes.ConditionProfileType]
  set [Title]= 'Is Required For'
  ,Description = 'This credential, assessment, or learning opportunity must be earned or completed prior to attempting to earn or complete the referenced credential, assessment, or learning opportunity.'
  where [Title]= 'Post-Award Connections (Is Required For)'
  go
    update [dbo].[Codes.ConditionProfileType]
  set [Title]= 'Is Recommended For', Description = 'It is recommended to earn or complete this credential, assessment, or learning opportunity before attempting to earn or complete the referenced credential, assessment, or learning opportunity.'
  where [Title]= 'Post-Award Connections (Is Recommended For)'
  go

 update [dbo].[Codes.ConditionProfileType]
  set [ConditionManifestTitle]= 'Requires', Description = 'Requirement or set of requirements for this resource.'
  where [Title]= 'Requires'
  go

  --
INSERT INTO [dbo].[Codes.ConditionProfileType]
           ([Id] ,[CategoryId]
           ,[Title] ,[ConditionManifestTitle] ,[Description]
           ,[SortOrder] ,[IsActive]
           ,[IsCommonCondtionType] ,[IsLearningOpportunityType] ,[IsAssessmentType] ,[IsCredentialsConnectionType]
           ,[SchemaName] 
           ,[Created] ,[Totals] ,[CredentialTotals] ,[AssessmentTotals] ,[LoppTotals])
     VALUES
           (15,15,'Co-Prerequisite','Co-Prerequisite','Resource that must be completed prior to, or pursued at the same time as, this resource.'
           ,25, 1
           ,1,1,1,1
           ,'ceterms:coPrerequisite' 
           ,getdate(), 0,0,0,0)
GO



SELECT [Id]
      ,[CategoryId]
      ,[Title]
      ,[ConditionManifestTitle]
      ,[Description]
      ,[SortOrder]
      ,[IsActive]
      ,[IsCommonCondtionType]
      ,[IsLearningOpportunityType]
      ,[IsAssessmentType]
      ,[IsCredentialsConnectionType]
      ,[SchemaName]
      ,[Created]
      ,[Totals]
      ,[CredentialTotals]
      ,[AssessmentTotals]
      ,[LoppTotals]
  FROM [dbo].[Codes.ConditionProfileType]

GO



