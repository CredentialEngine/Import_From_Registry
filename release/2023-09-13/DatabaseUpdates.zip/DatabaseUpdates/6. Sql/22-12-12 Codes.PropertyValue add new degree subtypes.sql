-- 22-12-12 Codes.PropertyValue add new degree subtypes
-- *******************************************************************************************************
--	NOTE: MAKE A COPY OF THIS IN THE FINDER SQL FOLDER AND INCLUDE WITH APPROPRIATE IMPORT RELEASE FOLDER
-- *******************************************************************************************************

use ctdlEditor
go

use sandbox_ctdlEditor
go

--use staging_ctdlEditor
--go

--use sandbox_credFinder
--go

--use staging_credFinder
--go

--use credFinder
--go

--set IsActive appropriately before executing
--change sortOrder to make room
USE [sandbox_ctdlEditor]
GO

UPDATE [dbo].[Codes.PropertyValue]
   SET [SortOrder] = 200
 WHERE [CategoryId]=2
 and [SortOrder] = 99
GO

UPDATE [dbo].[Codes.PropertyValue]
   SET [SortOrder] = 100
 WHERE [CategoryId]=2
 and [SortOrder] = 50
GO

UPDATE [dbo].[Codes.PropertyValue]
   SET [SortOrder] = 50
 WHERE [CategoryId]=2
 and [SortOrder] = 42
GO
UPDATE [dbo].[Codes.PropertyValue]
   SET [SortOrder] = 60
 WHERE [CategoryId]=2
 and [SortOrder] = 43
GO
UPDATE [dbo].[Codes.PropertyValue]
   SET [SortOrder] = [SortOrder] + 26
 WHERE [CategoryId]=2
 and [SortOrder] in ( 44,45,46)
GO
--========================

UPDATE [dbo].[Codes.PropertyValue]
   SET [ParentSchemaName] =N'Associate Degrees'
 WHERE SchemaName='ceterms:AssociateDegree'

GO

INSERT [dbo].[Codes.PropertyValue] ( [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES ( 2, N'Associate of Arts Degree', N'College/university award for students typically completing the first one to two years of postsecondary school education with an emphasis in the liberal arts and sciences such as the humanities and social science fields.', 42, 1, N'ceterms:AssociateOfArtsDegree', NULL, N'Associate Degrees', CAST(N'2022-12-12T12:12:12.120' AS DateTime), 0, 0)

INSERT [dbo].[Codes.PropertyValue] ( [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES ( 2, N'Associate of Science Degree', N'College/university award for students typically completing the first one to two years of postsecondary school education with an emphasis in scientific and technical fields and professional fields of study.', 43, 1, N'ceterms:AssociateOfScienceDegree', NULL, N'Associate Degrees', CAST(N'2022-12-12T12:12:12.120' AS DateTime), 0, 0)

INSERT [dbo].[Codes.PropertyValue] ( [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES ( 2, N'Associate of Applied Arts Degree', N'College/university award for students typically completing one to two years of postsecondary school education in a technical, professional, or vocational program with an emphasis on direct employment in the arts and social sciences fields.', 44, 1, N'ceterms:AssociateOfAppliedArtsDegree', NULL, N'Associate Degrees', CAST(N'2022-12-12T12:12:12.120' AS DateTime), 0, 0)

INSERT [dbo].[Codes.PropertyValue] ( [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES ( 2, N'Associate of Applied Science Degree', N'College/university award for students typically completing one to two years of postsecondary school education in a technical, professional, or vocational program with an emphasis on direct employment in applied scientific and technological fields.', 45, 1, N'ceterms:AssociateOfAppliedScienceDegree', NULL, N'Associate Degrees', CAST(N'2022-12-12T12:12:12.120' AS DateTime), 0, 0)

--========================

UPDATE [dbo].[Codes.PropertyValue]
   SET [ParentSchemaName] =N'Bachelor Degrees'
 WHERE SchemaName='ceterms:BachelorDegree'

GO

INSERT [dbo].[Codes.PropertyValue] ( [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES ( 2, N'Bachelor of Arts Degree', N'College/university award for students typically completing three to five years of education where course work and activities advance skills beyond those of the first one to two years of college/university study, with an emphasis in the liberal arts and sciences such as the humanities and social science fields.', 51, 1, N'ceterms:BachelorOfArtsDegree', NULL, N'Bachelor Degrees', CAST(N'2022-12-12T12:12:12.120' AS DateTime), 0, 0)

INSERT [dbo].[Codes.PropertyValue] ( [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES ( 2, N'Bachelor of Science Degree', N'College/university award for students typically completing three to five years of education where course work and activities advance skills beyond those of the first one to two years of college/university study, with an emphasis in scientific and technical fields and professional fields of study.', 52, 1, N'ceterms:BachelorOfScienceDegree', NULL, N'Bachelor Degrees', CAST(N'2022-12-12T12:12:12.120' AS DateTime), 0, 0)

--========================

UPDATE [dbo].[Codes.PropertyValue]
   SET [ParentSchemaName] =N'Master Degrees'
 WHERE SchemaName='ceterms:MasterDegree'

GO

INSERT [dbo].[Codes.PropertyValue] ( [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES ( 2, N'Master of Arts Degree', N'Credential awarded for a graduate level course of study where course work and activities advance skills beyond those of the bachelor''s degree or its equivalent, with an emphasis in the liberal arts and sciences such as the humanities and social science fields.', 61, 1, N'ceterms:MasterOfArtsDegree', NULL, N'Master Degrees', CAST(N'2022-12-12T12:12:12.120' AS DateTime), 0, 0)

INSERT [dbo].[Codes.PropertyValue] ( [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES ( 2, N'Master of Science Degree', N'Credential awarded for a graduate level course of study where course work and activities advance skills beyond those of the bachelor''s degree or its equivalent, with an emphasis in scientific and technical fields and professional fields of study.', 62, 1, N'ceterms:MasterOfScienceDegree', NULL, N'Master Degrees', CAST(N'2022-12-12T12:12:12.120' AS DateTime), 0, 0)

--	TBD
-- not sure about parent or sort order
INSERT [dbo].[Codes.PropertyValue] ( [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES ( 2, N'Specialist Degree', N'Credential awarded for a graduate level course of study where course work and activities advance skills beyond those of the master''s degree and less than a doctoral degree and provides specific preparation for advanced careers in a specialist field', 65, 1, N'ceterms:SpecialistDegree', NULL, NULL, CAST(N'2022-12-12T12:12:12.120' AS DateTime), 0, 0)

--SET IDENTITY_INSERT [dbo].[Codes.PropertyValue] OFF

-- changes
  USE [ctdlEditor]
GO

--use staging_ctdlEditor
--go

use sandbox_ctdlEditor
go

UPDATE [dbo].[Codes.PropertyValue]
   SET [ParentSchemaName] = NULL
  where CategoryId=2
  and SchemaName='ceterms:CompletionCertificate'
GO
UPDATE [dbo].[Codes.PropertyValue]
   SET IsActive=0
  where CategoryId=2
  and SchemaName='ceterms:ParticipationCertificate'
GO


--check
SELECT TOP (1000) [Id]
      ,[CategoryId]
      ,[Title]
      ,[Description]
      ,[SortOrder]
      ,[IsActive]
      ,[SchemaName]
      ,[SchemaUrl]
      ,[ParentSchemaName]
      ,[Created]
      ,[Totals]
      ,[IsSubType1]
  FROM [dbo].[Codes.PropertyValue]
  where CategoryId = 2
