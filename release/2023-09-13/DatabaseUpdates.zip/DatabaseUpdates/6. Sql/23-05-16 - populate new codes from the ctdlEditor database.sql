
-- 23-05-16 - populate new codes from the ctdlEditor database
-- first ensure the ctdlEditor tables have been updated. Then use the latter to populate the credFinder tables. 
USE [credFinder]
GO
use sandbox_credFinder
go
--use staging_credFinder
--go
/*
--	Codes.PropertyCategory
INSERT INTO [dbo].[Codes.PropertyCategory]
           ([Id]
           ,[Title]
           ,[Description]
           ,[SortOrder]
           ,[IsActive]
           ,[SchemaName]
           ,[SchemaUrl]
           ,[Created] ,[CodeName]
          
           ,[InterfaceType]
           ,[PropertyTableName]
           ,[IsConceptScheme]
           ,[SchemeFor])
SELECT [Id]
      ,[Title]
      ,[Description]
      ,[SortOrder]
      ,[IsActive]
      ,[SchemaName]
      ,[SchemaUrl]
      ,[Created] ,[CodeName]
     
      ,[InterfaceType]
      ,[PropertyTableName]
      ,[IsConceptScheme]
      ,[SchemeFor]
  FROM sandbox_ctdlEditor.[dbo].[Codes.PropertyCategory]
  where id in (100,101)
GO

*/


INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId]
           ,[Title]
           ,[Description]
           ,[SortOrder]
           ,[IsActive]
           ,[SchemaName]
           ,[SchemaUrl]
           ,[ParentSchemaName]
           ,[Created]
           ,[Totals]
           ,[IsSubType1])

SELECT [CategoryId]
      ,[Title]
      ,[Description]
      ,[SortOrder]
      ,[IsActive]
      ,[SchemaName]
      ,[SchemaUrl]
      ,[ParentSchemaName]
      ,[Created]
      ,[Totals]
      ,[IsSubType1]
  FROM [ctdlEditor].[dbo].[Codes.PropertyValue]
  where CategoryId in (100,1010)
GO

--delete FROM [sandbox_ctdlEditor].[dbo].[Codes.PropertyValue]
--where CategoryId = 100


--delete FROM [sandbox_credFinder].[dbo].[Codes.PropertyValue]
--where CategoryId = 100



