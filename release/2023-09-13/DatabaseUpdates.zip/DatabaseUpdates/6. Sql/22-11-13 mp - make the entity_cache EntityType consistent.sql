/****** 
SELECT [EntityTypeId]
      ,[EntityType]
    ,count(*) as ttl
  FROM [sandbox_credFinder].[dbo].[Entity_Cache]
  group by 
   [EntityTypeId]
      ,[EntityType]
    
	order by 1
	go
	
******/

USE [sandbox_credFinder]
GO
--use credfinder
--go
--	22-11-13 mp - make the entity_cache EntityType consistent

UPDATE [dbo].[Entity_Cache]
   SET [EntityType] = 'Assessment'

 WHERE [EntityType] = 'AssessmentProfile'
GO

UPDATE [dbo].[Entity_Cache]
   SET [EntityType] = 'Organization'

 WHERE [EntityType] = 'Credential Organization'
GO
--
UPDATE [dbo].[Entity_Cache]
   SET [EntityType] = 'LearningOpportunity'

 WHERE [EntityType] = 'Learning Opportunity'
GO

UPDATE [dbo].[Entity_Cache]
   SET [EntityType] = 'ConceptScheme'

 WHERE [EntityType] = 'Concept Scheme'
GO

UPDATE [dbo].[Entity_Cache]
   SET [EntityType] = 'DataSetProfile'

 WHERE [EntityType] = 'DataSet Profile'
GO
UPDATE [dbo].[Entity_Cache]
   SET [EntityType] = 'JobProfile'

 WHERE [EntityType] = 'Job Profile'
GO
	