/****** ProPath dataset profile issues  ******/
use credfinder
go

use credfinder_prod
go

-- list all where an entity.lopp has a relationship with a dsp, published by ProPath

SELECT TOP (1000) a.[Id]
      ,a.[EntityId], b.EntityTypeId, b.EntityBaseId as dspId, dsp.CTID as dspCTID, dsp.LastUpdated as dspLastUpdated
	  , c.Name as Lopp, c.CTID as loppCTId
      ,a.[LearningOpportunityId], c.LastUpdated as loppLastUpdated
      --,a.[Created]
      --,a.[RelationshipTypeId]
--	select count(*) as ttl
  FROM [dbo].[Entity.LearningOpportunity] a
  inner join entity b on a.EntityId = b.id 
  inner join DataSetProfile dsp on b.EntityUid = dsp.RowId
  inner join LearningOpportunity c on a.LearningOpportunityId = c.id 
  inner join Organization lOrg on c.owningAgentUID = lOrg.RowId
  inner join (select PublisherCTID, dataOwnerCTID from [Import.PendingRequest] a
				group by PublisherCTID, dataOwnerCTID) 
	publisher on lOrg.CTID = publisher.DataOwnerCTID

  where publisher.PublisherCTID = 'ce-89bd0d16-6492-4ae1-8059-deabc3d89c15'

  --AND a.created > '2022-06-12'

  and b.EntityTypeId=31
  order by c.Name, c.id, entityid 
  ---4041 for '2022-06-12' and all

  /*
  -- ========== delete the entity.lopps for PP datasets
  Delete a
--	select count(*) ttl
	FROM [dbo].[Entity.LearningOpportunity] a

  inner join entity b on a.EntityId = b.id 
  inner join DataSetProfile dsp on b.EntityUid = dsp.RowId
  inner join LearningOpportunity c on a.LearningOpportunityId = c.id 
  inner join Organization lOrg on c.owningAgentUID = lOrg.RowId
  inner join (select PublisherCTID, dataOwnerCTID from [Import.PendingRequest] a
				group by PublisherCTID, dataOwnerCTID) 
	publisher on lOrg.CTID = publisher.DataOwnerCTID

  where publisher.PublisherCTID = 'ce-89bd0d16-6492-4ae1-8059-deabc3d89c15'
  and b.EntityTypeId=31
  --AND a.created > '2022-06-12'

  */

  /****** ======================================================= ******/
SELECT TOP (1000) a.[Id]
      ,a.[RowId]
      ,a.[EntityStateId]
      ,a.[CTID]
      ,a.[Name]
	       ,a.[DataProviderUID], b.Name
		   ,publisher.PublisherCTID
      ,a.[Description]
      ,a.[Source]
      ,a.[Created]
      ,a.[LastUpdated]
      ,a.[CredentialRegistryId]
 
      ,a.[DataSuppressionPolicy]
      ,a.[SubjectIdentification]
      ,a.[DistributionFile]
      ,a.[DataSetTimePeriodJson]
  FROM [dbo].[DataSetProfile] a
  inner join Organization b on a.DataProviderUID = b.RowId
  inner join (select PublisherCTID, dataOwnerCTID from [Import.PendingRequest] a
  group by PublisherCTID, dataOwnerCTID) 
	publisher on b.CTID = publisher.DataOwnerCTID

  where publisher.PublisherCTID = 'ce-89bd0d16-6492-4ae1-8059-deabc3d89c15'
  order by id desc 
  go

  /*
  update   [dbo].[DataSetProfile]
  set EntityStateId = 0
  FROM [dbo].[DataSetProfile] a
  inner join Organization b on a.DataProviderUID = b.RowId
  inner join (select PublisherCTID, dataOwnerCTID from [Import.PendingRequest] a
  group by PublisherCTID, dataOwnerCTID) publisher on b.CTID = publisher.DataOwnerCTID

  where publisher.PublisherCTID = 'ce-89bd0d16-6492-4ae1-8059-deabc3d89c15'

    --SELECT *
	 -- into DataSetProfile_propathOld_230210
  --FROM [dbo].[DataSetProfile]
  --where [EntityStateId]= 0
  --go
  --  delete   FROM [dbo].[DataSetProfile]
  --where [EntityStateId]= 0

  */
  /*
  --vdelete lopps
    update   [dbo].LearningOpportunity
  set EntityStateId = 0
--	select a.Id, a.entityStateId, a.CTID, a.name, b.name, a.LastUpdated
  FROM [dbo].LearningOpportunity a
  inner join Organization b on a.OwningAgentUid = b.RowId
  inner join (select PublisherCTID, dataOwnerCTID from [Import.PendingRequest] a
  group by PublisherCTID, dataOwnerCTID) publisher on b.CTID = publisher.DataOwnerCTID
  
  where a.EntityStateId = 3
  and  publisher.PublisherCTID = 'ce-89bd0d16-6492-4ae1-8059-deabc3d89c15'
  and a.LastUpdated < '2024-01-01'
  go

  SELECT *
	  into LearningOpportunity_propathOld_230210
  FROM [dbo].[LearningOpportunity]
  where [EntityStateId]= 0
  go
    delete   FROM [dbo].[LearningOpportunity]
  where [EntityStateId]= 0

  go
  */
  /*
  --vdelete creds
    update   [dbo].Credential
  set EntityStateId = 0
--	select a.Id, a.entityStateId, a.CTID, a.name, b.name, a.LastUpdated
  FROM [dbo].Credential a
  inner join Organization b on a.OwningAgentUid = b.RowId
  inner join (
		select PublisherCTID, dataOwnerCTID from [Import.PendingRequest] a
		group by PublisherCTID, dataOwnerCTID
	) 
  publisher on b.CTID = publisher.DataOwnerCTID
  
  where a.EntityStateId = 3
  and  publisher.PublisherCTID = 'ce-89bd0d16-6492-4ae1-8059-deabc3d89c15'
  and a.LastUpdated < '2024-01-01'
  go

    SELECT *
	  into Credential_propathOld_230210
  FROM [dbo].[Credential]
  where [EntityStateId]= 0
  go
    delete   FROM [dbo].[Credential]
  where [EntityStateId]= 0

  drop table Credential_propathOld_230210

  */