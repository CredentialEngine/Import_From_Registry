--Update SchemeFor for concept scheme collection category
 use credFinder
 go
 use sandbox_credfinder
 go

UPDATE [dbo].[Codes.PropertyCategory]
   SET [SchemeFor] = 'ceterms:collectionType'
 WHERE id=85
GO


