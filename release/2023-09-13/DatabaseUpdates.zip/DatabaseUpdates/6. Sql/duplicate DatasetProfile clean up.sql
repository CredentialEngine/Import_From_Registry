/**
	-- duplicate DatasetProfile clean up
SELECT TOP (5000) a.[Id]
      ,a.[RowId]
      ,a.[EntityStateId]
      ,a.[CTID]
      ,a.[Name], org.Name as Organization
      ,a.[Description]
      ,a.[Source]
      ,a.[Created]
      ,a.[LastUpdated]
      ,a.[CredentialRegistryId]
      ,a.[DataProviderUID]
      ,a.[DataSuppressionPolicy]
      ,a.[SubjectIdentification]
      ,a.[DistributionFile]
      ,a.[DataSetTimePeriodJson]
  FROM [credFinder_prod].[dbo].[DataSetProfile] a
    Left join Organization org on a.DataProviderUID = org.RowId
--  inner join [LastDSPForLopp] b on a.Id = b.lastDataSetProfileId
  where a.[EntityStateId] >= 0
    and a.Created > '2022-06-01' and  a.Created < '2022-07-31'
  order by Description
  go
  */

  SELECT TOP (5000) 
  --a.[Id]
  --    ,a.[RowId]
  --    ,a.[EntityStateId]
  --    ,a.[CTID]
	  a.[DataProviderUID], org.Name as Organization
      ,a.[Description]
	  	  ,min(a.Id) as minId
	  ,max(a.Id) as maxId
	  ,min(a.[LastUpdated]) as minLastUpdatedDate
	  ,max(a.[LastUpdated]) as maxLastUpdatedDate
	  , count(*) as Total

--	***** populate the work table *****
--into DatasetProfile_DeleteSubjects

  FROM [dbo].[DataSetProfile] a
  inner join entity e on a.RowId = e.EntityUid
  Left join Organization org on a.DataProviderUID = org.RowId
  where a.[EntityStateId]= 3
  and isnull(a.description,'') <> ''
  and a.Created > '2022-06-01' and  a.Created < '2022-12-31'
group by  a.[DataProviderUID], org.Name, a.[Description] having count(*) > 1

order by maxId, org.Name, a.Description
  go