USE [sandbox_credFinder]
GO
use credFinder
go
-- 23-05-16 Codes.ConditionProfileType Add Support Service Condition(16)

INSERT INTO [dbo].[Codes.ConditionProfileType]
           ([Id]
           ,[CategoryId]
           ,[Title]
           ,[ConditionManifestTitle]
           ,[Description]
           ,[SortOrder]
           ,[IsActive]
           ,[IsCommonCondtionType]

           ,[IsLearningOpportunityType]
           ,[IsAssessmentType]
           ,[IsCredentialsConnectionType]
           ,[SchemaName]
           ,[Created]
           ,[Totals]
           ,[CredentialTotals]
           ,[AssessmentTotals]
           ,[LoppTotals])
     VALUES
           (16
           ,15
           ,'Support Service Condition'
           ,'Support Service Condition'
           ,'Requirements to qualify for a support service.'
           ,25
           ,1
           ,1
           ,0
           ,0
           ,0
           ,'ceterms:supportServiceCondition'
           ,GetDate()
           ,0
           ,0
           ,0
           ,0)
GO


