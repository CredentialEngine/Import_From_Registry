/****** Script for SelectTopNRows command from SSMS  ******/

-- 23-06-15 Codes.PropertyValue_Add deliveryType-VariableSite to missed databases

USE [sandbox_ctdlEditor]
GO
use ctdlEditor
go
use sandbox_Credfinder
go
use credfinder
go
SELECT TOP (1000) [Id]
      ,[CategoryId]
      ,[Title]
      ,[Description]
      ,[SortOrder]
      ,[IsActive]
      ,[SchemaName]
      ,[SchemaUrl]
      ,[ParentSchemaName]
      ,[Created]
      ,[Totals]
      ,[IsSubType1]
  FROM [dbo].[Codes.PropertyValue]
  where schemaname like '%delivery%'
  go

INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId]
           ,[Title]
           ,[Description]
           ,[SortOrder]
           ,[IsActive]
           ,[SchemaName]
           ,[SchemaUrl]
           ,[ParentSchemaName]
           ,[Created]
           ,[Totals]
           ,[IsSubType1])


SELECT 21
      ,[Title]
      ,[Description]
      ,[SortOrder]
      ,[IsActive]
      ,[SchemaName]
      ,[SchemaUrl]
      ,[ParentSchemaName]
      ,[Created]
      ,[Totals]
      ,[IsSubType1]
  FROM ctdlEditor.[dbo].[Codes.PropertyValue]
  where categoryId = 21 and [SchemaName] = 'deliveryType:VariableSite'

GO



