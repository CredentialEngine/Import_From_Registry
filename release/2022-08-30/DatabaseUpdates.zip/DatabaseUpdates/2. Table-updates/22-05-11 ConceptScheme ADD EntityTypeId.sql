
--NOTE: check the 5/27 version of the database to check if ConceptScheme already has 
--		the column EntityTypeId. 
--		Worst case is that there will be an error that the column already exists
--
/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.ConceptScheme ADD
	EntityTypeId int NOT NULL CONSTRAINT DF_ConceptScheme_EntityTypeId DEFAULT 11
GO
ALTER TABLE dbo.ConceptScheme SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
go
-- update trigger


/****** Object:  Trigger [dbo].[trgConceptSchemeAfterInsert]    Script Date: 5/11/2022 10:05:29 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


ALTER TRIGGER [dbo].[trgConceptSchemeAfterInsert] ON  [dbo].[ConceptScheme]
FOR INSERT
AS  
    INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
					 ,EntityBaseId, EntityBaseName)
    SELECT RowId,11, getdate(), Id, Name
    FROM inserted;

--Update ConceptScheme 
--		set StatusId = 1
--		from ConceptScheme a 
--		inner join inserted b on a.Id = b.Id
GO




Update dbo.ConceptScheme
	Set EntityTypeId = 12
where IsProgressionModel = 1
GO