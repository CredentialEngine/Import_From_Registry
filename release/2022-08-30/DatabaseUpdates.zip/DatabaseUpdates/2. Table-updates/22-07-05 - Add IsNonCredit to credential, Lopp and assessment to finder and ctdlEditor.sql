use credfinder_220527
go
-- 22-07-05 - Add IsNonCredit to credential, Lopp and assessment finder and ctdlEditor
/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.Credential ADD
	IsNonCredit bit NULL
GO
ALTER TABLE dbo.Credential SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
Go

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.Assessment ADD
	IsNonCredit bit NULL
GO
ALTER TABLE dbo.Assessment SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
Go

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.LearningOpportunity ADD
	IsNonCredit bit NULL
GO
ALTER TABLE dbo.LearningOpportunity SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
