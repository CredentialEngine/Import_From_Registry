-- 22-07-09 added LifeCycleStatusTypeId to Lopp, asmt, and org



/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.LearningOpportunity ADD
	LifeCycleStatusTypeId int NOT NULL CONSTRAINT DF_LearningOpportunity_LifeCycleStatusTypeId DEFAULT 0
GO
ALTER TABLE dbo.LearningOpportunity SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO

BEGIN TRANSACTION
GO
ALTER TABLE dbo.Organization ADD
	LifeCycleStatusTypeId int NOT NULL CONSTRAINT DF_Organization_LifeCycleStatusTypeId DEFAULT 0
GO
ALTER TABLE dbo.Organization SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO

BEGIN TRANSACTION
GO
ALTER TABLE dbo.Assessment ADD
	LifeCycleStatusTypeId int NOT NULL CONSTRAINT DF_Assessment_LifeCycleStatusTypeId DEFAULT 0
GO
ALTER TABLE dbo.Assessment SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO

--populate 

-- =========================================
-- categoryId: status id - 84
/*
SELECT TOP (1000) [Id]      ,[CategoryId]      ,[Title] ,SchemaName     
  FROM [dbo].[Codes.PropertyValue]
  where CategoryId = 84
  go

  */
    
UPDATE [dbo].LearningOpportunity
   SET LifeCycleStatusTypeId = c.PropertyValueId
--	select a.Id, a.Name, c.PropertyValueId, d.Title
   from [dbo].LearningOpportunity a
   inner join entity b on a.rowId = b.EntityUid
   inner join [Entity.Property] c on b.id = c.EntityId
   inner join [codes.propertyValue] d on c.propertyValueId = d.Id
 WHERE d.CategoryId = 84
--and a.EntityStateId = 3
and Isnull(a.LifeCycleStatusTypeId,0) = 0
GO
--set references and pending to active
UPDATE [dbo].LearningOpportunity
   SET LifeCycleStatusTypeId = d.Id
--	select a.Id, a.Name, a.EntityStateId, d.Id, d.Title
   from [dbo].LearningOpportunity a
   left join [codes.propertyValue] d on d.Title = 'Active'
 WHERE d.CategoryId = 84
and a.EntityStateId in (1,2)
and Isnull(a.LifeCycleStatusTypeId,0) = 0
GO

--=============================================================

UPDATE [dbo].Assessment
   SET LifeCycleStatusTypeId = c.PropertyValueId
--	select a.Id, a.Name, c.PropertyValueId, d.Title
   from [dbo].Assessment a
   inner join entity b on a.rowId = b.EntityUid
   inner join [Entity.Property] c on b.id = c.EntityId
   inner join [codes.propertyValue] d on c.propertyValueId = d.Id
 WHERE d.CategoryId = 84
--and a.EntityStateId = 3
and Isnull(a.LifeCycleStatusTypeId,0) = 0
GO
--set references and pending to active
UPDATE [dbo].Assessment
   SET LifeCycleStatusTypeId = d.Id
--	select a.Id, a.Name, a.EntityStateId, d.Id, d.Title
   from [dbo].Assessment a
   left join [codes.propertyValue] d on d.Title = 'Active'
 WHERE d.CategoryId = 84
and a.EntityStateId in (1,2)
and Isnull(a.LifeCycleStatusTypeId,0) = 0
GO
--=============================================================

UPDATE [dbo].Organization
   SET LifeCycleStatusTypeId = c.PropertyValueId
--	select a.Id, a.Name, c.PropertyValueId, d.Title
   from [dbo].Organization a
   inner join entity b on a.rowId = b.EntityUid
   inner join [Entity.Property] c on b.id = c.EntityId
   inner join [codes.propertyValue] d on c.propertyValueId = d.Id
 WHERE d.CategoryId = 84
--and a.EntityStateId = 3
and Isnull(a.LifeCycleStatusTypeId,0) = 0
GO
--set references and pending to active
UPDATE [dbo].Organization
   SET LifeCycleStatusTypeId = d.Id
--	select a.Id, a.Name, a.EntityStateId, d.Id, d.Title
   from [dbo].Organization a
   left join [codes.propertyValue] d on d.Title = 'Active'
 WHERE d.CategoryId = 84
and a.EntityStateId in (1,2)
and Isnull(a.LifeCycleStatusTypeId,0) = 0
GO
