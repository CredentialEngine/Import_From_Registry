-- 22-07-09 added LifeCycleStatusTypeId to collection, and transferValueProfile


--=============================================================

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.Collection ADD
	LifeCycleStatusTypeId int NOT NULL CONSTRAINT DF_Collection_LifeCycleStatusTypeId DEFAULT 0
GO
ALTER TABLE dbo.Collection SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO
--set ALL to active
UPDATE [dbo].Collection
   SET LifeCycleStatusTypeId = d.Id
--	select a.Id, a.Name, a.EntityStateId, d.Id, d.Title
   from [dbo].Collection a
   left join [codes.propertyValue] d on d.Title = 'Active'
 WHERE d.CategoryId = 84
and a.EntityStateId in (1,2,3)
and Isnull(a.LifeCycleStatusTypeId,0) = 0
GO

--=============================================================

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.TransferValueProfile ADD
	LifeCycleStatusTypeId int NOT NULL CONSTRAINT DF_TransferValueProfile_LifeCycleStatusTypeId DEFAULT 0
GO
ALTER TABLE dbo.TransferValueProfile SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO
--set ALL to active
UPDATE [dbo].TransferValueProfile
   SET LifeCycleStatusTypeId = d.Id
--	select a.Id, a.Name, a.EntityStateId, d.Id, d.Title
   from [dbo].TransferValueProfile a
   left join [codes.propertyValue] d on d.Title = 'Active'
 WHERE d.CategoryId = 84
and a.EntityStateId in (1,2,3)
and Isnull(a.LifeCycleStatusTypeId,0) = 0
GO
