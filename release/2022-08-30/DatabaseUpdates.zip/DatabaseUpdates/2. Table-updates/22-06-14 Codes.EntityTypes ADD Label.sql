
/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Codes.EntityTypes] ADD
	Label varchar(100) NULL
GO
ALTER TABLE dbo.[Codes.EntityTypes] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
go

--22-06-14 Codes.EntityTypes ADD Label

Update [Codes.EntityTypes]
set Label = title


/*
--use description if previously changed to be used for display
Update [Codes.EntityTypes]
set Label = Description
where len(Description) < 100

*/