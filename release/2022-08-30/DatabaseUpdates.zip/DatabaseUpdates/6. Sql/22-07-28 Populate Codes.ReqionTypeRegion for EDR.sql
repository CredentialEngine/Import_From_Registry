

/*
22-07-28 Populate Codes.ReqionTypeRegion for Illinois EDR

EDR 1 - Central (PDF)
EDR 2 - East Central (PDF)
EDR 3 - North Central (PDF)
EDR 4 - Northeast (PDF)
EDR 5 - Northern Stateline (PDF)
EDR 6 - Northwest (PDF)
EDR 7 - Southeast (PDF)
EDR 8 - Southern (PDF)
EDR 9 - Southwest (PDF)
EDR 10 West Central (PDF)

*/
INSERT INTO [dbo].[Codes.ReqionType]
           ([Id]
           ,[Name]
           ,[Description]
           ,[IsActive])
     VALUES
           (2
           ,'EDR'
           ,'Illinois Economic Development Regions'
           ,1)
GO



--=========================
INSERT INTO [dbo].[Codes.ReqionTypeRegion]
           ([RegionTypeId] ,[Name] ,[Value] ,[IsActive] ,[Created])
     VALUES (2 ,'Central (PDF)' ,'1' ,1 ,GETDATE())
GO

INSERT INTO [dbo].[Codes.ReqionTypeRegion]
           ([RegionTypeId] ,[Name] ,[Value] ,[IsActive] ,[Created])
     VALUES (2 ,'East Central (PDF)' ,'2' ,1 ,GETDATE())
GO

INSERT INTO [dbo].[Codes.ReqionTypeRegion]
           ([RegionTypeId] ,[Name] ,[Value] ,[IsActive] ,[Created])
     VALUES (2 ,'North Central (PDF)' ,'3' ,1 ,GETDATE())
GO

INSERT INTO [dbo].[Codes.ReqionTypeRegion]
           ([RegionTypeId] ,[Name] ,[Value] ,[IsActive] ,[Created])
     VALUES (2 ,'Northeast (PDF)' ,'4' ,1 ,GETDATE())
GO

INSERT INTO [dbo].[Codes.ReqionTypeRegion]
           ([RegionTypeId] ,[Name] ,[Value] ,[IsActive] ,[Created])
     VALUES (2 ,'Northern Stateline (PDF)' ,'5' ,1 ,GETDATE())
GO

INSERT INTO [dbo].[Codes.ReqionTypeRegion]
           ([RegionTypeId] ,[Name] ,[Value] ,[IsActive] ,[Created])
     VALUES (2 ,'Northwest (PDF)' ,'6' ,1 ,GETDATE())
GO

INSERT INTO [dbo].[Codes.ReqionTypeRegion]
           ([RegionTypeId] ,[Name] ,[Value] ,[IsActive] ,[Created])
     VALUES (2 ,'Southeast (PDF)' ,'7' ,1 ,GETDATE())
GO

INSERT INTO [dbo].[Codes.ReqionTypeRegion]
           ([RegionTypeId] ,[Name] ,[Value] ,[IsActive] ,[Created])
     VALUES (2 ,'Southern (PDF)' ,'8' ,1 ,GETDATE())
GO

INSERT INTO [dbo].[Codes.ReqionTypeRegion]
           ([RegionTypeId] ,[Name] ,[Value] ,[IsActive] ,[Created])
     VALUES (2 ,'Southwest (PDF)' ,'9' ,1 ,GETDATE())
GO

INSERT INTO [dbo].[Codes.ReqionTypeRegion]
           ([RegionTypeId] ,[Name] ,[Value] ,[IsActive] ,[Created])
     VALUES (2 ,'West Central (PDF)' ,'10' ,1 ,GETDATE())
GO
