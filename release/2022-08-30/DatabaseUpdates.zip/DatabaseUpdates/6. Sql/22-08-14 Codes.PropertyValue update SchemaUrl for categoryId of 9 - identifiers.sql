

-- 22-08-14 Codes.PropertyValue update SchemaUrl for categoryId of 9 - identifiers
/****** 
SELECT TOP (1000) [Id]
      ,[CategoryId]
      ,[Title]
      ,[Description]
      ,[SortOrder]
      ,[IsActive]
      ,[SchemaName]
      ,[SchemaUrl]

  FROM [dbo].[Codes.PropertyValue]
  where categoryid = 9
  order by sortorder , [SchemaName]
  go

   ******/


UPDATE [dbo].[Codes.PropertyCategory]
   SET [Description] = 'Organizaton identifiers including: DUNS, FEIN, IPEDS, ISICV4, Legal Entity Identifier Code, NCES ID, and OPE ID'
 WHERE Id=9
GO




UPDATE [dbo].[Codes.PropertyValue]
   SET [SchemaUrl] = 'https://credreg.net/ctdl/terms/duns'
 WHERE [SchemaName]='ceterms:duns'
GO


UPDATE [dbo].[Codes.PropertyValue]
   SET [SchemaUrl] = 'https://credreg.net/ctdl/terms/fein'
 WHERE [SchemaName]='ceterms:fein'
GO

UPDATE [dbo].[Codes.PropertyValue]
   SET [SchemaUrl] = 'https://credreg.net/ctdl/terms/ipedsID'
 WHERE [SchemaName]='ceterms:ipedsID'
GO

UPDATE [dbo].[Codes.PropertyValue]
   SET [SchemaUrl] = 'https://credreg.net/ctdl/terms/isicV4'
 WHERE [SchemaName]='ceterms:isicv4'
GO

UPDATE [dbo].[Codes.PropertyValue]
   SET [SchemaUrl] = 'https://credreg.net/ctdl/terms/leiCode'
 WHERE [SchemaName]='ceterms:leiCode'
GO
UPDATE [dbo].[Codes.PropertyValue]
   SET [SchemaUrl] = 'https://credreg.net/ctdl/terms/ncesID'
 WHERE [SchemaName]='ceterms:ncesID'
GO


UPDATE [dbo].[Codes.PropertyValue]
   SET [SchemaUrl] = 'https://credreg.net/ctdl/terms/opeID', Title = 'OPE ID'
 WHERE [SchemaName]='ceterms:opeID'
GO


