
/*
NOTE run this script after adding entityTypeId to the organization and conceptScheme tables (these should already be present)
	- 22-05-09 Organization ADD EntityTypeId

New EntityTypesId are being added for 
- QACredentialOrganization (13)
- Organization (14)
- ProgressionModel (12)

For convenience (and probably will not do this type of rearrangement of entity type ids again), we renumbered some of the non-top level entities to keep the top level entities more closely numbered. 
This resulted in (and the purpose of this script):
- renumbering (actually copying first to avoid problems with Referential Integritry)
	- 12 (RevocationProfile)	to 40
	- 13 (VerificationProfile)	to 41
	- 14 (ProcessProfile)		to 42
	- 15 (ContactPoint)			to 43
- updating the Entity.EntityTypeId values for the latter
- updating the orginal [Codes.EntityTypes] with the new values.
- note 15 has not been reassigned yet
- update the triggers for the tables related to the change in the entityTypeId numbers
- update the entityTypeId from the default for the table as needed
- remove '_copy' from then copied [Codes.EntityTypes] (this was necessary to avoid an error on a unique index)

*/

		

-- =================================================================
--move RevocationProfile

--just in case
delete [dbo].[Codes.EntityTypes] where id in (40,41,42,43)
go

INSERT INTO [dbo].[Codes.EntityTypes]
           ([Id],[Title],[Description],[IsActive],[SchemaName],[Created],[SortOrder],[Totals],[IsTopLevelEntity],[Label])

SELECT 40      ,[Title]  + '_copy'      ,[Description],[IsActive],[SchemaName],[Created],[SortOrder],[Totals], [IsTopLevelEntity],[Label]
  FROM [dbo].[Codes.EntityTypes]
  where id = 12

GO

--move VerificationProfile
INSERT INTO [dbo].[Codes.EntityTypes]
           ([Id],[Title],[Description],[IsActive],[SchemaName],[Created],[SortOrder],[Totals],[IsTopLevelEntity],[Label])

SELECT 41      ,[Title]  + '_copy'      ,[Description],[IsActive],[SchemaName],[Created],[SortOrder],[Totals], [IsTopLevelEntity],[Label]
  FROM [dbo].[Codes.EntityTypes]
  where id = 13

GO
--move ProcessProfile
INSERT INTO [dbo].[Codes.EntityTypes]
           ([Id],[Title],[Description],[IsActive],[SchemaName],[Created],[SortOrder],[Totals],[IsTopLevelEntity],[Label])

SELECT 42      ,[Title]  + '_copy'      ,[Description],[IsActive],[SchemaName],[Created],[SortOrder],[Totals], [IsTopLevelEntity],[Label]
  FROM [dbo].[Codes.EntityTypes]
  where id = 14

GO
--move ContactPoint
INSERT INTO [dbo].[Codes.EntityTypes]
           ([Id],[Title],[Description],[IsActive],[SchemaName],[Created],[SortOrder],[Totals],[IsTopLevelEntity],[Label])

SELECT 43      ,[Title]  + '_copy'      ,[Description],[IsActive],[SchemaName],[Created],[SortOrder],[Totals], [IsTopLevelEntity],[Label]
  FROM [dbo].[Codes.EntityTypes]
  where id = 15

GO
-- ==================================================================================
-- update Entity.EntityTypeId
-- ==================================================================================

UPDATE [dbo].[Entity]
   SET [EntityTypeId] = 40
 WHERE [EntityTypeId]=12
GO

UPDATE [dbo].[Entity]
   SET [EntityTypeId] = 41
 WHERE [EntityTypeId]=13
GO

UPDATE [dbo].[Entity]
   SET [EntityTypeId] = 42
 WHERE [EntityTypeId]=14
GO

UPDATE [dbo].[Entity]
   SET [EntityTypeId] = 43
 WHERE [EntityTypeId]=15
GO

-- ==================================================================================
-- Replace existing with new org types (And late addition of ProgressionModel)
-- ==================================================================================
UPDATE [dbo].[Codes.EntityTypes]
   SET title= 'ProgressionModel', 
   Description= 'Progression Model'
   ,Label= 'Progression Model'
   ,SchemaName='ceterms:ProgressionModel'
   ,IsTopLevelEntity=1
   ,Totals=0
 WHERE [Id]=12
GO
UPDATE [dbo].[Codes.EntityTypes]
   SET title= 'QAOrganization',
   Description= 'Quality Assurance Organization'
   , Label= 'Quality Assurance Organization'
    ,SchemaName='ceterms:QACredentialOrganization'
	,IsTopLevelEntity=1
	,Totals=0
 WHERE [Id]=13
GO
UPDATE [dbo].[Codes.EntityTypes]
   SET title= 'Credential Organization'
   ,label= 'Credential Organization'
    ,SchemaName='ceterms:CredentialOrganization'

 WHERE [Id]=2
GO

UPDATE [dbo].[Codes.EntityTypes]
   SET title= 'Organization'
   ,  Description= 'An entity such as an association, company, corporation, club, co-operative, labor union etc.'
   ,Label= 'Organization'
    ,SchemaName='ceterms:Organization'
		,IsTopLevelEntity=1
	,Totals=0
 WHERE [Id]=14
GO


UPDATE [dbo].[Codes.EntityTypes]
   SET title= 'TBD'
   ,  Label= 'TBD'
   ,  Description= 'TBD'
   ,SchemaName='ceterms:TBD'
		,IsTopLevelEntity=0
			,IsActive=0
	,Totals=0
	,Created=GETDATE()
 WHERE [Id]=15
GO



-- ==================================================================================
-- update insert triggers for moved entity types
-- ==================================================================================

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--RevocationProfile =============================================
ALTER TRIGGER [dbo].[trgEntityRevocationProfileAfterInsert] ON  [dbo].[Entity.RevocationProfile]
FOR INSERT
AS  
    INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
          ,[Created]
					 ,EntityBaseId, EntityBaseName)
    SELECT RowId,40, getdate(), Id, isnull(ProfileName,'RevocationProfile')
    FROM inserted;
go



--VerificationProfile =============================================
ALTER TRIGGER [dbo].[trgEntityVerificationProfileAfterInsert] ON  [dbo].[Entity.VerificationProfile]
FOR INSERT
AS  
    INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
					 ,EntityBaseId, EntityBaseName)
    SELECT RowId,41, getdate(), Id, NULL
	FROM inserted;
GO

--ProcessProfile =============================================
ALTER TRIGGER [dbo].[trgEntityProcessProfileAfterInsert] ON  [dbo].[Entity.ProcessProfile]
FOR INSERT
AS  
    INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
            ,[Created]
					 ,EntityBaseId, EntityBaseName)
    SELECT RowId,42, getdate(), Id, NULL
    FROM inserted;
GO



--ContactPoint =============================================
ALTER TRIGGER [dbo].[trgEntityContactPointAfterInsert] ON  [dbo].[Entity.ContactPoint]
FOR INSERT
AS  
    INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
					 ,EntityBaseId
					 ,EntityBaseName)
    SELECT RowId,43, getdate(), 
				Id, 
				case 
					when len(isnull(Name,'')) > 0 then Name 
					when len(isnull(ContactType,'')) > 0 then ContactType 
					when len(isnull(ContactOption,'')) > 0 then ContactOption 
					else 'Contact Point' end
    FROM inserted;
GO

-- === convertions	====================================
-- org
  update [Organization]
  set EntityTypeId=13
  where ISQAOrganization = 1
go
  -- concept scheme
update [ConceptScheme]
  set EntityTypeId=12
  where [IsProgressionModel] = 1
go


-- ===================================
--revert copy name

UPDATE [dbo].[Codes.EntityTypes]
   SET title= Replace(title, '_copy','')

 WHERE title like '%_copy'
GO