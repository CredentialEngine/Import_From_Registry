/****** Codes.EntityTypes- update sort order ******/
SELECT TOP (1000) [Id]
      ,[Title]      ,[SortOrder]
      ,[Label]
      ,[Description]
      ,[IsActive]
      ,[SchemaName]
      ,[Created]
      ,[Totals]

      ,[IsTopLevelEntity]
  FROM [dbo].[Codes.EntityTypes]
  order by [SortOrder], Title
  go

  update [Codes.EntityTypes]
  set SortOrder = Id
  where IsTopLevelEntity = 1
  go
  
  update [Codes.EntityTypes]
  set SortOrder = 50
  where IsTopLevelEntity = 0
