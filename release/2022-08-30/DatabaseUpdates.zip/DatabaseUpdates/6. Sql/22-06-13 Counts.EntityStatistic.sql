
/*
- updates to Counts.EntityStatistic

*/
-- update description 
UPDATE [dbo].[Counts.EntityStatistic]
   SET [Description] = 'The resource has Outcome data from an Aggregate Data Profile or a DataSet Profile.'
 WHERE [Title]='Has Outcome Data'
GO

-- Add new row for asmtReport:HasOutcomeData

INSERT INTO [dbo].[Counts.EntityStatistic]
           ([Id]
           ,[EntityTypeId]
           ,[CategoryId]
           ,[Title]
           ,[Description]
           ,[SortOrder]
           ,[IsActive]
           ,[SchemaName]
           ,[Totals]
           ,[Created])
     VALUES
           (135
           ,3
           ,60
           ,'Has Outcome Data'
           ,'The resource has Outcome data from an Aggregate Data Profile or a DataSet Profile.'
           ,25
           ,1
           ,'asmtReport:HasOutcomeData'
           ,0
           ,GETDATE())
GO


UPDATE [dbo].[Counts.EntityStatistic]
   SET IsActive=0
 where title like 'is availabl%'
GO

	
UPDATE [dbo].[Counts.EntityStatistic]
   SET Title='Has Cost(s)'
 where title like 'Has Cost Profile(s)'
GO


	
UPDATE [dbo].[Counts.EntityStatistic]
   SET Title='Has Time Estimate(s)'
 where title like 'Has Duration Profile'
GO
