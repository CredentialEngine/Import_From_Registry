
/****** Object:  Trigger [dbo].[trgOrganizationAfterInsert]    Script Date: 8/17/2017 3:03:56 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
Modifcations
22-05-10 mparsons - updates to use the actual org.EntityTypeId for entity. 
22-07-07 mparsons - went back to single, as many unexpected problems/dependencies

*/
Alter TRIGGER [dbo].[trgOrganizationAfterInsert] ON  [dbo].[Organization]
FOR INSERT
AS  
    INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
					 ,EntityBaseId, EntityBaseName)
    SELECT RowId, 2, getdate(), Id, Name
    FROM inserted;

GO


