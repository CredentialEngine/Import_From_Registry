
-- 22-08-31 DROP TRIGGER trgEntityAfterInsert

/****** Object:  Trigger [trgEntityAfterInsert]    Script Date: 8/31/2022 9:38:35 AM ******/
DROP TRIGGER [dbo].[trgEntityAfterInsert]
GO


