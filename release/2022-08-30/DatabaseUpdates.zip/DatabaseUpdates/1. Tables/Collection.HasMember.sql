
/****** Object:  Table [dbo].[Collection.HasMember]    Script Date: 4/15/2022 4:56:24 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
HasMember can refer to a competency. This competency can be in a framework?
- would it be useful to include the EntityTypeId?

DROP TABLE [dbo].[Collection.HasMember]
*/


CREATE TABLE [dbo].[Collection.HasMember](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[CollectionId] [int] NOT NULL,
	[EntityTypeId] [int] NOT NULL,
	[MemberUID] [uniqueidentifier] NOT NULL,
	[Created] [datetime] NULL,
 CONSTRAINT [PK_Collection.HasMember] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Collection.HasMember] ADD  CONSTRAINT [DF_Collection.HasMember_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Collection.HasMember]  WITH CHECK ADD  CONSTRAINT [FK_Collection.HasMember_Codes.EntityTypes] FOREIGN KEY([EntityTypeId])
REFERENCES [dbo].[Codes.EntityTypes] ([Id])
GO

ALTER TABLE [dbo].[Collection.HasMember] CHECK CONSTRAINT [FK_Collection.HasMember_Codes.EntityTypes]
GO

ALTER TABLE [dbo].[Collection.HasMember]  WITH CHECK ADD  CONSTRAINT [FK_Collection.HasMember_Collection] FOREIGN KEY([CollectionId])
REFERENCES [dbo].[Collection] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Collection.HasMember] CHECK CONSTRAINT [FK_Collection.HasMember_Collection]
GO



