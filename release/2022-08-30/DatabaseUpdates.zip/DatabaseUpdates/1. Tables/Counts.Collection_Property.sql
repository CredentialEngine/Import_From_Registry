USE [sandbox_credFinder]
GO

/****** Object:  Table [dbo].[Counts.Collection_Property]    Script Date: 8/8/2022 4:22:55 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Counts.Collection_Property](
	[Id] [int] NOT NULL,
	[Property] [nvarchar](128) NOT NULL,
	[Label] [varchar](100) NULL,
	[Policy] [varchar](50) NULL,
	[PropertyGroup] [varchar](50) NULL,
	[Total] [int] NOT NULL,
	[PercentOfOverallTotal] [decimal](5, 2) NOT NULL
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Counts.Collection_Property] ADD  CONSTRAINT [DF_Counts.Collection_Property_PercentOfTotal]  DEFAULT ((0.00)) FOR [PercentOfOverallTotal]
GO


