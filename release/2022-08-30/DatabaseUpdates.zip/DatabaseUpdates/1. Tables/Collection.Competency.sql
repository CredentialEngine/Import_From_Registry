

/****** Object:  Table [dbo].[Collection.Competency]    Script Date: 6/7/2022 9:47:35 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
Would it be better to have a stand alone competency table?
- Then Collection.Competency and CompetencyFramework.Competency would just be parentId, and competency CTID (although have handle competencies without CTIDs/frameworks)
- would also more easily enable sharing?
- Or can Entity.Competency be used as the general table?

*/
CREATE TABLE [dbo].[Collection.Competency](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[CollectionId] [int] NOT NULL,
	[CompetencyText] [nvarchar](max) NOT NULL,
	[CTID] [varchar](50) NULL,
	[CompetencyCategory] [varchar](300) NULL,
	[CompetencyLabel] [nvarchar](300) NULL,
	[CredentialRegistryURI] [varchar](500) NULL,
	[Created] [datetime] NULL,
	[RowId] [uniqueidentifier] NOT NULL,
	[LastUpdated] [datetime] NULL,
	[CompetencyDetailJson] [varchar](max) NULL,
 CONSTRAINT [PK_Collection.Competency] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[Collection.Competency] ADD  CONSTRAINT [DF_Collection.Competency_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Collection.Competency] ADD  CONSTRAINT [DF_Collection.Competency_RowId]  DEFAULT (newid()) FOR [RowId]
GO

ALTER TABLE [dbo].[Collection.Competency] ADD  CONSTRAINT [DF_Collection.Competency_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO

ALTER TABLE [dbo].[Collection.Competency]  WITH CHECK ADD  CONSTRAINT [FK_Collection.Competency_Collection] FOREIGN KEY([CollectionId])
REFERENCES [dbo].[Collection] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Collection.Competency] CHECK CONSTRAINT [FK_Collection.Competency_Collection]
GO


