

/*
select * from [Codes.EntityTypes]
order by 1


exec [CodesEntityTypes_UpdateTotals]

Update the entity totals for Codes.EntityTypes.

Modifications
21-05-24 mparsons	- New
21-11-24 mparsons - why is competency framework excluded?
	- perhaps should split up and not use entity_summary?
	- need to accomodate spliting lopp up based on lopp.EntityTypeId. Should there be a specific Entity.EntityTypeId?
21-11-30 mparsons - split out the lopp related entities
22-08-07 mparsons - Need to keep separate totals for course, learning programs, QA org and org, to enable showing related filters for the search
					- also need to do something similar for org classes


********** IS Entity_Cache really dependable???
- or just do one at time
*/
Alter  Procedure [dbo].[CodesEntityTypes_UpdateTotals]
    @debugLevel int = 0

AS

--=== all top level except lopps ===
UPDATE [dbo].[Codes.EntityTypes]
   SET [Totals] = isnull(base.Totals,0)
from [Codes.EntityTypes] codes
Inner join ( 
SELECT tags.EntityTypeId,count(*) AS Totals
  FROM [dbo].[Entity] tags			--Entity.EntityTypeId is now always the top level type. So can't use with resources that have sub classes
  inner join [Codes.EntityTypes] b on tags.EntityTypeId = b.Id  

  inner join Entity_Cache e on tags.Id = e.Id
	 -- and e.EntityTypeId in (1,2,3,8,9,10, 11,19,20,23,24, 26, 31, 32,33,34,35) --update Entity_Summary to include 27, or use alternate (better) means to get total 
	 -- and Len(isnull(e.ctid,'')) > 10
	  where b.IsTopLevelEntity = 1
	  AND	e.EntityStateId = 3
	  and	e.EntityTypeId NOT in (2, 7, 13,14,36,37) 
	  --and e.EntityTypeId NOT in (7, 36,37) 
  group by tags.EntityTypeId
 --order by tags.EntityTypeId
    ) base on codes.Id = base.EntityTypeId
where codes.IsActive = 1

-- ====================================================================
-- ORGANIZATIONs
-- Entity for QAOrg, org etc, will be 2, not 13.14, so do separately
-- ====================================================================
UPDATE [dbo].[Codes.EntityTypes]
   SET [Totals] = isnull(base.Totals,0)
from [Codes.EntityTypes] codes
Inner join ( 
SELECT e.EntityTypeId, count(*) AS Totals
  FROM Organization e 
where  e.EntityTypeId in (13,14) 
and e.EntityStateId = 3
	  --and Len(isnull(e.ctid,'')) > 10
group by e.EntityTypeId
    ) base on codes.Id = base.EntityTypeId
where codes.IsActive = 1

-- *** organization totals ***
-- 22-08-07 - Add combined totals for orgs
UPDATE [dbo].[Codes.EntityTypes]
   SET [Totals] = isnull(base.Totals,0)
from [Codes.EntityTypes] codes
Inner join ( 
SELECT count(*) AS Totals
  FROM Organization e 
where  e.EntityTypeId in (2,13,14) 
and e.EntityStateId = 3
  --group by e.EntityTypeId
    ) base on codes.Id = 2	-- base.EntityTypeId
where codes.IsActive = 1

-- ====================================================================
--			Learning Opportunities
-- Entity for courses etc, will be 7, not 37, so do separately
-- ====================================================================
UPDATE [dbo].[Codes.EntityTypes]
   SET [Totals] = isnull(base.Totals,0)
from [Codes.EntityTypes] codes
Inner join ( 
SELECT e.EntityTypeId, count(*) AS Totals
  FROM LearningOpportunity e 
where  e.EntityTypeId in (36,37) 
and e.EntityStateId = 3
	  --and Len(isnull(e.ctid,'')) > 10
group by e.EntityTypeId
    ) base on codes.Id = base.EntityTypeId
where codes.IsActive = 1

-- ==== lopp types =================================
-- TODO do we want all lopp types in one total, or have separate counts on the home page? 
--		The reports registry data page should change: separate sections or have a sub-section under lopps for lopp classes, etc.?
-- 22-06-14 - combining all under lopp
-- 22-08-07 - the latter results in a zero for the course count. The learning type filters show on the lopp page based on a count for Courses?
--		- realistically we want separate totals and should only combine for the home page or a faux property?

UPDATE [dbo].[Codes.EntityTypes]
   SET [Totals] = isnull(base.Totals,0)
from [Codes.EntityTypes] codes
Inner join ( 
SELECT count(*) AS Totals
  FROM LearningOpportunity e 
where  e.EntityTypeId in (7, 36,37) 
and e.EntityStateId = 3
	  --and Len(isnull(e.ctid,'')) > 10
  --group by e.EntityTypeId
    ) base on codes.Id = 7	-- base.EntityTypeId
where codes.IsActive = 1


go

grant execute on [CodesEntityTypes_UpdateTotals] to public
go

