
/*
[Entity_Cache_PopulateDataSetProfile]

*/
Create Procedure [dbo].[Entity_Cache_PopulateDataSetProfile]
AS

	 Begin
	print 'deleting dataset profiles'
	delete from  [Entity_Cache] where entityTypeId = 31
	print 'inserting dataset profiles'
	INSERT INTO [dbo].[Entity_Cache]
           ([Id]
           ,[EntityTypeId]
           ,[EntityType]
           ,[EntityUid]
           ,[parentEntityId]
           ,[parentEntityUid]
           ,[parentEntityType]
           ,[parentEntityTypeId]
           ,[BaseId]
           ,[Name]
           ,[Description]
		   ,OwningOrgId
			,SubjectWebpage
			,CTID
			,ImageUrl
			,EntityStateId
           ,[Created]
           ,[LastUpdated]
		   --,PublishedByOrgId
		   )

SELECT b.[Id] as EntityId
		,31
		,'DataSetProfile' as [EntityType]
		,a.RowId
		,0 as [parentEntityId]
		,NULL
		,'' as [parentEntityType]
		,0 as [parentEntityTypeId]
		,a.[Id]
		,a.[Name]
		,a.[Description]
		,a.Id as OwningOrgId
		,a.Source As SubjectWebpage
		,a.CTID
		,'' as ImageUrl
		,a.EntityStateId
		,a.[Created] ,a.[LastUpdated]
		--,a.PublishedByOrgId
FROM [dbo].DataSetProfile a
Inner join [Entity] b on a.RowId = b.EntityUid
Left Join Organization o on a.DataProviderUID = o.RowId
where a.EntityStateId = 3
	Order by Id
	End
go
grant execute on Entity_Cache_PopulateDataSetProfile to public
go

