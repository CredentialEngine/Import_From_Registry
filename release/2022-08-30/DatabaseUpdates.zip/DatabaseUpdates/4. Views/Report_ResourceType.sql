
/*
Reports_ResourceType - view of all top level full resources

*/
Alter View [dbo].[Reports_ResourceType]
 as 
SELECT distinct Publisher
	,PublisherCTID
	,Organization
	,OrganizationCTID
	,ES.Title as EntityType
	,EntityTypeId
	,Name
	,CTID
	,LastUpdated
	,SubjectWebpage
	,c.Description
  FROM [dbo].[Entity_CacheSummary] as c
  inner join [dbo].[Codes.EntityTypes] ES on c.EntityTypeId=ES.Id
  Where ES.IsTopLevelEntity=1
go
grant select on Reports_ResourceType to public
go