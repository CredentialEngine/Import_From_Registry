

/****** Object:  View [dbo].[PathwaySummary]    Script Date: 12/16/2020 1:11:13 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*

SELECT [Id]
      ,[RowId]
      ,[CTID]
      ,[Description]
      ,[EntityStateId]
      ,[SubjectWebpage]
      ,[OwningAgentUid]
      ,[OrganizationId]
      ,[OrganizationName]
      ,[OrganizationCTID]
      ,[CredentialRegistryId]
      ,[EntityLastUpdated]
      ,[Created]
      ,[LastUpdated]

  FROM [dbo].[PathwaySummary]

GO




*/
Alter VIEW [dbo].[PathwaySummary]
AS

SELECT a.[Id]
	,a.[RowId]
	,a.[CTID]
	,a.[Name]
	,a.[Description]
	,a.[EntityStateId]
	,a.[SubjectWebpage]
	,a.[OwningAgentUid]
	,b.Id as OrganizationId
	,b.Name      as OrganizationName
	,b.CTID as OrganizationCTID
	,a.[CredentialRegistryId]
	,a.hasProgressionModel
	--,isnull(statusProperty.Property,'') As LifeCycleStatusType
	--,isnull(statusProperty.PropertyValueId,'') As LifeCycleStatusTypeId
	,c.LastUpdated as EntityLastUpdated
	,a.[Created]
	,a.[LastUpdated]
	  --

  FROM [dbo].[Pathway] a
Left join dbo.Organization b on a.OwningAgentUid = b.RowId
INNER JOIN dbo.Entity AS c ON a.RowId = c.EntityUid
--Left Join EntityProperty_Summary	statusProperty on a.RowId = statusProperty.EntityUid and statusProperty.CategoryId = 84


GO
grant select on [PathwaySummary] to public
go

