

/****** Object:  View [dbo].[Entity_Summary]    Script Date: 7/26/2017 10:52:55 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*

SELECT [Id]
      ,[EntityTypeId]
      ,[EntityType]
      ,[EntityUid]
      ,[parentEntityId]
      ,[parentEntityUid]
      ,[parentEntityType]
      ,[parentEntityTypeId]
      ,[BaseId]
      ,[Name]
      ,[Description]
      ,[Created]
      ,[LastUpdated]
      ,[OwningOrgId]
      ,[OwningOrganization]
      ,[SubjectWebpage]
      ,[ImageUrl]
      ,[CTID]
      ,[EntityStateId]
  FROM [dbo].[Entity_Summary]
  where EntityTypeId= 3
GO




where id = 334


 -- where parententityuid = 'C10E0233-16E9-4790-9F77-AC4C0A33E901'
order by 
      [EntityType]
      ,[Name]


*/
/*
Modifications
17-08-22 mparsons - added to workIT
20-04-20 mparsons - replace EducationFrameworks with CompetencyFrameworks
21-05-29 mparsons - add OccupationProfile, JobProfile
21-11-24 mparsons - updated to use specific entityTypeIds for lopp classes - need to test implications
22-02-23 mparsons - Added collection. For credential, removed the inner join to credential type. 
22-03-01 mparsons - Added transfer intermediary
22-06-01 mparsons - now excluding non-top level resources
22-06-14 mparsons - added dataSet profile
22-07-07 mparsons - need to distinguish between the base type and a subtype. Use the base type (i.e. 7 for lopps) for main reporting
***** trying to move away from using this. Though may be useful for a full build ****
***** can we get rid of the non top level resources (ex. condition profiles, addresses)
*/
Alter VIEW [dbo].[Entity_Summary]
AS
SELECT        
-- Credential  --------------------------------------------
Isnull(e.Id, -1) As Id, e.EntityTypeId,  e.EntityTypeId As EntitySubTypeId, cet.Title AS EntityType, e.EntityUid
,0 as parentEntityId, null As parentEntityUid, '' as parentEntityType,  0 as parentEntityTypeId,
 
base.Id as BaseId,
IsNull(base.Name,'') As Name,  IsNull(base.Description,'') As Description
,base.Created, e.LastUpdated
,isnull(o.Id,0) as OwningOrgId
,isnull(o.Name,0) as OwningOrganization
,isnull(base.SubjectWebpage,'') As SubjectWebpage
,isnull(base.ImageUrl,'') As ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,base.PublishedByOrgId
FROM dbo.Entity e -- entity for the base
INNER JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.Credential base				ON e.EntityUid = base.RowId
Left Join Organization o on base.OwningAgentUid = o.RowId
--Inner join [Codes.PropertyValue] credTypeProperty on base.CredentialTypeId = credTypeProperty.Id 
where base.EntityStateId > 1
--20-08-23 mp - start including these now
--AND isnull(credTypeProperty.SchemaName,'') <> 'ceterms:QualityAssuranceCredential'

UNION
SELECT        
-- Organization --------------------------------------------
e.Id, e.EntityTypeId,  base.EntityTypeId As EntitySubTypeId, cet.Title AS EntityType, e.EntityUid
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType,0 as parentEntityTypeId,

base.Id as BaseId,
IsNull(base.Name,'') As Name,  IsNull(base.Description,'') As Description
,base.Created,  e.LastUpdated
,base.Id as OwingOrgId
,isnull(base.Name,'') as OwningOrganization
,isnull(base.SubjectWebpage,'') As SubjectWebpage
,isnull(base.ImageUrl,'') As ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,base.PublishedByOrgId
FROM dbo.Entity e		-- entity for the base
INNER JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.Organization base			ON e.EntityUid = base.RowId
where base.EntityStateId > 1

UNION
-- Assessment --------------------------------------------
SELECT        
e.Id, e.EntityTypeId,  e.EntityTypeId As EntitySubTypeId, 'Assessment' AS EntityType, e.EntityUid
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType, 0 as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  IsNull(base.Description,'') As Description

,base.Created, e.LastUpdated
,isnull(o.Id,0) as OwningOrgId
,isnull(o.Name,0) as OwningOrganization
,isnull(base.SubjectWebpage,'') As SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,base.PublishedByOrgId
FROM dbo.Entity e -- entity for the base
INNER JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.Assessment base				ON e.EntityUid = base.RowId
Left Join Organization o on base.OwningAgentUid = o.RowId
where base.EntityStateId > 1
UNION
-- LearningOpportunity --------------------------------------------
SELECT        
e.Id, e.EntityTypeId,  base.EntityTypeId As EntitySubTypeId, cet.Title  AS EntityType, e.EntityUid 
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType, 0 as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  IsNull(base.Description,'') As Description

,base.Created, e.LastUpdated 
,isnull(o.Id,0) as OwningOrgId
	,isnull(o.Name,0) as OwningOrganization
,isnull(base.SubjectWebpage,'') As SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,base.PublishedByOrgId
FROM dbo.Entity e -- entity for the base
INNER JOIN dbo.LearningOpportunity base		ON e.EntityUid = base.RowId
INNER JOIN dbo.[Codes.EntityTypes]	cet		ON base.EntityTypeId = cet.Id 
Left Join Organization o on base.OwningAgentUid = o.RowId
where base.EntityStateId > 1

UNION
-- ConditionManifest --------------------------------------------
SELECT        
e.Id, e.EntityTypeId,  e.EntityTypeId As EntitySubTypeId, 'ConditionManifest' AS EntityType, e.EntityUid 
, 0 as parentEntityId, o.EntityUid As parentEntityUid, 'Organization' as parentEntityType, o.EntityTypeId as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  IsNull(base.Description,'') As Description

,base.Created, e.LastUpdated
,base.OrganizationId as OwningOrgId
	,isnull(o.EntityBaseName,0) as OwningOrganization
,isnull(base.SubjectWebpage,'') As SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,0 as PublishedByOrgId
FROM dbo.Entity e -- entity for the base
INNER JOIN dbo.[Codes.EntityTypes]	cet		ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.ConditionManifest base		ON e.EntityUid = base.RowId
Left Join dbo.Entity o on base.OrganizationId = o.EntityBaseId and o.EntityTypeId = 2
where base.EntityStateId > 1

UNION
-- CostManifest --------------------------------------------
SELECT        
e.Id, e.EntityTypeId,  e.EntityTypeId As EntitySubTypeId, 'CostManifest' AS EntityType, e.EntityUid 
, 0 as parentEntityId, o.EntityUid As parentEntityUid, 'Organization' as parentEntityType, o.EntityTypeId as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  IsNull(base.Description,'') As Description

,base.Created, e.LastUpdated
,base.OrganizationId as OwningOrgId
,isnull(o.EntityBaseName,0) as OwningOrganization
,base.CostDetails As SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,0 as PublishedByOrgId
FROM dbo.Entity e -- entity for the base
INNER JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.CostManifest base			ON e.EntityUid = base.RowId
Left Join dbo.Entity o on base.OrganizationId = o.EntityBaseId and o.EntityTypeId = 2
where base.EntityStateId > 1

UNION
-- Competency Framework --------------------------------------------
SELECT        
e.Id, e.EntityTypeId,  e.EntityTypeId As EntitySubTypeId, 'CompetencyFramework' AS EntityType, e.EntityUid 
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType, 0 as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  '' As Description

,base.Created, e.LastUpdated
,isnull(o.Id,0) as OwningOrgId
,isnull(o.Name,0) as OwningOrganization
,base.FrameworkUri As SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,base.PublishedByOrgId
FROM dbo.Entity e -- entity for the base
Left JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
--INNER JOIN dbo.[EducationFramework] base			ON e.EntityUid = base.RowId
INNER JOIN dbo.CompetencyFramework base			ON e.EntityUid = base.RowId
Left Join Organization o on base.OrganizationCTID = o.CTID
where base.EntityStateId > 1

UNION
-- Concept scheme --------------------------------------------
SELECT        
e.Id, e.EntityTypeId,  base.EntityTypeId As EntitySubTypeId, 'Concept scheme' AS EntityType, e.EntityUid 
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType, 0 as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  '' As Description

,base.Created, e.LastUpdated
,isnull(o.Id,0) as OwningOrgId
,isnull(o.Name,0) as OwningOrganization
,base.Source As SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,base.PublishedByOrgId
FROM dbo.Entity e -- entity for the base
Left JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.Conceptscheme base			ON e.EntityUid = base.RowId
Left Join Organization o on base.OrgId = o.Id
where base.EntityStateId > 1

UNION
-- Collection  --------------------------------------------
SELECT        
e.Id, e.EntityTypeId,  e.EntityTypeId As EntitySubTypeId, 'Collection' AS EntityType, e.EntityUid 
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType, 0 as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  '' As Description

,base.Created, e.LastUpdated
,isnull(o.Id,0) as OwningOrgId
,isnull(o.Name,0) as OwningOrganization
,base.SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,base.PublishedByOrgId
FROM dbo.Entity e -- entity for the base
Left JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.Collection base			ON e.EntityUid = base.RowId
Left Join Organization o on base.OwningAgentUid = o.RowId
where base.EntityStateId > 1

UNION
-- Pathway --------------------------------------------
SELECT        
e.Id, e.EntityTypeId,  e.EntityTypeId As EntitySubTypeId, cet.Title AS EntityType, e.EntityUid 
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType, 0 as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  '' As Description
,base.Created, e.LastUpdated
,isnull(o.Id,0) as OwningOrgId
,isnull(o.Name,0) as OwningOrganization
,base.SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,base.PublishedByOrgId
FROM dbo.Entity e -- entity for the base
Left JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.Pathway base			ON e.EntityUid = base.RowId
Left Join Organization o on base.OwningAgentUID = o.RowId
where base.EntityStateId > 1

UNION
-- PathwaySet --------------------------------------------
SELECT        
e.Id, e.EntityTypeId,  e.EntityTypeId As EntitySubTypeId, 'PathwaySet' AS EntityType, e.EntityUid 
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType, 0 as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  '' As Description
,base.Created, e.LastUpdated
,isnull(o.Id,0) as OwningOrgId
,isnull(o.Name,0) as OwningOrganization
,base.SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,base.PublishedByOrgId
FROM dbo.Entity e -- entity for the base
Left JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.PathwaySet base			ON e.EntityUid = base.RowId
Left Join Organization o on base.OwningAgentUID = o.RowId
where base.EntityStateId > 1

UNION
-- TransferValueProfile --------------------------------------------
SELECT        
e.Id, e.EntityTypeId,  e.EntityTypeId As EntitySubTypeId, 'TransferValue' AS EntityType, e.EntityUid 
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType, 0 as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  '' As Description
,base.Created, e.LastUpdated
,isnull(o.Id,0) as OwningOrgId
,isnull(o.Name,0) as OwningOrganization
,base.SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,base.PublishedByOrgId
FROM dbo.Entity e -- entity for the base
Left JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.TransferValueProfile base			ON e.EntityUid = base.RowId
Left Join Organization o on base.OwningAgentUID = o.RowId
where base.EntityStateId > 1

UNION
-- TransferIntermediary --------------------------------------------
SELECT        
e.Id, e.EntityTypeId,  e.EntityTypeId As EntitySubTypeId, 'TransferIntermediary' AS EntityType, e.EntityUid 
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType, 0 as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  '' As Description
,base.Created, e.LastUpdated
,isnull(o.Id,0) as OwningOrgId
,isnull(o.Name,0) as OwningOrganization
,base.SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,base.PublishedByOrgId
FROM dbo.Entity e -- entity for the base
Left JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.TransferIntermediary base			ON e.EntityUid = base.RowId
Left Join Organization o on base.OwningAgentUID = o.RowId
where base.EntityStateId > 1

UNION
-- DataSet Profile --------------------------------------------
SELECT        
e.Id, e.EntityTypeId,  e.EntityTypeId As EntitySubTypeId, 'DataSetProfile' AS EntityType, e.EntityUid 
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType, 0 as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  '' As Description
,base.Created, e.LastUpdated
,isnull(o.Id,0) as OwningOrgId
,isnull(o.Name,0) as OwningOrganization
,base.Source As SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,base.PublishedByOrgId
--	select count(*)
FROM dbo.Entity e -- entity for the base
INNER JOIN dbo.DataSetProfile base			ON e.EntityUid = base.RowId
Left Join Organization o on base.DataProviderUID = o.RowId
where base.EntityStateId > 0

UNION
-- Occupation --------------------------------------------
SELECT        
e.Id, e.EntityTypeId,  e.EntityTypeId As EntitySubTypeId, cet.Title AS EntityType, e.EntityUid 
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType, 0 as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  '' As Description
,base.Created, e.LastUpdated
,0 as OwningOrgId
,'' as OwningOrganization
,base.SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,0 as PublishedByOrgId
FROM dbo.Entity e -- entity for the base
Left JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.OccupationProfile base			ON e.EntityUid = base.RowId
--Left Join Organization o on base.OwningAgentUID = o.RowId
where base.EntityStateId > 1


UNION
-- Job --------------------------------------------
SELECT        
e.Id, e.EntityTypeId,  e.EntityTypeId As EntitySubTypeId, cet.Title AS EntityType, e.EntityUid 
, 0 as parentEntityId, null As parentEntityUid, '' as parentEntityType, 0 as parentEntityTypeId,
base.Id as BaseId,
IsNull(base.Name,'') As Name,  '' As Description
,base.Created, e.LastUpdated
,0 as OwningOrgId
,'' as OwningOrganization
,base.SubjectWebpage
,'' as ImageUrl
,isnull(base.CTID,'') As CTID
,base.EntityStateId
--,0 as PublishedByOrgId
FROM dbo.Entity e -- entity for the base
Left JOIN dbo.[Codes.EntityTypes]	cet ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.JobProfile base			ON e.EntityUid = base.RowId
--Left Join Organization o on base.OwningAgentUID = o.RowId
where base.EntityStateId > 1

/*
Skip non top level resources

UNION
-- [Entity.ConditionProfile] --------------------------------------------
SELECT        
e.Id, e.EntityTypeId,  e.EntityTypeId As EntitySubTypeId, cet.Title AS EntityType, e.EntityUid, 
parentEntity.Id as parentEntityId,
parentEntity.EntityUid As parentEntityUid, 
eptype.Title as parentEntityType, 
parentEntity.EntityTypeId as parentEntityTypeId,

base.Id as BaseId,
IsNull(base.Name,'') As Name,  
IsNull(base.Description,'') As Description

,base.Created, e.LastUpdated  
,parentEntitySummary.OwningOrgId
,'' as OwningOrganization
,'' as SubjectWebpage
,'' as ImageUrl
,'' As CTID
,0 As EntityStateId

FROM dbo.Entity e -- entity for the base conditionProfile
INNER JOIN dbo.[Codes.EntityTypes]	cet				ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.[Entity.ConditionProfile] base		ON e.EntityUid = base.RowId
Inner Join dbo.Entity parentEntity					on base.EntityId = parentEntity.Id	 -- entity for the Parent of the condition Profile
INNER JOIN dbo.[Codes.EntityTypes] eptype		ON parentEntity.EntityTypeId = eptype.Id 
--get parent reference from entity_cache, as it will have the managing orgId
Left Join Entity_Cache parentEntitySummary	on parentEntity.EntityUid = parentEntitySummary.EntityUid


UNION
-- [Entity.ProcessProfile] --------------------------------------------
SELECT        
e.Id, e.EntityTypeId,  e.EntityTypeId As EntitySubTypeId, cet.Title AS EntityType, e.EntityUid, 
parentEntity.Id as parentEntityId,parentEntity.EntityUid As parentEntityUid, 
eptype.Title as parentEntityType, parentEntity.EntityTypeId as parentEntityTypeId,

base.Id as BaseId,
'' As Name,  
IsNull(base.Description,'') As Description

,base.Created, e.LastUpdated

,parentEntitySummary.OwningOrgId
,'' as OwningOrganization
,'' as SubjectWebpage
,'' as ImageUrl
,'' As CTID
,0 As EntityStateId

FROM dbo.Entity e 
INNER JOIN dbo.[Codes.EntityTypes]	cet			ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.[Entity.ProcessProfile] base		ON e.EntityUid = base.RowId
Inner Join dbo.Entity parentEntity				on base.EntityId = parentEntity.Id
INNER JOIN dbo.[Codes.EntityTypes] eptype	ON parentEntity.EntityTypeId = eptype.Id 
Left Join Entity_Cache parentEntitySummary on parentEntity.EntityUid = parentEntitySummary.EntityUid

UNION
-- [Entity.CostProfile] --------------------------------------------
SELECT        
e.Id, e.EntityTypeId,  e.EntityTypeId As EntitySubTypeId, cet.Title AS EntityType, e.EntityUid,parentEntity.Id as parentEntityId,
parentEntity.EntityUid As parentEntityUid, eptype.Title as parentEntityType, parentEntity.EntityTypeId as parentEntityTypeId,
 
base.Id as BaseId,
IsNull(base.ProfileName,'') As Name,  IsNull(base.Description,'') As Description

,base.Created, e.LastUpdated

,0 as OwningOrgId
,'' as OwningOrganization
,isnull(base.DetailsUrl,'') As SubjectWebpage
,'' as ImageUrl
,'' As CTID
,0 As EntityStateId

FROM dbo.Entity e 
INNER JOIN dbo.[Codes.EntityTypes]	cet			ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.[Entity.CostProfile] base	ON e.EntityUid = base.RowId
Inner Join dbo.Entity parentEntity				on base.EntityId = parentEntity.Id
INNER JOIN dbo.[Codes.EntityTypes] eptype	ON parentEntity.EntityTypeId = eptype.Id 

UNION
-- [Entity.CostProfileItem] --------------------------------------------
-- NOTE: showing the CostProfile parent as the parent entity, not the Cost Profile, may change this later!
SELECT        
e.Id, e.EntityTypeId,  e.EntityTypeId As EntitySubTypeId, cet.Title AS EntityType, e.EntityUid,parentEntity.Id as parentEntityId,parentEntity.EntityUid As parentEntityUid, eptype.Title as parentEntityType, parentEntity.EntityTypeId as parentEntityTypeId,
 
base.Id as BaseId,
'' As Name,  
'' As Description

,base.Created, e.LastUpdated
,0 as OwningOrgId
,'' as OwningOrganization
,'' as SubjectWebpage
,'' as ImageUrl
,'' As CTID
,0 As EntityStateId

FROM dbo.Entity e 
INNER JOIN dbo.[Codes.EntityTypes]	cet			ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.[Entity.CostProfileItem] base ON e.EntityUid = base.RowId
Inner Join dbo.[Entity.CostProfile] cp		on base.CostProfileId = cp.Id
Inner Join dbo.Entity parentEntity				on cp.EntityId = parentEntity.Id
INNER JOIN dbo.[Codes.EntityTypes] eptype	ON parentEntity.EntityTypeId = eptype.Id 

UNION
-- [Entity.RevocationProfile] --------------------------------------------
SELECT        
e.Id, e.EntityTypeId,  e.EntityTypeId As EntitySubTypeId, cet.Title AS EntityType, e.EntityUid,parentEntity.Id as parentEntityId,parentEntity.EntityUid As parentEntityUid, eptype.Title as parentEntityType, parentEntity.EntityTypeId as parentEntityTypeId,
 
base.Id as BaseId,
'RevocationProfile' As Name,  IsNull(base.Description,'') As Description

,base.Created, e.LastUpdated
,0 as OwningOrgId
,'' as OwningOrganization
,'' as SubjectWebpage
,'' as ImageUrl
,'' As CTID
,0 As EntityStateId

FROM dbo.Entity e 
INNER JOIN dbo.[Codes.EntityTypes]	cet			ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.[Entity.RevocationProfile] base		ON e.EntityUid = base.RowId
Inner Join dbo.Entity parentEntity				on base.EntityId = parentEntity.Id
INNER JOIN dbo.[Codes.EntityTypes] eptype	ON parentEntity.EntityTypeId = eptype.Id 
Inner Join dbo.Credential parent					on parentEntity.EntityUid = parent.RowId

UNION
-- [Entity.VerificationProfile] --------------------------------
SELECT        
e.Id, e.EntityTypeId,  e.EntityTypeId As EntitySubTypeId, cet.Title AS EntityType, e.EntityUid,parentEntity.Id as parentEntityId,parentEntity.EntityUid As parentEntityUid, eptype.Title as parentEntityType, parentEntity.EntityTypeId as parentEntityTypeId,
 
base.Id as BaseId,
'VerificationProfile' As Name,  IsNull(base.Description,'') As Description

,base.Created, e.LastUpdated
,0 as OwningOrgId
,'' as OwningOrganization
,isnull(base.SubjectWebpage,'') as SubjectWebpage
,'' as ImageUrl
,'' As CTID
,0 As EntityStateId

FROM dbo.Entity e 
INNER JOIN dbo.[Codes.EntityTypes]	cet		ON e.EntityTypeId = cet.Id 
INNER JOIN dbo.[Entity.VerificationProfile] base		ON e.EntityUid = base.RowId
Inner Join dbo.Entity parentEntity			on base.EntityId = parentEntity.Id
INNER JOIN dbo.[Codes.EntityTypes] eptype	ON parentEntity.EntityTypeId = eptype.Id 
Inner Join dbo.Organization parent			on parentEntity.EntityUid = parent.RowId

*/
GO
grant select on [Entity_Summary] to public
go

