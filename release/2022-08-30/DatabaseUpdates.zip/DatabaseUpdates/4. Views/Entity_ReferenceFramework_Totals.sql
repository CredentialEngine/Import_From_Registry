
/****** Object:  View [dbo].[Entity_ReferenceFramework_Totals]    Script Date: 12/3/2017 10:26:52 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
USE [credFinder]
GO

SELECT [CategoryId]
      ,[EntityTypeId]
      ,[CodeGroup]
      ,[CodedNotation]
      ,[Name]
      ,[ReferenceFrameworkItemId]
      ,[TargetNode]
      ,[Totals]
  FROM [dbo].[Entity_ReferenceFramework_Totals]


order by EntityTypeId, NaicsCode
GO


*/
/*
Use for searching for unique industry records - search candidates
*/
--drop VIEW [dbo].[Entity_ReferenceFramework_Totals]
--go
Alter VIEW [dbo].[Entity_ReferenceFramework_Totals]
AS

SELECT  
	efi.CategoryId,
	base.EntityTypeId,	 
	efi.CodeGroup,
	efi.CodedNotation,
	efi.Name,
	efi.ReferenceFrameworkItemId, 
	efi.TargetNode,

	count(*) as Totals

FROM dbo.Entity base
--Inner join dbo.[Codes.EntityTypes]				cet on base.EntityTypeId = cet.Id
--INNER JOIN dbo.[Entity.FrameworkItem]		efi ON base.Id = efi.EntityId 
INNER JOIN dbo.[Entity_ReferenceFramework_Summary]	efi ON base.Id = efi.EntityId 
--Left JOIN dbo.[Codes.PropertyCategory] cpc ON efi.CategoryId = cpc.Id 

--where efi.CategoryId = 10
--and code.NaicsGroup is not null
group by 
	efi.CategoryId,
	base.EntityTypeId,
	efi.CodeGroup,
	efi.CodedNotation,
	efi.Name,
	efi.ReferenceFrameworkItemId,
	efi.TargetNode 

go
grant select on [Entity_ReferenceFramework_Totals] to public
GO


