
use credFinder
go

USE [sandbox_credFinder]
GO

--	24-11-14 Triggers for [DataSetProfile.Observation]

/****** Object:  Trigger [dbo].[trgDataSetProfile.ObservationAfterInsert]    Script Date: 11/14/2024 3:00:10 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE TRIGGER [dbo].[trgDataSetProfile.ObservationAfterInsert] ON  [dbo].[DataSetProfile.Observation]
FOR INSERT
AS  
    INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
			,EntityBaseId
			, EntityBaseName)
    SELECT RowId,52, getdate(), Id, 'DataSetProfile.Observation'
    FROM inserted;

GO

ALTER TABLE [dbo].[DataSetProfile.Observation] ENABLE TRIGGER [trgDataSetProfile.ObservationAfterInsert]
GO


/****** Object:  Trigger [dbo].[trgDataSetProfile.ObservationAfterDelete]    Script Date: 11/14/2024 3:05:52 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE TRIGGER [dbo].[trgDataSetProfile.ObservationAfterDelete]
ON [dbo].[DataSetProfile.Observation]
   AFTER DELETE
AS
BEGIN

     -- Delete the related Entity
		DELETE a	
			FROM [dbo].[Entity] a
			inner join Deleted d on a.EntityUid = d.RowId
END
GO

ALTER TABLE [dbo].[DataSetProfile.Observation] ENABLE TRIGGER [trgDataSetProfile.ObservationAfterDelete]
GO


