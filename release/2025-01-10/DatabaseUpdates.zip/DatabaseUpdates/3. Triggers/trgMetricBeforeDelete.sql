use credfinder
go
USE [sandbox_credFinder]
GO


CREATE TRIGGER [dbo].[trgMetricBeforeDelete]
ON [dbo].[Metric]
INSTEAD OF DELETE
AS
BEGIN

     -- Some code you want to do before delete
		DELETE a	
			FROM [dbo].[Entity] a
			inner join Deleted d on a.EntityUid = d.RowId

		DELETE a	
			FROM [dbo].[Entity_Cache] a
			inner join Deleted d on a.EntityUid = d.RowId

		 -- do the delete
     DELETE Metric
     FROM DELETED D
     INNER JOIN dbo.Metric T ON T.Id = D.Id
END

GO

ALTER TABLE [dbo].[Metric] ENABLE TRIGGER [trgMetricBeforeDelete]
GO
