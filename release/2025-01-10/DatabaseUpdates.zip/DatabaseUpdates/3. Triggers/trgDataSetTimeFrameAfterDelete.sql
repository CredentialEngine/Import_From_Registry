

USE [sandbox_credFinder]
GO
/****** Object:  Trigger [dbo].[trgDataSetTimeFrameAfterDelete]   Script Date: 11/22/2024 1:40:48 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Description:	
--	Deletes are typically triggered from entity frameworks code. 
--	Tables like Entity are not removed via Referencial Integrity. 
--	As DataSetTimeFrame is part of a cascading delete, an instead of trigger is not allowed, so deleting the Entity after the delete of DataSetTimeFrame
-- =============================================


Create TRIGGER [dbo].[trgDataSetTimeFrameAfterDelete]
ON [dbo].[DataSetTimeFrame]
FOR DELETE
AS
BEGIN

     -- Some code you want to do before delete
		DELETE a	
			FROM [dbo].[Entity] a
			inner join Deleted d on a.EntityUid = d.RowId


END
GO
