
use credfinder
go
USE [sandbox_credFinder]
GO

/****** Object:  Trigger [dbo].[trgMetricAfterInsert]    Script Date: 8/26/2024 3:51:15 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [dbo].[trgMetricAfterInsert] ON  [dbo].[Metric]
FOR INSERT
AS  
    INSERT INTO [dbo].[Entity]
           ([EntityUid]
			,[EntityTypeId]
			,[Created]
			,EntityBaseId, EntityBaseName)
    SELECT RowId,48, getdate(), Id, Name
    FROM inserted;
GO

ALTER TABLE [dbo].[Metric] ENABLE TRIGGER [trgMetricAfterInsert]
GO


/****** Object:  Trigger [dbo].[trgMetricBeforeDelete]    Script Date: 8/26/2024 4:04:53 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




