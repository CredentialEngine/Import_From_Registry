USE [sandbox_credFinder]
GO

/****** Object:  Trigger [dbo].[trgDataSetTimeFrameAfterInsert]    Script Date: 11/4/2024 11:45:50 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE TRIGGER [dbo].[trgDataSetTimeFrameAfterInsert] ON  [dbo].[DataSetTimeFrame]
FOR INSERT
AS  
    INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
			,EntityBaseId
			, EntityBaseName)
    SELECT RowId,51, getdate(), Id, 'DataSetTimeFrame'
    FROM inserted;

GO

ALTER TABLE [dbo].[DataSetTimeFrame] ENABLE TRIGGER [trgDataSetTimeFrameAfterInsert]
GO

/****** Object:  Trigger [dbo].[trgDataSetTimeFrameBeforeDelete]    Script Date: 11/4/2024 11:45:55 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





