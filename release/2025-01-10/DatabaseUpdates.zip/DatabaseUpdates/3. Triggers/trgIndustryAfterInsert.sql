
use credfinder
go
USE [sandbox_credFinder]
GO

/****** Object:  Trigger [dbo].[trgIndustryAfterInsert]    Script Date: 8/26/2024 3:51:15 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [dbo].[trgIndustryAfterInsert] ON  [dbo].[Industry]
FOR INSERT
AS  
    INSERT INTO [dbo].[Entity]
           ([EntityUid]
			,[EntityTypeId]
			,[Created]
			,EntityBaseId, EntityBaseName)
    SELECT RowId,47, getdate(), Id, Name
    FROM inserted;
GO

ALTER TABLE [dbo].[Industry] ENABLE TRIGGER [trgIndustryAfterInsert]
GO

