use credFinder
go

USE [sandbox_credFinder]
GO

--	24-11-14 Triggers for [DataSetProfile.Dimension]

/****** Object:  Trigger [dbo].[trgDataSetProfile.DimensionAfterInsert]    Script Date: 11/14/2024 3:00:10 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE TRIGGER [dbo].[trgDataSetProfile.DimensionAfterInsert] ON  [dbo].[DataSetProfile.Dimension]
FOR INSERT
AS  
    INSERT INTO [dbo].[Entity]
           ([EntityUid]
           ,[EntityTypeId]
           ,[Created]
			,EntityBaseId
			, EntityBaseName)
    SELECT RowId,53, getdate(), Id, 'DataSetProfile.Dimension'
    FROM inserted;

GO

ALTER TABLE [dbo].[DataSetProfile.Dimension] ENABLE TRIGGER [trgDataSetProfile.DimensionAfterInsert]
GO



/****** Object:  Trigger [dbo].[trgDataSetProfile.DimensionAfterDelete]    Script Date: 11/14/2024 3:05:52 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE TRIGGER [dbo].[trgDataSetProfile.DimensionAfterDelete]
ON [dbo].[DataSetProfile.Dimension]
   AFTER DELETE
AS
BEGIN

     -- Delete the related Entity
		DELETE a	
			FROM [dbo].[Entity] a
			inner join Deleted d on a.EntityUid = d.RowId
END
GO

ALTER TABLE [dbo].[DataSetProfile.Dimension] ENABLE TRIGGER [trgDataSetProfile.DimensionAfterDelete]
GO


