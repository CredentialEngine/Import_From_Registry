
/****** Object:  Table [dbo].[DataSetProfile.DataSetDistribution]    Script Date: 10/10/2024 5:13:52 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DataSetProfile.DataSetDistribution]') AND type in (N'U'))
DROP TABLE [dbo].[DataSetProfile.DataSetDistribution]
GO


CREATE TABLE [dbo].[DataSetProfile.DataSetDistribution](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[RowId] [uniqueidentifier] NOT NULL,
	[DataSetProfileId] [int] NOT NULL,
	[Name] [nvarchar](800) NULL,
	[Description] [nvarchar](max) NULL,
	[AlternateName] [nvarchar](max) NULL,
	[ConformsTo] [nvarchar](max) NULL,
	[DateEffective] [varchar](50) NULL,
	[DistributionFile] [nvarchar](800) NULL,
	[License] [nvarchar](max) NULL,
	[MediaType] [nvarchar](500) NULL,
	[Rights] [nvarchar](max) NULL,
	[Source] [nvarchar](max) NULL,
	[Created] [datetime] NULL,
	[LastUpdated] [datetime] NULL,
 CONSTRAINT [PK_DataSetProfile.DataSetDistribution] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON ) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[DataSetProfile.DataSetDistribution] ADD  CONSTRAINT [DF_DataSetProfile.DataSetDistribution_RowId]  DEFAULT (newid()) FOR [RowId]
GO

ALTER TABLE [dbo].[DataSetProfile.DataSetDistribution] ADD  CONSTRAINT [DF_DataSetProfile.DataSetDistribution_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[DataSetProfile.DataSetDistribution] ADD  CONSTRAINT [DF_DataSetProfile.DataSetDistribution_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO

ALTER TABLE [dbo].[DataSetProfile.DataSetDistribution]  WITH CHECK ADD  CONSTRAINT [FK_DataSetProfile.DataSetDistribution_DataSetProfile] FOREIGN KEY([DataSetProfileId])
REFERENCES [dbo].[DataSetProfile] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[DataSetProfile.DataSetDistribution] CHECK CONSTRAINT [FK_DataSetProfile.DataSetDistribution_DataSetProfile]
GO

