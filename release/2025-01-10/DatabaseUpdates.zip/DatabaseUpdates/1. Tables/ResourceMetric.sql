

/****** Object:  Table [dbo].[ResourceMetric]    Script Date: 10/19/2024 4:15:42 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ResourceMetric]') AND type in (N'U'))
	DROP TABLE [dbo].[ResourceMetric]
GO

/****** Object:  Table [dbo].[ResourceMetric]    Script Date: 10/19/2024 4:15:42 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
Hmm. if a DSP can only have a Metric with an observation, then don't need a concrete HasMetric.
Just get the unique list from DSP.HasObservation

*/
CREATE TABLE [dbo].[ResourceMetric](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	--DSP or observation
	[ResourceUID] [uniqueidentifier] NULL,
	--OR
	[ResourceEntityTypeId] [int] NOT NULL,
	[ResourceId] int NOT NULL,

	[MetricId] [int] NOT NULL,
	[Created] [datetime] NULL,
 CONSTRAINT [PK_ResourceMetric] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[ResourceMetric] ADD  CONSTRAINT [DF_ResourceMetric_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[ResourceMetric]  WITH CHECK ADD  CONSTRAINT [FK_ResourceMetric_Entity_Cache] FOREIGN KEY([ResourceEntityTypeId], [ResourceId])
REFERENCES [dbo].[Entity_Cache] ([EntityTypeId], [BaseId])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[ResourceMetric] CHECK CONSTRAINT [FK_ResourceMetric_Entity_Cache]
GO

ALTER TABLE [dbo].[ResourceMetric]  WITH CHECK ADD  CONSTRAINT [FK_ResourceMetric_Metric] FOREIGN KEY([MetricId])
REFERENCES [dbo].[Metric] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[ResourceMetric] CHECK CONSTRAINT [FK_ResourceMetric_Metric]
GO

