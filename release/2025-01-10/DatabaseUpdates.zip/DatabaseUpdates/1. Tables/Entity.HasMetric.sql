
/****** Object:  Table [dbo].[Entity.HasMetric]    Script Date: 10/31/2024 10:02:59 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Entity.HasMetric](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[EntityId] [int] NOT NULL,
	[MetricId] [int] NOT NULL,
	[Created] [datetime] NULL,
 CONSTRAINT [PK_Entity.HasMetric] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Entity.HasMetric] ADD  CONSTRAINT [DF_Entity.HasMetric_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Entity.HasMetric]  WITH CHECK ADD  CONSTRAINT [FK_Entity.HasMetric_Entity] FOREIGN KEY([EntityId])
REFERENCES [dbo].[Entity] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Entity.HasMetric] CHECK CONSTRAINT [FK_Entity.HasMetric_Entity]
GO

ALTER TABLE [dbo].[Entity.HasMetric]  WITH CHECK ADD  CONSTRAINT [FK_Entity.HasMetric_Metric] FOREIGN KEY([MetricId])
REFERENCES [dbo].[Metric] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Entity.HasMetric] CHECK CONSTRAINT [FK_Entity.HasMetric_Metric]
GO


