
/****** Object:  Table [dbo].[Industry]    Script Date: 8/26/2024 4:07:27 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Industry](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[RowId] [uniqueidentifier] NOT NULL,
	[Name] [nvarchar](800) NOT NULL,
	[Description] [nvarchar](max) NULL,
	[EntityStateId] [int] NOT NULL,
	[CTID] [varchar](50) NULL,
	[SubjectWebpage] [nvarchar](600) NULL,
	[AlternateName] [nvarchar](max) NULL,
	[Classification] [nvarchar](max) NULL,
	[CodedNotation] [nvarchar](100) NULL,
	[Comment] [nvarchar](max) NULL,
	[Identifier] [nvarchar](max) NULL,
	[InCatalog] [nvarchar](max) NULL,
	[Keyword] [nvarchar](max) NULL,
	[LifeCycleStatusTypeId] [int] NULL,
	[SameAs] [nvarchar](max) NULL,
	[VersionIdentifier] [nvarchar](max) NULL,
	[PrimaryAgentUID] [uniqueidentifier] NULL,
	[Created] [datetime] NULL,
	[LastUpdated] [datetime] NULL,
 CONSTRAINT [PK_Industry] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[Industry] ADD  CONSTRAINT [DF_Industry_RowId]  DEFAULT (newid()) FOR [RowId]
GO

ALTER TABLE [dbo].[Industry] ADD  CONSTRAINT [DF_Industry_EntityStateId]  DEFAULT ((1)) FOR [EntityStateId]
GO

ALTER TABLE [dbo].[Industry] ADD  CONSTRAINT [DF_Industry_LifeCycleStatusTypeId]  DEFAULT ((0)) FOR [LifeCycleStatusTypeId]
GO

ALTER TABLE [dbo].[Industry] ADD  CONSTRAINT [DF_Industry_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Industry] ADD  CONSTRAINT [DF_Industry_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO


