
ALTER TABLE [dbo].[Metric] DROP CONSTRAINT [DF_Metric_LastUpdated]
GO

ALTER TABLE [dbo].[Metric] DROP CONSTRAINT [DF_Metric_Created]
GO

ALTER TABLE [dbo].[Metric] DROP CONSTRAINT [DF_Metric_EntityStateId]
GO

ALTER TABLE [dbo].[Metric] DROP CONSTRAINT [DF_Metric_RowId]
GO

/****** Object:  Table [dbo].[Metric]    Script Date: 10/19/2024 6:44:19 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Metric]') AND type in (N'U'))
DROP TABLE [dbo].[Metric]
GO

/****** Object:  Table [dbo].[Metric]    Script Date: 10/19/2024 6:44:19 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Metric](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[RowId] [uniqueidentifier] NOT NULL,
	[CTID] [varchar](50) NULL,
	[Name] [nvarchar](800) NULL,
	[Description] [nvarchar](max) NULL,
	[Adjustment] [nvarchar](max) NULL,
	[EntityStateId] [int] NOT NULL,
	[DerivedFromId] [int] NULL,
	[EarningsDefinition] [nvarchar](max) NULL,
	[EarningsThreshold] [nvarchar](max) NULL,
	[EmploymentDefinition] [nvarchar](max) NULL,
	[IncomeDeterminationTypeId] [int] NULL,
	[RecordTypeId] [int] NULL,
	[SameAs] [nvarchar](max) NULL,
	[PrimaryAgentUID] [uniqueidentifier] NULL,
	[Created] [datetime] NULL,
	[LastUpdated] [datetime] NULL,
	[RecordType] [nvarchar](max) NULL,
 CONSTRAINT [PK_Metric] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[Metric] ADD  CONSTRAINT [DF_Metric_RowId]  DEFAULT (newid()) FOR [RowId]
GO

ALTER TABLE [dbo].[Metric] ADD  CONSTRAINT [DF_Metric_EntityStateId]  DEFAULT ((1)) FOR [EntityStateId]
GO

ALTER TABLE [dbo].[Metric] ADD  CONSTRAINT [DF_Metric_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[Metric] ADD  CONSTRAINT [DF_Metric_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO

