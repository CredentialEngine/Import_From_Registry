-- drop and recreate
ALTER TABLE [dbo].[OccupationProfile] DROP CONSTRAINT [DF_OccupationProfile_LastUpdated]
GO

ALTER TABLE [dbo].[OccupationProfile] DROP CONSTRAINT [DF_OccupationProfile_Created]
GO

ALTER TABLE [dbo].[OccupationProfile] DROP CONSTRAINT [DF_Table_1_ExistsInRegistry]
GO

ALTER TABLE [dbo].[OccupationProfile] DROP CONSTRAINT [DF_OccupationProfile_EntityStateId]
GO

ALTER TABLE [dbo].[OccupationProfile] DROP CONSTRAINT [DF_OccupationProfile_RowId]
GO

/****** Object:  Table [dbo].[OccupationProfile]    Script Date: 8/25/2021 5:38:01 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OccupationProfile]') AND type in (N'U'))
DROP TABLE [dbo].[OccupationProfile]
GO

USE [credFinder_github]
GO

/****** Object:  Table [dbo].[OccupationProfile]    Script Date: 1/10/2025 11:19:30 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[OccupationProfile](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[RowId] [uniqueidentifier] NOT NULL,
	[Name] [nvarchar](800) NOT NULL,
	[Description] [nvarchar](max) NULL,
	[EntityStateId] [int] NOT NULL,
	[CTID] [varchar](50) NULL,
	[SubjectWebpage] [varchar](500) NULL,
	[AbilityEmbodied] [nvarchar](max) NULL,
	[Classification] [nvarchar](max) NULL,
	[CodedNotation] [varchar](100) NULL,
	[Comment] [nvarchar](max) NULL,
	[Identifier] [nvarchar](max) NULL,
	[KnowledgeEmbodied] [nvarchar](max) NULL,
	[SkillEmbodied] [nvarchar](max) NULL,
	[SameAs] [nvarchar](max) NULL,
	[VersionIdentifier] [nvarchar](max) NULL,
	[JsonProperties] [nvarchar](max) NULL,
	[Created] [datetime] NULL,
	[LastUpdated] [datetime] NULL,
	[PrimaryAgentUID] [uniqueidentifier] NULL,
	[AlternateName] [varchar](500) NULL,
	[EnvironmentalHazardType] [varchar](max) NULL,
	[PerformanceLevelType] [varchar](max) NULL,
	[PhysicalCapabilityType] [varchar](max) NULL,
	[SensoryCapabilityType] [varchar](max) NULL,
	[Keyword] [varchar](max) NULL,
	[TargetCompetency] [nvarchar](max) NULL,
	[LifeCycleStatusTypeId] [int] NULL,
	[InCatalog] [nvarchar](max) NULL,
 CONSTRAINT [PK_OccupationProfile] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[OccupationProfile] ADD  CONSTRAINT [DF_OccupationProfile_RowId]  DEFAULT (newid()) FOR [RowId]
GO

ALTER TABLE [dbo].[OccupationProfile] ADD  CONSTRAINT [DF_OccupationProfile_EntityStateId]  DEFAULT ((1)) FOR [EntityStateId]
GO

ALTER TABLE [dbo].[OccupationProfile] ADD  CONSTRAINT [DF_OccupationProfile_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[OccupationProfile] ADD  CONSTRAINT [DF_OccupationProfile_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO

ALTER TABLE [dbo].[OccupationProfile] ADD  CONSTRAINT [DF_OccupationProfile_LifeCycleStatusTypeId]  DEFAULT ((0)) FOR [LifeCycleStatusTypeId]
GO


