
/****** Object:  Table [dbo].[ResourceRelationship]    Script Date: 10/19/2024 4:15:42 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ResourceRelationship]') AND type in (N'U'))
	DROP TABLE [dbo].ResourceRelationship
GO

/****** Object:  Table [dbo].[ResourceRelationship]    Script Date: 10/17/2024 10:43:59 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE TABLE [dbo].[ResourceRelationship](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ResourceUID] [uniqueidentifier] NOT NULL,
	[RelationshipTypeId] [int] NOT NULL,
	[TargetEntityTypeId] [int] NOT NULL,
	[TargetResourceId] [int] NOT NULL,
	[Created] [datetime] NULL,
 CONSTRAINT [PK_ResourceRelationship] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[ResourceRelationship] ADD  CONSTRAINT [DF_ResourceRelationship_RelationshipTypeId]  DEFAULT ((1)) FOR [RelationshipTypeId]
GO

ALTER TABLE [dbo].[ResourceRelationship] ADD  CONSTRAINT [DF_ResourceRelationship_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[ResourceRelationship]  WITH CHECK ADD  CONSTRAINT [FK_ResourceRelationship_Codes.EntityTypes] FOREIGN KEY([TargetEntityTypeId])
REFERENCES [dbo].[Codes.EntityTypes] ([Id])
GO

ALTER TABLE [dbo].[ResourceRelationship] CHECK CONSTRAINT [FK_ResourceRelationship_Codes.EntityTypes]
GO


