
/****** Object:  Table [dbo].[DataSetProfile.Observation]    Script Date: 10/24/2024 10:53:59 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DataSetProfile.Observation]') AND type in (N'U'))
DROP TABLE [dbo].[DataSetProfile.Observation]
GO

/****** Object:  Table [dbo].[DataSetProfile.Observation]    Script Date: 10/24/2024 10:53:59 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DataSetProfile.Observation](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[RowId] [uniqueidentifier] NOT NULL,
	[DataSetProfileId] [int] NOT NULL,
	[AtPoint] [nvarchar](600) NULL,
	[Comment] [nvarchar](max) NULL,
	[Currency] [nvarchar](100) NULL,
	[DataWithholdingTypeId] [int] NULL,
	[IsObservationOf] [int] NULL,
	[Mean] [decimal](18, 2) NULL,
	[Median] [decimal](18, 2) NULL,
	[MinPercentage] [decimal](18, 2) NULL,
	[MaxPercentage] [decimal](18, 2) NULL,
	[MinValue] [decimal](18, 2) NULL,
	[MaxValue] [decimal](18, 2) NULL,
	[Percentage] [decimal](18, 2) NULL,
	[Percentile10] [decimal](18, 2) NULL,
	[Percentile25] [decimal](18, 2) NULL,
	[Percentile75] [decimal](18, 2) NULL,
	[Percentile90] [decimal](18, 2) NULL,
	[SizeOfData] [int] NULL,
	[SizeOfNoData] [int] NULL,
	[SizeOfPopulation] [int] NULL,
	[StandardDeviation] [decimal](18, 2) NULL,
	[Value] [decimal](18, 2) NULL,
	[Created] [datetime] NULL,
	[LastUpdated] [datetime] NULL,
 CONSTRAINT [PK_DataSetProfile.Observation] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[DataSetProfile.Observation] ADD  CONSTRAINT [DF_DataSetProfile.Observation_RowId]  DEFAULT (newid()) FOR [RowId]
GO

ALTER TABLE [dbo].[DataSetProfile.Observation] ADD  CONSTRAINT [DF_DataSetProfile.Observation_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[DataSetProfile.Observation] ADD  CONSTRAINT [DF_DataSetProfile.Observation_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO

ALTER TABLE [dbo].[DataSetProfile.Observation]  WITH CHECK ADD  CONSTRAINT [FK_DataSetProfile.Observation_DataSetProfile] FOREIGN KEY([DataSetProfileId])
REFERENCES [dbo].[DataSetProfile] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[DataSetProfile.Observation] CHECK CONSTRAINT [FK_DataSetProfile.Observation_DataSetProfile]
GO


