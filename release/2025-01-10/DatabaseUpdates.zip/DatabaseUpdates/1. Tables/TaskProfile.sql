USE [credFinder_github]
GO

ALTER TABLE [dbo].[TaskProfile] DROP CONSTRAINT [DF_TaskProfile_LifeCycleStatusTypeId]
GO

ALTER TABLE [dbo].[TaskProfile] DROP CONSTRAINT [DF_TaskProfile_LastUpdated]
GO

ALTER TABLE [dbo].[TaskProfile] DROP CONSTRAINT [DF_TaskProfile_Created]
GO

ALTER TABLE [dbo].[TaskProfile] DROP CONSTRAINT [DF_TaskProfile_EntityStateId]
GO

ALTER TABLE [dbo].[TaskProfile] DROP CONSTRAINT [DF_TaskProfile_RowId]
GO

/****** Object:  Table [dbo].[TaskProfile]    Script Date: 1/10/2025 11:21:42 AM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TaskProfile]') AND type in (N'U'))
DROP TABLE [dbo].[TaskProfile]
GO

/****** Object:  Table [dbo].[TaskProfile]    Script Date: 1/10/2025 11:21:42 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[TaskProfile](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[RowId] [uniqueidentifier] NOT NULL,
	[EntityStateId] [int] NOT NULL,
	[Name] [nvarchar](800) NULL,
	[Description] [nvarchar](max) NOT NULL,
	[CTID] [varchar](50) NULL,
	[AbilityEmbodied] [nvarchar](max) NULL,
	[Classification] [nvarchar](max) NULL,
	[CodedNotation] [varchar](100) NULL,
	[Comment] [nvarchar](max) NULL,
	[Identifier] [nvarchar](max) NULL,
	[KnowledgeEmbodied] [nvarchar](max) NULL,
	[ListID] [varchar](200) NULL,
	[SkillEmbodied] [nvarchar](max) NULL,
	[VersionIdentifier] [nvarchar](max) NULL,
	[JsonProperties] [nvarchar](max) NULL,
	[Created] [datetime] NULL,
	[LastUpdated] [datetime] NULL,
	[PrimaryAgentUid] [uniqueidentifier] NULL,
	[EnvironmentalHazardType] [varchar](max) NULL,
	[PerformanceLevelType] [varchar](max) NULL,
	[PhysicalCapabilityType] [varchar](max) NULL,
	[SensoryCapabilityType] [varchar](max) NULL,
	[AlternateName] [varchar](500) NULL,
	[TargetCompetency] [nvarchar](max) NULL,
	[LifeCycleStatusTypeId] [int] NULL,
	[InCatalog] [nvarchar](max) NULL,
 CONSTRAINT [PK_TaskProfile] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[TaskProfile] ADD  CONSTRAINT [DF_TaskProfile_RowId]  DEFAULT (newid()) FOR [RowId]
GO

ALTER TABLE [dbo].[TaskProfile] ADD  CONSTRAINT [DF_TaskProfile_EntityStateId]  DEFAULT ((1)) FOR [EntityStateId]
GO

ALTER TABLE [dbo].[TaskProfile] ADD  CONSTRAINT [DF_TaskProfile_Created]  DEFAULT (getdate()) FOR [Created]
GO

ALTER TABLE [dbo].[TaskProfile] ADD  CONSTRAINT [DF_TaskProfile_LastUpdated]  DEFAULT (getdate()) FOR [LastUpdated]
GO

ALTER TABLE [dbo].[TaskProfile] ADD  CONSTRAINT [DF_TaskProfile_LifeCycleStatusTypeId]  DEFAULT ((0)) FOR [LifeCycleStatusTypeId]
GO

