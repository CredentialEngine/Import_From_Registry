

INSERT INTO [dbo].[Codes.PropertyCategory]
           ([Id]
           ,[Title],[Description]
           ,[SortOrder],[IsActive]
           ,[SchemaName],[SchemaUrl]
           ,[Created]
           ,[CodeName]
           ,[InterfaceType]
           ,[PropertyTableName]
           ,[IsConceptScheme]
           ,[SchemeFor])
     VALUES
           (106
           ,'Demographic Category','Classification of various means (such as classification schemes) used to describe and categorize subjects in a population.'
           ,10,1
           ,'qdata:DemographicCategory', 'https://credreg.net/ctdl/terms/MetricCategory'
           ,GETDATE()
           ,'DemographicCategory'
           ,NULL
           ,'Codes.PropertyValue'
           ,1
           ,'dimensionType')
GO



INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId],[Title],[Description]
           ,[SortOrder],[IsActive]
           ,[SchemaName],[SchemaUrl]
           ,[ParentSchemaName],[Created],[Totals],[IsSubType1])
     VALUES
           (106
           ,'Accommodation'
           ,'Means of indicating the subjects'' use of services or resources for equal access.'
           ,25, 1
           ,'demoCat:Accommodation'
           ,'https://credreg.net/qdata/vocabs/demoCat/Accommodation'
           ,'',getdate(),0,0)
GO


INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId],[Title],[Description]
           ,[SortOrder],[IsActive]
           ,[SchemaName],[SchemaUrl]
           ,[ParentSchemaName],[Created],[Totals],[IsSubType1])
     VALUES
           (106
           ,'Age'
           ,'Means of indicating the age of subjects, typically categorized into age groups.'
           ,25, 1
           ,'demoCat:Age'
           ,'https://credreg.net/qdata/vocabs/demoCat/Age'
           ,'',getdate(),0,0)
GO

INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId],[Title],[Description]
           ,[SortOrder],[IsActive]
           ,[SchemaName],[SchemaUrl]
           ,[ParentSchemaName],[Created],[Totals],[IsSubType1])
     VALUES
           (106
           ,'Benefits'
           ,'Means of indicating whether subjects receive public or other benefits.'
           ,25, 1
           ,'demoCat:Benefits'
           ,'https://credreg.net/qdata/vocabs/demoCat/Benefits'
           ,'',getdate(),0,0)
GO

INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId],[Title],[Description]
           ,[SortOrder],[IsActive]
           ,[SchemaName],[SchemaUrl]
           ,[ParentSchemaName],[Created],[Totals],[IsSubType1])
     VALUES
           (106
           ,'Dependency Responsibility','Means of indicating the caring responsibilities of subjects, such as for dependents or other family members.'
           ,25, 1
           ,'demoCat:DependencyResponsibility'
           ,'https://credreg.net/qdata/vocabs/demoCat/DependencyResponsibility'
           ,'',getdate(),0,0)
GO


INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId],[Title],[Description]
           ,[SortOrder],[IsActive]
           ,[SchemaName],[SchemaUrl]
           ,[ParentSchemaName],[Created],[Totals],[IsSubType1])
     VALUES
           (106
           ,'Disability','Means of indicating whether subjects have a disability, including physical, sensory, cognitive, mental health, or learning disabilities, recognizing both visible and invisible disabilities.'
           ,25, 1
           ,'demoCat:Disability'
           ,'https://credreg.net/qdata/vocabs/demoCat/Disability'
           ,'',getdate(),0,0)
GO

INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId],[Title],[Description]
           ,[SortOrder],[IsActive]
           ,[SchemaName],[SchemaUrl]
           ,[ParentSchemaName],[Created],[Totals],[IsSubType1])
     VALUES
           (106
           ,'Education Level','Means of indicating the highest level of education completed by subjects.'
           ,25, 1
           ,'demoCat:EducationLevel'
           ,'https://credreg.net/qdata/vocabs/demoCat/EducationLevel'
           ,'',getdate(),0,0)
GO


INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId],[Title],[Description]
           ,[SortOrder],[IsActive]
           ,[SchemaName],[SchemaUrl]
           ,[ParentSchemaName],[Created],[Totals],[IsSubType1])
     VALUES
           (106
           ,'Employment','Means of indicating the employment status of subjects.'
           ,25, 1
           ,'demoCat:Employment'
           ,'https://credreg.net/qdata/vocabs/demoCat/Employment'
           ,'',getdate(),0,0)
GO


INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId],[Title],[Description]
           ,[SortOrder],[IsActive]
           ,[SchemaName],[SchemaUrl]
           ,[ParentSchemaName],[Created],[Totals],[IsSubType1])
     VALUES
           (106
           ,'Ethnicity','Means of indicating the ethnicity of subjects, reflecting their cultural identity.'
           ,25, 1
           ,'demoCat:Ethnicity'
           ,'https://credreg.net/qdata/vocabs/demoCat/Ethnicity'
           ,'',getdate(),0,0)
GO

INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId],[Title],[Description]
           ,[SortOrder],[IsActive]
           ,[SchemaName],[SchemaUrl]
           ,[ParentSchemaName],[Created],[Totals],[IsSubType1])
     VALUES
           (106
           ,'Family Educational Background','Means of indicating the educational background of a subject''s family, for example whether subjects are the first in their family to attend higher education institutions.'
           ,25, 1
           ,'demoCat:FamilyEducationalBackground'
           ,'https://credreg.net/qdata/vocabs/demoCat/FamilyEducationalBackground'
           ,'',getdate(),0,0)
GO
INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId],[Title],[Description]
           ,[SortOrder],[IsActive]
           ,[SchemaName],[SchemaUrl]
           ,[ParentSchemaName],[Created],[Totals],[IsSubType1])
     VALUES
           (106
           ,'Gender','Means of indicating the gender identity of subjects, which can include male, female, and other gender identities.'
           ,25, 1
           ,'demoCat:Gender'
           ,'https://credreg.net/qdata/vocabs/demoCat/Gender'
           ,'',getdate(),0,0)
GO

INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId],[Title],[Description]
           ,[SortOrder],[IsActive]
           ,[SchemaName],[SchemaUrl]
           ,[ParentSchemaName],[Created],[Totals],[IsSubType1])
     VALUES
           (106
           ,'Housing','Means of indicating whether subjects are housed or experiencing housing instability'
           ,25, 1
           ,'demoCat:Housing'
           ,'https://credreg.net/qdata/vocabs/demoCat/Housing'
           ,'',getdate(),0,0)
GO


INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId],[Title],[Description]
           ,[SortOrder],[IsActive]
           ,[SchemaName],[SchemaUrl]
           ,[ParentSchemaName],[Created],[Totals],[IsSubType1])
     VALUES
           (106
           ,'Income','Means of indicating the financial stability of subjects.'
           ,25, 1
           ,'demoCat:Income'
           ,'https://credreg.net/qdata/vocabs/demoCat/Income'
           ,'',getdate(),0,0)
GO

INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId],[Title],[Description]
           ,[SortOrder],[IsActive]
           ,[SchemaName],[SchemaUrl]
           ,[ParentSchemaName],[Created],[Totals],[IsSubType1])
     VALUES
           (106
           ,'Language','Means of indicating the primary language spoken by subjects.'
           ,25, 1
           ,'demoCat:Language'
           ,'https://credreg.net/qdata/vocabs/demoCat/Language'
           ,'',getdate(),0,0)
GO

INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId],[Title],[Description]
           ,[SortOrder],[IsActive]
           ,[SchemaName],[SchemaUrl]
           ,[ParentSchemaName],[Created],[Totals],[IsSubType1])
     VALUES
           (106
           ,'Literacy','Means of indicating the literacy level of subjects, including reading and writing skills.'
           ,25, 1
           ,'demoCat:Literacy'
           ,'https://credreg.net/qdata/vocabs/demoCat/Literacy'
           ,'',getdate(),0,0)
GO


INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId],[Title],[Description]
           ,[SortOrder],[IsActive]
           ,[SchemaName],[SchemaUrl]
           ,[ParentSchemaName],[Created],[Totals],[IsSubType1])
     VALUES
           (106
           ,'Marital Status','Means of indicating the marital status of subjects.'
           ,25, 1
           ,'demoCat:MaritalStatus'
           ,'https://credreg.net/qdata/vocabs/demoCat/MaritalStatus'
           ,'',getdate(),0,0)
GO


INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId],[Title],[Description]
           ,[SortOrder],[IsActive]
           ,[SchemaName],[SchemaUrl]
           ,[ParentSchemaName],[Created],[Totals],[IsSubType1])
     VALUES
           (106
           ,'Military Status','Means of indicating the status of being associated with military service, either personally or through family.'
           ,25, 1
           ,'demoCat:MilitaryStatus'
           ,'https://credreg.net/qdata/vocabs/demoCat/MilitaryStatus'
           ,'',getdate(),0,0)
GO


INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId],[Title],[Description]
           ,[SortOrder],[IsActive]
           ,[SchemaName],[SchemaUrl]
           ,[ParentSchemaName],[Created],[Totals],[IsSubType1])
     VALUES
           (106
           ,'Race','Means of indicating the race / ethnicity of subjects, categorized according to widely recognized standards.'
           ,25, 1
           ,'demoCat:Race'
           ,'https://credreg.net/qdata/vocabs/demoCat/Race'
           ,'',getdate(),0,0)
GO


INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId],[Title],[Description]
           ,[SortOrder],[IsActive]
           ,[SchemaName],[SchemaUrl]
           ,[ParentSchemaName],[Created],[Totals],[IsSubType1])
     VALUES
           (106
           ,'Residency','Means of indicating where subjects live.'
           ,25, 1
           ,'demoCat:Residency'
           ,'https://credreg.net/qdata/vocabs/demoCat/Residency'
           ,'',getdate(),0,0)
GO


INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId],[Title],[Description]
           ,[SortOrder],[IsActive]
           ,[SchemaName],[SchemaUrl]
           ,[ParentSchemaName],[Created],[Totals],[IsSubType1])
     VALUES
           (106
           ,'Skills','Means of indicating the type or nature of skills acquired by subjects, including both hard and soft skills.'
           ,25, 1
           ,'demoCat:Skills'
           ,'https://credreg.net/qdata/vocabs/demoCat/Skills'
           ,'',getdate(),0,0)
GO
