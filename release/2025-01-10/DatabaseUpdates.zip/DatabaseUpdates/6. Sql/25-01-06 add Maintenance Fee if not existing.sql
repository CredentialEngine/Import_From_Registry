
-- 25-01-06 add Maintenance Fee if not existing

if ( NOT exists (
select Id from [dbo].[Codes.PropertyValue] where [SchemaName] = 'costType:RenewalFee'
)) Begin
INSERT INTO [dbo].[Codes.PropertyValue]
           ([CategoryId] ,[Title]
           ,[Description] 
		   ,[SortOrder] ,[IsActive] ,[SchemaName] ,[SchemaUrl] ,[ParentSchemaName]
           ,[Created] ,[Totals] ,[IsSubType1])
     VALUES
           (5, 'Maintenance Fee'
           ,'Cost for maintenance or renewal of the resource being described.'
           ,25 ,1 ,'costType:RenewalFee' ,'' ,NULL
           ,GETDATE() ,0 ,0)
End

/*
  delete from [dbo].[Codes.PropertyValue]
 where [SchemaName] = 'costType:RenewalFee2'

*/

