
-- 24-10-09 Codes.EntityType - correct schema name for concept scheme and concept

UPDATE [dbo].[Codes.EntityTypes]
   SET [SchemaName] = 'skos:ConceptScheme'
 WHERE Id = 11
GO


UPDATE [dbo].[Codes.EntityTypes]
   SET [SchemaName] = 'skos:Concept'
 WHERE Id = 29
GO

use [sandbox_ctdlEditor]
go
use ctdlEditor
go

UPDATE [dbo].[Codes.EntityType]
   SET [SchemaUrl] = 'skos:ConceptScheme'
 WHERE Id = 11
GO


UPDATE [dbo].[Codes.EntityType]
   SET [SchemaUrl] = 'skos:Concept'
 WHERE Id = 29
GO
