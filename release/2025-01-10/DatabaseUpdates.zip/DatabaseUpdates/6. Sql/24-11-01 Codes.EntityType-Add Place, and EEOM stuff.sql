
/*

-- 24-11-01 Codes.EntityType-Add Place, and EEOM stuff

*/
-- noticed and error, so fix in case in all databases
Update [Codes.EntityTypes]
	set SchemaName = 'ceterms:Place'
where Id = 16
go

INSERT INTO [dbo].[Codes.EntityTypes]
           ([Id],[Title],Label, [Description],[IsActive], [SchemaName],[Created] , [IsTopLevelEntity], [Totals],[SortOrder])
     VALUES
           (51,'DataSetTimeFrame','Data Set Time Frame', 'Time frame including earnings and employment start and end dates of the data set.', 1, 'qdata:DataSetTimeFrame', GETDATE(), 0,0,50)
GO
INSERT INTO [dbo].[Codes.EntityTypes]
           ([Id],[Title],Label, [Description],[IsActive], [SchemaName],[Created] , [IsTopLevelEntity], [Totals],[SortOrder])
     VALUES
            (52,'Observation','Observation', 'Data within a dataset defined by specific values for all relevant dimensions and associated with measured values.', 1, 'qdata:Observation', GETDATE(), 0,0,50)
GO
INSERT INTO [dbo].[Codes.EntityTypes]
           ([Id],[Title],Label, [Description],[IsActive], [SchemaName],[Created] , [IsTopLevelEntity], [Totals],[SortOrder])
     VALUES
            (53,'Dimension','Dimension', 'Aspect or characteristic along which observations in a dataset can be organized and identified.', 1, 'qdata:Dimension', GETDATE(), 0,0,50)
GO

-- renumber the obsolete codes

Update [Codes.EntityTypes]
	set Id = 200 
where SchemaName = 'ceterms:EarningsProfile'
go
Update [Codes.EntityTypes]
	set Id = 201 
where SchemaName = 'ceterms:EmploymentOutcomeProfile'
go
Update [Codes.EntityTypes]
	set Id = 202 
where SchemaName = 'ceterms:HoldersProfile'
go