
-- 24-08-26 Codes.EntityType-Add Industry, Metric
/*
47 - Industry
48 - Metric
-- if these already exist in the current database, then delete
delete from [Codes.EntityTypes]
where id in (47,48)
Go
*/


INSERT INTO [dbo].[Codes.EntityTypes]
           ([Id],[Title],Label, [Description],[IsActive], [SchemaName],[Created] , [IsTopLevelEntity], [Totals],[SortOrder])
     VALUES
           (47,'Industry','Industry', 'Resource providing information about an Industry.', 1, 'ceterms:Industry', GETDATE(), 1,0,50)
GO
INSERT INTO [dbo].[Codes.EntityTypes]
           ([Id],[Title],Label, [Description],[IsActive], [SchemaName],[Created] , [IsTopLevelEntity], [Totals],[SortOrder])
     VALUES
           (48,'Metric','Metric','What is being measured and the method of measurement used for observations within a data set. ',1,'qdata:Metric',GETDATE(), 1,0,50)
GO
