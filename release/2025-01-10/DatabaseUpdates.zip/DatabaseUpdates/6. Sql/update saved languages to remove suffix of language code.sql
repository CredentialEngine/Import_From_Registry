
select distinct TextValue, b.Id 
From [Entity.Reference] a
inner join [Codes.Language] b on a.TextValue = b.LanguageName
where CategoryId = 65



UPDATE [dbo].[Entity.Reference]
   SET [TextValue] = 'English'
     
 WHERE CategoryId = 65 
 AND [TextValue] = 'English (en)'
GO
UPDATE [dbo].[Entity.Reference]
   SET [TextValue] = 'French'
     
 WHERE CategoryId = 65 
 AND [TextValue] = 'French (fr)'
GO
UPDATE [dbo].[Entity.Reference]
   SET [TextValue] = 'Spanish'
     
 WHERE CategoryId = 65 
 AND [TextValue] = 'Spanish (es)'
GO
UPDATE [dbo].[Entity.Reference]
   SET [TextValue] = 'Spanish'
     
 WHERE CategoryId = 65 
 AND [TextValue] = 'Spanish; Castilian (es)'
GO
UPDATE [dbo].[Entity.Reference]
   SET [TextValue] = 'Chinese'
 WHERE CategoryId = 65 
 AND [TextValue] = 'Chinese (zh)'
GO
-- =======================================
UPDATE [dbo].[Entity.Reference]
   SET [TextValue] = 'German'
 WHERE CategoryId = 65 
 AND [TextValue] = 'German (de)'
GO
UPDATE [dbo].[Entity.Reference]
   SET [TextValue] = 'Fijian'
 WHERE CategoryId = 65 
 AND [TextValue] = 'Fijian (fj)'
GO
UPDATE [dbo].[Entity.Reference]
   SET [TextValue] = 'Afar'
 WHERE CategoryId = 65 
 AND [TextValue] = 'Afar (aa)'
GO
UPDATE [dbo].[Entity.Reference]
   SET [TextValue] = 'Afrikaans'
 WHERE CategoryId = 65 
 AND [TextValue] = 'Afrikaans (af)'
GO
UPDATE [dbo].[Entity.Reference]
   SET [TextValue] = 'Akan'
 WHERE CategoryId = 65 
 AND [TextValue] = 'Akan (ak)'
GO
UPDATE [dbo].[Entity.Reference]
   SET [TextValue] = 'Arabic'
 WHERE CategoryId = 65 
 AND [TextValue] = 'Arabic (ar)'
GO

UPDATE [dbo].[Entity.Reference]
   SET [TextValue] = 'Aragonese'
 WHERE CategoryId = 65 
 AND [TextValue] = 'Aragonese (an)'
GO
UPDATE [dbo].[Entity.Reference]
   SET [TextValue] = 'Armenian'
 WHERE CategoryId = 65 
 AND [TextValue] = 'Armenian (hy)'
GO
UPDATE [dbo].[Entity.Reference]
   SET [TextValue] = 'Bihari'
 WHERE CategoryId = 65 
 AND [TextValue] = 'Bihari (bh)'
GO
--------------
UPDATE [dbo].[Entity.Reference]
   SET [TextValue] = 'Divehi'
 WHERE CategoryId = 65 
 AND [TextValue] = 'Divehi; Dhivehi; Maldivian; (dv)'
GO
UPDATE [dbo].[Entity.Reference]
   SET [TextValue] = 'Dzongkha'
 WHERE CategoryId = 65 
 AND [TextValue] = 'Dzongkha (dz)'
GO
UPDATE [dbo].[Entity.Reference]
   SET [TextValue] = 'Hindi'
 WHERE CategoryId = 65 
 AND [TextValue] = 'Hindi (hi)'
GO
--------------
UPDATE [dbo].[Entity.Reference]
   SET [TextValue] = 'Marathi'
 WHERE CategoryId = 65 
 AND [TextValue] like 'Marathi%'
GO
UPDATE [dbo].[Entity.Reference]
   SET [TextValue] = 'Shona'
 WHERE CategoryId = 65 
 AND [TextValue] = 'Shona (sn)'
GO
UPDATE [dbo].[Entity.Reference]
   SET [TextValue] = 'Telugu'
 WHERE CategoryId = 65 
 AND [TextValue] = 'Telugu (te)'
GO






