
--	24-11-14 correct namespace for concept/conceptScheme (was OK in azure)

UPDATE [dbo].[Codes.EntityType]
   SET [SchemaUrl] = 'skos:ConceptScheme'
 WHERE schemaUrl = 'ceasn:ConceptScheme'
GO

UPDATE [dbo].[Codes.EntityType]
   SET [SchemaUrl] = 'skos:Concept'
 WHERE schemaUrl = 'ceasn:Concept'
GO

--use credFinder	
--go

use sandbox_credFinder
go

UPDATE [dbo].[Codes.EntityTypes]
   SET [SchemaName] = 'skos:ConceptScheme'
 WHERE [SchemaName] = 'ceasn:ConceptScheme'
GO

UPDATE [dbo].[Codes.EntityTypes]
   SET [SchemaName] = 'skos:Concept'
 WHERE [SchemaName] = 'ceasn:Concept'
GO


