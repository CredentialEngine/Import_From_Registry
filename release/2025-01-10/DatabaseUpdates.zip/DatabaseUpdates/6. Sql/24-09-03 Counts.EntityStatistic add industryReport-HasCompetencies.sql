
--	24-09-03 Counts.EntityStatistic add industryReport-HasCompetencies


--
INSERT INTO [dbo].[Counts.EntityStatistic]
    ([Id], [EntityTypeId], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [Totals], [Created])
VALUES
(194, 47, NULL, 'Has Competencies', '', 25, 1, 'industryReport:HasCompetencies', 1, GETDATE());



