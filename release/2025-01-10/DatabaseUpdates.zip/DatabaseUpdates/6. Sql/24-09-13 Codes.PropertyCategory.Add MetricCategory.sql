
--	24-09-13 Codes.PropertyCategory.Add MetricCategory 

/*
NOTES
This script was created by exporting the data including the Id column.
The steps are:
- first run the insert for [Codes.PropertyCategory]
- next turn off the auto identity feature 
	SET IDENTITY_INSERT [dbo].[Codes.PropertyValue] ON
	GO
- run all of the insert statements
- turn Identity insert back on 

Technically you should be able to just press f5 to run everything
To be sure, run the following and ensure the current max id is less than 2919 (the first insert statement)
select max(id) as lastId from [Codes.PropertyValue]

*/
INSERT INTO [dbo].[Codes.PropertyCategory]
           ([Id]
           ,[Title],[Description]
           ,[SortOrder],[IsActive]
           ,[SchemaName],[SchemaUrl]
           ,[Created]
           ,[CodeName]
           ,[InterfaceType]
           ,[PropertyTableName]
           ,[IsConceptScheme]
           ,[SchemeFor])
     VALUES
           (105
           ,'Metric Category','Types of metrics applicable to an Observation.'
           ,10,1
           ,'qdata:MetricCategory', 'https://credreg.net/ctdl/terms/MetricCategory'
           ,GETDATE()
           ,'MetricCategory'
           ,NULL
           ,'Codes.PropertyValue'
           ,1
           ,'metricType')
GO




SET IDENTITY_INSERT [dbo].[Codes.PropertyValue] ON
GO

INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2919, 105, N'Participation and Engagement', N'Measurement of subjects'' active involvement, admission, enrollment, and re-enrollment in specified education or work preparation activities or resources.', 25, 1, N'metricCat:ParticipationEngagement', N'https://credreg.net/qdata/vocabs/metricCat/ParticipationEngagement', N'', CAST(N'2024-09-14T16:44:15.230' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2920, 105, N'Access', N'Measurement of subjects who access educational or work activities or resources.', 25, 1, N'metricCat:Access', N'https://credreg.net/qdata/vocabs/metricCat/Access', N'metricCat:ParticipationEngagement', CAST(N'2024-09-14T16:44:27.097' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2921, 105, N'Acceptance', N'Measurement of subjects who are admitted to an organization or its educational or work preparation activity or resource after completing the application process.', 25, 1, N'metricCat:Acceptance', N'https://credreg.net/qdata/vocabs/metricCat/Acceptance', N'metricCat:ParticipationEngagement', CAST(N'2024-09-14T16:44:28.610' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2922, 105, N'Credit Transfer', N'Measurement of credits earned prior to enrollment transferred to another educational program.', 25, 1, N'metricCat:CreditTransfer', N'https://credreg.net/qdata/vocabs/metricCat/CreditTransfer', N'metricCat:ParticipationEngagement', CAST(N'2024-09-14T16:44:28.640' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2923, 105, N'Enrollment', N'Measurement of subjects who enroll in an organization or its specified education or work preparation activity or resource.', 25, 1, N'metricCat:Enrollment', N'https://credreg.net/qdata/vocabs/metricCat/Enrollment', N'metricCat:ParticipationEngagement', CAST(N'2024-09-14T16:44:28.660' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2924, 105, N'Prior Learning', N'Measurement of the recognition and assessment of subjects'' existing knowledge and skills to potentially fulfill certain requirements for a work preparation activity or resource.', 25, 1, N'metricCat:PriorLearning', N'https://credreg.net/qdata/vocabs/metricCat/PriorLearning', N'metricCat:ParticipationEngagement', CAST(N'2024-09-14T16:44:28.680' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2925, 105, N'Re-Enrollment', N'Measurement of eligible subjects who re-enroll in an organization or its specified education or work activity or resource.', 25, 1, N'metricCat:ReEnrollment', N'https://credreg.net/qdata/vocabs/metricCat/ReEnrollment', N'metricCat:ParticipationEngagement', CAST(N'2024-09-14T16:44:28.703' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2926, 105, N'Retention and Completion', N'Measurement of subjects'' persistence, discontinuation, completion, credential attainment, and highest level of education achieved in educational or work activities or resources.', 25, 1, N'metricCat:RetentionCompletion', N'https://credreg.net/qdata/vocabs/metricCat/RetentionCompletion', N'', CAST(N'2024-09-14T16:44:28.730' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2927, 105, N'Retention', N'Measurement of subjects who continue or persist in a particular organization or its educational or work preparation activity or resource.', 25, 1, N'metricCat:Retention', N'https://credreg.net/qdata/vocabs/metricCat/Retention', N'metricCat:RetentionCompletion', CAST(N'2024-09-14T16:44:28.753' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2928, 105, N'Completion', N'Measurement of subjects who do or don''t meet completion requirements for a specified education or work activity or resource.', 25, 1, N'metricCat:Completion', N'https://credreg.net/qdata/vocabs/metricCat/Completion', N'metricCat:RetentionCompletion', CAST(N'2024-09-14T16:44:28.773' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2929, 105, N'Credential Attainment', N'Measurement of subjects who do or don�t attain a credential.', 25, 1, N'metricCat:CredentialAttainment', N'https://credreg.net/qdata/vocabs/metricCat/CredentialAttainment', N'metricCat:RetentionCompletion', CAST(N'2024-09-14T16:44:28.797' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2930, 105, N'Education Level', N'Measurement of subjects� highest level of education achieved.', 25, 1, N'metricCat:EducationLevel', N'https://credreg.net/qdata/vocabs/metricCat/EducationLevel', N'metricCat:RetentionCompletion', CAST(N'2024-09-14T16:44:28.820' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2931, 105, N'Pass Rate', N'Measurement of the proportion of subjects who have passed the relevant program education or workforce preparation activity or resource.', 25, 1, N'metricCat:PassRate', N'https://credreg.net/qdata/vocabs/metricCat/PassRate', N'metricCat:RetentionCompletion', CAST(N'2024-09-14T16:44:28.843' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2932, 105, N'Progression', N'Measurement of subjects who progress in a particular organization or its educational or work preparation activity or resource.', 25, 1, N'metricCat:Progression', N'https://credreg.net/qdata/vocabs/metricCat/Progression', N'metricCat:RetentionCompletion', CAST(N'2024-09-14T16:44:28.863' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2933, 105, N'Performance', N'Measurement of subjects'' achievement, including completion requirements, proficiency, placement in work or further education, and measurable skills gains in educational or work preparation activities or resources.', 25, 1, N'metricCat:Performance', N'https://credreg.net/qdata/vocabs/metricCat/Performance', N'', CAST(N'2024-09-14T16:44:28.887' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2934, 105, N'Concentrator', N'Measurement of  subjects within a single educational program who meet completion requirements related to a specific  workforce preparation program of study.', 25, 1, N'metricCat:Concentrator', N'https://credreg.net/qdata/vocabs/metricCat/Concentrator', N'metricCat:Performance', CAST(N'2024-09-14T16:44:28.947' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2935, 105, N'Placement', N'Measurement of  subjects who advance from an education or work preparation activity to work, military, or a higher-level program.', 25, 1, N'metricCat:Placement', N'https://credreg.net/qdata/vocabs/metricCat/Placement', N'metricCat:Performance', CAST(N'2024-09-14T16:44:28.967' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2936, 105, N'Skills Proficiency', N'Measurement of subjects� proficiency within an educational or work preparation activity or resource.', 25, 1, N'metricCat:SkillsProficiency', N'https://credreg.net/qdata/vocabs/metricCat/SkillsProficiency', N'metricCat:Performance', CAST(N'2024-09-14T16:44:28.990' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2937, 105, N'Student Satisfaction', N'Measurement of the level of satisfaction subjects have with their educational or work preparation programs.', 25, 1, N'metricCat:StudentSatisfaction', N'https://credreg.net/qdata/vocabs/metricCat/StudentSatisfaction', N'metricCat:Performance', CAST(N'2024-09-14T16:44:29.013' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2938, 105, N'Employer Satisfaction', N'Measurement of the satisfaction of employers with the performance of subjects from educational or work preparation activity or resource.', 25, 1, N'metricCat:EmployerSatisfaction', N'https://credreg.net/qdata/vocabs/metricCat/EmployerSatisfaction', N'metricCat:Performance', CAST(N'2024-09-14T16:44:29.040' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2939, 105, N'Cost and Duration', N'Measurement of the financial costs and time required for subjects to participate in and complete educational or work preparation activities or resources.', 25, 1, N'metricCat:CostDuration', N'https://credreg.net/qdata/vocabs/metricCat/CostDuration', N'', CAST(N'2024-09-14T16:44:29.067' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2940, 105, N'Direct Cost', N'Measurement of costs charged for subjects to participate in an organization or an educational or work preparation activity or resource.', 25, 1, N'metricCat:DirectCost', N'https://credreg.net/qdata/vocabs/metricCat/DirectCost', N'metricCat:CostDuration', CAST(N'2024-09-14T16:44:29.090' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2941, 105, N'Total Cost of Participation', N'Measurement of all costs incurred directly or indirectly by a subject as a result of participation in an organization or an educational or work preparation activity or resource.', 25, 1, N'metricCat:ParticipationCost', N'https://credreg.net/qdata/vocabs/metricCat/ParticipationCost', N'metricCat:CostDuration', CAST(N'2024-09-14T16:44:29.117' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2942, 105, N'Education and Work Preparation Cost', N'Measurement of the cost for a subject to participate in an organization or an educational or work preparation activity or resource.', 25, 1, N'metricCat:PreparationCost', N'https://credreg.net/qdata/vocabs/metricCat/PreparationCost', N'metricCat:CostDuration', CAST(N'2024-09-14T16:44:29.143' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2943, 105, N'Education and Work Preparation Duration', N'Measurement of the period of time to complete an educational or work preparation activity or resource.', 25, 1, N'metricCat:PreparationDuration', N'https://credreg.net/qdata/vocabs/metricCat/PreparationDuration', N'metricCat:CostDuration', CAST(N'2024-09-14T16:44:29.170' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2944, 105, N'Activity and Earnings', N'Measurement of subjects'' activity and employment status, income, wages, salaries, time to secure employment, and related rates.', 25, 1, N'metricCat:ActivityEarnings', N'https://credreg.net/qdata/vocabs/metricCat/ActivityEarnings', N'', CAST(N'2024-09-14T16:44:29.190' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2945, 105, N'Career Advancement', N'Measurement of the impact of educational or work preparation activities or resources on subjects'' career advancement opportunities.', 25, 1, N'metricCat:CareerAdvancement', N'https://credreg.net/qdata/vocabs/metricCat/CareerAdvancement', N'metricCat:ActivityEarnings', CAST(N'2024-09-14T16:44:29.210' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2946, 105, N'Employment', N'Measurement of the status of subjects being engaged with paid work.', 25, 1, N'metricCat:Employment', N'https://credreg.net/qdata/vocabs/metricCat/Employment', N'metricCat:ActivityEarnings', CAST(N'2024-09-14T16:44:29.233' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2947, 105, N'Earnings', N'Measurement of the income subjects receive from all forms of work.', 25, 1, N'metricCat:Earnings', N'https://credreg.net/qdata/vocabs/metricCat/Earnings', N'metricCat:ActivityEarnings', CAST(N'2024-09-14T16:44:29.253' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2948, 105, N'Time To Employment', N'Measurement of the duration between subjects completing an educational or training program to secure paid work.', 25, 1, N'metricCat:TimeToEmployment', N'https://credreg.net/qdata/vocabs/metricCat/TimeToEmployment', N'metricCat:ActivityEarnings', CAST(N'2024-09-14T16:44:29.277' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2949, 105, N'Student Financial', N'Measurement of financial assistance, student funding sources, and various aspects of student loans and debt related to educational or work preparation activities or resources.', 25, 1, N'metricCat:StudentFinancial', N'https://credreg.net/qdata/vocabs/metricCat/StudentFinancial', N'', CAST(N'2024-09-14T16:44:29.297' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2950, 105, N'Student Financial Assistance', N'Measurement of the financial aid provided to subjects, including grants, scholarships, loans, and other financial support.', 25, 1, N'metricCat:StudentFinancialAssistance', N'https://credreg.net/qdata/vocabs/metricCat/StudentFinancialAssistance', N'metricCat:StudentFinancial', CAST(N'2024-09-14T16:44:29.320' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2951, 105, N'Student Loan Amount', N'Measurement of the loan amount accumulated by subjects after completing a learning or workforce preparation program.', 25, 1, N'metricCat:StudentLoanAmount', N'https://credreg.net/qdata/vocabs/metricCat/StudentLoanAmount', N'metricCat:StudentFinancial', CAST(N'2024-09-14T16:44:29.340' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2952, 105, N'Student Loan Debt', N'Measurement of the loan debt incurred by subjects for the purpose of enrolling in and participating in an educational or work preparation activity or resource.', 25, 1, N'metricCat:StudentLoanDebt', N'https://credreg.net/qdata/vocabs/metricCat/StudentLoanDebt', N'metricCat:StudentFinancial', CAST(N'2024-09-14T16:44:29.363' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2953, 105, N'Student Loan Subject', N'Measurement of the percentage of subjects with loans.', 25, 1, N'metricCat:StudenLoanSubject', N'https://credreg.net/qdata/vocabs/metricCat/StudenLoanSubject', N'metricCat:StudentFinancial', CAST(N'2024-09-14T16:44:29.383' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2954, 105, N'Organization', N'Measurement of organizational support, advisor and faculty availability, benefits received by subjects, and the acceptance of prior learning.', 25, 1, N'metricCat:Organization', N'https://credreg.net/qdata/vocabs/metricCat/Organization', N'', CAST(N'2024-09-14T16:44:29.400' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2955, 105, N'Support', N'Measurement of the support offered by the resource available for subjects.', 25, 1, N'metricCat:Support', N'https://credreg.net/qdata/vocabs/metricCat/Support', N'metricCat:Organization', CAST(N'2024-09-14T16:44:29.423' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2956, 105, N'Learner to Advisor', N'Measurement of the number of learners per available advisor.', 25, 1, N'metricCat:LearnerToAdvisor', N'https://credreg.net/qdata/vocabs/metricCat/LearnerToAdvisor', N'metricCat:Organization', CAST(N'2024-09-14T16:44:29.443' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2957, 105, N'Benefits Received', N'Measurement of the benefits received by subjects.', 25, 1, N'metricCat:BenefitsReceived', N'https://credreg.net/qdata/vocabs/metricCat/BenefitsReceived', N'metricCat:Organization', CAST(N'2024-09-14T16:44:29.467' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2958, 105, N'Learner to Faculty', N'Measurement of the number of learners per available faculty.', 25, 1, N'metricCat:LearnerToFaculty', N'https://credreg.net/qdata/vocabs/metricCat/LearnerToFaculty', N'metricCat:Organization', CAST(N'2024-09-14T16:44:29.487' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2959, 105, N'Transfer Value', N'Measurement of the acceptance rate of subjects'' prior learning towards an educational or work preparation activity or resource.', 25, 1, N'metricCat:TransferValue', N'https://credreg.net/qdata/vocabs/metricCat/TransferValue', N'metricCat:Organization', CAST(N'2024-09-14T16:44:29.503' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2960, 105, N'Credential', N'Measurement of the awarding, offering, and value of credentials obtained by subjects in educational or work preparation programs.', 25, 1, N'metricCat:Credential', N'https://credreg.net/qdata/vocabs/metricCat/Credential', N'metricCat:Organization', CAST(N'2024-09-14T16:44:29.527' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2961, 105, N'Credential Awarded', N'Measurement of individual credentials awarded to subjects.', 25, 1, N'metricCat:CredentialAwarded', N'https://credreg.net/qdata/vocabs/metricCat/CredentialAwarded', N'metricCat:Credential', CAST(N'2024-09-14T16:44:29.547' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2962, 105, N'Credential Types Offered', N'Measurement of the types of credential available for award.', 25, 1, N'metricCat:CredentialTypesOffered', N'https://credreg.net/qdata/vocabs/metricCat/CredentialTypesOffered', N'metricCat:Credential', CAST(N'2024-09-14T16:44:29.850' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2963, 105, N'Credential Value', N'Measurement of the value of credentials available or awarded to subjects.', 25, 1, N'metricCat:CredentialValue', N'https://credreg.net/qdata/vocabs/metricCat/CredentialValue', N'metricCat:Credential', CAST(N'2024-09-14T16:44:29.867' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2964, 105, N'Technology and Innovation', N'Measurement of the integration and adoption of technology and innovative practices in educational or work preparation activities or resources.', 25, 1, N'metricCat:TechnologyInnovation', N'https://credreg.net/qdata/vocabs/metricCat/TechnologyInnovation', N'', CAST(N'2024-09-14T16:44:29.887' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2965, 105, N'Use of Technology', N'Measurement of the extent to which educational or work preparation activities or resources integrate technology in their delivery.', 25, 1, N'metricCat:UseOfTechnology', N'https://credreg.net/qdata/vocabs/metricCat/UseOfTechnology', N'metricCat:TechnologyInnovation', CAST(N'2024-09-14T16:44:29.910' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2966, 105, N'Innovation Adoption', N'Measurement of the rate at which new and innovative practices are adopted in educational or work activities or resources.', 25, 1, N'metricCat:InnovationAdoption', N'https://credreg.net/qdata/vocabs/metricCat/InnovationAdoption', N'metricCat:TechnologyInnovation', CAST(N'2024-09-14T16:44:29.930' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2967, 105, N'Job, Industry and Occupation', N'Measurement of employment and earnings in industries or occupational areas.', 25, 1, N'metricCat:JobIndustryOccupation', N'https://credreg.net/qdata/vocabs/metricCat/JobIndustryOccupation', N'', CAST(N'2024-09-14T16:44:29.953' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2968, 105, N'Job Openings', N'Measurement of the number of job openings.', 25, 1, N'metricCat:JobOpenings', N'https://credreg.net/qdata/vocabs/metricCat/JobOpenings', N'metricCat:JobIndustryOccupation', CAST(N'2024-09-14T16:44:29.973' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2969, 105, N'Industry Employment', N'Measurement of the number of subjects employed within an industry.', 25, 1, N'metricCat:IndustryEmployment', N'https://credreg.net/qdata/vocabs/metricCat/IndustryEmployment', N'metricCat:JobIndustryOccupation', CAST(N'2024-09-14T16:44:29.997' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2970, 105, N'Occupation Employment', N'Measurement of the number of subjects employed in an occupational area.', 25, 1, N'metricCat:OccupationEmployment', N'https://credreg.net/qdata/vocabs/metricCat/OccupationEmployment', N'metricCat:JobIndustryOccupation', CAST(N'2024-09-14T16:44:30.020' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2971, 105, N'High Wage Occupation', N'Measurement of the number of subjects employed in a high-wage occupation.', 25, 1, N'metricCat:HighWageOccupation', N'https://credreg.net/qdata/vocabs/metricCat/HighWageOccupation', N'metricCat:JobIndustryOccupation', CAST(N'2024-09-14T16:44:30.040' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2972, 105, N'High-Skill Occupation', N'Measurement of the number of subjects employed in a high-skill occupation.', 25, 1, N'metricCat:HighSkillOccupation', N'https://credreg.net/qdata/vocabs/metricCat/HighSkillOccupation', N'metricCat:JobIndustryOccupation', CAST(N'2024-09-14T16:44:30.063' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2973, 105, N'In-demand Occupation', N'Measurement of the number of subjects employed in a high-demand occupation.', 25, 1, N'metricCat:InDemandOccupation', N'https://credreg.net/qdata/vocabs/metricCat/InDemandOccupation', N'metricCat:JobIndustryOccupation', CAST(N'2024-09-14T16:44:30.083' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2974, 105, N'Industry Growth', N'Measurement of the growth rate of an industry.', 25, 1, N'metricCat:IndustryGrowth', N'https://credreg.net/qdata/vocabs/metricCat/IndustryGrowth', N'metricCat:JobIndustryOccupation', CAST(N'2024-09-14T16:44:30.103' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2975, 105, N'Occupation Growth', N'Measure the growth rate of an occupational area.', 25, 1, N'metricCat:OccupationGrowth', N'https://credreg.net/qdata/vocabs/metricCat/OccupationGrowth', N'metricCat:JobIndustryOccupation', CAST(N'2024-09-14T16:44:30.123' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2976, 105, N'WIOA', N'Measurement of subjects related to Workforce Innovation Opportunity Act services and sponsored education or workforce preparation activity or resource.', 25, 1, N'metricCat:WIOA', N'https://credreg.net/qdata/vocabs/metricCat/WIOA', N'', CAST(N'2024-09-14T16:44:30.143' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2977, 105, N'WIOA Completer', N'Measurement of subjects who completed a WIOA-sponsored education or workforce preparation activity or resource, regardless of whether they were successful or unsuccessful.', 25, 1, N'metricCat:WIOACompleter', N'https://credreg.net/qdata/vocabs/metricCat/WIOACompleter', N'metricCat:WIOA', CAST(N'2024-09-14T16:44:30.163' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2978, 105, N'WIOA Participant', N'Measurement of subjects who have received staff-assisted Workforce Innovation Opportunity Act services.', 25, 1, N'metricCat:WIOAParticipant', N'https://credreg.net/qdata/vocabs/metricCat/WIOAParticipant', N'metricCat:WIOA', CAST(N'2024-09-14T16:44:30.197' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2979, 105, N'WIOA Program Exiter', N'Measurement of subjects who have received WIOA services and have an exit date or have not received any reportable services in the last 90 days.', 25, 1, N'metricCat:WIOAProgramExiter', N'https://credreg.net/qdata/vocabs/metricCat/WIOAProgramExiter', N'metricCat:WIOA', CAST(N'2024-09-14T16:44:30.227' AS DateTime), 0, 0)
GO
INSERT [dbo].[Codes.PropertyValue] ([Id], [CategoryId], [Title], [Description], [SortOrder], [IsActive], [SchemaName], [SchemaUrl], [ParentSchemaName], [Created], [Totals], [IsSubType1]) VALUES (2980, 105, N'WIOA Training Exiter', N'Measures of subjects who either completed or withdrew from a WIOA-sponsored training program, or transferred to a different program.', 25, 1, N'metricCat:WIOATrainingExiter', N'https://credreg.net/qdata/vocabs/metricCat/WIOATrainingExiter', N'metricCat:WIOA', CAST(N'2024-09-14T16:44:30.257' AS DateTime), 0, 0)
GO
SET IDENTITY_INSERT [dbo].[Codes.PropertyValue] OFF
GO

