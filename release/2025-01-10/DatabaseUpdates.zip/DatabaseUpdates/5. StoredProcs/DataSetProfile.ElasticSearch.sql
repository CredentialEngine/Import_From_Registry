USE [credFinder]
GO


--use sandbox_credFinder
--go
--use staging_credFinder
--go
--use flstaging_credFinder	
--go
--use txlibrary_credFinder
--go

/****** Object:  StoredProcedure [dbo].[DataSetProfile.ElasticSearch]    Script Date: 4/20/2018 11:40:06 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
USE [sandbox_credFinder]
GO

SELECT [Id]
      ,[RowId]
      ,[EntityStateId]
      ,[CTID]
      ,[Name]
      ,[Description]
      ,[Source]
      ,[Created]
      ,[LastUpdated]
      ,[CredentialRegistryId]
      ,[DataProviderUID]
      ,[DataSuppressionPolicy]
      ,[SubjectIdentification]
      ,[DistributionFile]
      ,[DataSetTimePeriodJson]
  FROM [dbo].[DataSetProfile]

GO
select top 1000
* 
from DataSetProfileSummary
where credentialid is not null





--=====================================================

DECLARE @RC int,@SortOrder varchar(100),@Filter varchar(5000)
DECLARE @StartPageIndex int, @PageSize int, @TotalRows int
--

set @SortOrder = ''
set @SortOrder = 'base.Name'

--set @Filter = ' ( base.Id in (SELECT  OrgId FROM [DataSetProfile.Member] where UserId = 2) ) '
set @Filter = ' ( base.InternalDSPEntityId is null) '

-- blind search 
set @Filter = ''

set @StartPageIndex = 1
set @PageSize = 55
--set statistics time on       
EXECUTE @RC = [DataSetProfile.ElasticSearch]
     @Filter,@SortOrder  ,@StartPageIndex  ,@PageSize,  @TotalRows OUTPUT

select 'total rows = ' + convert(varchar,@TotalRows)

--set statistics time off       


*/


/* =============================================
Description:      DataSetProfile search
Options:

  @StartPageIndex - starting page number. If interface is at 20 when next
page is requested, this would be set to 21?
  @PageSize - number of records on a page
  @TotalRows OUTPUT - total available rows. Used by interface to build a
custom pager
  ------------------------------------------------------
Modifications
21-05-31 mparsons - new
					- this currently gets all. Should it only get external datasets or make this configurable?

*/

Alter PROCEDURE [dbo].[DataSetProfile.ElasticSearch] 
		@Filter           varchar(5000)
		,@SortOrder       varchar(100)
		,@StartPageIndex  int
		,@PageSize        int
		,@TotalRows       int OUTPUT

As

SET NOCOUNT ON;
-- paging
DECLARE
      @first_id int
      ,@startRow int
	  ,@lastRow int
      ,@debugLevel int
      ,@SQL varchar(5000)
      ,@OrderBy varchar(100)

-- =================================

Set @debugLevel = 4

if @SortOrder = 'relevance' set @SortOrder = 'base.Name '
else if @SortOrder = 'alpha' set @SortOrder = 'base.Name '
else if @SortOrder = 'newest' set @SortOrder = 'base.lastUpdated Desc '
else set @SortOrder = 'base.Name '

if len(@SortOrder) > 0 
      set @OrderBy = ' Order by ' + @SortOrder
else
      set @OrderBy = ' Order by base.Name '

--===================================================
-- Calculate the range
--===================================================
IF @StartPageIndex < 1 SET @StartPageIndex = 1
SET @StartPageIndex =  ((@StartPageIndex - 1)  * @PageSize) + 1
SET @lastRow =  (@StartPageIndex + @PageSize) - 1

-- =================================
CREATE TABLE #tempWorkTable(
	RowNumber         int PRIMARY KEY  NOT NULL,      
	Id int,
	RowId uniqueidentifier,
	Name             varchar(1000),		--name is unlikely
	LastUpdated			datetime,
)
  CREATE TABLE #tempQueryTotalTable(
      TotalRows int
)
--
-- =================================

  if len(@Filter) > 0 begin
     if charindex( 'where', @Filter ) = 0 OR charindex( 'where',  @Filter ) > 10
        set @Filter =     ' where ' + @Filter
     end

  print '@Filter len: '  +  convert(varchar,len(@Filter))

  -- ================================= 
set @SQL = '   SELECT count(*) as TotalRows  FROM [dbo].DataSetProfileSummary base  '  + @Filter 
INSERT INTO #tempQueryTotalTable (TotalRows)
exec (@SQL)
--select * from #tempQueryTotalTable
select top 1  @TotalRows= TotalRows from #tempQueryTotalTable

-- ================================= 
  set @SQL = ' 
  SELECT        
		DerivedTable.RowNumber, 
		base.Id
		,base.RowId
		,base.[Name]
		,base.[lastUpdated]
	From 
	   (
		SELECT 
			 ROW_NUMBER() OVER(' + @OrderBy + ') as RowNumber,
			  base.Id, base.RowId, base.Name, base.lastUpdated
			from [DataSetProfileSummary] base  ' 
			+ @Filter + ' 
	   ) as DerivedTable
       Inner join [dbo].[DataSetProfileSummary] base on DerivedTable.Id = base.Id
WHERE RowNumber BETWEEN ' + convert(varchar,@StartPageIndex) + ' AND ' + convert(varchar,@lastRow) + ' '  

  print '@SQL len: '  +  convert(varchar,len(@SQL))
  print @SQL
  INSERT INTO #tempWorkTable (RowNumber, Id, RowId, Name, LastUpdated)
  exec (@SQL)

--select * from #tempWorkTable
/*
--================================= 
  set @SQL = 'SELECT  base.Id, base.Name from [DataSetProfileSummary] base   '
        + @Filter
        
  if charindex( 'order by', lower(@Filter) ) = 0
    set @SQL = @SQL + ' ' + @OrderBy

  print '@SQL len: '  +  convert(varchar,len(@SQL))
  print @SQL

  INSERT INTO #tempWorkTable (Id, Name)
  exec (@SQL)
  --print 'rows: ' + convert(varchar, @@ROWCOUNT)
  SELECT @TotalRows = @@ROWCOUNT
-- =================================

print 'added to temp table: ' + convert(varchar,@TotalRows)
if @debugLevel > 7 begin
  select * from #tempWorkTable
  end

-- Calculate the range
--===================================================
PRINT '@StartPageIndex = ' + convert(varchar,@StartPageIndex)

SET ROWCOUNT @StartPageIndex
--SELECT @first_id = RowNumber FROM #tempWorkTable   ORDER BY RowNumber
SELECT @first_id = @StartPageIndex
PRINT '@first_id = ' + convert(varchar,@first_id)

if @first_id = 1 set @first_id = 0
--set max to return
SET ROWCOUNT @PageSize
*/
-- ================================= 
SELECT        Distinct
	RowNumber, 
	base.[Id]
	,base.[RowId]
	,base.EntityId
	,base.[EntityStateId]
	,base.[Name]
	,base.[Description]
	,base.Source
	,base.[CTID]
	--
	,base.DataProviderUID
	,base.DataProviderId
	,base.DataProviderName
	,base.DataProviderCTID
	,base.DataSuppressionPolicy
	,base.SubjectIdentification
	,base.DistributionFile
	,e.LastUpdated as EntityLastUpdated
	,base.[Created]
	,base.[LastUpdated]

	,base.EntityLastUpdated
	,base.[DateEffective]
	,base.[PublicationStatusType]
	--not sure can have both, so should only one be returned?
	-- but would want type. would be more flexible to have the CTID
	,base.Credentials as AboutCredentials
	,base.LearningOpportunities as AboutLearningOpportunities

	--,case when Len(ISNULL(base.Credentials,'')) > 4 then base.Credentials
	--	when Len(ISNULL(base.LearningOpportunities,'')) > 4 then base.LearningOpportunities
	--	else '' end as About

	,base.DataSetTimePeriodJson
	-- need to join on Metrics
	,  ( SELECT DISTINCT a.CategoryId, a.[PropertyValueId], a.Property, PropertySchemaName  FROM [dbo].[EntityProperty_Summary] a
	inner join Metric m on a.EntityUid = m.RowId 
	inner join [Entity.HasMetric] ehm on m.Id = ehm.MetricId
	--inner join DataSetProfile dsp on ehm.EntityId
	where EntityTypeId= 48 AND CategoryId IN (105) AND base.EntityId = ehm.EntityId 
	
	FOR XML RAW, ROOT('DataSetProfileProperties')) Properties

	,(SELECT DISTINCT ear.AgentRelativeId As OrgId, ear.AgentName, ear.AgentUrl, ear.EntityStateId, ear.RoleIds as RelationshipTypeIds,  ear.Roles as Relationships, ear.AgentContextRoles FROM [dbo].[Entity.AgentRelationshipIdCSV] ear
	WHERE ear.EntityTypeId= 31 AND ear.EntityBaseId = base.id 
	FOR XML RAW, ROOT('AgentRelationshipsForEntity')) AgentRelationshipsForEntity

	,base.ResourceDetail

From #tempWorkTable work
Inner join DataSetProfileSummary base on work.Id = base.Id
Inner join Entity_Cache e on base.RowId = e.EntityUid


--WHERE RowNumber > @first_id
order by RowNumber 
go

grant execute on [DataSetProfile.ElasticSearch] to public
go
/*
<HasPathways><row PathwayId="186" Pathway="UpSkill! SA Pathway- Skillbooster"/>
<row PathwayId="187" Pathway="UpSkill! SA Pathway- Certificate +"/></HasPathways>

187~UpSkill! SA Pathway- Certificate +|186~UpSkill! SA Pathway- Skillbooster

select        * from DataSetProfileSummary

*/