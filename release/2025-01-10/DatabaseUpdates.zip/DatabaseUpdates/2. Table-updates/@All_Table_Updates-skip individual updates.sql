
--		2025-01-01 - all table updates for this release 

--	24-10-09 dbo.[ConceptScheme.Concept] DROP COLUMN CreatedById, LastUpdatedById


/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[ConceptScheme.Concept]
	DROP COLUMN CreatedById, LastUpdatedById
GO
ALTER TABLE dbo.[ConceptScheme.Concept] SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
Go

--	24-10-11 datasetProfile - add columns

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.DataSetProfile ADD
	AlternateName nvarchar(MAX) NULL,
	DateEffective varchar(50) NULL,
	PublicationStatusType nvarchar(50) NULL,
	License nvarchar(MAX) NULL,
	Rights nvarchar(MAX) NULL
GO
ALTER TABLE dbo.DataSetProfile SET (LOCK_ESCALATION = TABLE)
GO
COMMIT

GO

--	24-10-13 - CompetencyFramework ADD LatestVersion,PreviousVersion,NextVersion 

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.CompetencyFramework ADD
	LatestVersion varchar(500) NULL,
	PreviousVersion varchar(500) NULL,
	NextVersion varchar(500) NULL
GO
ALTER TABLE dbo.CompetencyFramework SET (LOCK_ESCALATION = TABLE)
GO
COMMIT

GO
--	24-10-13 Collection ADD LatestVersion, PreviousVersion, NextVersion

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.Collection ADD
	LatestVersion varchar(500) NULL,
	PreviousVersion varchar(500) NULL,
	NextVersion varchar(500) NULL
GO
ALTER TABLE dbo.Collection SET (LOCK_ESCALATION = TABLE)
GO
COMMIT

GO
--	24-10-19 DataSetTimeFrame ADD AlternateName


/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.DataSetTimeFrame ADD
	AlternateName nvarchar(MAX) NULL
GO
ALTER TABLE dbo.DataSetTimeFrame SET (LOCK_ESCALATION = TABLE)
GO
COMMIT

GO
--	24-11-06 DataSetProfile add PointsSummary

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.DataSetProfile ADD
	PointsSummary nvarchar(MAX) NULL
GO
ALTER TABLE dbo.DataSetProfile SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO


--	 24-11-07 DataSetTimeFrame add TimeFrameType

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.DataSetTimeFrame ADD
	TimeFrameType varchar(50) NULL
GO
ALTER TABLE dbo.DataSetTimeFrame ADD CONSTRAINT
	DF_DataSetTimeFrame_Property DEFAULT 'DSTP' FOR TimeFrameType
GO
ALTER TABLE dbo.DataSetTimeFrame SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
GO


/*
Update DataSetTimeFrame
set TimeFrameType= 'DSTP'

select * from DataSetTimeFrame

*/
GO


-- 24-12-23 Entity.IdentifierValue - increase IdentifierType to 600

/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Entity.IdentifierValue]
	DROP CONSTRAINT [FK_Entity.IdentifierValue_Entity]
GO
ALTER TABLE dbo.Entity SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.[Entity.IdentifierValue]
	DROP CONSTRAINT [DF_Entity.IdentifierValue_IdentityTypeId]
GO
ALTER TABLE dbo.[Entity.IdentifierValue]
	DROP CONSTRAINT [DF_Entity.IdentifierValue_Created]
GO
CREATE TABLE dbo.[Tmp_Entity.IdentifierValue]
	(
	Id int NOT NULL IDENTITY (1, 1),
	EntityId int NOT NULL,
	IdentityValueTypeId int NOT NULL,
	Name nvarchar(500) NULL,
	Description nvarchar(1000) NULL,
	IdentifierType nvarchar(600) NULL,
	IdentifierValueCode nvarchar(1000) NULL,
	Created datetime NOT NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.[Tmp_Entity.IdentifierValue] SET (LOCK_ESCALATION = TABLE)
GO
ALTER TABLE dbo.[Tmp_Entity.IdentifierValue] ADD CONSTRAINT
	[DF_Entity.IdentifierValue_IdentityTypeId] DEFAULT ((1)) FOR IdentityValueTypeId
GO
ALTER TABLE dbo.[Tmp_Entity.IdentifierValue] ADD CONSTRAINT
	[DF_Entity.IdentifierValue_Created] DEFAULT (getdate()) FOR Created
GO
SET IDENTITY_INSERT dbo.[Tmp_Entity.IdentifierValue] ON
GO
IF EXISTS(SELECT * FROM dbo.[Entity.IdentifierValue])
	 EXEC('INSERT INTO dbo.[Tmp_Entity.IdentifierValue] (Id, EntityId, IdentityValueTypeId, Name, Description, IdentifierType, IdentifierValueCode, Created)
		SELECT Id, EntityId, IdentityValueTypeId, Name, Description, IdentifierType, IdentifierValueCode, Created FROM dbo.[Entity.IdentifierValue] WITH (HOLDLOCK TABLOCKX)')
GO
SET IDENTITY_INSERT dbo.[Tmp_Entity.IdentifierValue] OFF
GO
DROP TABLE dbo.[Entity.IdentifierValue]
GO
EXECUTE sp_rename N'dbo.[Tmp_Entity.IdentifierValue]', N'Entity.IdentifierValue', 'OBJECT' 
GO
ALTER TABLE dbo.[Entity.IdentifierValue] ADD CONSTRAINT
	[PK_Entity.IdentifierValue] PRIMARY KEY CLUSTERED 
	(
	Id
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
ALTER TABLE dbo.[Entity.IdentifierValue] ADD CONSTRAINT
	[FK_Entity.IdentifierValue_Entity] FOREIGN KEY
	(
	EntityId
	) REFERENCES dbo.Entity
	(
	Id
	) ON UPDATE  CASCADE 
	 ON DELETE  CASCADE 
	
GO
COMMIT
GO
