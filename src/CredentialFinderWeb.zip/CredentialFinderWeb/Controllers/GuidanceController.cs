﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace workIT.Web.Controllers
{
    public class GuidanceController : Controller
    {
        // GET: Guidance
        public ActionResult Index()
        {
            return View();
        }
    }
}